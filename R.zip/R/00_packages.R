# ============================================================
# Script  : 00_packages.R
#
# Objetivo:
#   Verificar, instalar (se necessário) e carregar os pacotes.
#
# Observação:
#   vars (VAR do script 11) é instalado mas não carregado; as funções
#   são chamadas como vars::VAR, vars::irf etc.
# ============================================================

required_packages <- c(
  "tidyverse",
  "lubridate",
  "here",
  "broom",
  "lmtest",
  "sandwich",
  "urca",
  "ARDL",
  "strucchange",
  "car",
  "quantmod",
  "jsonlite",
  "patchwork",
  "scales",
  "xtable",
  "openxlsx"   # Excel consolidado do 04_descriptive.R
)

installed <- rownames(installed.packages())

for (pkg in required_packages) {
  if (!(pkg %in% installed)) install.packages(pkg)
  suppressPackageStartupMessages(library(pkg, character.only = TRUE))
}

# Pacotes usados com vars::/aod:: (instalados, mas não carregados,
# para não mascarar funções do dplyr)
for (pkg in c("vars")) if (!(pkg %in% installed)) install.packages(pkg)

# rb3 é só a 2ª alternativa para o DI (a 1ª é o download direto da
# B3, no 01_import.R); não precisa estar instalado.

# Evitar conflitos comuns (dplyr x stats/MASS)
select <- dplyr::select
filter <- dplyr::filter
lag    <- dplyr::lag
lead   <- dplyr::lead
