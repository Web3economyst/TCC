# ============================================================
# Script  : 00_functions.R
#
# Objetivo:
#   Funções auxiliares. As primeiras são as mesmas do projeto
#   MEFA; as seguintes são específicas deste trabalho (dados
#   diários empilhados por ciclo eleitoral).
#
# Regra importante:
#   Defasagens e leads são SEMPRE construídos dentro de cada
#   ciclo (group_by(ciclo)). Assim o 1º dia de 2022 nunca recebe
#   como "dia anterior" o último dia de 2018.
# ============================================================

# ------------------------------------------------------------
# 1. Funções herdadas do MEFA
# ------------------------------------------------------------

save_object <- function(object, file) {
  saveRDS(object, file = file)
  message("Objeto salvo em: ", file)
}

load_object <- function(file) readRDS(file)

check_missing <- function(data) colSums(is.na(data))

data_summary <- function(data) {
  list(observations = nrow(data), variables = ncol(data), names = names(data))
}

export_table <- function(data, file) {
  dir.create(dirname(file), recursive = TRUE, showWarnings = FALSE)
  readr::write_csv(data, file)
  message("Tabela exportada para: ", file)
}

# Os gráficos são salvos no diretório e, numa sessão interativa
# (RStudio), também mostrados no painel de gráficos, para conferir
# sem abrir os arquivos. Para só salvar:
#   options(tcc.mostrar_graficos = FALSE)
# Rodando por Rscript (fora do RStudio), só salva. Se o painel for
# pequeno demais para o gráfico, o erro de exibição é ignorado e o
# arquivo continua salvo.
mostrar_graficos <- function() isTRUE(getOption("tcc.mostrar_graficos", interactive()))

save_plot <- function(plot, filename, width = 7, height = 5, dpi = 300) {
  dir.create(dirname(filename), recursive = TRUE, showWarnings = FALSE)
  ggplot2::ggsave(filename = filename, plot = plot, width = width,
                  height = height, dpi = dpi, bg = "white")
  message("Gráfico salvo em: ", filename)
  if (mostrar_graficos()) tryCatch(print(plot), error = function(e)
    message("  (não exibido no painel: ", conditionMessage(e), ")"))
  invisible(plot)
}

save_base_plot <- function(expr, filename, width = 1800, height = 1400, res = 300) {
  ex <- substitute(expr); env <- parent.frame()
  dir.create(dirname(filename), recursive = TRUE, showWarnings = FALSE)
  png(filename, width = width, height = height, res = res)
  tryCatch(eval(ex, env), finally = dev.off())
  message("Gráfico salvo em: ", filename)
  if (mostrar_graficos()) {
    op <- graphics::par(no.readonly = TRUE)
    tryCatch(eval(ex, env), error = function(e)
      message("  (não exibido no painel: ", conditionMessage(e), ")"),
      finally = graphics::par(op))
  }
  invisible(NULL)
}

format_table <- function(data, digits = 3) {
  dplyr::mutate(data, dplyr::across(where(is.numeric), ~ round(.x, digits)))
}

# ------------------------------------------------------------
# 2. Defasagens e leads dentro do ciclo
# ------------------------------------------------------------
#
# x_l1 = valor de x no dia útil anterior (t-1)
# x_f1 = valor de x no dia útil seguinte (t+1)  ("f" de futuro)

add_lags <- function(data, vars, k, group = "ciclo") {
  if (k < 1) return(data)
  if ("data" %in% names(data)) data <- dplyr::arrange(data, dplyr::across(dplyr::all_of(group)), .data[["data"]])
  data <- dplyr::group_by(data, dplyr::across(dplyr::all_of(group)))
  for (v in vars) for (j in seq_len(k)) {
    data[[paste0(v, "_l", j)]] <- NULL
    data <- dplyr::mutate(data, "{v}_l{j}" := dplyr::lag(.data[[v]], j))
  }
  dplyr::ungroup(data)
}

add_leads <- function(data, vars, k, group = "ciclo") {
  if (k < 1) return(data)
  data <- dplyr::group_by(data, dplyr::across(dplyr::all_of(group)))
  for (v in vars) for (j in seq_len(k)) {
    data <- dplyr::mutate(data, "{v}_f{j}" := dplyr::lead(.data[[v]], j))
  }
  dplyr::ungroup(data)
}

# Nomes dos termos de uma estrutura defasagem/lead.
# Ex.: lag_terms("dp_pt", 2) -> "dp_pt_l1" "dp_pt_l2"
lag_terms  <- function(v, k) if (k < 1) character(0) else paste0(v, "_l", seq_len(k))
lead_terms <- function(v, k) if (k < 1) character(0) else paste0(v, "_f", seq_len(k))

# ------------------------------------------------------------
# 3. Erros-padrão Newey-West (HAC)
# ------------------------------------------------------------
#
# Com dados diários, os resíduos podem ter autocorrelação e
# heterocedasticidade; o erro-padrão Newey-West é válido nos dois
# casos. Toda a inferência (p-valores e intervalos de 95%) usa a
# distribuição t com os graus de liberdade do resíduo: tidy_nw,
# sum_nw e ic_t abaixo.

#
# Modelos empilhados (2018, 2022 e 2026 na mesma regressão): as
# autocovariâncias dos escores são calculadas só entre pregões do
# MESMO ciclo. O último pregão de um ciclo nunca entra como
# defasagem do primeiro pregão do ciclo seguinte. As contribuições
# dos ciclos são somadas na matriz de covariância dos coeficientes.
# Mesmo núcleo (Bartlett) e mesma regra automática de defasagens
# (Newey-West, 1994) do pacote sandwich, com as somas restritas ao
# ciclo. Modelos de um ciclo só usam o sandwich::NeweyWest comum.

# Ciclo de cada observação do modelo (NULL se o modelo tem um ciclo só)
ciclo_do_modelo <- function(model) {
  mf <- stats::model.frame(model)
  v <- intersect(c("factor(ciclo)", "ciclo_f", "ciclo"), names(mf))
  if (!length(v)) return(NULL)
  g <- as.character(mf[[v[1]]])
  if (length(unique(g)) < 2) NULL else g
}

# Newey-West com as defasagens restritas aos blocos de g
vcov_nw_blocos <- function(model, g, lag = NULL) {
  u <- sandwich::estfun(model)[, , drop = FALSE]
  n <- nrow(u)
  stopifnot(length(g) == n)
  blocos <- split(seq_len(n), factor(g, unique(g)))
  # Soma, dentro de cada bloco, de a_t' a_{t+j}
  cruz <- function(a, j) {
    out <- matrix(0, ncol(a), ncol(a))
    for (i in blocos) {
      m <- length(i)
      if (m > j) out <- out + crossprod(a[i[1:(m - j)], , drop = FALSE], a[i[(j + 1):m], , drop = FALSE])
    }
    out
  }
  if (is.null(lag)) {
    pesos <- rep(1, ncol(u))
    pesos[colnames(u) == "(Intercept)"] <- 0
    hw <- u %*% pesos
    m <- floor(4 * (n / 100)^(2 / 9))
    sigma <- c(sum(hw^2), vapply(seq_len(m), function(j) cruz(hw, j)[1, 1], numeric(1))) / n
    s0 <- sigma[1] + 2 * sum(sigma[-1])
    s1 <- 2 * sum(seq_len(m) * sigma[-1])
    lag <- floor(1.1447 * ((s1 / s0)^2)^(1 / 3) * n^(1 / 3))
  }
  w <- seq(1, 0, by = -(1 / (lag + 1)))
  utu <- 0.5 * crossprod(u) * w[1]
  for (j in seq_len(lag)) utu <- utu + w[j + 1] * cruz(u, j)
  utu <- utu + t(utu)
  V <- sandwich::sandwich(model, meat. = utu / n)
  attr(V, "nw_lag") <- lag
  V
}

# lag: número de defasagens do Newey-West. NULL = regra automática.
# O padrão é o nw_lag do 00_config.R; quem quer outro valor passa
# lag = ... na chamada (robustez R10), sem mexer em variável global.
# O número efetivamente usado fica no atributo "nw_lag" da matriz
# (nw_lag_usado(V)).
vcov_nw <- function(model, lag = nw_lag) {
  g <- ciclo_do_modelo(model)
  if (!is.null(g)) return(vcov_nw_blocos(model, g, lag = lag))
  if (is.null(lag)) lag <- floor(sandwich::bwNeweyWest(model, prewhite = FALSE))
  V <- sandwich::NeweyWest(model, lag = lag, prewhite = FALSE)
  attr(V, "nw_lag") <- lag
  V
}

nw_lag_usado <- function(V) attr(V, "nw_lag") %||% NA_real_

tidy_nw <- function(model, conf_level = 0.95, lag = nw_lag) {
  ct <- lmtest::coeftest(model, vcov. = vcov_nw(model, lag = lag))
  tc <- qt(1 - (1 - conf_level) / 2, df = df.residual(model))
  tibble::tibble(
    term      = rownames(ct),
    estimate  = ct[, 1],
    std.error = ct[, 2],
    statistic = ct[, 3],
    p.value   = ct[, 4],
    conf.low  = ct[, 1] - tc * ct[, 2],
    conf.high = ct[, 1] + tc * ct[, 2]
  )
}

# Teste de Wald conjunto (H0: todos os termos = 0) com vcov NW
wald_nw <- function(model, terms, lag = nw_lag) {
  terms <- intersect(terms, names(coef(model)))
  if (length(terms) == 0) {
    return(tibble::tibble(n_terms = 0, F = NA_real_, df1 = NA_real_, p_value = NA_real_))
  }
  h <- car::linearHypothesis(model, paste0(terms, " = 0"),
                             vcov. = vcov_nw(model, lag = lag), test = "F")
  tibble::tibble(n_terms = length(terms), F = h$F[2], df1 = h$Df[2],
                 p_value = h$`Pr(>F)`[2])
}

# Valor crítico t para o intervalo de confiança
ic_t <- function(model, conf_level = 0.95) qt(1 - (1 - conf_level) / 2, df = df.residual(model))

# Coeficientes de inclinação: todos, menos o intercepto e os efeitos
# fixos de ciclo
termos_inclinacao <- function(model) {
  nm <- names(coef(model))[!is.na(coef(model))]
  nm[nm != "(Intercept)" & !grepl("^factor\\(ciclo\\)|^ciclo_f", nm)]
}

# Teste global: H0 = todos os coeficientes de inclinação são zero
# (o intercepto e os efeitos fixos de ciclo ficam fora da hipótese).
#   F clássico : matriz de covariância do MQO; só descritivo.
#   Wald NW    : matriz Newey-West do vcov_nw(), que na amostra
#                empilhada não cruza a fronteira entre os ciclos.
# É um teste do conjunto dos regressores (ΔP(PT) e controles). Não
# substitui o teste individual do coeficiente de ΔP(PT): o conjunto
# pode ser significativo só por causa dos controles.
teste_global <- function(model, lag = nw_lag) {
  termos <- termos_inclinacao(model)
  h0 <- paste0(termos, " = 0")
  V <- vcov_nw(model, lag = lag)
  cl <- car::linearHypothesis(model, h0, test = "F")
  nw <- car::linearHypothesis(model, h0, vcov. = V, test = "F")
  tibble::tibble(n = nobs(model), gl1 = length(termos), gl2 = df.residual(model),
                 f_classico = cl$F[2], p_classico = cl$`Pr(>F)`[2],
                 f_wald_nw = nw$F[2], p_wald_nw = nw$`Pr(>F)`[2],
                 nw_lag = nw_lag_usado(V))
}

# Soma de coeficientes e seu erro-padrão NW (efeito acumulado)
sum_nw <- function(model, terms, conf_level = 0.95, lag = nw_lag) {
  terms <- intersect(terms, names(coef(model)))
  if (length(terms) == 0) {
    return(tibble::tibble(soma = NA_real_, ep = NA_real_, p_value = NA_real_,
                          conf.low = NA_real_, conf.high = NA_real_))
  }
  b <- coef(model)[terms]
  V <- vcov_nw(model, lag = lag)[terms, terms, drop = FALSE]
  s <- sum(b); ep <- sqrt(sum(V)); gl <- df.residual(model); tc <- ic_t(model, conf_level)
  tibble::tibble(soma = s, ep = ep, p_value = 2 * pt(-abs(s / ep), df = gl),
                 conf.low = s - tc * ep, conf.high = s + tc * ep)
}

# ------------------------------------------------------------
# 4. Curva de juros: interpolação flat-forward (convenção B3)
# ------------------------------------------------------------
#
# Fator de capitalização F(du) = (1 + r)^(du/252). A convenção
# flat-forward interpola log F linearmente em dias úteis entre
# dois vértices. Retorna a taxa (decimal, base 252) no vértice
# 'alvo'.

# Horário de fechamento do pregão regular de ações da B3 (Brasília)
# em cada data: 17h com horário de verão nos EUA, 18h sem ele, ou o
# número fixado em hora_corte_b3 (00_config.R).
hora_fechamento_b3 <- function(datas) {
  if (is.numeric(hora_corte_b3)) return(rep(hora_corte_b3, length(datas)))
  meio_dia_ny <- as.POSIXct(paste(as.Date(datas), "12:00:00"), tz = "America/New_York")
  ifelse(lubridate::dst(meio_dia_ny), 17, 18)
}

interp_flat_forward <- function(du, r, alvo) {
  ok <- is.finite(du) & is.finite(r) & du > 0
  du <- du[ok]; r <- r[ok]
  if (length(du) < 2 || alvo < min(du) || alvo > max(du)) return(NA_real_)
  o <- order(du); du <- du[o]; r <- r[o]
  logF <- log1p(r) * du / 252
  logF_alvo <- approx(du, logF, xout = alvo, ties = "ordered")$y
  exp(logF_alvo * 252 / alvo) - 1
}

# ------------------------------------------------------------
# 5. Correlação cruzada dentro do ciclo
# ------------------------------------------------------------
#
# Para k = -K..K calcula corr(y_t, x_{t+k}):
#   k > 0 : x no FUTURO  -> y se mexe ANTES de x
#   k = 0 : mesmo dia
#   k < 0 : x no PASSADO -> y reage DEPOIS de x
# Banda aproximada de 95% sob H0 de correlação zero: ±1,96/√n.

ccf_within <- function(data, x, y, max_lag = 10, group = "ciclo") {
  purrr::map_dfr(-max_lag:max_lag, function(k) {
    d <- data |>
      dplyr::group_by(dplyr::across(dplyr::all_of(group))) |>
      dplyr::mutate(x_k = if (k >= 0) dplyr::lead(.data[[x]], k) else dplyr::lag(.data[[x]], -k)) |>
      dplyr::ungroup()
    ok <- is.finite(d[[y]]) & is.finite(d$x_k)
    n  <- sum(ok)
    tibble::tibble(k = k, n = n,
                   cor = if (n > 3) cor(d[[y]][ok], d$x_k[ok]) else NA_real_,
                   banda = 1.96 / sqrt(n))
  })
}

# Pré-branqueamento (Box e Jenkins) para a correlação cruzada.
# A banda ±1,96/√n supõe que ao menos uma das séries é ruído branco;
# com autocorrelação nas duas, ela fica estreita demais e aparecem
# picos espúrios. Dentro de cada ciclo, ajusta-se um AR(p) a x por
# MQO (p de 0 a p_max, escolhido pelo BIC) e aplica-se o MESMO filtro
# a x e a y. Com x filtrado próximo de ruído branco, a banda volta a
# ser válida (Bartlett), mesmo que y tenha autocorrelação.
# Valores NA (noites eleitorais) são mantidos: o filtro só usa
# pregões vizinhos dentro do ciclo.
prewhiten_within <- function(data, x, y, p_max = 5, group = "ciclo") {
  data |>
    dplyr::group_by(dplyr::across(dplyr::all_of(group))) |>
    dplyr::group_modify(function(d, key) {
      X <- sapply(0:p_max, function(j) dplyr::lag(d[[x]], j))   # coluna 1 = x_t
      ok <- stats::complete.cases(X)
      ajusta <- function(p) if (p == 0) lm(X[ok, 1] ~ 1) else lm(X[ok, 1] ~ X[ok, 2:(p + 1), drop = FALSE])
      p <- which.min(sapply(0:p_max, function(p) stats::BIC(ajusta(p)))) - 1
      phi <- if (p == 0) numeric(0) else unname(coef(ajusta(p))[-1])
      filtra <- function(z) {
        out <- z
        for (j in seq_len(p)) out <- out - phi[j] * dplyr::lag(z, j)
        out
      }
      d[[x]] <- filtra(d[[x]]); d[[y]] <- filtra(d[[y]])
      d$ordem_ar <- p
      d
    }) |>
    dplyr::ungroup()
}

# ------------------------------------------------------------
# 6. Granger dentro do ciclo (com NW e efeito fixo de ciclo)
# ------------------------------------------------------------
#
# Modelo irrestrito:
#   efeito_t = a_ciclo + sum_{j=1..L} b_j efeito_{t-j}
#                      + sum_{j=1..L} c_j causa_{t-j} + controles_t + e_t
# H0: c_1 = ... = c_L = 0  ("causa" não ajuda a prever "efeito").

granger_within <- function(data, cause, effect, L, controls = NULL, fe = TRUE) {
  d <- add_lags(data, c(cause, effect), L)
  rhs <- c(lag_terms(effect, L), lag_terms(cause, L), controls)
  if (fe && dplyr::n_distinct(d$ciclo) > 1) rhs <- c(rhs, "factor(ciclo)")
  f <- stats::as.formula(paste(effect, "~", paste(rhs, collapse = " + ")))
  m <- lm(f, data = d)
  if (nobs(m) < 30) {   # amostra pequena demais (ex.: pesquisas em 2018)
    return(tibble::tibble(causa = cause, efeito = effect, L = L, n = nobs(m),
                          F = NA_real_, p_value = NA_real_))
  }
  w <- wald_nw(m, lag_terms(cause, L))
  tibble::tibble(causa = cause, efeito = effect, L = L, n = nobs(m),
                 F = w$F, p_value = w$p_value)
}

# ------------------------------------------------------------
# 7. ARDL (uma variável endógena; só valores contemporâneos e passados)
# ------------------------------------------------------------
#
#   y_t = a_ciclo + sum_{i=1..p} phi_i y_{t-i}
#       + sum_{j=0..q} theta_j x_{t-j} + controles_t + e_t
#
#   Sentido "probabilidade -> ativo" (y = ativo, x = ΔP):
#     j = 0      -> reação (P medida no fechamento da B3; se for
#                   medida depois dele, t-1 também é reação: ver
#                   resolver_reacao)
#     j >= 1     -> antecedência (a probabilidade ajuda a prever o
#                   ativo dias depois)
#
#   Sentido inverso, "ativo -> probabilidade" (y = ΔP, x = ativo):
#     j >= 1     -> retroalimentação (o ativo de dias anteriores ajuda
#                   a prever a mudança de expectativa)
#
#   O ARDL não tem leads. Para tratar as duas direções ao mesmo tempo,
#   com todas as variáveis endógenas, usa-se o VAR (script 11).
#
# (Os nomes das funções mantêm "leadlag" por compatibilidade; com
#  n_leads = 0 elas estimam um ARDL comum.)

formula_leadlag <- function(y, x, p, q, m = 0, controls = NULL, extra = NULL, fe = TRUE) {
  rhs <- c(lag_terms(y, p), lead_terms(x, m), x, lag_terms(x, q), controls, extra)
  if (fe) rhs <- c(rhs, "factor(ciclo)")
  stats::as.formula(paste(y, "~", paste(rhs, collapse = " + ")))
}

prepare_leadlag <- function(data, y, x, p, q, m = 0, controls = NULL) {
  d <- data |>
    add_lags(y, p) |>
    add_lags(x, q) |>
    add_leads(x, m)
  tidyr::drop_na(d, dplyr::all_of(c(y, x, lag_terms(y, p), lag_terms(x, q),
                                    lead_terms(x, m), controls)))
}

`%||%` <- function(a, b) if (is.null(a)) b else a

# Seleção de p (defasagens de y) e q (defasagens de x) por BIC,
# sempre na MESMA amostra (a do maior p e q), para que os BICs
# sejam comparáveis. Mesma lógica do auto_ardl do MEFA.
# O tamanho dessa amostra fica em n_selecao.
select_pq_bic <- function(data, y, x, max_p, max_q, controls = NULL, trim_m = 0,
                          criterion = c("BIC", "AIC"), min_q = 1) {
  criterion <- match.arg(criterion)
  fe <- dplyr::n_distinct(data$ciclo) > 1
  d  <- prepare_leadlag(data, y, x, max_p, max_q, 0, controls)
  grid <- tidyr::expand_grid(p = 0:max_p, q = min_q:max_q)
  grid$ic <- purrr::map2_dbl(grid$p, grid$q, function(p, q) {
    mod <- lm(formula_leadlag(y, x, p, q, 0, controls, fe = fe), data = d)
    if (criterion == "BIC") BIC(mod) else AIC(mod)
  })
  grid$n_selecao <- nrow(d)
  grid |> dplyr::arrange(ic)
}

# Perfil temporal: soma dos coeficientes de x em cada bloco de
# defasagens, com EP e Wald conjunto (Newey-West)
# Defasagem que fecha o bloco de reação (ver defasagem_reacao no
# 00_config.R). Os scripts 09 e 10 gravam o valor em
# options(tcc.defasagem_reacao = ...) a partir de
# resolver_reacao(model_data); sem isso, vale 1 (t e t-1). (Uma opção
# do R, e não uma variável, porque o run_all roda cada script num
# ambiente separado.)
resolver_reacao <- function(md) {
  if (is.numeric(defasagem_reacao)) return(as.integer(defasagem_reacao))
  if ("horario_p" %in% names(md) && all(md$horario_p == "fechamento_b3", na.rm = TRUE)) 0L else 1L
}
r_reacao <- function() getOption("tcc.defasagem_reacao", 1L)

rotulos_blocos <- function(r = r_reacao()) {
  c(mesmo_dia    = "mesmo dia (t)",
    reacao       = if (r == 0) "reação (t)" else if (r == 1) "reação (t e t-1)" else paste0("reação (t a t-", r, ")"),
    defasado_1   = "defasado (t-1 em diante)",
    antecedencia = paste0("antecedência (t-", r + 1, " em diante)"),
    total        = "total (t e defasagens)")
}

profile_leadlag <- function(model, x, q, m = 0, r = r_reacao(), lag = nw_lag) {
  rot <- rotulos_blocos(r)
  tibble::tibble(
    chave = names(rot),
    bloco = unname(rot),
    termos = list(x, c(x, lag_terms(x, min(r, q))),
                  lag_terms(x, q), setdiff(lag_terms(x, q), lag_terms(x, r)),
                  c(x, lag_terms(x, q)))
  ) |>
    dplyr::mutate(res = purrr::map(termos, ~ sum_nw(model, .x, lag = lag)),
                  wald = purrr::map(termos, ~ wald_nw(model, .x, lag = lag))) |>
    dplyr::mutate(
      termos   = purrr::map_chr(termos, ~ paste(.x, collapse = ", ")),
      soma     = purrr::map_dbl(res, "soma"),
      ep       = purrr::map_dbl(res, "ep"),
      p_soma   = purrr::map_dbl(res, "p_value"),
      F_wald   = purrr::map_dbl(wald, "F"),
      p_wald   = purrr::map_dbl(wald, "p_value")
    ) |>
    dplyr::select(-res, -wald)
}

# Posição temporal de um termo: x -> 0; x_l2 -> 2
term_j <- function(term, x) {
  out <- rep(NA_integer_, length(term)); out[term == x] <- 0L
  f <- grepl("_f\\d+$", term); out[f] <- -as.integer(sub(".*_f", "", term[f]))
  l <- grepl("_l\\d+$", term); out[l] <- as.integer(sub(".*_l", "", term[l]))
  out
}

# ------------------------------------------------------------
# 7b. Bloco completo do ARDL (usado no 09 e no 10)
# ------------------------------------------------------------
# extra: regressores adicionais (nomes de colunas), ex. dummies ou a
#        probabilidade das pesquisas; o Wald conjunto deles sai em
#        $wald_extra.
# r    : defasagem que fecha o bloco de reação no perfil (0 = só t;
#        1 = t e t-1). Padrão: a do modelo principal (r_reacao()).
#
# Duas etapas, com amostras diferentes e registradas:
#   1. Seleção de p e q por BIC na amostra comum a todas as ordens
#      testadas (perde os primeiros max(max_lag_y, max_lag_dp)
#      pregões de cada ciclo). Tamanho em ajuste$n_selecao.
#   2. Estimação da ordem escolhida na maior amostra que ela
#      permite (mesma amostra do 06). Tamanho em ajuste$n.
# Quando p e q são informados, não há seleção e n_selecao fica NA.
# lag_nw: defasagens do Newey-West em toda a inferência do bloco
#        (NULL = automática). O número usado sai em ajuste$nw_lag.
rodar_leadlag <- function(d, y, x, rotulo, p = NULL, q = NULL, m = 0,
                          ctrl = controles, extra = NULL, criterion = "BIC",
                          r = r_reacao(), lag_nw = nw_lag) {
  fe <- dplyr::n_distinct(d$ciclo) > 1
  if (is.null(p) || is.null(q)) {
    sel <- select_pq_bic(d, y, x, max_lag_y, max_lag_dp, c(ctrl, extra),
                         criterion = criterion, min_q = min_lag_dp)
    p <- sel$p[1]; q <- sel$q[1]
  } else sel <- NULL
  dd <- prepare_leadlag(d, y, x, max(p, 1), max(q, 1), 0, c(ctrl, extra))
  modelo <- lm(formula_leadlag(y, x, p, q, 0, ctrl, extra, fe), data = dd)

  # Multiplicador de longo prazo: Σθ / (1 − Σφ), com EP pelo método delta (NW)
  lr <- tryCatch({
    num <- paste(c(x, lag_terms(x, q)), collapse = " + ")
    den <- if (p > 0) paste0("(1 - (", paste(lag_terms(y, p), collapse = " + "), "))") else "1"
    dm <- car::deltaMethod(modelo, paste0("(", num, ")/", den), vcov. = vcov_nw(modelo, lag = lag_nw))
    tibble::tibble(lr = dm$Estimate, lr_ep = dm$SE,
                   lr_p = 2 * pt(-abs(dm$Estimate / dm$SE), df = df.residual(modelo)))
  }, error = function(e) tibble::tibble(lr = NA_real_, lr_ep = NA_real_, lr_p = NA_real_))

  list(
    rotulo = rotulo, y = y, x = x, p = p, q = q, selecao = sel,
    modelo = modelo,
    com_leads = modelo,                     # nome antigo, mantido por compatibilidade
    wald_extra = if (length(extra)) wald_nw(modelo, extra, lag = lag_nw) else NULL,
    amostra_usada = dd |> dplyr::select(ciclo, data),
    perfil = profile_leadlag(modelo, x, q, r = r, lag = lag_nw),
    coefs = tidy_nw(modelo, lag = lag_nw) |>
      dplyr::filter(term %in% c(x, lag_terms(x, q))) |>
      dplyr::mutate(j = term_j(term, x)),
    lr = lr,
    ajuste = tibble::tibble(
      n = nobs(modelo),
      n_selecao = if (is.null(sel)) NA_integer_ else as.integer(sel$n_selecao[1]),
      nw_lag = nw_lag_usado(vcov_nw(modelo, lag = lag_nw)),
      bic = BIC(modelo),
      adj_r2 = summary(modelo)$adj.r.squared
    )
  )
}

# Tabelas a partir de uma lista de resultados
tabelas_leadlag <- function(res) {
  list(
    ordens = purrr::map_dfr(res, ~ tibble::tibble(amostra = .x$rotulo, y = .x$y, x = .x$x,
                                                  p = .x$p, q = .x$q) |>
                              dplyr::bind_cols(.x$ajuste, .x$lr)),
    perfil = purrr::map_dfr(res, ~ .x$perfil |> dplyr::mutate(amostra = .x$rotulo, y = .x$y,
                                                              x = .x$x, .before = 1)),
    coefs = purrr::map_dfr(res, ~ .x$coefs |> dplyr::mutate(amostra = .x$rotulo, y = .x$y,
                                                            x = .x$x, .before = 1))
  )
}

# ------------------------------------------------------------
# 7c. Amostra contínua para os pacotes de série temporal
# ------------------------------------------------------------
# vars::VAR e ARDL::auto_ardl criam as defasagens pela posição da
# linha. Se uma linha do meio do ciclo é retirada por ter NA, o
# pregão anterior a ela vira "defasagem 1" do pregão seguinte.
# Esta função recebe os pregões de UM ciclo, confere as linhas
# completas contra o calendário do ciclo e:
#   - sem lacuna interna: devolve todas as linhas completas
#     (NA só no começo ou no fim não é lacuna);
#   - com lacuna interna: devolve o MAIOR trecho contínuo de
#     pregões completos e avisa.
# Atributos: "lacunas" (pregões incompletos no meio da amostra),
# "disponiveis" (pregões completos do ciclo), "descartadas"
# (pregões completos fora do trecho usado) e "perda_pct".
# perdas_amostra(out) devolve esses números em uma linha, para as
# tabelas de cada modelo.
amostra_continua <- function(d, vars, rotulo = "") {
  d <- dplyr::arrange(d, data)
  ok <- stats::complete.cases(d[vars])
  if (!any(ok)) {
    out <- d[0, ]; attr(out, "lacunas") <- 0L; attr(out, "disponiveis") <- 0L
    attr(out, "descartadas") <- 0L; attr(out, "perda_pct") <- NA_real_
    return(out)
  }
  faixa <- min(which(ok)):max(which(ok))
  lacunas <- sum(!ok[faixa])
  trechos <- rle(ok); fim <- cumsum(trechos$lengths); ini <- fim - trechos$lengths + 1
  k <- which(trechos$values)[which.max(trechos$lengths[trechos$values])]
  out <- d[ini[k]:fim[k], ]
  descartadas <- sum(ok) - nrow(out)
  if (lacunas > 0)
    warning(rotulo, ": ", lacunas, " pregão(ões) incompleto(s) no meio da amostra (",
            paste(format(d$data[faixa][!ok[faixa]]), collapse = ", "),
            "). Usado o maior trecho contínuo: ", format(min(out$data)), " a ", format(max(out$data)),
            " (", nrow(out), " pregões; ", descartadas, " completos ficaram fora).", call. = FALSE)
  attr(out, "lacunas") <- as.integer(lacunas); attr(out, "disponiveis") <- as.integer(sum(ok))
  attr(out, "descartadas") <- as.integer(descartadas); attr(out, "perda_pct") <- 100 * descartadas / sum(ok)
  out
}

perdas_amostra <- function(out) {
  tibble::tibble(obs_disponiveis = attr(out, "disponiveis"), obs_usadas = nrow(out),
                 obs_descartadas = attr(out, "descartadas"), perda_pct = attr(out, "perda_pct"),
                 lacunas = attr(out, "lacunas"))
}

# ------------------------------------------------------------
# 7d. Diagnósticos de resíduos usados em mais de um script
# ------------------------------------------------------------

# Breusch-Godfrey com o resíduo defasado DENTRO do grupo (ciclo).
# Regressão auxiliar do resíduo sobre os regressores e as
# defasagens do resíduo; LM = n·R² ~ qui-quadrado(ordem).
# H0: ausência de autocorrelação até a ordem testada.
bg_ciclo <- function(m, ciclo_obs, ordem = 1) {
  e <- residuals(m)
  X <- model.matrix(m)[, -1, drop = FALSE]
  E <- sapply(seq_len(ordem), function(j) ave(e, ciclo_obs, FUN = function(z) dplyr::lag(z, j)))
  E <- matrix(E, ncol = ordem)
  ok <- stats::complete.cases(E)
  aux <- lm(e[ok] ~ X[ok, , drop = FALSE] + E[ok, , drop = FALSE])
  lm_stat <- sum(ok) * summary(aux)$r.squared
  tibble::tibble(ordem = ordem, n = sum(ok), lm = lm_stat,
                 p_value = pchisq(lm_stat, df = ordem, lower.tail = FALSE))
}

# Ljung-Box DENTRO de cada ciclo. Os ciclos são blocos separados
# (anos de distância), então o teste é feito em cada um e, para a
# amostra empilhada, as estatísticas Q são somadas: blocos
# independentes, gl = soma dos gl de cada ciclo.
# H0: autocorrelações dos resíduos iguais a zero até a defasagem h.
# h é limitado a n/4 em cada ciclo (Box e Jenkins).
# fitdf: graus de liberdade descontados (0 com regressores exógenos;
# 1, aproximado, quando o modelo tem y defasado).
# quadrado = TRUE aplica o teste a e², que detecta agrupamento de
# volatilidade (McLeod-Li).
lb_ciclo <- function(e, ciclo_obs, h, fitdf = 0, quadrado = FALSE) {
  if (quadrado) e <- e^2
  por_ciclo <- purrr::map_dfr(split(e, ciclo_obs), function(z) {
    z <- z[is.finite(z)]; n <- length(z)
    hh <- min(h, floor(n / 4))
    if (hh <= fitdf) return(tibble::tibble(n = n, h_usado = hh, Q = NA_real_, gl = NA_real_, p_value = NA_real_))
    t <- stats::Box.test(z, lag = hh, type = "Ljung-Box", fitdf = fitdf)
    tibble::tibble(n = n, h_usado = hh, Q = unname(t$statistic), gl = unname(t$parameter), p_value = t$p.value)
  }, .id = "ciclo")
  ok <- is.finite(por_ciclo$Q)
  conjunto <- tibble::tibble(ciclo = "conjunto", n = sum(por_ciclo$n), h_usado = NA_real_,
                             Q = sum(por_ciclo$Q[ok]), gl = sum(por_ciclo$gl[ok]),
                             p_value = pchisq(sum(por_ciclo$Q[ok]), sum(por_ciclo$gl[ok]), lower.tail = FALSE))
  dplyr::bind_rows(por_ciclo, conjunto)
}

# Perfil do Ljung-Box: o teste é refeito para cada h de 1 a h_max.
# Cada ponto testa H0: ρ1 = ... = ρh = 0 (todas as autocorrelações
# até h, de forma acumulada). Em cada ciclo, h é limitado a n/4;
# a coluna limitado marca os h em que o ciclo já atingiu esse teto.
lb_perfil <- function(e, ciclo_obs, h_max = 60, fitdf = 0, quadrado = FALSE) {
  purrr::map_dfr(seq_len(h_max), function(hh) {
    lb_ciclo(e, ciclo_obs, hh, fitdf = fitdf, quadrado = quadrado) |>
      dplyr::mutate(h = hh, .before = 1)
  }) |>
    dplyr::mutate(limitado = ciclo != "conjunto" & h_usado < h)
}

# RESET de Ramsey, clássico (F do MQO) e HAC (Wald com Newey-West na
# mesma regressão auxiliar, com ŷ² e ŷ³). H0: os dois termos não
# acrescentam explicação. m: modelo; d: as linhas da base usadas em
# m, na mesma ordem.
reset_um <- function(m, d) {
  t <- tryCatch(lmtest::resettest(m, power = 2:3, type = "fitted"), error = function(e) NULL)
  classico <- if (is.null(t)) tibble::tibble(f_reset = NA_real_, gl1 = NA_real_, gl2 = NA_real_, p_reset = NA_real_) else
    tibble::tibble(f_reset = unname(t$statistic), gl1 = unname(t$parameter[1]),
                   gl2 = unname(t$parameter[2]), p_reset = t$p.value)
  hac <- tryCatch({
    stopifnot(nrow(d) == nobs(m))
    z <- fitted(m) / stats::sd(fitted(m))
    d$reset_yhat2 <- z^2; d$reset_yhat3 <- z^3
    aux <- lm(stats::update(formula(m), . ~ . + reset_yhat2 + reset_yhat3), data = d)
    if (anyNA(coef(aux))) stop("termos do RESET não identificados")
    w <- wald_nw(aux, c("reset_yhat2", "reset_yhat3"))
    tibble::tibble(f_reset_hac = w$F, p_reset_hac = w$p_value)
  }, error = function(e) tibble::tibble(f_reset_hac = NA_real_, p_reset_hac = NA_real_))
  dplyr::bind_cols(classico, hac)
}

# ------------------------------------------------------------
# 8. Criar diretório
# ------------------------------------------------------------

create_directory <- function(path) {
  if (!dir.exists(path)) dir.create(path, recursive = TRUE)
}

# ------------------------------------------------------------
# 9. Aviso de dados simulados
# ------------------------------------------------------------
# Os testes do pipeline foram feitos com séries financeiras
# simuladas. Se por engano essa base estiver em data/raw, todo
# script avisa.

aviso_simulado <- function(obj) {
  if (isTRUE(attr(obj, "simulado"))) {
    warning("ATENÇÃO: a base financeira é SIMULADA (só para teste do código). ",
            "Rode o 01_import.R com internet para baixar os dados reais.",
            call. = FALSE)
  }
}

# ------------------------------------------------------------
# Decomposição de Shapley (LMG) do R²
# ------------------------------------------------------------
# Reparte o R² de um modelo MQO entre grupos de regressores. A
# parcela de cada grupo é o ganho médio de R² ao incluí-lo, tomado
# sobre todas as ordens possíveis de entrada dos grupos; as parcelas
# somam o R² do modelo completo (Grömping, 2007).
#
#   grupos: lista nomeada; cada elemento traz os termos do grupo,
#           como entram na fórmula. Ex.:
#           list(dp = "dp_pt", controles = c("r_spx", "d_ust10", "r_vix"),
#                ciclo = "factor(ciclo)")
#   Devolve um vetor nomeado com a parcela de cada grupo (escala 0-1).

shapley_r2 <- function(d, y, grupos) {
  nomes <- names(grupos); k <- length(nomes)
  memo <- new.env()
  r2_de <- function(s) {
    chave <- paste(sort(s), collapse = "+")
    if (chave == "") return(0)
    if (is.null(memo[[chave]]))
      memo[[chave]] <- summary(lm(stats::reformulate(unlist(grupos[s]), y), data = d))$r.squared
    memo[[chave]]
  }
  subconjuntos <- function(x, i) if (i == 0) list(character(0)) else utils::combn(x, i, simplify = FALSE)
  vapply(nomes, function(g) {
    outros <- setdiff(nomes, g); total <- 0
    for (i in 0:(k - 1)) for (s in subconjuntos(outros, i)) {
      peso <- factorial(i) * factorial(k - i - 1) / factorial(k)
      total <- total + peso * (r2_de(c(s, g)) - r2_de(s))
    }
    total
  }, numeric(1))
}
