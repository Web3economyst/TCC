# ============================================================
# Script  : 10e_favorito_azarao.R
#
# Objetivo:
#   Robustez do modelo E à correção do viés favorito-azarão.
#   A probabilidade do mercado é recalibrada como em Rothschild (2009):
#     p_corr = pnorm(a * qnorm(p))
#   com a = 1,64 (Leigh, Wolfers e Zitzewitz, 2007, apud Rothschild)
#   e a = 2,72 (valor que Rothschild encontra para a Intrade em 2008).
#   O modelo E é reestimado com a variação da probabilidade corrigida,
#   na mesma amostra do modelo E do 06_models (711 / 709 pregões).
#
# Saída: output/10e_saida/favorito_azarao.csv
# ============================================================

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

saida_dir <- saida("10e")
model_data <- load_object(model_data_file)

calibrar <- function(p, a) {
  p <- pmin(pmax(p, 0.001), 0.999)   # evita qnorm(0) e qnorm(1)
  pnorm(a * qnorm(p))
}

d <- model_data |>
  dplyr::arrange(ciclo, data) |>
  dplyr::group_by(ciclo) |>
  dplyr::mutate(
    dp_fa164 = 100 * (calibrar(p_pt, 1.64) - dplyr::lag(calibrar(p_pt, 1.64))),
    dp_fa272 = 100 * (calibrar(p_pt, 2.72) - dplyr::lag(calibrar(p_pt, 2.72)))
  ) |>
  dplyr::ungroup() |>
  # mesma amostra do modelo E: só onde a variação original existe
  dplyr::mutate(dplyr::across(c(dp_fa164, dp_fa272), ~ dplyr::if_else(is.finite(dp_pt), .x, NA_real_))) |>
  # defasagens de 1 pregão, só para replicar a amostra do 06_models
  # (E, E1 e D estimados na mesma amostra: exige y_l1 e dp_pt_l1)
  add_lags(c("r_ibov", "r_usd", "dp_pt"), 1)

estimar <- function(y, x, rotulo) {
  dd <- tidyr::drop_na(d, dplyr::all_of(c(y, x, paste0(y, "_l1"), "dp_pt_l1", controles)))
  m <- lm(formula_leadlag(y, x, 0, 0, 0, controles), data = dd)
  tidy_nw(m) |>
    dplyr::filter(term == x) |>
    dplyr::mutate(ativo = y, especificacao = rotulo, n = nobs(m), .before = 1)
}

res <- purrr::map_dfr(c("r_ibov", "r_usd"), function(y) dplyr::bind_rows(
  estimar(y, "dp_pt",    "R0 – Modelo E original"),
  estimar(y, "dp_fa164", "R16a – Viés favorito-azarão corrigido (a = 1,64)"),
  estimar(y, "dp_fa272", "R16b – Viés favorito-azarão corrigido (a = 2,72)")
))

# Desvio-padrão de cada medida de ΔP, para comparar magnitudes
dp_sd <- d |>
  dplyr::summarise(dplyr::across(c(dp_pt, dp_fa164, dp_fa272), ~ sd(.x, na.rm = TRUE)))

print(res |> dplyr::select(ativo, especificacao, n, estimate, std.error, p.value))
print(dp_sd)

export_table(res, file.path(saida_dir, "favorito_azarao.csv"))
export_table(dp_sd, file.path(saida_dir, "favorito_azarao_dp_sd.csv"))
