# ============================================================
# Script  : 09b_comparacao_ciclos.R
#
# Objetivo:
#   Comparar, entre 2018, 2022 e 2026, a reação de cada ativo à
#   variação da probabilidade de vitória do PT, com os controles
#   internacionais (S&P 500, Treasury 10 anos e VIX).
#
#   1. Coeficiente de reação (θ_0) estimado em cada ciclo, com as
#      mesmas ordens (p, q) do ARDL empilhado (09) e erros-padrão
#      Newey-West. Com o BIC escolhendo (0, 0), é a regressão
#      estática por ciclo: y_t = a + θ_0 ΔP_t + g'·controles_t + e_t.
#      O coeficiente empilhado não é reestimado aqui: está no 06
#      (modelo E, Tabela 5).
#   2. Teste de igualdade: modelo empilhado com ΔP_t interagido com o
#      ciclo (um θ_0 por ciclo) e efeito fixo de ciclo; Wald
#      (Newey-West) de que os três θ_0 são iguais. É o único teste
#      de igualdade entre ciclos do pipeline.
#   3. Gráfico com os coeficientes e os intervalos de 95% lado a lado,
#      com o p-valor do teste de igualdade em cada painel.
#
# Entrada : data/processed/model_data_daily.rds, output/09_saida/ardl_main.rds
# Saída   : output/09b_saida/comparacao_ciclos.csv
#           output/09b_saida/comparacao_ciclos_igualdade.csv
#           output/09b_saida/comparacao_ciclos.png
#
# Próximo script: 10_robustness.R
# ============================================================

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

saida_dir <- saida("09b")

model_data <- load_object(model_data_file)
aviso_simulado(model_data)

base_ardl <- load_object(file.path(saida("09"), "ardl_main.rds"))$empilhado
respostas_disp <- names(respostas)[purrr::map_lgl(names(respostas), ~ sum(is.finite(model_data[[.x]])) > 50)]
ciclos_disp <- sort(unique(model_data$ciclo))
x <- "dp_pt"

# ------------------------------------------------------------
# 1. Coeficiente de reação por ciclo (mesmas ordens do empilhado)
# ------------------------------------------------------------

por_ciclo <- purrr::map_dfr(respostas_disp, function(y) {
  p0 <- base_ardl[[y]]$p; q0 <- base_ardl[[y]]$q
  purrr::map_dfr(as.character(ciclos_disp), function(cc) {
    d <- dplyr::filter(model_data, ciclo == as.numeric(cc))
    r <- tryCatch(rodar_leadlag(d, y, x, cc, p = p0, q = q0), error = function(e) NULL)
    if (is.null(r)) return(NULL)
    s <- sum_nw(r$modelo, x)
    tibble::tibble(amostra = cc, y = y, p = p0, q = q0, n = nobs(r$modelo),
                   coef = s$soma, ep = s$ep, p_valor = s$p_value,
                   ic_inf = s$conf.low, ic_sup = s$conf.high)
  })
})

export_table(por_ciclo |> format_table(4), file.path(saida_dir, "comparacao_ciclos.csv"))

# ------------------------------------------------------------
# 2. Teste de igualdade do θ_0 entre os ciclos
# ------------------------------------------------------------

igualdade <- purrr::map_dfr(respostas_disp, function(y) {
  p0 <- base_ardl[[y]]$p; q0 <- base_ardl[[y]]$q
  d <- prepare_leadlag(model_data, y, x, max(p0, 1), max(q0, 1), 0, controles) |>
    dplyr::mutate(ciclo_f = factor(ciclo))
  rhs <- c(lag_terms(y, p0), paste0(x, ":ciclo_f"), lag_terms(x, q0), controles, "ciclo_f")
  m <- lm(stats::as.formula(paste(y, "~", paste(rhs, collapse = " + "))), data = d)
  termos <- grep(paste0("^", x, ":ciclo_f"), names(coef(m)), value = TRUE)
  restr <- paste(termos[-1], "=", termos[1])
  h <- car::linearHypothesis(m, restr, vcov. = vcov_nw(m), test = "F")
  tibble::tibble(y = y, F = h$F[2], gl = h$Df[2], p_valor = h$`Pr(>F)`[2], n = nobs(m))
})

export_table(igualdade |> format_table(4), file.path(saida_dir, "comparacao_ciclos_igualdade.csv"))

# ------------------------------------------------------------
# 3. Gráfico
# ------------------------------------------------------------

rot_painel <- igualdade |>
  dplyr::mutate(painel = paste0(respostas[y], "\nigualdade entre ciclos: p = ",
                                formatC(p_valor, format = "f", digits = 3, decimal.mark = ","))) |>
  dplyr::select(y, painel)

g <- por_ciclo |>
  dplyr::left_join(rot_painel, by = "y") |>
  dplyr::mutate(painel = factor(painel, rot_painel$painel[match(respostas_disp, rot_painel$y)]),
                amostra = factor(amostra, as.character(ciclos_disp))) |>
  ggplot(aes(amostra, coef)) +
  geom_hline(yintercept = 0, colour = "grey50") +
  geom_pointrange(aes(ymin = ic_inf, ymax = ic_sup), size = 0.4, colour = "steelblue4") +
  facet_wrap(~ painel, scales = "free_y", nrow = 1) +
  labs(x = NULL, y = "resposta no mesmo pregão a +1 p.p. em P(PT)",
       title = "Reação dos preços à probabilidade de vitória do PT, por ciclo",
       subtitle = "Controles: S&P 500, Treasury 10 anos e VIX. IC de 95% (Newey-West). Teste de igualdade: Wald dos três coeficientes.") +
  theme_minimal(base_size = 10) + theme(panel.grid.minor = element_blank())

save_plot(g, file.path(saida_dir, "comparacao_ciclos.png"), width = 11, height = 4.5)

cat("\n========== COMPARAÇÃO ENTRE CICLOS ==========\n")
print(por_ciclo, n = Inf)
print(igualdade)
message("09b_comparacao_ciclos.R concluído com sucesso.")
