# ============================================================
# Script  : 13_tables_figures.R
#
# Objetivo:
#   Reunir as tabelas e figuras do texto. Não reestima nada: só
#   lê o que os scripts 02 a 12 exportaram, padroniza e grava em
#   CSV e LaTeX.
#
#   Texto principal
#     Tabela 1   Dados                                   (02)
#     Tabela 2   Descritivas                             (04)
#     Tabela 3   Noites eleitorais                       (04)
#     Tabela 4   Estacionariedade                        (05)
#     Tabela 5   Sensibilidade: modelos E, E1 e D        (06)
#     Tabela 5a  Modelo E completo: todos os coeficientes (06)
#     Tabela 6   Magnitude: quanto ΔP(PT) explica        (06b)
#     Tabela 7   Defasagens escolhidas pelo BIC          (09)
#     Tabela 8   ARDL invertido: preço -> probabilidade  (09)
#     Tabela 9   Sensibilidade por ciclo e igualdade     (09b)
#     Tabela 10  β com e sem as noites eleitorais        (07)
#     Tabela 11  Estabilidade dentro do ciclo            (07)
#     Tabela 12  Robustez                                (10)
#     Tabela 13  Noites: previsto x observado            (09c)
#     Tabela 14  Noites: fim de semana x apuração        (09c)
#     Tabela 15  Estudo de eventos das pesquisas         (12)
#   Apêndice
#     Tabela A1  Granger nos dois sentidos               (08)
#     Tabela A2  VAR                                     (11)
#     Tabela A3  ARDL em níveis e teste Bounds           (09)
#     Tabela A4  Conferência com o pacote ARDL           (09)
#     Tabela A5  Resumo dos diagnósticos                 (07)
#     Tabela A6  RESET com e sem os grandes choques      (07)
#     Tabela A7  Interação: pregões pós-1º turno         (09d)
#     Tabela A8  Influência de cada evento no β          (09d)
#     Tabela A9  Interação sem cada evento               (09d)
#     Tabela A10 Modelo E com dummy pós-1º turno         (09e)
#     Tabela A11 Diagnósticos: E e E com dummy           (09e)
#     Tabela A12 Resíduos e influência nos eventos       (09e)
#
# Saída   : output/13_saida/tabelas/  (Tabela_*.csv e Tabela_*.tex)
#           output/13_saida/figuras/ (Figura_*.png)
# ============================================================

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

tabelas_dir <- file.path(saida("13"), "tabelas")
figuras_dir <- file.path(saida("13"), "figuras")
dir.create(tabelas_dir, showWarnings = FALSE); dir.create(figuras_dir, showWarnings = FALSE)

ler <- function(...) readr::read_csv(file.path(...), show_col_types = FALSE)
estrela <- function(p) dplyr::case_when(is.na(p) ~ "", p < .01 ~ "***", p < .05 ~ "**",
                                        p < .10 ~ "*", TRUE ~ "")
# Sem valor (ex.: bloco de defasagens vazio quando o BIC escolhe q = 0) -> "--"
num <- function(x, d = 3) ifelse(is.finite(as.numeric(x)),
  formatC(as.numeric(x), format = "f", digits = d, decimal.mark = ","), "--")
coef_ep <- function(b, ep, p, d = 3) ifelse(is.finite(as.numeric(b)),
  paste0(num(b, d), estrela(p), " (", num(ep, d), ")"), "--")

nomes_y <- c(r_ibov = "Ibovespa", r_usd = "Dólar", d_di1 = "DI 1 ano", d_di5 = "DI 5 anos",
             r_usd_alt = "Dólar (fonte alternativa)")

# Símbolos Unicode -> LaTeX em modo matemático (pdflatex não tem as
# letras gregas nem a raiz nas fontes de texto). Usada nas células,
# nos cabeçalhos, nas notas e nos títulos das tabelas.
tex_simbolos <- function(x) {
  x <- gsub("√([[:alnum:]]+)", "$\\\\sqrt{\\1}$", x)
  x <- gsub("√", "$\\surd$", x, fixed = TRUE)
  x <- gsub("Δ", "$\\Delta$", x, fixed = TRUE)
  x <- gsub("β", "$\\beta$", x, fixed = TRUE)
  x <- gsub("δ", "$\\delta$", x, fixed = TRUE)
  x <- gsub("θ", "$\\theta$", x, fixed = TRUE)
  x <- gsub("φ", "$\\phi$", x, fixed = TRUE)
  x <- gsub("²", "$^2$", x, fixed = TRUE)
  x <- gsub("×", "$\\times$", x, fixed = TRUE)
  x <- gsub("·", "$\\cdot$", x, fixed = TRUE)
  x <- gsub("->", "$\\rightarrow$", x, fixed = TRUE)
  x <- gsub("†", "$^\\dagger$", x, fixed = TRUE)
  x <- gsub("−", "-", x, fixed = TRUE)
  x
}

# LaTeX (pdflatex): escapa caracteres especiais e troca símbolos Unicode
tex_safe <- function(x) {
  x <- gsub("\\", "\\textbackslash{}", x, fixed = TRUE)
  x <- gsub("([%_&#$])", "\\\\\\1", x)
  x <- gsub("^", "\\textasciicircum{}", x, fixed = TRUE)
  x <- gsub("~", "\\textasciitilde{}", x, fixed = TRUE)
  tex_simbolos(x)
}

tabelas_geradas <- character(0)   # arquivos gravados nesta execução

salvar_tabela <- function(df, nome, titulo, nota = NULL) {
  # Notas e títulos: escapa %, &, _ e # que ainda não estejam
  # escapados (algumas notas já trazem "\\&"), troca ^ e os símbolos
  tex_texto <- function(x) x |>
    gsub(pattern = "(?<!\\\\)([%&_#])", replacement = "\\\\\\1", perl = TRUE) |>
    gsub(pattern = "^", replacement = "\\textasciicircum{}", fixed = TRUE) |>
    tex_simbolos()
  if (!is.null(nota)) nota <- tex_texto(nota)
  export_table(df, file.path(tabelas_dir, paste0(nome, ".csv")))
  tabelas_geradas <<- c(tabelas_geradas, paste0(nome, c(".csv", ".tex")))
  xt <- xtable::xtable(df, caption = tex_texto(titulo), label = paste0("tab:", tolower(nome)))
  arq <- file.path(tabelas_dir, paste0(nome, ".tex"))
  print(xt, file = arq, include.rownames = FALSE, booktabs = TRUE,
        caption.placement = "top", sanitize.text.function = tex_safe,
        add.to.row = if (!is.null(nota)) list(pos = list(nrow(df)),
          command = paste0("\\bottomrule\n\\multicolumn{", ncol(df), "}{p{0.95\\linewidth}}{\\footnotesize ",
                           nota, "}\\\\\n")) else NULL,
        hline.after = if (!is.null(nota)) c(-1, 0) else c(-1, 0, nrow(df)))
  message("Tabela do artigo: ", nome)
}

nota_nw <- "Erros-padrão Newey-West entre parênteses. *** p<0,01; ** p<0,05; * p<0,10. Efeito fixo de ciclo e controles (S\\&P 500, Treasury 10 anos, VIX) em todas as colunas."

# ------------------------------------------------------------
# Tabela 1 — Dados
# ------------------------------------------------------------

dic <- ler(saida("02"), "dicionario_dados.csv")
salvar_tabela(dic |> dplyr::select(Variável = variavel, Descrição = descricao, Fonte = fonte,
                                   Unidade = unidade, Período = periodo, N = n),
              "Tabela_1_Dados", "Variáveis, fontes e cobertura da base integrada")

# ------------------------------------------------------------
# Tabela 2 — Estatísticas descritivas
# ------------------------------------------------------------

desc <- ler(saida("04"), "descriptive_statistics.csv") |>
  dplyr::filter(variavel %in% c("dp_pt", names(respostas))) |>
  dplyr::transmute(Ciclo = ciclo, Variável = descricao, N,
                   Média = num(media), DP = num(dp), Mín = num(min), Máx = num(max),
                   `Curtose exc.` = num(curtose_exc, 1))
salvar_tabela(desc, "Tabela_2_Descritivas", "Estatísticas descritivas das variações diárias")

# ------------------------------------------------------------
# Tabela 3 — Noites eleitorais
# ------------------------------------------------------------

noites <- ler(saida("04"), "noites_eleitorais.csv") |>
  dplyr::transmute(Ciclo = ciclo, Evento = evento, Pregão = format(as.Date(data), "%d/%m/%Y"),
                   `P(PT)` = num(p_pt, 2), `ΔP(PT) p.p.` = num(dp_pt, 1),
                   `Ibovespa %` = num(r_ibov, 2), `Dólar %` = num(r_usd, 2),
                   `DI 1a p.b.` = num(d_di1, 1), `DI 5a p.b.` = num(d_di5, 1))
salvar_tabela(noites, "Tabela_3_Noites_eleitorais", "Primeiro pregão após cada turno")

# ------------------------------------------------------------
# Tabela 4 — Estacionariedade
# ------------------------------------------------------------

est <- ler(saida("05"), "stationarity_summary.csv") |>
  dplyr::select(ciclo, variable, forma, leitura) |>
  tidyr::pivot_wider(names_from = ciclo, values_from = leitura) |>
  dplyr::rename(Variável = variable, Forma = forma)
salvar_tabela(est, "Tabela_4_Estacionariedade",
              "Testes de raiz unitária e de estacionariedade por ciclo (leitura conjunta de ADF, PP e KPSS)",
              "Evidência de estacionariedade: ADF e PP rejeitam a raiz unitária e o KPSS não rejeita a estacionariedade. Evidência de raiz unitária: ADF e PP não rejeitam e o KPSS rejeita. Nos demais casos o resultado é inconclusivo; não rejeitar a raiz unitária não a comprova. Nível de 5%. ADF com até 4(T/100)^(1/4) defasagens, escolhidas por AIC; PP e KPSS com a mesma regra de banda. Log-preços com tendência; 'nível sem tendência' repete o teste só com constante.")

# ------------------------------------------------------------
# Tabela 5 — Estático e dinâmico (empilhado)
# ------------------------------------------------------------

sd_ <- ler(saida("06"), "static_dynamic_coefficients.csv") |>
  dplyr::filter(amostra == "empilhado")
fit <- ler(saida("06"), "static_dynamic_fit.csv") |> dplyr::filter(amostra == "empilhado")

linha <- function(termo, rotulo) {
  sd_ |> dplyr::filter(term == termo | (rotulo == "y(t-1)" & grepl("_l1$", term) & !grepl("^dp", term))) |>
    dplyr::transmute(y, espec, linha = rotulo, valor = coef_ep(estimate, se_nw, p_nw))
}
t5 <- dplyr::bind_rows(linha("dp_pt", "ΔP(PT) t"), linha("dp_pt_l1", "ΔP(PT) t-1"),
                       linha("__", "y(t-1)"),
                       fit |> dplyr::transmute(y, espec, linha = "R² ajustado", valor = num(adj_r2)),
                       fit |> dplyr::transmute(y, espec, linha = "N", valor = as.character(nobs))) |>
  tidyr::pivot_wider(names_from = linha, values_from = valor, values_fill = "") |>
  dplyr::mutate(y = factor(y, names(nomes_y)), espec = factor(espec, c("E", "E1", "D"))) |>
  dplyr::arrange(y, espec) |>
  dplyr::mutate(Ativo = nomes_y[as.character(y)], `Especificação` = as.character(espec), .before = 1) |>
  dplyr::select(-y, -espec)
salvar_tabela(t5, "Tabela_5_Estatico_dinamico",
              "Especificações estática (E), estática com t-1 (E1) e dinâmica (D), ciclos empilhados", nota_nw)

# ------------------------------------------------------------
# Tabela 5a — Modelo E completo (empilhado)
# ------------------------------------------------------------

if (file.exists(file.path(saida("06"), "modelo_E_completo.csv"))) {
  ec <- ler(saida("06"), "modelo_E_completo.csv")
  ge <- ler(saida("06"), "static_dynamic_global_tests.csv") |>
    dplyr::filter(amostra == "empilhado", espec == "E")
  fe <- fit |> dplyr::filter(espec == "E")
  ciclos_fe <- sort(sub("factor(ciclo)", "", unique(ec$term[grepl("^factor\\(ciclo\\)", ec$term)]), fixed = TRUE))
  ciclo_base <- setdiff(unique(ler(saida("06"), "static_dynamic_fit.csv")$amostra), c("empilhado", ciclos_fe))
  rotulos_e <- c(dp_pt = "ΔP(PT) (p.p.)", r_spx = "S&P 500 (%)",
                 d_ust10 = "Treasury 10 anos (p.b.)", r_vix = "VIX (%)",
                 setNames(paste("Ciclo", ciclos_fe), paste0("factor(ciclo)", ciclos_fe)),
                 `(Intercept)` = "Constante")
  pval <- function(p) ifelse(as.numeric(p) < 0.001, "<0,001", num(p))
  t5a <- dplyr::bind_rows(
    ec |> dplyr::filter(term %in% names(rotulos_e)) |>
      dplyr::transmute(y, linha = rotulos_e[term], valor = coef_ep(estimate, se_nw, p_nw)),
    fe |> dplyr::transmute(y, linha = "N", valor = as.character(nobs)),
    fe |> dplyr::transmute(y, linha = "R²", valor = num(r2)),
    fe |> dplyr::transmute(y, linha = "R² ajustado", valor = num(adj_r2)),
    fe |> dplyr::transmute(y, linha = "Erro-padrão da regressão", valor = num(sigma)),
    ge |> dplyr::transmute(y, linha = "F (MQO)", valor = paste0(num(f_classico, 2), " (p ", pval(p_classico), ")")),
    ge |> dplyr::transmute(y, linha = "Wald (Newey-West)", valor = paste0(num(f_wald_nw, 2), " (p ", pval(p_wald_nw), ")")),
    ge |> dplyr::transmute(y, linha = "Defasagens Newey-West", valor = as.character(nw_lag))
  ) |>
    dplyr::mutate(linha = factor(linha, c(unname(rotulos_e), "N", "R²", "R² ajustado", "Erro-padrão da regressão",
                                          "F (MQO)", "Wald (Newey-West)", "Defasagens Newey-West")),
                  y = factor(y, names(nomes_y))) |>
    dplyr::arrange(y) |>
    dplyr::mutate(y = nomes_y[as.character(y)]) |>
    tidyr::pivot_wider(names_from = y, values_from = valor, values_fill = "") |>
    dplyr::arrange(linha) |>
    dplyr::mutate(linha = as.character(linha)) |>
    dplyr::rename(` ` = linha)
  salvar_tabela(t5a, "Tabela_5a_Modelo_E_completo",
                "Modelo E: todos os coeficientes, ciclos empilhados",
                paste0("Erros-padrão Newey-West entre parênteses, calculados dentro de cada ciclo. *** p<0,01; ** p<0,05; * p<0,10. ",
                       "A constante corresponde ao ciclo de ", paste(ciclo_base, collapse = ", "),
                       "; as linhas de ciclo são diferenças de intercepto em relação a ele. ",
                       "F (MQO) e Wald (Newey-West): H0 de que todos os coeficientes de inclinação (ΔP(PT) e controles) são zero."))
}

# ------------------------------------------------------------
# Tabela 6 — Magnitude: quanto ΔP(PT) explica (06b)
# ------------------------------------------------------------

if (file.exists(file.path(saida("06b"), "magnitude.csv"))) {
  mg <- ler(saida("06b"), "magnitude.csv") |> dplyr::filter(amostra == "empilhado")
  t6 <- mg |>
    dplyr::transmute(Ativo = nomes_y[y], Amostra = noites, N = as.character(n),
                     `β` = coef_ep(beta, ep, p_value),
                     `R² sem ΔP` = num(r2_sem), `R² com ΔP` = num(r2_com),
                     `Ganho de R²` = num(r2_ganho), `R² parcial` = num(r2_parcial),
                     `DP de ΔP (p.p.)` = num(dp_dp_pt, 2),
                     `Efeito de 1 DP` = paste0(num(efeito_1dp), " [", num(efeito_1dp_inf), "; ", num(efeito_1dp_sup), "]"),
                     `Em DP do ativo` = num(efeito_dp_relativo),
                     `Efeito do p95` = num(efeito_p95))
  salvar_tabela(t6, "Tabela_6_Magnitude", "Quanto a probabilidade eleitoral explica dos preços (ciclos empilhados)",
                paste("Modelo E com e sem ΔP(PT), na mesma amostra. R² parcial: parcela da variação não explicada pelos",
                      "controles que ΔP(PT) explica. Efeito de 1 DP: β vezes o desvio-padrão de ΔP(PT) dentro do ciclo,",
                      "na unidade do ativo (% ou p.b.), com intervalo de 95% entre colchetes; 'Em DP do ativo' divide esse",
                      "efeito pelo desvio-padrão do ativo. Efeito do p95: β vezes o percentil 95 de |ΔP(PT)|.", nota_nw))
}

# ------------------------------------------------------------
# Tabela A1 (apêndice) — Granger nos dois sentidos
# ------------------------------------------------------------

gr <- ler(saida("08"), "granger_summary.csv") |>
  dplyr::filter(amostra == "empilhado") |>
  dplyr::transmute(Fonte = dplyr::if_else(x == "dp_pt", "Mercado de previsão", "Pesquisas"),
                   Ativo = nomes_y[y], Sentido = sentido,
                   `p (L=1)` = num(p_L1), `p (L=3)` = num(p_L3), `p (L=5)` = num(p_L5))
salvar_tabela(gr, "Tabela_A1_Granger", "Testes de Granger nos dois sentidos (ciclos empilhados)",
              "H0: a variável de origem não ajuda a prever a de destino. Efeito fixo de ciclo, controles (S\\&P 500, Treasury 10 anos, VIX) e Wald com Newey-West.")

# ------------------------------------------------------------
# Função das tabelas de ARDL (usada na Tabela 8)
# ------------------------------------------------------------

# Estrelas: teste t da SOMA mostrada (Newey-West). A linha "Wald"
# traz o p-valor do teste conjunto (todos os coeficientes do bloco
# iguais a zero), que é o teste de precedência no estilo Granger.
tabela_ardl <- function(pf, ordens, blocos, bloco_wald, rotulo_wald) {
  pf |>
    dplyr::filter(bloco %in% names(blocos)) |>
    dplyr::transmute(amostra, coluna = col, bloco = blocos[bloco],
                     valor = coef_ep(soma, ep, p_soma)) |>
    dplyr::bind_rows(
      pf |> dplyr::filter(bloco == bloco_wald) |>
        dplyr::transmute(amostra, coluna = col, bloco = rotulo_wald, valor = num(p_wald)),
      ordens |> dplyr::transmute(amostra, coluna = col, bloco = "Longo prazo",
                                 valor = coef_ep(lr, lr_ep, lr_p)),
      ordens |> dplyr::transmute(amostra, coluna = col, bloco = "Ordens (p, q)", valor = paste(p, q, sep = ", ")),
      ordens |> dplyr::transmute(amostra, coluna = col, bloco = "N", valor = as.character(n))
    ) |>
    dplyr::mutate(coluna = nomes_y[coluna],
                  bloco = factor(bloco, c(unname(blocos), rotulo_wald, "Longo prazo", "Ordens (p, q)", "N"))) |>
    tidyr::pivot_wider(names_from = coluna, values_from = valor, values_fill = "") |>
    dplyr::mutate(amostra = factor(amostra, c("empilhado", sort(setdiff(unique(amostra), "empilhado"))))) |>
    dplyr::arrange(amostra, bloco) |>
    dplyr::select(amostra, bloco, dplyr::any_of(unname(nomes_y))) |>
    dplyr::rename(Amostra = amostra, Bloco = bloco)
}

# Rótulos dos blocos a partir do próprio perfil (dependem de
# defasagem_reacao: reação em t, ou em t e t-1)
maiuscula <- function(x) paste0(toupper(substr(x, 1, 1)), substring(x, 2))
blocos_de <- function(pf, chaves, renomear = character(0)) {
  lab <- pf |> dplyr::distinct(chave, bloco) |> dplyr::filter(chave %in% chaves)
  lab <- lab[match(chaves, lab$chave), ]
  rot <- maiuscula(lab$bloco)
  for (k in names(renomear)) rot[lab$chave == k] <- renomear[[k]]
  stats::setNames(rot, lab$bloco)
}
bloco_txt <- function(pf, k) pf$bloco[pf$chave == k][1]

# ------------------------------------------------------------
# Tabela 7 — Defasagens escolhidas pelo BIC (09)
# ------------------------------------------------------------
# A sensibilidade está na Tabela 5; aqui só a evidência de que o
# BIC escolhe a ordem do modelo principal.

bic <- ler(saida("09"), "ardl_bic_grid_all.csv") |> dplyr::filter(posicao <= 3)
t7 <- bic |>
  dplyr::transmute(`Posição` = paste0(posicao, "ª"), y = nomes_y[y],
                   valor = paste0("(", p, ", ", q, ")  ΔBIC = ", num(delta_bic, 1))) |>
  tidyr::pivot_wider(names_from = y, values_from = valor)
salvar_tabela(t7, "Tabela_7_Selecao_BIC", "Ordens (p, q) do ARDL em variações com menor BIC, ciclos empilhados",
              paste0("p: defasagens do ativo (0 a ", max_lag_y, "); q: defasagens de ΔP(PT) (", min_lag_dp, " a ", max_lag_dp,
                     "). Comparação feita na amostra comum a todas as ordens (N = ", bic$n_selecao[1],
                     "), que perde os primeiros pregões de cada ciclo. ΔBIC: distância para a ordem escolhida. ",
                     "Com (0, 0), o ARDL é o modelo E da Tabela 5, estimado na amostra completa."))

# ------------------------------------------------------------
# Tabela 8 — ARDL invertido: ativo -> probabilidade
# ------------------------------------------------------------

pf_i <- ler(saida("09"), "ardl_inverse_profile.csv") |> dplyr::mutate(col = x)
ordens_i <- ler(saida("09"), "ardl_inverse_orders_fit.csv") |> dplyr::mutate(col = x)
t8 <- tabela_ardl(pf_i, ordens_i, blocos_de(pf_i, c("mesmo_dia", "defasado_1", "total"),
                                            c(defasado_1 = "Retroalimentação (t-1 em diante)", total = "Total")),
                    bloco_txt(pf_i, "defasado_1"), "Wald retroalimentação (p)")
salvar_tabela(t8, "Tabela_8_ARDL_invertido",
              "ARDL invertido: os preços ajudam a prever a probabilidade de vitória do PT?",
              paste("Variável dependente: ΔP(PT) em p.p. Cada coluna indica o ativo usado como regressor;",
                    "soma dos coeficientes do ativo em cada bloco; estrelas pelo teste t da soma.",
                    "Wald retroalimentação: p-valor do teste conjunto de que todos os coeficientes do ativo de t-1 em diante são zero.",
                    "Ordens por BIC; quando o BIC escolhe q = 0, usa-se q = 1 para que o teste exista.",
                    nota_nw))

# ------------------------------------------------------------
# Tabela A2 (apêndice) — VAR: causalidade e impulso-resposta
# ------------------------------------------------------------

if (file.exists(file.path(saida("11"), "var_pairwise_wald.csv"))) {
  pw <- ler(saida("11"), "var_pairwise_wald.csv")
  irs <- ler(saida("11"), "var_irf_summary.csv") |>
    dplyr::filter(ordenacao == "P primeiro") |>
    dplyr::mutate(txt = paste0(num(irf), ifelse(signif, "†", ""), " [", num(lo), "; ", num(hi), "]"))
  t9 <- dplyr::bind_rows(
    pw |> dplyr::transmute(ciclo, ativo, linha = "Granger P(PT) -> ativo (p)", valor = num(p_P_no_ativo)),
    pw |> dplyr::transmute(ciclo, ativo, linha = "Granger ativo -> P(PT) (p)", valor = num(p_ativo_no_P)),
    irs |> dplyr::filter(impulso == "dp_pt", horizonte == "h=0") |>
      dplyr::transmute(ciclo, ativo = resposta, linha = "IRF P(PT) -> ativo, impacto", valor = txt),
    irs |> dplyr::filter(impulso == "dp_pt", horizonte == paste0("acumulado h=", var_n_ahead)) |>
      dplyr::transmute(ciclo, ativo = resposta, linha = paste0("IRF P(PT) -> ativo, acumulada h=", var_n_ahead),
                       valor = txt),
    irs |> dplyr::filter(impulso != "dp_pt", horizonte == "h=1") |>
      dplyr::transmute(ciclo, ativo = impulso, linha = "IRF ativo -> P(PT), h=1", valor = txt)
  ) |>
    dplyr::mutate(ativo = nomes_y[ativo]) |>
    tidyr::pivot_wider(names_from = ativo, values_from = valor, values_fill = "") |>
    dplyr::arrange(ciclo) |>
    dplyr::select(ciclo, linha, dplyr::any_of(unname(nomes_y))) |>
    dplyr::rename(Ciclo = ciclo, `Estatística` = linha)
  salvar_tabela(t9, "Tabela_A2_VAR", "VAR por ciclo: precedência e impulso-resposta",
                paste("Granger: Wald (Newey-West) das defasagens de uma variável na equação da outra.",
                      "IRF ortogonalizada (Cholesky, P(PT) primeiro); choque em P(PT) reescalado para +1 p.p.;",
                      "choque no ativo de 1 desvio-padrão. IC de 95% por bootstrap entre colchetes;",
                      "† = intervalo não contém zero. Controles exógenos: S\\&P 500, Treasury 10 anos, VIX."))
}

# ------------------------------------------------------------
# Tabela 9 — Reação por ciclo e teste de igualdade (09b)
# ------------------------------------------------------------

if (file.exists(file.path(saida("09b"), "comparacao_ciclos.csv"))) {
  cc_tab <- ler(saida("09b"), "comparacao_ciclos.csv")
  ig <- ler(saida("09b"), "comparacao_ciclos_igualdade.csv")
  t9c <- cc_tab |>
    dplyr::mutate(valor = coef_ep(coef, ep, p_valor),
                  amostra = factor(amostra, sort(unique(amostra)))) |>
    dplyr::select(amostra, y, valor) |>
    tidyr::pivot_wider(names_from = y, values_from = valor) |>
    dplyr::arrange(amostra) |>
    dplyr::mutate(amostra = as.character(amostra)) |>
    dplyr::bind_rows(
      ig |> dplyr::transmute(amostra = "Igualdade entre ciclos (p)", y, valor = num(p_valor)) |>
        tidyr::pivot_wider(names_from = y, values_from = valor)
    )
  names(t9c) <- c("Amostra", nomes_y[names(t9c)[-1]])
  salvar_tabela(t9c, "Tabela_9_Comparacao_ciclos", "Reação no mesmo pregão por ciclo e teste de igualdade",
                "Coeficiente de ΔP(PT) em t, com as mesmas ordens do ARDL empilhado e controles (S&P 500, Treasury 10 anos, VIX). Erros-padrão Newey-West entre parênteses. *** p<0,01; ** p<0,05; * p<0,10. O coeficiente dos três ciclos empilhados está na Tabela 5. Igualdade: Wald (Newey-West) de que o coeficiente é o mesmo nos três ciclos, no modelo empilhado com ΔP(PT) interagido com o ciclo.")
}

# ------------------------------------------------------------
# Tabela 10 — β com e sem as noites eleitorais (07)
# ------------------------------------------------------------

if (file.exists(file.path(saida("07"), "diagnostics_beta_sem_noites.csv"))) {
  bn <- ler(saida("07"), "diagnostics_beta_sem_noites.csv")
  t10 <- bn |>
    dplyr::transmute(Ativo = nomes_y[y], Amostra = amostra, N = as.character(n),
                     `β de ΔP(PT)` = coef_ep(beta, ep, p_value),
                     `IC 95%` = paste0("[", num(conf.low), "; ", num(conf.high), "]"),
                     `Variação do β (%)` = ifelse(amostra == "amostra completa", "--", num(variacao_pct, 1)),
                     `DFBETAS da noite` = num(dfbetas_noite, 2))
  salvar_tabela(t10, "Tabela_10_Influencia_noites", "Sensibilidade com e sem as noites eleitorais (modelo E, ciclos empilhados)",
                paste("Modelo E reestimado sem cada pregão seguinte a um turno e sem todos. Variação do β: em relação à",
                      "amostra completa. DFBETAS: quantos erros-padrão o β muda ao retirar o pregão; referência de",
                      "influência alta: |DFBETAS| > 2/√N.", nota_nw))
}

# ------------------------------------------------------------
# Tabela 11 — Estabilidade dentro do ciclo (07)
# ------------------------------------------------------------

if (file.exists(file.path(saida("07"), "diagnostics_stability_within.csv"))) {
  ew <- readr::read_csv(file.path(saida("07"), "diagnostics_stability_within.csv"), show_col_types = FALSE,
                        col_types = readr::cols(bp_datas = readr::col_character()))
  t11 <- ew |>
    dplyr::transmute(Ciclo = ciclo, Ativo = nomes_y[y], N = as.character(n),
                     `CUSUM (p)` = num(cusum_p), `MOSUM (p)` = num(mosum_p),
                     `Quebras (Bai-Perron)` = ifelse(is.na(bp_quebras), "--", as.character(bp_quebras)),
                     `Datas das quebras` = ifelse(is.na(bp_datas), "", bp_datas))
  salvar_tabela(t11, "Tabela_11_Estabilidade_ciclo", "Estabilidade dos coeficientes dentro de cada ciclo (modelo E)",
                "H0 do CUSUM e do MOSUM (resíduos de MQO): coeficientes constantes ao longo do ciclo. Bai-Perron com segmento mínimo de 15% da amostra, número de quebras por BIC. Ciclos com menos de 15 observações por parâmetro não são testados.")
}

# ------------------------------------------------------------
# Tabela 12 — Robustez
# ------------------------------------------------------------

rob <- ler(saida("10"), "robustness_compact.csv") |>
  dplyr::mutate(y = nomes_y[y])
salvar_tabela(rob, "Tabela_12_Robustez", "Robustez do ARDL (probabilidade -> ativo)",
              "Coeficientes de t e t-1 e soma dos blocos de reação e antecedência. Estrelas: teste t (coeficientes e reação) e Wald conjunto (antecedência), com Newey-West.")

# ------------------------------------------------------------
# Tabela 13 e 14 — Noites eleitorais: previsto x realizado (09c)
# ------------------------------------------------------------

if (file.exists(file.path(saida("09c"), "noites_previsto_realizado.csv"))) {
  nt <- ler(saida("09c"), "noites_previsto_realizado.csv")
  d_y <- c(r_ibov = 2, r_usd = 2, d_di1 = 1, d_di5 = 1)
  t13n <- nt |>
    dplyr::mutate(dd = d_y[y],
                  celula = purrr::pmap_chr(list(previsto, ic_inf, ic_sup, dd), function(a, b, c, d)
                    paste0(num(a, d), " [", num(b, d), "; ", num(c, d), "]")),
                  amostra_beta = dplyr::if_else(amostra_beta == "empilhado", "previsto (β empilhado)", "previsto (β do ciclo)")) |>
    dplyr::select(noite, choque_pp, y, amostra_beta, celula) |>
    tidyr::pivot_wider(names_from = amostra_beta, values_from = celula) |>
    dplyr::left_join(nt |> dplyr::filter(amostra_beta == "empilhado") |>
                       dplyr::transmute(noite, y, observado = purrr::map2_chr(realizado, d_y[y], num)),
                     by = c("noite", "y")) |>
    dplyr::mutate(y = nomes_y[y], choque_pp = num(choque_pp, 1)) |>
    dplyr::arrange(factor(y, nomes_y), noite)
  names(t13n)[1:3] <- c("Noite", "ΔP (p.p.)", "Ativo")
  salvar_tabela(t13n, "Tabela_13_Noites_previsto_realizado", "Noites eleitorais: reação prevista e observada",
                "Previsto: modelo principal reestimado sem a noite prevista, aplicado ao choque da noite e aos controles do dia; entre colchetes, intervalo de previsão de 95% (Newey-West). ΔP: no 2º turno, resultado menos a probabilidade do pregão anterior. Ibovespa e dólar em %; DI em p.b.")
}

if (file.exists(file.path(saida("09c"), "noites_decomposicao.csv"))) {
  dc <- ler(saida("09c"), "noites_decomposicao.csv") |>
    dplyr::transmute(Noite = noite, Fonte = fonte,
                     `P sexta (%)` = num(p_sexta, 1), `P domingo 17h (%)` = num(p_domingo_17h, 1),
                     `P final (%)` = num(p_fim, 1), `Fim de semana (p.p.)` = num(fim_de_semana_pp, 1),
                     `Apuração (p.p.)` = num(apuracao_pp, 1), `Total (p.p.)` = num(total_pp, 1))
  salvar_tabela(dc, "Tabela_14_Noites_decomposicao", "Choque da noite eleitoral: fim de semana e apuração",
                "P sexta: fechamento da B3 de sexta-feira. P final: resultado (2º turno) ou fechamento da B3 de segunda-feira (1º turno).")
}

# ------------------------------------------------------------
# Tabela 15 — Estudo de eventos: divulgação de pesquisas
# ------------------------------------------------------------

if (file.exists(file.path(saida("12"), "event_study_regressions.csv"))) {
  es <- ler(saida("12"), "event_study_regressions.csv") |>
    dplyr::filter(defasagem == defasagem_divulgacao)
  t15 <- es |>
    dplyr::transmute(variavel = c(dp_pt = "P(PT)", nomes_y)[variavel],
                     janela = factor(janela, c("antes", "dia 0", "depois")),
                     valor = coef_ep(beta, ep, p)) |>
    tidyr::pivot_wider(names_from = variavel, values_from = valor) |>
    dplyr::arrange(janela) |>
    # N pode variar entre as janelas (eventos sem dado numa janela);
    # mostra o intervalo quando varia
    dplyr::bind_rows(es |> dplyr::group_by(variavel) |>
                       dplyr::summarise(valor = if (min(n_eventos) == max(n_eventos)) as.character(min(n_eventos))
                                        else paste0(min(n_eventos), "-", max(n_eventos)), .groups = "drop") |>
                       dplyr::transmute(variavel = c(dp_pt = "P(PT)", nomes_y)[variavel],
                                        janela = "N (eventos)", valor) |>
                       tidyr::pivot_wider(names_from = variavel, values_from = valor)) |>
    dplyr::select(janela, dplyr::any_of(c("P(PT)", unname(nomes_y)))) |>
    dplyr::rename(Janela = janela)
  salvar_tabela(t15, "Tabela_15_Estudo_eventos",
                "Estudo de eventos: resposta à surpresa das pesquisas do 2º turno",
                paste0("Coeficiente de CAR na surpresa da pesquisa (p.p., perspectiva do PT). Janelas: antes = [-",
                       janela_antes, ", -1], dia 0, depois = [+1, +", janela_depois, "] pregões. Ativos: retorno anormal ",
                       "(resíduo contra os controles); P(PT): variação sem ajuste. Efeito fixo de ciclo, EP Newey-West. ",
                       "*** p<0,01; ** p<0,05; * p<0,10."))
}

# ------------------------------------------------------------
# Tabela A3 (apêndice) — ARDL em níveis e teste Bounds
# ------------------------------------------------------------

if (file.exists(file.path(saida("09"), "ardl_levels_bounds.csv"))) {
  bd <- ler(saida("09"), "ardl_levels_bounds.csv") |>
    dplyr::transmute(Ciclo = ciclo, `Variável` = y, Regressores = regressores, Ordem = ordem, N = n,
                     `F (Bounds)` = num(bounds_F, 2), `p (Bounds)` = num(bounds_p),
                     `LP de P(PT)` = paste0(num(lr_p_pt), estrela(lr_p_pt_p)))
  salvar_tabela(bd, "Tabela_A3_Bounds", "ARDL em níveis e teste Bounds (caso 3), por ciclo")
}

# ------------------------------------------------------------
# Tabela A4 (apêndice) — Conferência com o pacote ARDL (09)
# ------------------------------------------------------------

if (file.exists(file.path(saida("09"), "ardl_package_by_cycle.csv"))) {
  pk <- ler(saida("09"), "ardl_package_by_cycle.csv") |>
    dplyr::transmute(Ciclo = ciclo, Ativo = nomes_y[y], `Ordem (auto_ardl, BIC)` = ordem,
                     `Soma dos coeficientes de ΔP(PT)` = num(soma_dp), N = as.character(n))
  salvar_tabela(pk, "Tabela_A4_Conferencia_pacote_ARDL",
                "Conferência com o pacote ARDL (auto_ardl), ciclo a ciclo")
}

# ------------------------------------------------------------
# Tabela A5 (apêndice) — Resumo dos diagnósticos (07)
# ------------------------------------------------------------
# Uma linha por ativo, amostra (empilhado ou ciclo) e modelo.

if (file.exists(file.path(saida("07"), "diagnostics_summary.csv"))) {
  rd <- ler(saida("07"), "diagnostics_summary.csv")
  a5 <- rd |>
    dplyr::mutate(y = factor(y, names(nomes_y)), espec = factor(espec, c("E", "E1", "D")),
                  amostra = factor(amostra, c("empilhado", sort(setdiff(unique(amostra), "empilhado"))))) |>
    dplyr::arrange(y, amostra, espec) |>
    dplyr::transmute(Ativo = nomes_y[as.character(y)], Amostra = as.character(amostra),
                     Modelo = as.character(espec), N = as.character(n),
                     `Breusch-Pagan (p)` = num(p_breusch_pagan),
                     `BG ordem 1 (p)` = num(p_bg_ordem1), `BG ordem 5 (p)` = num(p_bg_ordem5),
                     `RESET (p)` = num(p_reset), `RESET HAC (p)` = num(p_reset_hac),
                     `Maior GVIF ajustado` = paste0(num(maior_gvif_ajustado, 2), " (", variavel_maior_gvif, ")"),
                     `F global clássico (p)` = paste0(num(f_classico, 2), " (", num(p_f_classico), ")"),
                     `Wald global NW (p)` = paste0(num(f_wald_nw, 2), " (", num(p_wald_nw), ")"))
  salvar_tabela(a5, "Tabela_A5_Diagnosticos", "Resumo dos diagnósticos dos modelos E, E1 e D",
                paste("Hipóteses nulas: Breusch-Pagan (studentizado), homocedasticidade; BG (Breusch-Godfrey, com o resíduo",
                      "defasado dentro de cada ciclo), ausência de autocorrelação até a ordem indicada; RESET, os termos quadrático",
                      "e cúbico dos valores ajustados não acrescentam explicação (clássico: F do MQO; HAC: Wald com Newey-West na",
                      "mesma regressão auxiliar); F global e Wald global, todos os coeficientes de",
                      "inclinação iguais a zero (sem o intercepto e os efeitos fixos de ciclo). O F clássico usa a covariância do MQO",
                      "e é descritivo; o Wald usa Newey-West, sem cruzar a fronteira entre os ciclos. Os testes globais avaliam o",
                      "conjunto dos regressores e não o coeficiente de ΔP(PT). GVIF ajustado = GVIF^(1/(2·gl)); para um regressor",
                      "simples é a raiz do VIF, isto é, o fator de aumento do erro-padrão; entre parênteses, o termo mais afetado.",
                      "Nível de referência: 5%. Não rejeitar uma hipótese nula não comprova as hipóteses de Gauss-Markov; rejeitar a",
                      "homocedasticidade não invalida o MQO, pois a inferência usa Newey-West. O Breusch-Pagan supõe erros sem",
                      "autocorrelação; com autocorrelação, o seu p-valor é só indicativo."))
}

# ------------------------------------------------------------
# Tabela A6 (apêndice) — RESET com e sem os grandes choques (07)
# ------------------------------------------------------------

if (file.exists(file.path(saida("07"), "diagnostics_reset_investigacao.csv"))) {
  ri <- ler(saida("07"), "diagnostics_reset_investigacao.csv") |> dplyr::filter(amostra == "empilhado")
  a6 <- ri |>
    dplyr::mutate(y = factor(y, names(nomes_y)), espec = factor(espec, c("E", "E1", "D")),
                  versao = factor(versao, unique(versao))) |>
    dplyr::arrange(y, espec, versao) |>
    dplyr::transmute(Ativo = nomes_y[as.character(y)], Modelo = as.character(espec), `Versão` = as.character(versao),
                     N = as.character(n), `F (RESET)` = num(f_reset, 2), `p (RESET)` = num(p_reset),
                     `Rejeita a 5%` = ifelse(is.na(rejeita_5pct), "--", ifelse(rejeita_5pct, "sim", "não")),
                     `F (RESET HAC)` = num(f_reset_hac, 2), `p (RESET HAC)` = num(p_reset_hac),
                     `β de ΔP(PT)` = coef_ep(beta_dp_pt, ep_nw, p_beta))
  salvar_tabela(a6, "Tabela_A6_RESET_investigacao", "RESET na amostra original, sem os pregões pós-1º turno e sem as observações influentes (ciclos empilhados)",
                paste("H0 do RESET: os termos quadrático e cúbico dos valores ajustados não acrescentam explicação. RESET: F clássico",
                      "do MQO; RESET HAC: Wald com Newey-West na mesma regressão auxiliar. Sem pregões",
                      "pós-1º turno: mesma exclusão da análise de magnitude. Sem observações influentes: distância de Cook acima de",
                      "4/N ou |DFBETAS de ΔP(PT)| acima de 2/√N. A especificação é a mesma nas três versões; nenhum termo foi",
                      "acrescentado. Os pregões extremos permanecem na regressão principal.", nota_nw))
}

# ------------------------------------------------------------
# Tabelas A7 a A9 (apêndice) — Pregões pós-primeiro turno (09d)
# ------------------------------------------------------------
# Só importa e formata o que o 09d gravou; nada é reestimado.

if (file.exists(file.path(saida("09d"), "interacao_coeficientes.csv"))) {
  ic <- ler(saida("09d"), "interacao_coeficientes.csv")
  if (!"ep_beta_comum" %in% names(ic)) ic$ep_beta_comum <- NA_real_
  ic <- ic |> dplyr::filter(estimavel, comparacao_de_tres_eventos, is.finite(ep_beta_comum))
  if (nrow(ic)) {
    a7 <- ic |>
      dplyr::mutate(y = factor(y, names(nomes_y))) |> dplyr::arrange(y) |>
      dplyr::transmute(Ativo = nomes_y[as.character(y)],
                       `β comum` = paste0(num(beta_comum), " (", num(ep_beta_comum), ")"),
                       `δ interação` = paste0(num(delta), " (", num(ep_delta), ")"),
                       `β evento (β + δ)` = num(beta_evento),
                       `IC nominal de 95% do β evento` = paste0("[", num(ic_beta_evento_inf), "; ", num(ic_beta_evento_sup), "]"),
                       `θ dummy` = paste0(num(theta), " (", num(ep_theta), ")"),
                       `p Wald de δ (exploratório)` = num(p_wald_delta_exploratorio),
                       N = as.character(n), Eventos = as.character(n_eventos))
    salvar_tabela(a7, "Tabela_A7_Interacao_pos_primeiro_turno",
                  "Sensibilidade nos pregões comuns e nos primeiros pregões após o 1º turno (modelo de interação, exploratório)",
                  paste("Modelo E com a dummy do primeiro pregão após o 1º turno (θ) e a sua interação com ΔP(PT) (δ), ciclos",
                        "empilhados, efeito fixo de ciclo e controles (S\\&P 500, Treasury 10 anos, VIX). Erros-padrão Newey-West",
                        "entre parênteses; a variância de β + δ inclui a covariância entre os dois coeficientes. Há um evento por",
                        "eleição, três no total: erros-padrão, intervalo e p-valor de θ, δ e β + δ são nominais, sem garantia de",
                        "cobertura, e não são evidência de mudança de regime. δ impreciso também não prova que os regimes são iguais."))
  }
}

if (file.exists(file.path(saida("09d"), "leave_one_event_out.csv"))) {
  lo <- ler(saida("09d"), "leave_one_event_out.csv")
  a8 <- lo |>
    dplyr::mutate(y = factor(y, names(nomes_y))) |>
    dplyr::transmute(Ativo = nomes_y[as.character(y)], `Especificação` = especificacao, N = as.character(n),
                     `β de ΔP(PT)` = coef_ep(beta, ep_hac, p_value),
                     `IC 95%` = paste0("[", num(ic_inf), "; ", num(ic_sup), "]"),
                     `Diferença para o β original` = ifelse(excluidas == 0, "--", num(delta_beta)),
                     `Em EP do β original` = ifelse(excluidas == 0, "--", num(influencia_padronizada, 2)),
                     `Variação (%)` = ifelse(excluidas == 0, "--", num(influencia_pct, 1)))
  salvar_tabela(a8, "Tabela_A8_Leave_one_event_out",
                "Influência de cada primeiro pregão após o 1º turno no β do modelo E",
                paste("Modelo E reestimado sem cada pregão indicado, sobre a mesma amostra (as defasagens não são recalculadas).",
                      "Diferença: β sem o evento menos β original; 'Em EP': a mesma diferença em erros-padrão do β original (não é",
                      "teste de significância). Variação (%): complementar, mostrada só quando o β original supera um erro-padrão em",
                      "módulo, convenção descritiva. Mede sensibilidade à exclusão, não contribuição causal do evento.", nota_nw))
}

if (file.exists(file.path(saida("09d"), "interacao_estabilidade.csv"))) {
  es9 <- ler(saida("09d"), "interacao_estabilidade.csv")
  for (v in c("beta_comum", "delta", "beta_evento", "theta")) if (!v %in% names(es9)) es9[[v]] <- NA_real_
  a9 <- es9 |>
    dplyr::mutate(y = factor(y, names(nomes_y))) |>
    dplyr::transmute(Ativo = nomes_y[as.character(y)], Amostra = amostra, Eventos = as.character(n_eventos),
                     `β comum` = num(beta_comum), `δ interação` = num(delta), `β evento (β + δ)` = num(beta_evento),
                     `θ dummy` = num(theta), `Situação` = situacao)
  salvar_tabela(a9, "Tabela_A9_Interacao_estabilidade",
                "Modelo de interação reestimado sem cada evento (só estimativas pontuais)",
                "Com dois eventos, a dummy e a interação ajustam as duas observações exatamente; por isso não há erro-padrão nem p-valor. A tabela serve para ver quanto β + δ e δ mudam de um evento para outro.")
}

# ------------------------------------------------------------
# Tabelas A10 a A12 (apêndice) — Dummy dos pregões pós-1º turno (09e)
# ------------------------------------------------------------
# Só importa e formata o que o 09e gravou; nada é reestimado.

if (file.exists(file.path(saida("09e"), "dummy_modelos.csv"))) {
  dm <- ler(saida("09e"), "dummy_modelos.csv")
  ordem_m <- c("E", "E + D", "E + D + interação", "E sem os três eventos")
  a10 <- dm |>
    dplyr::mutate(y = factor(y, names(nomes_y)), modelo = factor(modelo, ordem_m)) |>
    dplyr::arrange(y, modelo) |>
    dplyr::transmute(Ativo = nomes_y[as.character(y)], Modelo = as.character(modelo),
                     N = as.character(n), Eventos = as.character(n_eventos),
                     `β de ΔP(PT)` = coef_ep(beta, ep_beta, p_beta),
                     `θ dummy` = ifelse(is.finite(theta), paste0(num(theta), " (", num(ep_theta), ")"), "--"),
                     `p nominal de θ` = num(p_theta_nominal),
                     `R² ajustado` = num(adj_r2), AIC = num(aic, 1), BIC = num(bic, 1),
                     `F global clássico (p)` = paste0(num(f_global_classico, 2), " (", num(p_f_global_classico), ")"),
                     `Wald global HAC (p)` = paste0(num(wald_global_hac, 2), " (", num(p_wald_global_hac), ")"),
                     `Defasagens NW` = as.character(nw_lag),
                     `Diferença do β para o E` = ifelse(modelo == "E", "--", num(delta_beta_vs_E)),
                     `Em EP do β do E` = ifelse(modelo == "E", "--", num(delta_beta_em_ep_de_E, 2)))
  salvar_tabela(a10, "Tabela_A10_Dummy_modelos",
                "Modelo E com dummy do primeiro pregão após o 1º turno: comparação de modelos (exploratório)",
                paste("E + D acrescenta ao modelo E uma dummy igual a 1 no primeiro pregão após o 1º turno de cada ciclo (θ);",
                      "β é a sensibilidade comum a todos os pregões. E + D + interação é o modelo da Tabela A7. Os três primeiros",
                      "modelos usam a mesma amostra, e AIC e BIC são comparáveis entre eles; o modelo sem os três eventos é análise",
                      "de sensibilidade amostral, sem AIC e BIC. θ é identificado por três pregões: o seu erro-padrão e o seu p-valor",
                      "são nominais e exploratórios. A diferença do β para o modelo E não é contribuição causal da dummy. F global e",
                      "Wald global: H0 de que todas as inclinações são zero (sem o intercepto e os efeitos fixos de ciclo).", nota_nw))
}

if (file.exists(file.path(saida("09e"), "dummy_diagnosticos.csv"))) {
  dd <- ler(saida("09e"), "dummy_diagnosticos.csv")
  a11 <- dd |>
    dplyr::mutate(y = factor(y, names(nomes_y)), modelo = factor(modelo, c("E", "E + D"))) |>
    dplyr::arrange(y, modelo) |>
    dplyr::transmute(Ativo = nomes_y[as.character(y)], Modelo = as.character(modelo), N = as.character(n),
                     `Breusch-Pagan (p)` = num(p_breusch_pagan),
                     `BG 1 (p)` = num(p_bg_ordem1), `BG 2 (p)` = num(p_bg_ordem2), `BG 3 (p)` = num(p_bg_ordem3),
                     `BG 4 (p)` = num(p_bg_ordem4), `BG 5 (p)` = num(p_bg_ordem5),
                     `RESET (p)` = num(p_reset_classico), `RESET HAC (p)` = num(p_reset_hac),
                     `Média do resíduo nos eventos` = num(media_residuo_eventos),
                     `Raiz do EQM nos eventos` = num(raiz_eqm_eventos),
                     `DP do resíduo nos pregões comuns` = num(dp_residuo_pregoes_comuns))
  salvar_tabela(a11, "Tabela_A11_Dummy_diagnosticos",
                "Diagnósticos dos resíduos: modelo E e modelo E com dummy, na mesma amostra",
                paste("Hipóteses nulas: Breusch-Pagan, homocedasticidade; BG (Breusch-Godfrey dentro do ciclo), ausência de",
                      "autocorrelação até a ordem indicada; RESET, os termos quadrático e cúbico dos valores ajustados não",
                      "acrescentam explicação (clássico: F do MQO; HAC: Wald com Newey-West). Com a dummy, a média do resíduo nos",
                      "três eventos é zero por construção; a raiz do erro quadrático médio mostra se o erro diminuiu ou só foi",
                      "redistribuído entre os eventos. Um teste que deixa de rejeitar não valida o modelo."))
}

if (file.exists(file.path(saida("09e"), "dummy_eventos_residuos_influencia.csv"))) {
  de <- ler(saida("09e"), "dummy_eventos_residuos_influencia.csv")
  a12 <- de |>
    dplyr::mutate(y = factor(y, names(nomes_y)), modelo = factor(modelo, c("E", "E + D"))) |>
    dplyr::arrange(y, ciclo, modelo) |>
    dplyr::transmute(Ativo = nomes_y[as.character(y)], Evento = paste0("pós-1º turno de ", ciclo),
                     Modelo = as.character(modelo), `ΔP (p.p.)` = num(dp_pt, 1),
                     Observado = num(observado), Ajustado = num(ajustado), `Resíduo` = num(residuo),
                     `Resíduo em DP dos pregões comuns` = num(residuo_em_dp_dos_comuns, 2),
                     Cook = num(cook, 4), `DFBETAS de ΔP(PT)` = num(dfbetas_dp_pt, 2))
  salvar_tabela(a12, "Tabela_A12_Dummy_eventos",
                "Resíduos e influência nos três primeiros pregões após o 1º turno, antes e depois da dummy",
                "DFBETAS: quantos erros-padrão o β muda ao retirar o pregão. Referências de influência alta: Cook acima de 4/N e |DFBETAS| acima de 2/√N. Ibovespa e dólar em %; DI em p.b.")
}

# ------------------------------------------------------------
# Figuras
# ------------------------------------------------------------

figuras <- tibble::tribble(
  ~origem,                                                       ~destino,
  file.path(saida("04"), "time_series.png"),            "Figura_1_Series.png",
  file.path(saida("04"), "dispersao_dp_respostas.png"), "Figura_2_Dispersao.png",
  file.path(saida("08"), "ccf_dp_pt.png"),                   "Figura_3_Correlacao_cruzada.png",
  file.path(saida("09"), "ardl_inverse_coefficients.png"),   "Figura_4_ARDL_invertido.png",
  file.path(saida("09b"), "comparacao_ciclos.png"),           "Figura_5_Comparacao_ciclos.png",
  file.path(saida("07"), "diag_empilhado_r_ibov_E_dfbetas.png"), "Figura_6a_DFBETAS_Ibovespa.png",
  file.path(saida("07"), "diag_empilhado_r_usd_E_dfbetas.png"),  "Figura_6b_DFBETAS_Dolar.png",
  file.path(saida("07"), "diag_empilhado_d_di1_E_dfbetas.png"),  "Figura_6c_DFBETAS_DI1.png",
  file.path(saida("07"), "diag_empilhado_d_di5_E_dfbetas.png"),  "Figura_6d_DFBETAS_DI5.png",
  file.path(saida("09c"), "noites_previsto_realizado.png"),   "Figura_7_Noites_previsto_realizado.png",
  file.path(saida("12"), "event_study_coefficients.png"),    "Figura_8_Estudo_eventos.png",
  file.path(saida("08"), "ccf_dp_pesq.png"),                 "Figura_A1_Correlacao_cruzada_pesquisas.png",
  file.path(saida("04"), "correlation_heatmap.png"),    "Figura_A2_Correlacoes.png",
  file.path(saida("04b"), "pesquisas_vs_mercado.png"),   "Figura_A3_Pesquisas_mercado.png",
  file.path(saida("04c"), "controles_extras_series.png"),      "Figura_A4_Controles_series.png",
  file.path(saida("04c"), "controles_extras_correlacoes.png"), "Figura_A5_Controles_correlacoes.png",
  file.path(saida("04c"), "decisoes_juros.png"),               "Figura_A6_Decisoes_juros.png",
  file.path(saida("11"), "var_irf_p_to_assets.png"),         "Figura_A7_VAR_IRF_P_para_ativos.png",
  file.path(saida("11"), "var_irf_assets_to_p.png"),         "Figura_A8_VAR_IRF_ativos_para_P.png",
  file.path(saida("07"), "diag_r_ibov_residuos_tempo.png"),  "Figura_A9a_Residuos_tempo_Ibovespa.png",
  file.path(saida("07"), "diag_r_usd_residuos_tempo.png"),   "Figura_A9b_Residuos_tempo_Dolar.png",
  file.path(saida("07"), "diag_d_di1_residuos_tempo.png"),   "Figura_A9c_Residuos_tempo_DI1.png",
  file.path(saida("07"), "diag_d_di5_residuos_tempo.png"),   "Figura_A9d_Residuos_tempo_DI5.png",
  file.path(saida("09d"), "interacao_beta_comum_evento.png"), "Figura_A10_Interacao_pos_primeiro_turno.png",
  file.path(saida("09d"), "leave_one_event_out.png"),         "Figura_A11_Leave_one_event_out.png",
  file.path(saida("09e"), "dummy_betas.png"),                 "Figura_A12_Dummy_betas.png",
  file.path(saida("09e"), "dummy_r_ibov_residuos_tempo.png"), "Figura_A13a_Dummy_residuos_tempo_Ibovespa.png",
  file.path(saida("09e"), "dummy_r_usd_residuos_tempo.png"),  "Figura_A13b_Dummy_residuos_tempo_Dolar.png",
  file.path(saida("09e"), "dummy_d_di1_residuos_tempo.png"),  "Figura_A13c_Dummy_residuos_tempo_DI1.png",
  file.path(saida("09e"), "dummy_d_di5_residuos_tempo.png"),  "Figura_A13d_Dummy_residuos_tempo_DI5.png",
  file.path(saida("09e"), "dummy_residuos_eventos.png"),      "Figura_A14_Dummy_residuos_eventos.png"
)
# Se a figura de origem não existe nesta execução, a cópia antiga é
# apagada da pasta final, para não ficar uma figura de outra rodada.
purrr::pwalk(figuras, function(origem, destino) {
  alvo <- file.path(figuras_dir, destino)
  if (file.exists(origem)) file.copy(origem, alvo, overwrite = TRUE)
  else {
    if (file.exists(alvo)) file.remove(alvo)
    warning("Figura não encontrada (não incluída na pasta final): ", origem, call. = FALSE)
  }
})

# Arquivos numerados de execuções anteriores que esta execução não
# gerou (tabela ou figura renomeada, ou cuja origem deixou de existir)
sobras <- c(
  file.path(tabelas_dir, setdiff(list.files(tabelas_dir, pattern = "^Tabela_.*\\.(csv|tex)$"), tabelas_geradas)),
  file.path(figuras_dir, setdiff(list.files(figuras_dir, pattern = "^Figura_.*\\.png$"), figuras$destino))
)
if (length(sobras)) {
  file.remove(sobras)
  message("Arquivos antigos removidos de output/13_saida: ", paste(basename(sobras), collapse = ", "))
}

message("13_tables_figures.R concluído com sucesso.")
