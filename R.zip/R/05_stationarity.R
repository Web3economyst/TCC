# ============================================================
# Script  : 05_stationarity.R
#
# Objetivo:
#   Descrever o comportamento das séries, ciclo a ciclo, em nível
#   e em variação, com ADF, Phillips-Perron e KPSS lidos em
#   conjunto.
#
#   Por que os modelos usam variações: a pergunta do trabalho é a
#   sensibilidade dos preços a MUDANÇAS na expectativa eleitoral.
#   Informação nova move o preço no dia em que chega; por isso a
#   variável explicada é o retorno (ou a variação da taxa) e a
#   explicativa é ΔP(PT). A especificação vem dessa leitura
#   teórica, não do resultado dos testes.
#
#   O papel dos testes é de conferência: ver se as variações usadas
#   nos scripts 06 a 10 se comportam como estacionárias, condição
#   para a inferência por MQO com Newey-West, e descrever os
#   níveis para o complemento em níveis (Bounds, 09, apêndice).
#   Em 2018, com cerca de 30 pregões, os testes têm pouco poder e
#   muitos resultados saem inconclusivos.
#
# Defasagens:
#   ADF: máximo de trunc(4 * (T/100)^(1/4)) por série e ciclo,
#   a mesma regra que o PP e o KPSS usam em lags = "short";
#   o número dentro desse limite é escolhido por AIC e por BIC.
#
# Log-preços: testados com tendência (especificação principal)
#   e também sem tendência, para comparação.
#
# Leitura dos testes:
#   ADF e PP : H0 = raiz unitária. Rejeitar é evidência contra a
#              raiz unitária; não rejeitar NÃO prova que ela existe.
#   KPSS     : H0 = estacionariedade. Rejeitar é evidência contra
#              a estacionariedade especificada.
#   Resumo por série (leitura), com os três testes juntos:
#     ADF e PP rejeitam, KPSS não  -> evidência de estacionariedade
#     ADF e PP não rejeitam, KPSS rejeita -> evidência de raiz unitária
#     demais casos -> inconclusivo (com o motivo)
#   Nível e variação lado a lado em stationarity_orders.csv.
#
# Entrada : data/processed/model_data_daily.rds
# Saída   : output/05_saida/{adf,pp,kpss}_results.csv
#           output/05_saida/stationarity_summary.csv
#           output/05_saida/stationarity_orders.csv
#
# Próximo script: 06_models.R
# ============================================================

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

saida_dir <- saida("05")

model_data <- load_object(model_data_file)
aviso_simulado(model_data)

# Especificação: tendência para log-preços; constante para os demais
especificacao <- tibble::tribble(
  ~variable, ~forma,     ~adf,    ~kpss,
  "p_pt",    "nível",    "drift", "mu",
  "l_ibov",  "nível",    "trend", "tau",
  "l_ibov",  "nível sem tendência", "drift", "mu",
  "l_usd",   "nível",    "trend", "tau",
  "l_usd",   "nível sem tendência", "drift", "mu",
  "di1",     "nível",    "drift", "mu",
  "di5",     "nível",    "drift", "mu",
  "l_spx",   "nível",    "trend", "tau",
  "l_spx",   "nível sem tendência", "drift", "mu",
  "ust10",   "nível",    "drift", "mu",
  "l_vix",   "nível",    "drift", "mu",
  "dp_pt",   "variação", "drift", "mu",
  "r_ibov",  "variação", "drift", "mu",
  "r_usd",   "variação", "drift", "mu",
  "d_di1",   "variação", "drift", "mu",
  "d_di5",   "variação", "drift", "mu",
  "r_spx",   "variação", "drift", "mu",
  "d_ust10", "variação", "drift", "mu",
  "r_vix",   "variação", "drift", "mu"
)

# ------------------------------------------------------------
# Funções
# ------------------------------------------------------------

lag_max <- function(n) trunc(4 * (n / 100)^(1 / 4))

run_adf <- function(series, type, criterion) {
  x <- as.numeric(na.omit(series))
  pmax <- lag_max(length(x))
  test <- urca::ur.df(y = x, type = type, lags = pmax, selectlags = criterion)
  nm <- rownames(test@cval)[1]
  stat <- unname(test@teststat[1, nm]); cv <- test@cval[nm, ]
  escolhidas <- sum(grepl("z.diff.lag", rownames(test@testreg$coefficients)))
  tibble::tibble(teste = paste0("ADF-", criterion), n = length(x), lags_max = pmax,
                 lags_usadas = escolhidas, estatistica = stat, cv_5 = cv["5pct"],
                 rejeita_h0 = stat < cv["5pct"],
                 decisao = ifelse(stat < cv["5pct"], "rejeita raiz unitária", "não rejeita raiz unitária"))
}

run_pp <- function(series, type) {
  x <- as.numeric(na.omit(series))
  test <- urca::ur.pp(x = x, type = "Z-tau",
                      model = ifelse(type == "drift", "constant", "trend"), lags = "short")
  stat <- unname(test@teststat); cv <- test@cval[1, ]
  tibble::tibble(teste = "PP", n = length(x), lags_max = lag_max(length(x)),
                 lags_usadas = lag_max(length(x)), estatistica = stat, cv_5 = cv["5pct"],
                 rejeita_h0 = stat < cv["5pct"],
                 decisao = ifelse(stat < cv["5pct"], "rejeita raiz unitária", "não rejeita raiz unitária"))
}

run_kpss <- function(series, type) {
  x <- as.numeric(na.omit(series))
  test <- urca::ur.kpss(y = x, type = type, lags = "short")
  stat <- unname(test@teststat); cv <- test@cval[1, ]
  # KPSS: H0 = estacionária (em torno da constante ou da tendência).
  tibble::tibble(teste = "KPSS", n = length(x), lags_max = lag_max(length(x)),
                 lags_usadas = lag_max(length(x)), estatistica = stat, cv_5 = cv["5pct"],
                 rejeita_h0 = stat > cv["5pct"],
                 decisao = ifelse(stat > cv["5pct"], "rejeita estacionariedade", "não rejeita estacionariedade"))
}

# ------------------------------------------------------------
# Rodar por ciclo
# ------------------------------------------------------------

resultados <- tidyr::expand_grid(ciclo = sort(unique(model_data$ciclo)), especificacao) |>
  dplyr::mutate(res = purrr::pmap(list(ciclo, variable, adf, kpss), function(cc, v, a, k) {
    x <- model_data |> dplyr::filter(ciclo == cc) |> dplyr::pull(v)
    if (sum(is.finite(x)) < 30) return(NULL)
    dplyr::bind_rows(run_adf(x, a, "AIC"), run_adf(x, a, "BIC"), run_pp(x, a), run_kpss(x, k))
  })) |>
  tidyr::unnest(res)

export_table(resultados |> dplyr::filter(grepl("ADF", teste)) |> format_table(),
             file.path(saida_dir, "adf_results.csv"))
export_table(resultados |> dplyr::filter(teste == "PP") |> format_table(),
             file.path(saida_dir, "pp_results.csv"))
export_table(resultados |> dplyr::filter(teste == "KPSS") |> format_table(),
             file.path(saida_dir, "kpss_results.csv"))

stationarity_summary <- resultados |>
  dplyr::group_by(ciclo, variable, forma) |>
  dplyr::mutate(n = max(n)) |>
  dplyr::ungroup() |>
  dplyr::select(ciclo, variable, forma, n, teste, rejeita_h0) |>
  tidyr::pivot_wider(names_from = teste, values_from = rejeita_h0) |>
  dplyr::rename(adf_aic_rejeita_ru = `ADF-AIC`, adf_bic_rejeita_ru = `ADF-BIC`,
                pp_rejeita_ru = PP, kpss_rejeita_estac = KPSS) |>
  dplyr::mutate(
    leitura = dplyr::case_when(
      adf_aic_rejeita_ru != pp_rejeita_ru                         ~ "inconclusivo: ADF e PP discordam",
      adf_aic_rejeita_ru & pp_rejeita_ru & !kpss_rejeita_estac    ~ "evidência de estacionariedade",
      !adf_aic_rejeita_ru & !pp_rejeita_ru & kpss_rejeita_estac   ~ "evidência de raiz unitária",
      adf_aic_rejeita_ru & pp_rejeita_ru & kpss_rejeita_estac     ~ "inconclusivo: testes em conflito",
      TRUE                                                        ~ "inconclusivo: nenhum teste rejeita"
    )
  )

export_table(stationarity_summary, file.path(saida_dir, "stationarity_summary.csv"))

# Nível e variação da mesma série, lado a lado. A série só é dita
# compatível com I(1) quando há evidência de raiz unitária no nível
# E de estacionariedade na variação; não rejeitar a raiz unitária,
# sozinho, não classifica a série.
pares <- c(p_pt = "dp_pt", l_ibov = "r_ibov", l_usd = "r_usd", di1 = "d_di1", di5 = "d_di5",
           l_spx = "r_spx", ust10 = "d_ust10", l_vix = "r_vix")

stationarity_orders <- stationarity_summary |>
  dplyr::filter(forma == "nível") |>
  dplyr::transmute(ciclo, serie = variable, n_nivel = n, leitura_nivel = leitura,
                   variacao = unname(pares[variable])) |>
  dplyr::left_join(
    stationarity_summary |> dplyr::filter(forma == "variação") |>
      dplyr::transmute(ciclo, variacao = variable, leitura_variacao = leitura),
    by = c("ciclo", "variacao")
  ) |>
  dplyr::mutate(
    conjunto = dplyr::case_when(
      leitura_nivel == "evidência de estacionariedade" ~ "compatível com I(0)",
      leitura_nivel == "evidência de raiz unitária" &
        leitura_variacao == "evidência de estacionariedade" ~ "compatível com I(1)",
      TRUE ~ "inconclusivo"
    )
  )

export_table(stationarity_orders, file.path(saida_dir, "stationarity_orders.csv"))

cat("\n========== ESTACIONARIEDADE ==========\n")
print(stationarity_summary, n = Inf, width = Inf)
cat("\n========== NÍVEL E VARIAÇÃO ==========\n")
print(stationarity_orders, n = Inf, width = Inf)
message("05_stationarity.R concluído com sucesso.")
