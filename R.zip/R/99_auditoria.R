# ============================================================
# Script  : 99_auditoria.R
#
# Objetivo:
#   Conferir a base inteira antes de escrever os resultados. Não
#   estima nada: só procura problemas de dados e de alinhamento e
#   grava um relatório em output/99_saida/auditoria_base.txt.
#
#   A. Calendário: pregões por ciclo, datas repetidas, buracos.
#   B. Horário de cada série (probabilidade, dólar, DI, EUA).
#   C. Probabilidade: faixa, dias "velhos", 17h x 23h59, Betfair no
#      corte (há quanto tempo foi a última atualização do livro).
#   D. Valores repetidos (série parada) por variável e ciclo.
#   E. Variações extremas (mais de 5 desvios-padrão).
#   F. Dólar: contrato usado, dias de troca de vencimento, comparação
#      com a PTAX e com o Yahoo.
#   G. DI: faixa, inclinação 5a - 1a, saltos.
#   H. Noites eleitorais: datas e sinais.
#   I. Pesquisas: cobertura e defasagem de divulgação.
#   J. Dados faltantes nas variações usadas nos modelos.
#
# Entrada : data/processed/*.rds, data/raw/*.rds, data/raw/eleitoral/
# Saída   : output/99_saida/auditoria_base.txt
# ============================================================

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

saida_dir <- saida("99")

options(width = 160, pillar.width = 160)
arq_saida <- file.path(saida_dir, "auditoria_base.txt")
sink(arq_saida, split = TRUE)


base <- load_object(clean_data_file)
md   <- load_object(model_data_file)
titulo <- function(x) cat("\n\n==================== ", x, " ====================\n", sep = "")
alerta <- character(0)
avisar <- function(...) { msg <- paste0(...); alerta <<- c(alerta, msg); cat(">>> ATENÇÃO: ", msg, "\n", sep = "") }

# ------------------------------------------------------------
titulo("A. Calendário")
# ------------------------------------------------------------
cal <- md |>
  dplyr::group_by(ciclo) |>
  dplyr::summarise(pregoes = dplyr::n(), primeiro = min(data), ultimo = max(data),
                   repetidas = sum(duplicated(data)),
                   fim_de_semana = sum(lubridate::wday(data, week_start = 1) > 5),
                   maior_buraco_dias = max(as.numeric(diff(data))), .groups = "drop")
print(cal)
if (any(cal$repetidas > 0)) avisar("datas repetidas no calendário")
if (any(cal$fim_de_semana > 0)) avisar("pregões em fim de semana")
if (any(cal$maior_buraco_dias > 5)) avisar("buraco de mais de 5 dias entre pregões dentro de um ciclo")
buracos <- md |> dplyr::group_by(ciclo) |> dplyr::mutate(salto = as.numeric(data - dplyr::lag(data))) |>
  dplyr::filter(salto > 4) |> dplyr::select(ciclo, data, salto)
cat("\nIntervalos de mais de 4 dias corridos entre pregões (feriados prolongados):\n"); print(buracos, n = Inf)

# ------------------------------------------------------------
titulo("B. Horário de referência de cada série")
# ------------------------------------------------------------
cat("Probabilidade (horario_p) por ciclo:\n"); print(md |> dplyr::count(ciclo, horario_p))
if (any(md$horario_p != "fechamento_b3")) avisar("há ciclo com a probabilidade do fim do dia (23h59)")
cat("\nFechamento da B3 usado no corte (17h com horário de verão nos EUA, 18h sem):\n")
print(md |> dplyr::mutate(hora = hora_fechamento_b3(data)) |> dplyr::count(ciclo, hora))
cat("\nFonte do dólar principal: ", attr(md, "fonte_usd") %||% "?", "; alternativa: ", attr(md, "fonte_usd_alt") %||% "?", "\n", sep = "")
if (!identical(attr(md, "fonte_usd"), "usd_b3")) avisar("o dólar principal não é o dólar futuro da B3")
di_raw <- if (file.exists(di_raw_file)) load_object(di_raw_file) else NULL
cat("Fonte do DI: ", attr(di_raw, "fonte") %||% "?", "\n", sep = "")
dol_raw <- if (file.exists(dolar_raw_file)) load_object(dolar_raw_file) else NULL
cat("Fonte do dólar: ", attr(dol_raw, "fonte") %||% "?", "\n", sep = "")

# ------------------------------------------------------------
titulo("C. Probabilidade de vitória do PT")
# ------------------------------------------------------------
print(md |> dplyr::group_by(ciclo) |>
        dplyr::summarise(min = min(p_pt, na.rm = TRUE), max = max(p_pt, na.rm = TRUE),
                         fora_0_1 = sum(p_pt < 0 | p_pt > 1, na.rm = TRUE),
                         sem_valor = sum(!is.finite(p_pt)),
                         copiada_de_dia_anterior = sum(defasagem_prob_dias > 0, na.rm = TRUE),
                         mais_de_3_dias = sum(defasagem_prob_dias > 3, na.rm = TRUE), .groups = "drop"))
cat("\nFechamento da B3 x fim do dia (23h59): diferença em p.p.\n")
comp <- md |> dplyr::filter(!pos_2t) |>
  dplyr::mutate(dif = 100 * (p_pt - p_pt_fimdia))
print(comp |> dplyr::group_by(ciclo) |>
        dplyr::summarise(media_abs = mean(abs(dif), na.rm = TRUE), max_abs = max(abs(dif), na.rm = TRUE),
                         cor_variacoes = stats::cor(dp_pt, dp_pt_fimdia, use = "complete.obs"), .groups = "drop"))
cat("\nDias com diferença acima de 10 p.p. entre as duas medidas:\n")
print(comp |> dplyr::filter(abs(dif) > 10) |> dplyr::select(ciclo, data, p_pt, p_pt_fimdia, dif), n = Inf)

for (ano in c(2018, 2022)) {
  arq <- file.path(electoral_raw_dir, paste0("betfair_", ano, "_diario_fechamento_b3.csv"))
  if (!file.exists(arq)) { avisar("não achei ", basename(arq)); next }
  bf <- readr::read_csv(arq, show_col_types = FALSE)
  pt <- strsplit(ciclos$cand_pt[ciclos$ciclo == ano], ";")[[1]]
  bf_pt <- bf |> dplyr::filter(nome_clean %in% pt, is.finite(prob_norm))
  if ("ultima_atualizacao_brt" %in% names(bf_pt)) {
    bf_pt <- bf_pt |>
      dplyr::mutate(ultima = as.POSIXct(ultima_atualizacao_brt, tz = "America/Sao_Paulo"),
                    corte = as.POSIXct(paste(data_brt, hora_corte), tz = "America/Sao_Paulo"),
                    horas_desde = as.numeric(difftime(corte, ultima, units = "hours")))
    cat("\nBetfair ", ano, " (", paste(pt, collapse = "+"), "): horas entre a última atualização do livro e o corte\n", sep = "")
    print(bf_pt |> dplyr::filter(data_brt >= ciclos$inicio[ciclos$ciclo == ano]) |>
            dplyr::summarise(dias = dplyr::n(), mediana_h = stats::median(horas_desde, na.rm = TRUE),
                             p90_h = stats::quantile(horas_desde, .9, na.rm = TRUE),
                             mais_de_24h = sum(horas_desde > 24, na.rm = TRUE),
                             depois_do_corte = sum(horas_desde < 0, na.rm = TRUE)))
    if (any(bf_pt$horas_desde < 0, na.rm = TRUE)) avisar("Betfair ", ano, ": atualização depois do horário de corte")
    cat("Fonte do preço no corte (mid = meio do spread; limite = só um lado do livro):\n")
    print(bf_pt |> dplyr::filter(data_brt >= ciclos$inicio[ciclos$ciclo == ano]) |> dplyr::count(nome_clean, prob_ref_fonte))
  }
}

# ------------------------------------------------------------
titulo("D. Séries paradas (valor igual ao do pregão anterior)")
# ------------------------------------------------------------
niveis <- c("p_pt", "ibov", "usd_b3", "ptax", "usdbrl", "di1", "di5", "spx", "ust10", "vix")
parados <- purrr::map_dfr(niveis, function(v) {
  base |> dplyr::filter(data >= inicio) |> dplyr::group_by(ciclo) |>
    dplyr::summarise(variavel = v, n = dplyr::n(),
                     iguais_ao_anterior = sum(.data[[v]] == dplyr::lag(.data[[v]]), na.rm = TRUE),
                     sem_valor = sum(!is.finite(.data[[v]])), .groups = "drop")
}) |> dplyr::mutate(pct_iguais = round(100 * iguais_ao_anterior / n, 1))
print(parados |> dplyr::arrange(variavel, ciclo), n = Inf)
cat("(É esperado: P(PT) parada em dias sem negociação; S&P/Treasury/VIX parados em feriados dos EUA;\n",
    " usdbrl (Yahoo) parado nos dias em que falta cotação. Ibovespa, dólar futuro e DI não deveriam parar.)\n")
for (v in c("ibov", "usd_b3", "di1", "di5")) {
  x <- parados |> dplyr::filter(variavel == v)
  if (any(x$pct_iguais > 2)) avisar(v, " parado em mais de 2% dos pregões de algum ciclo")
}
cat("\nDias com DI ou dólar futuro iguais ao pregão anterior:\n")
print(base |> dplyr::filter(data >= inicio) |> dplyr::group_by(ciclo) |>
        dplyr::filter(di1 == dplyr::lag(di1) | di5 == dplyr::lag(di5) | usd_b3 == dplyr::lag(usd_b3)) |>
        dplyr::select(ciclo, data, di1, di5, usd_b3), n = Inf)

# ------------------------------------------------------------
titulo("E. Variações extremas (mais de 5 desvios-padrão no ciclo)")
# ------------------------------------------------------------
vars_var <- c("dp_pt", "dp_pesq", "r_ibov", "r_usd", "r_usd_alt", "d_di1", "d_di5", "r_spx", "d_ust10", "r_vix")
ext <- purrr::map_dfr(vars_var, function(v) {
  md |> dplyr::group_by(ciclo) |>
    dplyr::mutate(z = (.data[[v]] - mean(.data[[v]], na.rm = TRUE)) / stats::sd(.data[[v]], na.rm = TRUE)) |>
    dplyr::ungroup() |> dplyr::filter(abs(z) > 5) |>
    dplyr::transmute(variavel = v, ciclo, data, valor = .data[[v]], z = round(z, 1), noite_eleicao)
})
print(ext |> dplyr::arrange(variavel, ciclo, data), n = Inf)
fora_noite <- ext |> dplyr::filter(noite_eleicao == 0, variavel %in% c("r_ibov", "r_usd", "d_di1", "d_di5"))
if (nrow(fora_noite)) cat("\n(Confira os casos fora das noites eleitorais acima: são notícias conhecidas ou erro de dado?)\n")

# ------------------------------------------------------------
titulo("F. Dólar futuro")
# ------------------------------------------------------------
if (!is.null(dol_raw)) {
  cat("Contratos usados (contrato: nº de pregões):\n")
  print(dol_raw |> dplyr::count(contrato) |> dplyr::arrange(dplyr::desc(n)), n = 60)
  if ("vencimento" %in% names(dol_raw)) {
    cat("\nDias até o vencimento do contrato usado:\n")
    print(summary(as.numeric(dol_raw$vencimento - dol_raw$data)))
    if (any(as.numeric(dol_raw$vencimento - dol_raw$data) <= 5, na.rm = TRUE))
      avisar("dólar: há dia usando contrato perto do vencimento")
  }
  cat("\nRetornos exatamente zero: ", sum(dol_raw$r_dol == 0, na.rm = TRUE), "\n", sep = "")
  if (sum(dol_raw$r_dol == 0, na.rm = TRUE) > 5) avisar("dólar futuro com muitos retornos exatamente zero")
}
cmp <- base |> dplyr::filter(data >= inicio) |> dplyr::arrange(ciclo, data) |> dplyr::group_by(ciclo) |>
  dplyr::mutate(r_ptax = 100 * log(ptax / dplyr::lag(ptax)), r_yahoo = 100 * log(usdbrl / dplyr::lag(usdbrl))) |>
  dplyr::ungroup()
cat("\nCorrelação das variações diárias do dólar futuro com a PTAX e com o Yahoo, por ciclo:\n")
print(cmp |> dplyr::group_by(ciclo) |>
        dplyr::summarise(cor_ptax = stats::cor(r_dol, r_ptax, use = "complete.obs"),
                         cor_yahoo = stats::cor(r_dol[!usdbrl_repetido], r_yahoo[!usdbrl_repetido], use = "complete.obs"),
                         dp_futuro = stats::sd(r_dol, na.rm = TRUE), dp_ptax = stats::sd(r_ptax, na.rm = TRUE),
                         .groups = "drop"))
cat("\n10 maiores diferenças entre dólar futuro e PTAX (p.p. de variação):\n")
print(cmp |> dplyr::mutate(dif = r_dol - r_ptax) |> dplyr::arrange(dplyr::desc(abs(dif))) |>
        dplyr::select(ciclo, data, r_dol, r_ptax, dif) |> head(10))
cat("(Diferenças grandes são esperadas em dias de notícia à tarde: a PTAX fecha às 13h, o futuro no fim do pregão.)\n")

# ------------------------------------------------------------
titulo("G. DI")
# ------------------------------------------------------------
print(base |> dplyr::filter(data >= inicio) |> dplyr::group_by(ciclo) |>
        dplyr::summarise(di1_min = min(di1, na.rm = TRUE), di1_max = max(di1, na.rm = TRUE),
                         di5_min = min(di5, na.rm = TRUE), di5_max = max(di5, na.rm = TRUE),
                         inclinacao_media_pb = 1e4 * mean(di5 - di1, na.rm = TRUE), .groups = "drop"))
if (any(base$di1 < 0.01 | base$di1 > 0.3, na.rm = TRUE)) avisar("DI 1 ano fora da faixa 1%-30%")

# ------------------------------------------------------------
titulo("H. Noites eleitorais")
# ------------------------------------------------------------
print(md |> dplyr::filter(noite_eleicao == 1) |>
        dplyr::select(ciclo, data, data_1t, data_2t, p_pt, p_pt_res, dp_pt, dp_pt_res, r_ibov, r_usd, d_di1, d_di5))
cat("(No pós-2º turno, p_pt e dp_pt ficam NA de propósito: o valor é o resultado, em p_pt_res.)\n")
n_noites <- md |> dplyr::filter(noite_eleicao == 1) |> dplyr::count(ciclo)
if (any(n_noites$n != 2)) avisar("algum ciclo não tem exatamente 2 noites eleitorais")
cat("\nPrimeiro pregão depois de cada turno deve ser o dia útil seguinte:\n")
print(ciclos |> dplyr::select(ciclo, data_1t, data_2t, fim))

# ------------------------------------------------------------
titulo("I. Pesquisas")
# ------------------------------------------------------------
print(md |> dplyr::group_by(ciclo) |>
        dplyr::summarise(pregoes = dplyr::n(), com_pesquisa = sum(is.finite(p_pesq)),
                         primeiro = min(data[is.finite(p_pesq)]), ultimo = max(data[is.finite(p_pesq)]),
                         dias_sem_mudanca = sum(dp_pesq == 0, na.rm = TRUE), .groups = "drop"))
cat("Defasagem de divulgação aplicada à probabilidade das pesquisas: ", defasagem_divulgacao, " dia(s)\n", sep = "")

# ------------------------------------------------------------
titulo("J. Faltantes nas variações dos modelos")
# ------------------------------------------------------------
print(md |> dplyr::group_by(ciclo) |>
        dplyr::summarise(dplyr::across(dplyr::all_of(intersect(vars_var, names(md))), ~ sum(!is.finite(.x))),
                         .groups = "drop") |> as.data.frame())

titulo("RESUMO")
if (length(alerta)) cat(paste0("- ", alerta), sep = "\n") else cat("Nenhum alerta.\n")
sink()
message("Relatório: ", normalizePath(arq_saida))
