# ============================================================
# Script  : 09c_noites_eleitorais.R
#
# Objetivo:
#   Testar a sensibilidade estimada na campanha nas noites eleitorais
#   (pregões seguintes ao 1º e ao 2º turno de cada ciclo).
#
#   Na apuração, a probabilidade muda pela contagem de votos já
#   depositados, com a B3 fechada (domingo à noite). A reação prevista
#   pela sensibilidade da campanha é comparada à reação observada.
#
#   1. Choque de cada noite: ΔP da noite (dp_pt_res). No 1º turno é a
#      variação da probabilidade; no 2º turno, o resultado (100 ou 0)
#      menos a probabilidade do pregão anterior.
#   2. Previsão: o modelo principal (mesmas ordens do ARDL empilhado do
#      09) é reestimado SEM a noite prevista e aplicado ao choque da
#      noite e aos controles do dia:
#        previsto = x0' b,   ep_prev = sqrt(x0' V_NW x0 + s^2)
#      x0' V_NW x0: incerteza dos coeficientes (Newey-West). s^2:
#      variância residual MÉDIA da campanha. O NW não corrige essa
#      parcela: supõe-se que a noite tem a variância de um dia comum,
#      o que subestima o intervalo numa mudança de regime. O
#      intervalo é referência descritiva, não teste de rejeição.
#      Intervalo: previsto ± t crítico × ep_prev.
#      fora da estimação principal; os pós-1º turno estão na amostra
#      principal e, aqui, saem da estimação da sua própria previsão.
#      Duas versões: β empilhado (três ciclos) e β do próprio ciclo.
#   3. Também se reporta o previsto só pela probabilidade (β × ΔP), sem
#      a contribuição dos controles e do efeito fixo.
#   4. Decomposição do choque (se os arquivos existirem): quanto da
#      variação de sexta a segunda veio do fim de semana (sexta no
#      fechamento da B3 -> domingo 17h) e quanto da apuração (domingo
#      17h -> segunda no fechamento ou resultado).
#        2018 e 2022: betfair_noites_resumo.csv (betfair_noites_eleitorais.R)
#        2026: polymarket_serie_horaria.csv
#
# Entrada : data/processed/model_data_daily.rds, output/09_saida/ardl_main.rds
#           (opcional) data/raw/eleitoral/betfair_noites_resumo.csv
#           (opcional) data/raw/eleitoral/polymarket_serie_horaria.csv
# Saída   : output/09c_saida/noites_previsto_realizado.csv
#           output/09c_saida/noites_decomposicao.csv
#           output/09c_saida/noites_previsto_realizado.png
#
# Próximo script: 09d_interacao_eventos.R
# ============================================================

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

saida_dir <- saida("09c")

model_data <- load_object(model_data_file)
aviso_simulado(model_data)

base_ardl <- load_object(file.path(saida("09"), "ardl_main.rds"))$empilhado
respostas_disp <- names(respostas)[purrr::map_lgl(names(respostas), ~ sum(is.finite(model_data[[.x]])) > 50)]

# ------------------------------------------------------------
# 1. As noites e o choque de cada uma
# ------------------------------------------------------------

noites <- model_data |>
  dplyr::filter(noite_eleicao == 1) |>
  dplyr::transmute(ciclo, data,
                   turno = dplyr::if_else(pos_1t == 1, "1º turno", "2º turno"),
                   noite = paste(ciclo, turno),
                   choque_pp = dp_pt_res) |>
  dplyr::arrange(ciclo, data)

if (!nrow(noites)) stop("Nenhuma noite eleitoral na base (noite_eleicao == 1).")

# ------------------------------------------------------------
# 2. Previsão de cada noite, sem a própria noite na estimação
# ------------------------------------------------------------

prever_noite <- function(y, n, amostra) {
  p0 <- base_ardl[[y]]$p; q0 <- base_ardl[[y]]$q
  d <- if (amostra == "empilhado") model_data else dplyr::filter(model_data, ciclo == n$ciclo)

  # estimação: a noite prevista sai (y e ΔP ficam NA nesse pregão)
  d_est <- d |>
    dplyr::mutate(fora = ciclo == n$ciclo & data == n$data,
                  dplyr::across(dplyr::all_of(c(y, "dp_pt")), ~ dplyr::if_else(fora, NA_real_, .x))) |>
    dplyr::select(-fora)
  r <- rodar_leadlag(d_est, y, "dp_pt", amostra, p = p0, q = q0)
  m <- r$modelo

  # linha da noite com o choque da noite no lugar de ΔP
  d_pred <- d |>
    dplyr::mutate(dp_pt = dplyr::if_else(ciclo == n$ciclo & data == n$data, dp_pt_res, dp_pt)) |>
    add_lags(y, max(p0, 1)) |>
    add_lags("dp_pt", max(q0, 1)) |>
    dplyr::filter(ciclo == n$ciclo, data == n$data)
  x0 <- stats::model.matrix(stats::delete.response(stats::terms(m)), d_pred, xlev = m$xlevels)
  b <- stats::coef(m)
  x0 <- x0[, names(b), drop = FALSE]
  V <- vcov_nw(m)[names(b), names(b)]
  prev <- as.numeric(x0 %*% b)
  ep_fit <- sqrt(as.numeric(x0 %*% V %*% t(x0)))
  s <- summary(m)$sigma
  ep_prev <- sqrt(ep_fit^2 + s^2)
  beta <- b[["dp_pt"]]; ep_beta <- sqrt(V["dp_pt", "dp_pt"]); tc <- ic_t(m)
  real <- d_pred[[y]]

  tibble::tibble(
    noite = n$noite, ciclo = n$ciclo, turno = n$turno, data = n$data, y = y, amostra_beta = amostra,
    choque_pp = n$choque_pp, beta = beta, ep_beta = ep_beta,
    previsto_so_prob = beta * n$choque_pp,
    previsto = prev, ic_inf = prev - tc * ep_prev, ic_sup = prev + tc * ep_prev,
    realizado = real,
    z = (real - prev) / ep_prev,
    dentro_ic = real >= prev - tc * ep_prev & real <= prev + tc * ep_prev,
    mesmo_sinal = sign(real) == sign(beta * n$choque_pp),
    razao_real_prev = real / (beta * n$choque_pp),
    n_estimacao = nobs(m)
  )
}

resultado <- purrr::map_dfr(respostas_disp, function(y) {
  purrr::map_dfr(seq_len(nrow(noites)), function(i) {
    purrr::map_dfr(c("empilhado", "ciclo"), function(a)
      tryCatch(prever_noite(y, noites[i, ], a), error = function(e) {
        message("  ", y, " ", noites$noite[i], " (", a, "): ", conditionMessage(e)); NULL
      }))
  })
})

export_table(resultado |> format_table(3), file.path(saida_dir, "noites_previsto_realizado.csv"))

# ------------------------------------------------------------
# 3. Gráfico: previsto (com intervalo de 95%) x realizado
# ------------------------------------------------------------

if (nrow(resultado)) {
  rot_y <- c(r_ibov = "Ibovespa (%)", r_usd = "Dólar (%)", d_di1 = "DI 1 ano (p.b.)", d_di5 = "DI 5 anos (p.b.)")
  gd <- resultado |>
    dplyr::mutate(y = factor(rot_y[y], rot_y[respostas_disp]),
                  noite = factor(noite, unique(noites$noite)),
                  amostra_beta = factor(amostra_beta, c("empilhado", "ciclo"),
                                        c("β dos três ciclos", "β do próprio ciclo")))
  g <- ggplot(gd, aes(noite)) +
    geom_hline(yintercept = 0, colour = "grey60") +
    geom_pointrange(aes(y = previsto, ymin = ic_inf, ymax = ic_sup, colour = amostra_beta),
                    position = position_dodge(width = 0.6), size = 0.3) +
    geom_point(aes(y = realizado), shape = 18, size = 3, colour = "black") +
    scale_colour_manual(values = c("steelblue4", "darkorange"), name = NULL) +
    facet_wrap(~ y, scales = "free_y", nrow = 2) +
    labs(x = NULL, y = NULL,
         title = "Noites eleitorais: reação prevista pela sensibilidade da campanha x reação observada",
         subtitle = "Pontos com barras: previsto e intervalo de previsão de 95% (Newey-West). Losango: observado no pregão seguinte à eleição.") +
    theme_minimal(base_size = 10) +
    theme(legend.position = "bottom", panel.grid.minor = element_blank(),
          axis.text.x = element_text(angle = 30, hjust = 1))
  save_plot(g, file.path(saida_dir, "noites_previsto_realizado.png"), width = 10, height = 6.5)
}

# ------------------------------------------------------------
# 4. Decomposição do choque: fim de semana x apuração
# ------------------------------------------------------------

decomp <- list()

arq_bf <- file.path(electoral_raw_dir, "betfair_noites_resumo.csv")
if (file.exists(arq_bf)) {
  bf <- readr::read_csv(arq_bf, show_col_types = FALSE)
  pega_bf <- function(cc, tt, mom) bf$p_pt[bf$ciclo == cc & bf$turno == tt & grepl(mom, bf$momento, fixed = TRUE)][1]
  for (k in seq_len(nrow(noites))) {
    n <- noites[k, ]
    if (!n$ciclo %in% bf$ciclo) next
    sexta <- pega_bf(n$ciclo, n$turno, "sexta")
    dom17 <- pega_bf(n$ciclo, n$turno, "domingo 17h")
    fim <- if (n$turno == "2º turno") as.numeric(ciclos$pt_venceu[ciclos$ciclo == n$ciclo]) else
      pega_bf(n$ciclo, n$turno, "segunda: fechamento")
    decomp[[length(decomp) + 1]] <- tibble::tibble(
      noite = n$noite, fonte = "Betfair (hora a hora)",
      p_sexta = 100 * sexta, p_domingo_17h = 100 * dom17, p_fim = 100 * fim,
      fim_de_semana_pp = 100 * (dom17 - sexta), apuracao_pp = 100 * (fim - dom17),
      total_pp = 100 * (fim - sexta))
  }
}

arq_pm <- file.path(electoral_raw_dir, arquivo_polymarket_horario)
if (file.exists(arq_pm) && 2026 %in% noites$ciclo) {
  pm <- tryCatch({
    readr::read_csv(arq_pm, show_col_types = FALSE) |>
      dplyr::mutate(hora = if (inherits(hora_utc, "POSIXct")) hora_utc else lubridate::ymd_hms(hora_utc, tz = "UTC"),
                    hora = lubridate::with_tz(hora, "America/Sao_Paulo")) |>
      dplyr::filter(!is.na(hora), is.finite(preco)) |>
      dplyr::group_by(hora) |>
      dplyr::mutate(p = preco / sum(preco, na.rm = TRUE)) |>
      dplyr::ungroup() |>
      dplyr::filter(grepl(padroes_polymarket_h2h[["pt"]], candidato))
  }, error = function(e) { message("Polymarket horária não lida: ", conditionMessage(e)); NULL })
  if (!is.null(pm) && nrow(pm)) {
    pm <- dplyr::arrange(pm, hora)
    ate <- function(t) { x <- pm$p[which(pm$hora <= t)]; if (length(x)) tail(x, 1) else NA_real_ }
    hora_b3 <- function(d) { ny <- as.POSIXct(paste(d, "12:00:00"), tz = "America/New_York")
      if (lubridate::dst(ny)) 17 else 18 }
    for (k in which(noites$ciclo == 2026)) {
      n <- noites[k, ]
      domingo <- if (n$turno == "1º turno") ciclos$data_1t[ciclos$ciclo == 2026] else ciclos$data_2t[ciclos$ciclo == 2026]
      sexta_d <- domingo - 2
      t_sexta <- as.POSIXct(paste(sexta_d, sprintf("%02d:00:00", hora_b3(sexta_d))), tz = "America/Sao_Paulo")
      t_dom <- as.POSIXct(paste(domingo, "17:00:00"), tz = "America/Sao_Paulo")
      t_seg <- as.POSIXct(paste(n$data, sprintf("%02d:00:00", hora_b3(n$data))), tz = "America/Sao_Paulo")
      sexta <- ate(t_sexta); dom17 <- ate(t_dom)
      fim <- if (n$turno == "2º turno") as.numeric(ciclos$pt_venceu[ciclos$ciclo == 2026]) else ate(t_seg)
      decomp[[length(decomp) + 1]] <- tibble::tibble(
        noite = n$noite, fonte = "Polymarket (hora a hora)",
        p_sexta = 100 * sexta, p_domingo_17h = 100 * dom17, p_fim = 100 * fim,
        fim_de_semana_pp = 100 * (dom17 - sexta), apuracao_pp = 100 * (fim - dom17),
        total_pp = 100 * (fim - sexta))
    }
  }
}

decomp <- dplyr::bind_rows(decomp)
if (nrow(decomp)) {
  decomp <- noites |> dplyr::select(noite, choque_base_pp = choque_pp) |> dplyr::left_join(decomp, by = "noite")
  export_table(decomp |> format_table(2), file.path(saida_dir, "noites_decomposicao.csv"))
} else message("Sem arquivos hora a hora: decomposição do choque não calculada.")

# ------------------------------------------------------------
# Console
# ------------------------------------------------------------

cat("\n========== NOITES ELEITORAIS: PREVISTO x REALIZADO ==========\n")
print(resultado |> dplyr::select(noite, y, amostra_beta, choque_pp, previsto, ic_inf, ic_sup, realizado, dentro_ic) |>
        format_table(2), n = Inf, width = Inf)
if (nrow(decomp)) { cat("\nDecomposição do choque (p.p.):\n"); print(decomp, n = Inf, width = Inf) }

message("09c_noites_eleitorais.R concluído com sucesso.")
