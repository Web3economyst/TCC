# ============================================================
# Script  : 09_ardl.R
#
# Objetivo:
#   ARDL em variações. O ARDL tem UMA variável endógena (a do lado
#   esquerdo) e usa só valores contemporâneos e passados dos
#   regressores; não há leads. Por isso ele é estimado nos dois
#   sentidos, cada um respondendo a uma pergunta:
#
#   (A) Probabilidade -> ativo  (y = ativo, x = ΔP)
#
#     y_t = a_ciclo + Σ_{i=1..p} φ_i y_{t−i}
#         + Σ_{j=0..q} θ_j ΔP_{t−j} + g'·controles_t + e_t
#
#     reação      : θ_0 (P medida no fechamento da B3, no mesmo horário
#                   dos preços) ou θ_0 + θ_1 (se algum ciclo ficou com P
#                   do fim do dia: notícia da noite chega ao preço no
#                   pregão seguinte). Ver defasagem_reacao no 00_config.R.
#     antecedência: as defasagens seguintes (a probabilidade de dias
#                   atrás ainda ajuda a prever o ativo: incorporação lenta)
#
#   (B) Ativo -> probabilidade  (y = ΔP, x = ativo)  "ARDL invertido"
#
#     ΔP_t = a_ciclo + Σ_{i=1..p} φ_i ΔP_{t−i}
#          + Σ_{j=0..q} δ_j y_{t−j} + g'·controles_t + u_t
#
#     δ_j, j ≥ 1 : retroalimentação (o ativo dos dias anteriores
#                  ajuda a prever a mudança de expectativa)
#     O BIC escolhe p e q; se escolher q = 0, usa-se q = 1, para que
#     o teste de retroalimentação exista (espelho do E1 do 06, que
#     testa ΔP_{t−1} na equação do ativo). A ordem do BIC fica na
#     coluna q_bic.
#
#   Papel no texto: a tabela principal da sensibilidade é a do 06
#   (modelo E). Daqui saem (i) a grade do BIC, que mostra a ordem
#   escolhida para (A), e (ii) o ARDL invertido (B), que testa o
#   sentido contrário. As seções 4 e 5 vão para o apêndice.
#
#   Para tratar todas as variáveis como endógenas ao mesmo tempo,
#   com respostas a impulso, usa-se o VAR (script 11). O ARDL e o VAR
#   são abordagens alternativas, não etapas do mesmo modelo.
#
#   Seções:
#   1. (A) empilhado: p e q por BIC; perfil temporal; longo prazo.
#   2. (A) ciclo a ciclo.
#   3. (B) ARDL invertido, empilhado e ciclo a ciclo.
#   4. Apêndice: conferência com o pacote ARDL (auto_ardl), ciclo
#      a ciclo.
#   5. Apêndice: ARDL em níveis + teste Bounds (Pesaran, Shin e
#      Smith, 2001), caso 3.
#
# Entrada : data/processed/model_data_daily.rds
# Saída   : output/09_saida/ardl_*.rds, output/09_saida/ardl_*.csv,
#           output/09_saida/ardl_*.png
#
# Próximo script: 10_robustness.R
# ============================================================

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

saida_dir <- saida("09")

model_data <- load_object(model_data_file)
aviso_simulado(model_data)

respostas_disp <- names(respostas)[purrr::map_lgl(names(respostas), ~ sum(is.finite(model_data[[.x]])) > 50)]
x <- "dp_pt"
anos <- sort(unique(as.character(model_data$ciclo)))
defasagem_reacao_efetiva <- resolver_reacao(model_data)
options(tcc.defasagem_reacao = defasagem_reacao_efetiva)
rot_blocos <- rotulos_blocos(defasagem_reacao_efetiva)
message("Bloco de reação: ", rot_blocos[["reacao"]], "; antecedência: ", rot_blocos[["antecedencia"]],
        " (horário da probabilidade: ", paste(unique(model_data$horario_p), collapse = ", "), ")")

# ------------------------------------------------------------
# 1. (A) Probabilidade -> ativo, amostra empilhada
# ------------------------------------------------------------

message("ARDL (probabilidade -> ativo) - empilhado...")
res_emp <- purrr::map(respostas_disp, ~ rodar_leadlag(model_data, .x, x, "empilhado")) |>
  setNames(respostas_disp)

# ------------------------------------------------------------
# 2. (A) Ciclo a ciclo (ordens p, q do empilhado, para comparar)
# ------------------------------------------------------------

message("ARDL (probabilidade -> ativo) - ciclo a ciclo...")
res_ciclo <- list()
for (cc in anos) for (y in respostas_disp) {
  d <- dplyr::filter(model_data, ciclo == cc)
  if (sum(is.finite(d[[y]]) & is.finite(d[[x]])) < 30) next
  r <- res_emp[[y]]
  res_ciclo[[paste(cc, y)]] <- rodar_leadlag(d, y, x, cc, p = r$p, q = r$q)
}

tab <- tabelas_leadlag(c(res_emp, res_ciclo))

export_table(tab$ordens |> format_table(4), file.path(saida_dir, "ardl_orders_fit.csv"))
export_table(tab$perfil |> format_table(4), file.path(saida_dir, "ardl_profile.csv"))
export_table(tab$coefs  |> format_table(4), file.path(saida_dir, "ardl_coefficients.csv"))

purrr::iwalk(res_emp, function(r, y) {
  export_table(r$selecao |> head(10) |> format_table(),
               file.path(saida_dir, paste0("ardl_bic_grid_", y, ".csv")))
})

# Grade do BIC: ordem escolhida, as melhores alternativas e a
# distância de cada uma para a escolhida
bic_grade <- purrr::imap_dfr(res_emp, function(r, y) {
  r$selecao |>
    dplyr::mutate(y = y, posicao = dplyr::row_number(), delta_bic = ic - min(ic), .before = 1) |>
    dplyr::rename(bic = ic)
})
export_table(bic_grade |> format_table(3), file.path(saida_dir, "ardl_bic_grid_all.csv"))

# ------------------------------------------------------------
# 3. (B) ARDL invertido: ativo -> probabilidade
# ------------------------------------------------------------
# Mesmo procedimento com os papéis trocados. A pergunta é se os
# preços de dias anteriores ajudam a prever ΔP(PT) (retroalimentação).
# O termo contemporâneo (δ_0) é reportado, mas não é precedência:
# no mesmo dia o ativo e a probabilidade reagem às mesmas notícias.

message("ARDL invertido (ativo -> probabilidade)...")
inv_bic <- purrr::map(respostas_disp, ~ rodar_leadlag(model_data, x, .x, "empilhado")) |>
  setNames(respostas_disp)
inv_emp <- purrr::map(respostas_disp, function(y) {
  b <- inv_bic[[y]]
  rodar_leadlag(model_data, x, y, "empilhado", p = b$p, q = max(b$q, 1))
}) |> setNames(respostas_disp)
inv_ciclo <- list()
for (cc in anos) for (y in respostas_disp) {
  d <- dplyr::filter(model_data, ciclo == cc)
  if (sum(is.finite(d[[y]]) & is.finite(d[[x]])) < 30) next
  r <- inv_emp[[y]]
  inv_ciclo[[paste(cc, y)]] <- rodar_leadlag(d, x, y, cc, p = r$p, q = r$q)
}
tab_inv <- tabelas_leadlag(c(inv_emp, inv_ciclo))
q_bic_inv <- purrr::map_int(inv_bic, ~ as.integer(.x$q))
tab_inv$ordens <- tab_inv$ordens |> dplyr::mutate(q_bic = unname(q_bic_inv[x]), .after = q)
export_table(tab_inv$ordens |> format_table(4), file.path(saida_dir, "ardl_inverse_orders_fit.csv"))
export_table(tab_inv$perfil |> format_table(4), file.path(saida_dir, "ardl_inverse_profile.csv"))
export_table(tab_inv$coefs  |> format_table(4), file.path(saida_dir, "ardl_inverse_coefficients.csv"))

# Figuras: coeficientes por defasagem, nos dois sentidos
plot_coefs <- function(co, titulo, xlab, ylab, rot_y, blocos) {
  co |>
    dplyr::mutate(y = factor(rot_y[y], rot_y),
                  amostra = factor(amostra, c("empilhado", anos)),
                  bloco = factor(blocos(j), unique(blocos(0:10)))) |>
    ggplot(aes(j, estimate, colour = bloco)) +
    geom_hline(yintercept = 0, colour = "grey60") +
    geom_pointrange(aes(ymin = conf.low, ymax = conf.high), size = 0.25) +
    scale_x_continuous(breaks = 0:10, labels = function(b) ifelse(b == 0, "t", paste0("t-", b))) +
    scale_colour_manual(values = c("black", "steelblue"), name = NULL) +
    facet_grid(y ~ amostra, scales = "free_y") +
    labs(x = xlab, y = ylab, title = titulo,
         subtitle = "ARDL em variações; IC de 95% Newey-West") +
    theme_minimal(base_size = 9) + theme(legend.position = "bottom")
}

g_a <- plot_coefs(tab$coefs |> dplyr::mutate(y = y),
                  "Quando a informação eleitoral chega aos preços?",
                  "Defasagem de ΔP(PT) em relação ao preço do dia t",
                  "resposta a +1 p.p. em P(PT)", respostas,
                  function(j) ifelse(j <= defasagem_reacao_efetiva, rot_blocos[["reacao"]], rot_blocos[["antecedencia"]]))
save_plot(g_a, file.path(saida_dir, "ardl_coefficients.png"), width = 10, height = 8)

g_b <- plot_coefs(tab_inv$coefs |> dplyr::mutate(y = x),
                  "Os preços ajudam a prever a probabilidade? (ARDL invertido)",
                  "Defasagem do ativo em relação a ΔP(PT) do dia t",
                  "resposta de P(PT) (p.p.) ao ativo", respostas,
                  function(j) ifelse(j == 0, "mesmo dia (t)", "retroalimentação (t-1 em diante)"))
save_plot(g_b, file.path(saida_dir, "ardl_inverse_coefficients.png"), width = 10, height = 8)

save_object(list(empilhado = res_emp, ciclo = res_ciclo), file.path(saida_dir, "ardl_main.rds"))
save_object(list(empilhado = inv_emp, ciclo = inv_ciclo), file.path(saida_dir, "ardl_inverse.rds"))

# ------------------------------------------------------------
# 4. Apêndice: conferência com o pacote ARDL (auto_ardl), ciclo a ciclo
# ------------------------------------------------------------
# O pacote ARDL trata a amostra como uma série contínua; por isso
# roda-se ciclo a ciclo (não faz sentido ligar 2018 a 2022).

message("auto_ardl por ciclo (pacote ARDL)...")
auto_tab <- list()
auto_mod <- list()
for (cc in sort(unique(model_data$ciclo))) for (y in respostas_disp) {
  # Pregões completos e consecutivos (ver amostra_continua no 00_functions.R)
  d <- model_data |>
    dplyr::filter(ciclo == cc) |>
    amostra_continua(c(y, x, controles), paste("auto_ardl", cc, y))
  perdas <- perdas_amostra(d)
  d <- d |> dplyr::select(dplyr::all_of(c(y, x, controles))) |> as.data.frame()
  if (nrow(d) < 30) next
  f <- as.formula(paste(y, "~", paste(c(x, controles), collapse = " + ")))
  a <- tryCatch(ARDL::auto_ardl(f, data = d, max_order = c(max_lag_y, max_lag_dp, 0, 0, 0),
                                selection = "BIC", grid = TRUE),
                error = function(e) NULL)
  if (is.null(a)) next
  b <- a$best_model
  auto_mod[[paste(cc, y)]] <- b
  co <- broom::tidy(b)
  auto_tab[[paste(cc, y)]] <- tibble::tibble(
    ciclo = cc, y = y,
    ordem = paste(names(b$order), b$order, sep = "=", collapse = ", "),
    soma_dp = sum(co$estimate[grepl(paste0("^", x, "$|L\\(", x), co$term)]),
    n = nobs(b)
  ) |> dplyr::bind_cols(perdas)
}
export_table(dplyr::bind_rows(auto_tab) |> format_table(4),
             file.path(saida_dir, "ardl_package_by_cycle.csv"))
save_object(auto_mod, file.path(saida_dir, "ardl_package_by_cycle.rds"))

# ------------------------------------------------------------
# 5. Apêndice: ARDL em níveis + Bounds test
# ------------------------------------------------------------
# Pergunta: existe relação de longo prazo entre o NÍVEL de P(PT) e o
# nível do ativo dentro de um ciclo? Caso 3 (constante irrestrita,
# sem tendência), como no MEFA. Com ~1 ano de dados diários e uma
# probabilidade que é limitada entre 0 e 1, o resultado é
# complementar, não o centro do trabalho.

niveis_spec <- list(
  l_ibov = c("p_pt", "l_spx", "l_vix"),
  l_usd  = c("p_pt", "ust10", "l_vix"),
  di1    = c("p_pt", "ust10"),
  di5    = c("p_pt", "ust10")
)

message("ARDL em níveis + Bounds...")
bounds_tab <- list(); bounds_mod <- list()
for (cc in sort(unique(model_data$ciclo))) for (y in names(niveis_spec)) {
  regs <- niveis_spec[[y]]
  d <- model_data |>
    dplyr::filter(ciclo == cc, !pos_2t) |>     # sem o dia do resultado (P vira 0 ou 1)
    amostra_continua(c(y, regs), paste("Bounds", cc, y))
  perdas <- perdas_amostra(d)
  d <- d |> dplyr::select(dplyr::all_of(c(y, regs))) |> as.data.frame()
  if (nrow(d) < 45) next
  f <- as.formula(paste(y, "~", paste(regs, collapse = " + ")))
  a <- tryCatch(ARDL::auto_ardl(f, data = d, max_order = rep(3, length(regs) + 1),
                                selection = "BIC", grid = TRUE), error = function(e) NULL)
  if (is.null(a)) next
  b <- a$best_model
  bt <- tryCatch(ARDL::bounds_f_test(b, case = 3), error = function(e) NULL)
  lr <- tryCatch(ARDL::multipliers(b, type = "lr"), error = function(e) NULL)
  lr_p <- if (!is.null(lr)) lr[lr$Term == "p_pt", ] else NULL
  bounds_mod[[paste(cc, y)]] <- list(modelo = b, bounds = bt, lr = lr)
  bounds_tab[[paste(cc, y)]] <- tibble::tibble(
    ciclo = cc, y = y, regressores = paste(regs, collapse = " + "),
    ordem = paste(b$order, collapse = ","), n = nobs(b),
    bounds_F = if (!is.null(bt)) unname(bt$statistic) else NA_real_,
    bounds_p = if (!is.null(bt)) bt$p.value else NA_real_,
    lr_p_pt = if (!is.null(lr_p) && nrow(lr_p)) lr_p$Estimate else NA_real_,
    lr_p_pt_p = if (!is.null(lr_p) && nrow(lr_p)) lr_p$`Pr(>|t|)` else NA_real_
  ) |> dplyr::bind_cols(perdas)
}
export_table(dplyr::bind_rows(bounds_tab) |> format_table(4),
             file.path(saida_dir, "ardl_levels_bounds.csv"))
save_object(bounds_mod, file.path(saida_dir, "ardl_levels_bounds.rds"))

# Perda de observações ao exigir pregões consecutivos (seções 4 e 5)
perdas_tab <- dplyr::bind_rows(
  dplyr::bind_rows(auto_tab) |> dplyr::mutate(modelo = "auto_ardl (variações)"),
  dplyr::bind_rows(bounds_tab) |> dplyr::mutate(modelo = "ARDL em níveis + Bounds")
) |> dplyr::select(dplyr::any_of(c("modelo", "ciclo", "y", "obs_disponiveis", "obs_usadas",
                                   "obs_descartadas", "perda_pct", "lacunas")))
export_table(perdas_tab |> format_table(2), file.path(saida_dir, "ardl_perdas_amostra_continua.csv"))

cat("\n========== PERDA DE OBSERVAÇÕES (pregões consecutivos) ==========\n")
print(perdas_tab, n = Inf, width = Inf)
cat("\n========== ORDENS E AJUSTE (probabilidade -> ativo) ==========\n")
print(tab$ordens |> dplyr::filter(amostra == "empilhado") |> format_table(3), width = Inf)
cat("\n========== PERFIL TEMPORAL (empilhado) ==========\n")
print(tab$perfil |> dplyr::filter(amostra == "empilhado") |>
        dplyr::select(y, bloco, soma, ep, p_soma, p_wald) |> format_table(3), n = Inf)
cat("\n========== ARDL INVERTIDO: retroalimentação (empilhado) ==========\n")
print(tab_inv$perfil |> dplyr::filter(amostra == "empilhado") |>
        dplyr::select(x, bloco, soma, ep, p_soma, p_wald) |> format_table(3), n = Inf)
message("09_ardl.R concluído com sucesso.")
