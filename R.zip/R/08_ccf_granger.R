# ============================================================
# Script  : 08_ccf_granger.R
#
# Objetivo:
#   Precedência temporal NOS DOIS SENTIDOS entre a informação
#   eleitoral e o mercado financeiro.
#
#   1. Correlação cruzada corr(y_{t+k}, ΔP_t), k = -10..10, na mesma
#      convenção do 04 (ccf(x = financeira, y = ΔP) do R):
#        k > 0 : ΔP vem ANTES  -> o mercado financeiro reage DEPOIS
#        k = 0 : mesmo dia     -> reage NA HORA
#        k < 0 : ΔP vem DEPOIS -> o mercado financeiro se mexe ANTES
#      Feita dentro de cada ciclo (e empilhada sem cruzar ciclos), sem
#      as noites eleitorais (como no 04): nesses pregões os valores
#      ficam NA, sem emendar o dia anterior com o seguinte.
#
#   1b. A mesma correlação cruzada com PRÉ-BRANQUEAMENTO (Box e
#      Jenkins): AR(p) ajustado a ΔP dentro do ciclo (p pelo BIC) e o
#      mesmo filtro aplicado aos dois lados. Com ΔP filtrado próximo
#      de ruído branco, a banda ±1,96/√n é válida mesmo com
#      autocorrelação no ativo; sem o filtro, ela é só indicativa.
#
#   2. Granger nos dois sentidos, L = 1..5 defasagens:
#        ΔP(PT) -> y : a probabilidade ajuda a prever o preço?
#        y -> ΔP(PT) : o preço ajuda a prever a probabilidade?
#      Efeito fixo de ciclo, controles internacionais (S&P 500,
#      Treasury 10 anos e VIX) e Newey-West, como nos demais modelos.
#
#   L = 1..5 é fixado antes de olhar os resultados: de um pregão a
#   uma semana de pregões. Como são vários testes (5 defasagens, 2
#   sentidos, 2 ativos), os p-valores são corrigidos por
#   Benjamini-Hochberg (controle da taxa de falsas descobertas). A
#   família é o conjunto de testes de cada amostra e fonte.
#
#   No texto, a retroalimentação (o ativo ajuda a prever a
#   probabilidade?) é testada por este Granger; a correlação cruzada
#   entra como figura e a tabela do Granger fica no apêndice.
#
#   As duas análises são repetidas com a probabilidade das
#   pesquisas (ΔP_pesq) quando o painel do script 08 do TCC existe.
#
# Entrada : data/processed/model_data_daily.rds
# Saída   : output/08_saida/ccf_*.csv, granger_*.csv
#           output/08_saida/ccf_*.png
#           output/08_saida/ccf_pw_*.csv, ccf_pw_*.png (pré-branqueada)
#
# Próximo script: 09_ardl.R
# ============================================================

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

saida_dir <- saida("08")

model_data <- load_object(model_data_file)
aviso_simulado(model_data)

respostas_disp <- names(respostas)[purrr::map_lgl(names(respostas), ~ sum(is.finite(model_data[[.x]])) > 50)]
fontes <- c(dp_pt = "mercado de previsão", dp_pesq = "pesquisas")
fontes <- fontes[purrr::map_lgl(names(fontes), ~ sum(is.finite(model_data[[.x]])) > 50)]

amostras <- c(list(empilhado = model_data),
              split(model_data, model_data$ciclo) |> setNames(as.character(sort(unique(model_data$ciclo)))))

# Para a correlação cruzada: noites eleitorais fora (valores NA)
md_ccf <- model_data |>
  dplyr::mutate(dplyr::across(dplyr::any_of(c(names(fontes), respostas_disp)),
                              ~ dplyr::if_else(noite_eleicao == 1, NA_real_, .x)))
amostras_ccf <- c(list(empilhado = md_ccf),
                  split(md_ccf, md_ccf$ciclo) |> setNames(as.character(sort(unique(md_ccf$ciclo)))))

# ------------------------------------------------------------
# 1. Correlação cruzada
# ------------------------------------------------------------

ccf_tab <- tidyr::expand_grid(amostra = names(amostras), x = names(fontes), y = respostas_disp) |>
  dplyr::mutate(res = purrr::pmap(list(amostra, x, y), function(a, x, y) {
    ccf_within(amostras_ccf[[a]], x, y, max_lag_ccf)
  })) |>
  tidyr::unnest(res) |>
  dplyr::mutate(
    # ccf_within devolve corr(y_t, x_{t+k}); trocar o sinal de k dá
    # corr(y_{t+k}, x_t), a convenção do 04: k > 0 = ΔP vem antes
    k = -k,
    leitura = dplyr::case_when(k > 0 ~ "probabilidade antes", k == 0 ~ "mesmo dia", TRUE ~ "financeiro antes"),
    fora_banda = abs(cor) > banda
  )

export_table(ccf_tab |> format_table(4), file.path(saida_dir, "ccf_all.csv"))

# Resumo: correlações significativas por bloco
ccf_resumo <- ccf_tab |>
  dplyr::group_by(amostra, x, y, leitura) |>
  dplyr::summarise(defasagens_fora_banda = paste(k[fora_banda], collapse = " "),
                   n_fora = sum(fora_banda), maior_abs = cor[which.max(abs(cor))],
                   k_maior = k[which.max(abs(cor))], .groups = "drop")

export_table(ccf_resumo |> format_table(4), file.path(saida_dir, "ccf_summary.csv"))

grafico_ccf <- function(tab, fx, sufixo_titulo = "", arquivo) {
  g <- tab |>
    dplyr::filter(x == fx) |>
    dplyr::mutate(y = factor(respostas[y], respostas),
                  amostra = factor(amostra, names(amostras))) |>
    (\(d) ggplot(d, aes(k, cor, fill = leitura)) +
       geom_hline(data = dplyr::summarise(d, b = mean(banda), .by = c(y, amostra)),
                  aes(yintercept = b), linetype = 2, linewidth = 0.3) +
       geom_hline(data = dplyr::summarise(d, b = mean(banda), .by = c(y, amostra)),
                  aes(yintercept = -b), linetype = 2, linewidth = 0.3))() +
    geom_col(width = 0.7) +
    geom_hline(yintercept = 0) +
    scale_fill_manual(values = c(`financeiro antes` = "darkorange", `mesmo dia` = "black",
                                 `probabilidade antes` = "steelblue"), name = NULL) +
    facet_grid(y ~ amostra, scales = "free_y") +
    labs(x = "k (pregões): corr( y_{t+k} , ΔP_t )", y = "correlação",
         title = paste0("Correlação cruzada: ", fontes[[fx]], " x mercado financeiro", sufixo_titulo),
         subtitle = "k > 0: a probabilidade se mexe antes do preço; k < 0: depois. Noites eleitorais excluídas. Tracejado: ±1,96/√n") +
    theme_minimal(base_size = 9) + theme(legend.position = "bottom")
  save_plot(g, arquivo, width = 10, height = 8)
}

for (fx in names(fontes)) {
  grafico_ccf(ccf_tab, fx, arquivo = file.path(saida_dir, paste0("ccf_", fx, ".png")))
}

# ------------------------------------------------------------
# 1b. Correlação cruzada com pré-branqueamento
# ------------------------------------------------------------
# O filtro AR(p) é estimado em ΔP dentro de cada ciclo e aplicado
# a ΔP e ao ativo (prewhiten_within, 00_functions.R, seção 5).
# ordem_ar: ordem escolhida pelo BIC em cada ciclo.

ccf_pw_tab <- tidyr::expand_grid(amostra = names(amostras), x = names(fontes), y = respostas_disp) |>
  dplyr::mutate(res = purrr::pmap(list(amostra, x, y), function(a, x, y) {
    d <- prewhiten_within(amostras_ccf[[a]], x, y)
    ordens <- d |> dplyr::distinct(ciclo, ordem_ar) |> dplyr::arrange(ciclo)
    ccf_within(d, x, y, max_lag_ccf) |>
      dplyr::mutate(ordem_ar = paste0(ordens$ciclo, ": AR(", ordens$ordem_ar, ")", collapse = "; "))
  })) |>
  tidyr::unnest(res) |>
  dplyr::mutate(
    k = -k,
    leitura = dplyr::case_when(k > 0 ~ "probabilidade antes", k == 0 ~ "mesmo dia", TRUE ~ "financeiro antes"),
    fora_banda = abs(cor) > banda
  )

export_table(ccf_pw_tab |> format_table(4), file.path(saida_dir, "ccf_pw_all.csv"))

ccf_pw_resumo <- ccf_pw_tab |>
  dplyr::group_by(amostra, x, y, ordem_ar, leitura) |>
  dplyr::summarise(defasagens_fora_banda = paste(k[fora_banda], collapse = " "),
                   n_fora = sum(fora_banda), maior_abs = cor[which.max(abs(cor))],
                   k_maior = k[which.max(abs(cor))], .groups = "drop")

export_table(ccf_pw_resumo |> format_table(4), file.path(saida_dir, "ccf_pw_summary.csv"))

for (fx in names(fontes)) {
  grafico_ccf(ccf_pw_tab, fx, sufixo_titulo = " (pré-branqueada)",
              arquivo = file.path(saida_dir, paste0("ccf_pw_", fx, ".png")))
}

cat("\n========== CCF PRÉ-BRANQUEADA (empilhado, mercado de previsão) ==========\n")
print(ccf_pw_resumo |> dplyr::filter(amostra == "empilhado", x == "dp_pt") |> format_table(3), width = Inf)

# ------------------------------------------------------------
# 2. Granger nos dois sentidos
# ------------------------------------------------------------

ativos_texto <- c("r_ibov", "r_usd")   # família da correção de Benjamini-Hochberg

granger_tab <- tidyr::expand_grid(amostra = names(amostras), x = names(fontes), y = respostas_disp,
                                  L = lags_granger) |>
  dplyr::mutate(res = purrr::pmap(list(amostra, x, y, L), function(a, x, y, L) {
    d <- amostras[[a]]
    dplyr::bind_rows(
      granger_within(d, cause = x, effect = y, L = L, controls = controles) |> dplyr::mutate(sentido = "probabilidade -> financeiro"),
      granger_within(d, cause = y, effect = x, L = L, controls = controles) |> dplyr::mutate(sentido = "financeiro -> probabilidade")
    ) |> dplyr::select(sentido, n, F, p_value)
  })) |>
  tidyr::unnest(res) |>
  # Correção de Benjamini-Hochberg (1995) para testes múltiplos.
  # Família: os testes dos ativos do texto (Ibovespa e dólar) em uma
  # mesma amostra e fonte (5 defasagens x 2 sentidos x 2 ativos = 20).
  # p_bh: p-valor ajustado (rejeita a 5% se p_bh < 0,05).
  # p_bh_todos: família ampliada com todas as amostras (empilhado e
  # cada ciclo), mais conservadora. Os demais ativos ficam com NA.
  dplyr::mutate(familia = y %in% ativos_texto) |>
  dplyr::group_by(amostra, x, familia) |>
  dplyr::mutate(p_bh = dplyr::if_else(familia, stats::p.adjust(p_value, method = "BH"), NA_real_),
                m_familia = sum(is.finite(p_value) & familia)) |>
  dplyr::group_by(x, familia) |>
  dplyr::mutate(p_bh_todos = dplyr::if_else(familia, stats::p.adjust(p_value, method = "BH"), NA_real_)) |>
  dplyr::ungroup() |>
  dplyr::select(-familia)

export_table(granger_tab |> format_table(4), file.path(saida_dir, "granger_both_directions.csv"))

granger_resumo <- granger_tab |>
  dplyr::filter(L %in% c(1, 3, 5)) |>
  dplyr::select(amostra, x, y, sentido, L, p_value, p_bh) |>
  tidyr::pivot_wider(names_from = L, values_from = c(p_value, p_bh), names_glue = "{.value}_L{L}")

export_table(granger_resumo |> format_table(4), file.path(saida_dir, "granger_summary.csv"))

cat("\n========== GRANGER (empilhado, mercado de previsão) ==========\n")
print(granger_resumo |> dplyr::filter(amostra == "empilhado", x == "dp_pt") |> format_table(3), width = Inf)
message("08_ccf_granger.R concluído com sucesso.")
