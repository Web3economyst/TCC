# ============================================================
# Script  : 04_descriptive.R
#
# Objetivo:
#   Análise exploratória:
#   1. estatísticas descritivas por ciclo e empilhadas;
#   2. níveis e volatilidade por fase eleitoral;
#   3. gráficos das séries temporais;
#   4. correlações por ciclo, empilhadas brutas e centralizadas;
#   5. noites eleitorais e maiores movimentos de P(PT);
#   6. dispersões entre P(PT) e variáveis financeiras.
#
# Entrada : data/processed/model_data_daily.rds
# Saída   : output/04_saida/
#           output/04_saida/
#
# Próximo script: 05_stationarity.R
# ============================================================

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

saida_dir <- saida("04")


# Garantir que os diretórios de saída existam.
dir.create(saida_dir, recursive = TRUE, showWarnings = FALSE)


model_data <- load_object(model_data_file)
aviso_simulado(model_data)

# Garantir ordenação temporal
model_data <- model_data |>
  dplyr::arrange(ciclo, data)


# Exportação consolidada para Excel.
# O script mantém também os CSVs individuais de cada tabela.
exportar_excel <- function(tabelas, arquivo) {
  tabelas <- tabelas[!vapply(tabelas, is.null, logical(1))]

  if (requireNamespace("openxlsx", quietly = TRUE)) {
    wb <- openxlsx::createWorkbook()

    for (nome in names(tabelas)) {
      aba <- substr(gsub("[^A-Za-z0-9_]", "_", nome), 1, 31)
      openxlsx::addWorksheet(wb, aba)
      openxlsx::writeData(
        wb, sheet = aba, x = as.data.frame(tabelas[[nome]]),
        withFilter = TRUE
      )
      openxlsx::freezePane(wb, sheet = aba, firstRow = TRUE)
      openxlsx::setColWidths(wb, sheet = aba, cols = 1:ncol(tabelas[[nome]]), widths = "auto")
    }

    openxlsx::saveWorkbook(wb, arquivo, overwrite = TRUE)

  } else if (requireNamespace("writexl", quietly = TRUE)) {
    writexl::write_xlsx(
      lapply(tabelas, as.data.frame),
      path = arquivo
    )

  } else {
    stop(
      "Para exportar o arquivo Excel, instale o pacote 'openxlsx' ",
      "ou 'writexl' (install.packages('openxlsx'))."
    )
  }

  message("Arquivo Excel salvo em: ", normalizePath(arquivo, winslash = "/", mustWork = FALSE))
}

# ------------------------------------------------------------
# 0. Preparação
# ------------------------------------------------------------

# Variáveis para estatísticas descritivas
vars_desc <- c(
  dp_pt = "Δ P(PT) (p.p.)",
  dp_pesq = "Δ P(PT) pesquisas (p.p.)",
  respostas,
  r_spx = "S&P 500 (%)",
  d_ust10 = "Treasury 10a (p.b.)",
  r_vix = "VIX (%)"
)

# Manter apenas variáveis existentes e numéricas
vars_desc <- vars_desc[names(vars_desc) %in% names(model_data)]
vars_desc <- vars_desc[
  vapply(model_data[names(vars_desc)], is.numeric, logical(1))
]

# Variáveis financeiras (já expressas como retornos/variações diárias)
vars_fin_cor <- intersect(
  c(names(respostas), controles),
  names(model_data)
)
vars_fin_cor <- vars_fin_cor[
  vapply(model_data[vars_fin_cor], is.numeric, logical(1))
]

# Probabilidades em nível e em primeira diferença.
vars_prob_cor <- intersect(
  c("p_pt", "dp_pt", "p_pesq", "dp_pesq"),
  names(model_data)
)
vars_prob_cor <- vars_prob_cor[
  vapply(model_data[vars_prob_cor], is.numeric, logical(1))
]

vars_cor <- unique(c(vars_prob_cor, vars_fin_cor))

if (length(vars_cor) < 2) {
  stop("Há menos de duas variáveis numéricas disponíveis para calcular correlações.")
}

# ------------------------------------------------------------
# 1. Estatísticas descritivas (por ciclo e empilhado)
# ------------------------------------------------------------

descrever <- function(d, rotulo) {
  purrr::imap_dfr(vars_desc, function(lbl, v) {
    x <- d[[v]]
    x <- x[is.finite(x)]
    n <- length(x)

    if (n == 0) {
      return(tibble::tibble(
        ciclo = rotulo,
        variavel = v,
        descricao = lbl,
        N = 0L,
        media = NA_real_,
        dp = NA_real_,
        min = NA_real_,
        p25 = NA_real_,
        mediana = NA_real_,
        p75 = NA_real_,
        max = NA_real_,
        curtose_exc = NA_real_
      ))
    }

    desvio <- if (n > 1) stats::sd(x) else NA_real_

    curtose <- if (n > 3 && is.finite(desvio) && desvio > 0) {
      mean(((x - mean(x)) / desvio)^4) - 3
    } else {
      NA_real_
    }

    tibble::tibble(
      ciclo = rotulo,
      variavel = v,
      descricao = lbl,
      N = n,
      media = mean(x),
      dp = desvio,
      min = min(x),
      p25 = unname(stats::quantile(x, 0.25)),
      mediana = stats::median(x),
      p75 = unname(stats::quantile(x, 0.75)),
      max = max(x),
      curtose_exc = curtose
    )
  })
}

ciclos_disponiveis <- sort(unique(model_data$ciclo))

descritivas <- dplyr::bind_rows(
  purrr::map_dfr(
    ciclos_disponiveis,
    ~ descrever(
      dplyr::filter(model_data, ciclo == .x),
      as.character(.x)
    )
  ),
  descrever(model_data, "empilhado")
) |>
  dplyr::filter(N > 0) |>
  format_table()

export_table(
  descritivas,
  file.path(saida_dir, "descriptive_statistics.csv")
)

# ------------------------------------------------------------
# 2. Níveis e volatilidade por fase eleitoral
# ------------------------------------------------------------

# Usa a data do segundo turno definida em 00_config.R.
# Não depende de uma variável pos_2t, que não é criada em 03_variables.R.

# data_2t já existe em model_data; não é necessário fazer join com ciclos.
niveis_base <- model_data |>
  dplyr::filter(!is.na(data_2t), data <= data_2t) |>
  dplyr::mutate(
    fase = dplyr::case_when(
      entre_turnos == 1 ~ "Entre turnos",
      campanha == 1 ~ "Campanha (1º turno)",
      TRUE ~ "Pré-campanha"
    ),
    fase = factor(
      fase,
      levels = c("Pré-campanha", "Campanha (1º turno)", "Entre turnos")
    )
  )

# Manter resultados numéricos para o gráfico; formatar apenas a tabela.
niveis_raw <- niveis_base |>
  dplyr::group_by(ciclo, fase) |>
  dplyr::summarise(
    pregoes = dplyr::n(),
    p_pt_media = mean(p_pt, na.rm = TRUE),
    p_pt_min = min(p_pt, na.rm = TRUE),
    p_pt_max = max(p_pt, na.rm = TRUE),
    vol_dp_pt = sd(dp_pt, na.rm = TRUE),
    vol_ibov = sd(r_ibov, na.rm = TRUE),
    vol_usd = sd(r_usd, na.rm = TRUE),
    vol_di1 = sd(d_di1, na.rm = TRUE),
    vol_di5 = sd(d_di5, na.rm = TRUE),
    .groups = "drop"
  )

niveis <- niveis_raw |> format_table()

export_table(
  niveis,
  file.path(saida_dir, "fases_campanha.csv")
)

# Cada ponto representa o DP das variações diárias naquela fase.
rotulos_vol <- c(
  vol_dp_pt = "Probabilidade do PT (Δ p.p.)",
  vol_ibov = "Ibovespa (retorno diário)",
  vol_usd = "Dólar (retorno diário)",
  vol_di1 = "DI 1 ano (variação diária)",
  vol_di5 = "DI 5 anos (variação diária)"
)

volatilidade_fases <- niveis_raw |>
  dplyr::select(ciclo, fase, dplyr::starts_with("vol_")) |>
  tidyr::pivot_longer(
    cols = dplyr::starts_with("vol_"),
    names_to = "variavel",
    values_to = "dp_diario"
  ) |>
  dplyr::mutate(variavel = dplyr::recode(variavel, !!!rotulos_vol)) |>
  dplyr::filter(is.finite(dp_diario))

g_volatilidade <- ggplot(
  volatilidade_fases,
  aes(x = fase, y = dp_diario)
) +
  geom_point(size = 2.2, colour = "steelblue4") +
  facet_grid(variavel ~ ciclo, scales = "free_y", drop = TRUE) +
  labs(
    x = NULL,
    y = "Desvio-padrão",
    title = "Volatilidade das variações diárias por fase eleitoral",
    subtitle = "DP calculado dentro de cada fase e ciclo; fases sem observações não aparecem"
  ) +
  theme_minimal(base_size = 10) +
  theme(
    axis.text.x = element_text(angle = 30, hjust = 1),
    panel.grid.minor = element_blank()
  )

save_plot(
  g_volatilidade,
  file.path(saida_dir, "volatility_by_phase.png"),
  width = 11,
  height = 8
)

# 3. Séries temporais
# ------------------------------------------------------------

marcas <- ciclos |>
  dplyr::select(ciclo, data_1t, data_2t) |>
  tidyr::pivot_longer(
    cols = c(data_1t, data_2t),
    names_to = "turno",
    values_to = "data_eleicao"
  )

normalizar <- function(x) {
  validos <- which(is.finite(x))

  if (length(validos) == 0 || x[validos[1]] == 0) {
    return(rep(NA_real_, length(x)))
  }

  100 * x / x[validos[1]]
}

series_plot <- model_data |>
  dplyr::group_by(ciclo) |>
  dplyr::transmute(
    data,
    `P(PT) (%)` = 100 * p_pt,
    `Ibovespa (base 100)` = normalizar(ibov),
    `Dólar (base 100)` = normalizar(usd),
    `DI 1 ano (%)` = 100 * di1,
    `DI 5 anos (%)` = 100 * di5
  ) |>
  dplyr::ungroup() |>
  tidyr::pivot_longer(
    cols = -c(ciclo, data),
    names_to = "serie",
    values_to = "valor"
  ) |>
  dplyr::filter(is.finite(valor)) |>
  dplyr::mutate(
    serie = factor(
      serie,
      levels = c(
        "P(PT) (%)",
        "Ibovespa (base 100)",
        "Dólar (base 100)",
        "DI 1 ano (%)",
        "DI 5 anos (%)"
      )
    )
  )

g_series <- ggplot(series_plot, aes(data, valor)) +
  geom_vline(
    data = marcas,
    aes(xintercept = data_eleicao),
    inherit.aes = FALSE,
    linetype = 2,
    colour = "grey50"
  ) +
  geom_line(linewidth = 0.5, colour = "steelblue4") +
  facet_grid(serie ~ ciclo, scales = "free", switch = "y", drop = TRUE) +
  scale_x_date(date_labels = "%b/%y") +
  labs(
    x = NULL,
    y = NULL,
    title = "Probabilidade de vitória do PT e preços financeiros",
    subtitle = "Cada painel usa apenas o intervalo com observações daquele ciclo; linhas tracejadas: datas dos turnos"
  ) +
  theme_minimal(base_size = 9) +
  theme(
    strip.placement = "outside",
    panel.grid.minor = element_blank()
  )

save_plot(
  g_series,
  file.path(saida_dir, "time_series.png"),
  width = 10,
  height = 9
)

# ------------------------------------------------------------
# 4. Correlações contemporâneas
# ------------------------------------------------------------
# A matriz inclui P(PT) em nível e ΔP(PT), além das variações
# financeiras diárias. Correlações são descritivas, não causais.

calcular_cor <- function(d, variaveis) {
  suppressWarnings(
    stats::cor(d[, variaveis, drop = FALSE], use = "pairwise.complete.obs")
  )
}

dados_por_ciclo <- split(model_data, model_data$ciclo)
cor_ciclos <- lapply(dados_por_ciclo, calcular_cor, variaveis = vars_cor)
names(cor_ciclos) <- paste("Ciclo", names(cor_ciclos))
cor_empilhada <- calcular_cor(model_data, vars_cor)

dados_centrados <- model_data |>
  dplyr::group_by(ciclo) |>
  dplyr::mutate(
    dplyr::across(
      dplyr::all_of(vars_cor),
      ~ .x - mean(.x, na.rm = TRUE)
    )
  ) |>
  dplyr::ungroup()

cor_centrada <- calcular_cor(dados_centrados, vars_cor)
matrizes_cor <- c(
  cor_ciclos,
  list(
    "Empilhado bruto" = cor_empilhada,
    "Empilhado centrado por ciclo" = cor_centrada
  )
)

rotulos_cor <- c(
  p_pt = "P(PT) nível",
  dp_pt = "ΔP(PT)",
  p_pesq = "P(PT) pesquisas",
  dp_pesq = "ΔP(PT) pesquisas",
  r_ibov = "Ibovespa",
  r_usd = "Dólar",
  d_di1 = "DI 1 ano",
  d_di5 = "DI 5 anos",
  r_spx = "S&P 500",
  d_ust10 = "Treasury 10a",
  r_vix = "VIX"
)
rotulos <- stats::setNames(vars_cor, vars_cor)
disponiveis <- intersect(names(rotulos_cor), vars_cor)
rotulos[disponiveis] <- rotulos_cor[disponiveis]

correlacoes <- purrr::imap_dfr(
  matrizes_cor,
  function(m, nome) {
    as.data.frame(as.table(m)) |>
      dplyr::rename(
        variavel = Var1,
        outra_variavel = Var2,
        correlacao = Freq
      ) |>
      dplyr::mutate(
        amostra = nome,
        variavel = unname(rotulos[as.character(variavel)]),
        outra_variavel = unname(rotulos[as.character(outra_variavel)]),
        .before = 1
      )
  }
) |>
  format_table()

export_table(
  correlacoes,
  file.path(saida_dir, "correlation_matrix.csv")
)

cor_plot <- purrr::imap_dfr(
  matrizes_cor,
  function(m, nome) {
    as.data.frame(as.table(m)) |>
      dplyr::rename(variavel = Var1, outra_variavel = Var2, r = Freq) |>
      dplyr::mutate(
        amostra = nome,
        v1 = factor(
          unname(rotulos[as.character(variavel)]),
          levels = unname(rotulos[vars_cor])
        ),
        v2 = factor(
          unname(rotulos[as.character(outra_variavel)]),
          levels = rev(unname(rotulos[vars_cor]))
        )
      )
  }
) |>
  dplyr::mutate(amostra = factor(amostra, levels = names(matrizes_cor)))

g_cor <- ggplot(cor_plot, aes(v1, v2, fill = r)) +
  geom_tile(colour = "white") +
  geom_text(
    aes(label = ifelse(is.na(r), "", sprintf("%.2f", r))),
    size = 2.7
  ) +
  scale_fill_gradient2(
    low = "firebrick", mid = "white", high = "steelblue",
    limits = c(-1, 1), na.value = "grey90"
  ) +
  facet_wrap(~amostra, ncol = 2) +
  labs(
    x = NULL,
    y = NULL,
    fill = "Correlação",
    title = "Correlações entre probabilidades eleitorais e mercado financeiro",
    subtitle = "P(PT) em nível e ΔP(PT); variáveis financeiras em variações diárias"
  ) +
  theme_minimal(base_size = 9) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    panel.grid = element_blank()
  )

save_plot(
  g_cor,
  file.path(saida_dir, "correlation_heatmap.png"),
  width = 13,
  height = max(8, 3.5 * ceiling(length(matrizes_cor) / 2))
)


# ------------------------------------------------------------
# 5. Funções de correlação cruzada (CCF)
# ------------------------------------------------------------
# Objetivo:
#   Verificar se variações em P(PT) antecedem ou sucedem
#   variações nas variáveis financeiras.
#
# Convenção:
#   ccf(x = variável financeira, y = dp_pt).
#   Com essa ordem, defasagens POSITIVAS indicam que dp_pt
#   antecede a variável financeira.
#
#   Ex.: lag = +2 corresponde à associação entre dp_pt no
#   pregão t e a variação financeira dois pregões depois.
#
# As CCFs são calculadas por ciclo, em pregões regulares,
# excluindo as noites eleitorais. As bandas ±1,96/sqrt(N)
# são referências aproximadas, não testes causais.
# ------------------------------------------------------------

vars_ccf <- intersect(names(respostas), names(model_data))
vars_ccf <- vars_ccf[
  vapply(model_data[vars_ccf], is.numeric, logical(1))
]

lag_max_ccf <- 10L

calcular_ccf <- function(d, variavel, lag_max = lag_max_ccf) {
  d_ccf <- d |>
    dplyr::arrange(data) |>
    dplyr::filter(noite_eleicao != 1) |>
    dplyr::transmute(
      dp_pt = dp_pt,
      financeira = .data[[variavel]]
    ) |>
    dplyr::filter(
      is.finite(dp_pt),
      is.finite(financeira)
    )

  n <- nrow(d_ccf)

  # Exige observações suficientes para estimar as defasagens.
  if (n < 12L) {
    return(NULL)
  }

  lag_usado <- min(lag_max, floor((n - 1L) / 4L))

  if (lag_usado < 1L) {
    return(NULL)
  }

  # A ordem x = financeira, y = dp_pt faz com que lag positivo
  # represente dp_pt antecedendo a variável financeira.
  ajuste <- stats::ccf(
    x = d_ccf$financeira,
    y = d_ccf$dp_pt,
    lag.max = lag_usado,
    plot = FALSE,
    na.action = na.fail,
    demean = TRUE
  )

  tibble::tibble(
    defasagem = as.numeric(ajuste$lag),
    ccf = as.numeric(ajuste$acf),
    N = n,
    limite = 1.96 / sqrt(n),
    variavel = variavel
  )
}

dados_ccf_por_ciclo <- split(model_data, model_data$ciclo)

ccf_resultados <- purrr::imap_dfr(
  dados_ccf_por_ciclo,
  function(d, ciclo_atual) {
    purrr::map_dfr(
      vars_ccf,
      function(v) calcular_ccf(d, v)
    ) |>
      dplyr::mutate(ciclo = ciclo_atual, .before = 1)
  }
)

if (nrow(ccf_resultados) == 0) {
  warning("Não foi possível calcular CCFs: verifique o número de observações.")
} else {
  ccf_resultados <- ccf_resultados |>
    dplyr::mutate(
      resposta = dplyr::recode(
        variavel,
        !!!as.list(respostas),
        .default = variavel
      )
    )

  ccf_tabela <- ccf_resultados |>
    dplyr::select(ciclo, variavel, defasagem, ccf, N, limite) |>
    format_table()

  export_table(
    ccf_tabela,
    file.path(saida_dir, "cross_correlation_functions.csv")
  )

  g_ccf <- ggplot(
    ccf_resultados,
    aes(x = defasagem, y = ccf)
  ) +
    geom_ribbon(
      aes(ymin = -limite, ymax = limite),
      fill = "grey85",
      alpha = 0.7
    ) +
    geom_hline(yintercept = 0, colour = "grey45", linewidth = 0.4) +
    geom_segment(
      aes(xend = defasagem, y = 0, yend = ccf),
      colour = "steelblue4",
      linewidth = 0.6
    ) +
    geom_point(size = 1.4, colour = "steelblue4") +
    facet_grid(resposta ~ ciclo, scales = "fixed", drop = TRUE) +
    scale_x_continuous(breaks = seq(-lag_max_ccf, lag_max_ccf, by = 2)) +
    coord_cartesian(ylim = c(-1, 1)) +
    labs(
      x = "Defasagem (pregões): positiva = ΔP(PT) antecede o mercado",
      y = "Correlação cruzada",
      title = "CCF entre ΔP(PT) e variações do mercado financeiro",
      subtitle = paste0(
        "Por ciclo; até ", lag_max_ccf,
        " pregões; noites eleitorais excluídas. ",
        "Faixa cinza: referência aproximada ±1,96/√N."
      )
    ) +
    theme_minimal(base_size = 10) +
    theme(panel.grid.minor = element_blank())

  save_plot(
    g_ccf,
    file.path(saida_dir, "cross_correlation_functions.png"),
    width = 11,
    height = max(7, 2.2 * length(vars_ccf))
  )
}

# 6. Noites eleitorais e maiores choques de P(PT)
# ------------------------------------------------------------

# Escore padronizado: (movimento - média do ciclo) / dp do ciclo
zscore <- function(x) {
  media <- mean(x, na.rm = TRUE)
  desvio <- sd(x, na.rm = TRUE)

  if (!is.finite(desvio) || desvio == 0) {
    return(rep(NA_real_, length(x)))
  }

  (x - media) / desvio
}

com_z <- model_data |>
  dplyr::group_by(ciclo) |>
  dplyr::mutate(
    dplyr::across(
      c(dp_pt_res, r_ibov, r_usd, d_di1, d_di5),
      zscore,
      .names = "z_{.col}"
    )
  ) |>
  dplyr::ungroup()

# No pregão seguinte ao 2º turno, P(PT) e ΔP(PT) ficam NA nos modelos
# (incluir_resultado_2t, 00_config.R): ali o valor é o resultado (1/0).
# Esta tabela é só descrição do que aconteceu nas noites, então usa
# p_pt_res e dp_pt_res, que guardam o resultado.
noites <- com_z |>
  dplyr::filter(noite_eleicao == 1) |>
  dplyr::mutate(
    evento = dplyr::if_else(
      pos_1t == 1,
      "pós 1º turno",
      "pós 2º turno"
    )
  ) |>
  dplyr::select(
    ciclo, evento, data, p_pt = p_pt_res, dp_pt = dp_pt_res,
    r_ibov, r_usd, d_di1, d_di5,
    dplyr::starts_with("z_")
  ) |>
  format_table()

export_table(
  noites,
  file.path(saida_dir, "noites_eleitorais.csv")
)

maiores_choques <- com_z |>
  dplyr::group_by(ciclo) |>
  dplyr::slice_max(
    order_by = abs(dp_pt),
    n = 10,
    with_ties = FALSE
  ) |>
  dplyr::ungroup() |>
  dplyr::select(
    ciclo, data, p_pt, dp_pt,
    r_ibov, r_usd, d_di1, d_di5,
    noite_eleicao
  ) |>
  dplyr::arrange(ciclo, dplyr::desc(abs(dp_pt))) |>
  format_table()

export_table(
  maiores_choques,
  file.path(saida_dir, "maiores_choques_p_pt.csv")
)

# ------------------------------------------------------------
# 7. Associação entre ΔP(PT) e variações financeiras
# ------------------------------------------------------------
# Exclui noites eleitorais para que movimentos extremos desses eventos
# não comprimam visualmente os pregões regulares. Os eventos são
# apresentados separadamente na tabela de noites eleitorais.

disp <- model_data |>
  dplyr::filter(noite_eleicao != 1) |>
  dplyr::select(ciclo, dp_pt, dplyr::all_of(names(respostas))) |>
  tidyr::pivot_longer(
    cols = dplyr::all_of(names(respostas)),
    names_to = "resposta",
    values_to = "variacao_financeira"
  ) |>
  dplyr::filter(
    is.finite(variacao_financeira),
    is.finite(dp_pt)
  ) |>
  dplyr::mutate(
    resposta = factor(respostas[resposta], levels = unname(respostas))
  )

g_disp <- ggplot(disp, aes(dp_pt, variacao_financeira)) +
  geom_hline(yintercept = 0, colour = "grey75") +
  geom_vline(xintercept = 0, colour = "grey75") +
  geom_point(size = 1, alpha = 0.45, colour = "steelblue4") +
  geom_smooth(
    method = "lm", formula = y ~ x, se = TRUE,
    colour = "black", linewidth = 0.6
  ) +
  facet_grid(resposta ~ ciclo, scales = "free", drop = TRUE) +
  labs(
    x = "Variação diária de P(PT) (p.p.)",
    y = "Variação diária da variável financeira",
    title = "Associação entre ΔP(PT) e variações do mercado financeiro",
    subtitle = "Pregões regulares; noites eleitorais excluídas. Linha: ajuste linear (MQO), não causal"
  ) +
  theme_minimal(base_size = 10) +
  theme(panel.grid.minor = element_blank())

save_plot(
  g_disp,
  file.path(saida_dir, "dispersao_dp_respostas.png"),
  width = 11,
  height = 8
)

# ------------------------------------------------------------
# 7.1. Exportar todas as tabelas para um único arquivo Excel
# ------------------------------------------------------------

tabelas_excel <- list(
  Estatisticas_descritivas = descritivas,
  Fases_e_volatilidade = niveis,
  Correlacoes = correlacoes,
  Noites_eleitorais = noites,
  Maiores_choques_P_PT = maiores_choques
)

if (exists("ccf_tabela")) {
  tabelas_excel$CCF = ccf_tabela
}

exportar_excel(
  tabelas_excel,
  file.path(saida_dir, "resultados_descritivos.xlsx")
)

# 8. Exibir tabelas e gráficos no RStudio
# ------------------------------------------------------------

mostrar_tabela <- function(x, titulo) {
  cat("\n\n========================================\n")
  cat(titulo, "\n")
  cat("========================================\n")
  print(as.data.frame(x), row.names = FALSE)

  # No RStudio, abre a tabela no Data Viewer.
  if (interactive() && identical(Sys.getenv("RSTUDIO"), "1")) {
    utils::View(as.data.frame(x), title = titulo)
  }
}

# Tabelas no console e no Data Viewer do RStudio
mostrar_tabela(descritivas, "Estatísticas descritivas")
mostrar_tabela(niveis, "Níveis e volatilidade por fase")
mostrar_tabela(correlacoes, "Correlações por ciclo e empilhadas")
if (exists("ccf_tabela")) mostrar_tabela(ccf_tabela, "Funções de correlação cruzada (CCF)")
mostrar_tabela(noites, "Noites eleitorais")
mostrar_tabela(maiores_choques, "Maiores choques de P(PT)")

# Gráficos na aba Plots do RStudio
print(g_series)
print(g_volatilidade)
print(g_cor)
if (exists("g_ccf")) print(g_ccf)
print(g_disp)

# Matrizes numéricas também ficam disponíveis no Environment
# como cor_ciclos, cor_empilhada e cor_centrada.

message("04_descriptive.R concluído.")
message("Tabelas (CSV e Excel): ", normalizePath(saida_dir, winslash = "/", mustWork = FALSE))
message("Gráficos (PNG): ", normalizePath(saida_dir, winslash = "/", mustWork = FALSE))
message("Os gráficos também foram enviados à aba Plots do RStudio.")
