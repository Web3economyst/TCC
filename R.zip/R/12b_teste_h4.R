# ============================================================
# Script  : 12b_teste_h4.R
#
# Objetivo:
#   Testar a H4: dada a probabilidade dos mercados de previsão, a
#   surpresa das pesquisas no dia da sua divulgação NÃO move os
#   preços. Complementa o 12_event_study.R, que regride os retornos
#   anormais na surpresa sem controlar pela probabilidade do mercado.
#
#   (A) Regressão diária, condicional ao mercado de previsão
#         y_t = a_ciclo + b·ΔP(PT)_t + d·surpresa_t + g·dia_pesq_t
#               + controles_t + e_t
#       surpresa_t = surpresa média das pesquisas que entram no
#       pregão t (0 nos pregões sem pesquisa); dia_pesq_t = 1 se
#       entra pesquisa em t. H4: d = 0. Amostras: todos os pregões e
#       só os pregões com pesquisa.
#
#   (B) Estudo de eventos com controle do mercado de previsão
#         CAR_ativo(w) = a_ciclo + d·surpresa_e + b·CAR_ΔP(PT)(w) + e
#       Janelas w: antes [−3,−1], dia 0, [−1,+1], [0,+1], depois
#       [+1,+2]. A mesma regressão sem CAR_ΔP(PT) é a forma reduzida
#       (é a do 12). H4: d = 0 no dia 0, em [−1,+1] e em [0,+1].
#
#       Inferência (problema das janelas sobrepostas): pesquisas
#       divulgadas em pregões próximos compartilham retornos nas
#       janelas, e os eventos não são igualmente espaçados. Por isso,
#       além do Newey-West (referência), o script reporta:
#         (B1) bootstrap circular em blocos MÓVEIS de pregões:
#              sorteia sequências consecutivas de dias da série original
#              DENTRO de cada ciclo; retém os eventos ancorados nesses
#              pregões, com reposição. O bloco NÃO é formado por grupos
#              encadeados de eventos (que geravam um só bloco em 2018).
#              Usa bloco_boot=20 pregões ou janela menor quando o ciclo
#              é curto (mínimo necessário para preservar sobreposições).
#              Reporta EP, p-valor bilateral centrado e IC SIMÉTRICO
#              baseado na mesma distribuição das réplicas centralizadas.
#              Bootstrap é aproximação: não recria retornos/CARs diários.
#         (B2) amostra de eventos com janelas não sobrepostas
#              (seleção gulosa em ordem cronológica: um evento só
#              entra se a sua janela completa não toca a do último
#              evento mantido), com Newey-West.
#
#   (C1) O mercado de previsão reage à surpresa das pesquisas?
#         CAR_ΔP(PT)(w) = a_ciclo + d·surpresa_e + e
#       com as mesmas três formas de inferência do bloco B.
#
#   (C2) Quem se move primeiro, mercado de previsão ou agregador?
#       Granger nos dois sentidos entre ΔP(PT) e ΔP(pesquisas),
#       L = 1, 3, 5, amostra empilhada. As defasagens são construídas
#       na sequência ORIGINAL de pregões de cada ciclo e só depois são
#       feitas as exclusões (noites eleitorais e pregões sem
#       agregador), para que t−1 seja sempre o pregão imediatamente
#       anterior. Sensibilidade: excluir também os pregões cujas
#       defasagens incluem uma noite eleitoral.
#
#   Data de divulgação: fim do campo + defasagem_divulgacao (1 dia);
#   robustez com 0 e 2 dias (Tabela_H4_sensibilidade_data.csv). A
#   janela [−1,+1] cobre um dia de erro na data presumida.
#
#   LIMITAÇÕES DE INTERPRETAÇÃO (para o texto):
#   - A data do evento é presumida, não a divulgação pública
#     efetiva. Os resultados avaliam a associação com a divulgação
#     presumida e não permitem afirmar com precisão se houve reação
#     antes ou depois da publicação, o que importa sobretudo para o
#     C1 e para qualquer afirmação sobre antecipação.
#   - Controlar por ΔP(PT) é controlar por uma variável que pode ter
#     reagido à própria surpresa. O β com controle responde à
#     pergunta condicional da H4 (a pesquisa acrescenta algo além do
#     que o mercado de previsão registrou?), mas não identifica um
#     efeito causal direto da pesquisa nem prova que toda a
#     informação já estava nos preços. Por isso o script reporta
#     também o β sem controle (forma reduzida) e a diferença entre os
#     dois (parcela absorvida pelo controle).
#
#   Regressões: efeito fixo de ciclo, Newey-West dentro de cada ciclo
#   (vcov_nw do 00_functions.R), noites eleitorais excluídas. Só
#   Ibovespa e dólar.
#
# Entrada : data/processed/model_data_daily.rds, eventos_pesquisas.csv
# Saída   : output/12b_bootstrap_corrigido_saida/
#   h4_A_regressao_diaria.csv
#   h4_eventos.csv                        (eventos e grupos de sobreposição)
#   h4_bootstrap_diagnostico.csv          (comprimentos e nº de blocos por ciclo)
#   h4_B_event_study_controlado.csv       (NW, bootstrap, não sobrepostas)
#   h4_C1_mercado_reage_surpresa.csv
#   h4_C2_granger_mercado_agregador.csv
#   Tabela_H4.csv                         (compacta, para o Word)
#   Tabela_H4_mercado_reage.csv
#   Tabela_H4_sensibilidade_data.csv
#
# Rodar depois do 12_event_study.R (usa os mesmos arquivos).
# ============================================================

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

# Mantém os CSVs anteriores de output/12b_saida INTACTOS.
saida_dir <- saida("12b_bootstrap_corrigido")

model_data <- load_object(model_data_file)
aviso_simulado(model_data)

ativos_h4  <- c(r_ibov = "Ibovespa", r_usd = "Dólar")
n_boot     <- 999      # réplicas do bootstrap
bloco_boot <- 20       # comprimento-alvo dos blocos móveis, em pregões
semente    <- 20261117

# ----------------------------------------------------------
# Eventos (mesma busca de arquivo do 12)
# ----------------------------------------------------------
candidatos <- unique(c(
  file.path(electoral_raw_dir, "eventos_pesquisas.csv"),
  file.path(root, "saida_mercados", "eventos_pesquisas.csv"),
  file.path(dirname(root), "saida_mercados", "eventos_pesquisas.csv"),
  file.path(root, "eventos_pesquisas.csv"),
  file.path(dirname(root), "eventos_pesquisas.csv")
))
arq_eventos <- candidatos[file.exists(candidatos)][1]
if (is.na(arq_eventos)) stop("eventos_pesquisas.csv não encontrado (procurado em: ",
                             paste(candidatos, collapse = "; "), ").")
message("Eventos: ", arq_eventos)

eventos_raw <- readr::read_csv(arq_eventos, show_col_types = FALSE) |>
  dplyr::transmute(ciclo = as.character(ano), data_fim = as.Date(data_fim),
                   instituto, surpresa_pp) |>
  dplyr::filter(ciclo %in% as.character(unique(model_data$ciclo)), is.finite(surpresa_pp))

# Base na sequência original de pregões de cada ciclo
base <- model_data |>
  dplyr::mutate(ciclo = as.character(ciclo)) |>
  dplyr::arrange(ciclo, data) |>
  dplyr::group_by(ciclo) |>
  dplyr::mutate(pos = dplyr::row_number()) |>
  dplyr::ungroup()

# Primeiro pregão em ou depois de data_fim + defas (como no 12).
# Pesquisas que caem no mesmo pregão: surpresa média.
eventos_por_pregao <- function(defas) {
  eventos_raw |>
    dplyr::mutate(alvo = data_fim + defas) |>
    dplyr::rowwise() |>
    dplyr::mutate(pos0 = {
      b <- base[base$ciclo == ciclo & base$data >= alvo, ]
      if (nrow(b)) min(b$pos) else NA_integer_
    }) |>
    dplyr::ungroup() |>
    dplyr::filter(!is.na(pos0)) |>
    dplyr::group_by(ciclo, pos0) |>
    dplyr::summarise(n_pesquisas = dplyr::n(), surpresa = mean(surpresa_pp), .groups = "drop")
}

coef_nw <- function(m, termo) {
  t <- tidy_nw(m) |> dplyr::filter(term == termo)
  if (!nrow(t)) return(tibble::tibble(beta = NA_real_, ep = NA_real_, p = NA_real_))
  tibble::tibble(beta = t$estimate, ep = t$std.error, p = t$p.value)
}
fe_ciclo <- function(d) if (dplyr::n_distinct(d$ciclo) > 1) "factor(ciclo)" else NULL

defasagens <- unique(c(defasagem_divulgacao, defasagens_divulgacao_rob))

# ==========================================================
# (A) Regressão diária condicional ao mercado de previsão
# ==========================================================
res_A <- purrr::map_dfr(defasagens, function(defas) {
  ev <- eventos_por_pregao(defas)
  d <- base |>
    dplyr::left_join(ev |> dplyr::select(ciclo, pos = pos0, surpresa, n_pesquisas),
                     by = c("ciclo", "pos")) |>
    dplyr::mutate(dia_pesq = as.integer(!is.na(surpresa)),
                  surpresa = tidyr::replace_na(surpresa, 0)) |>
    dplyr::filter(noite_eleicao == 0)

  purrr::imap_dfr(ativos_h4, function(rot, y) {
    amostras <- list("Todos os pregões" = d, "Só pregões com pesquisa" = dplyr::filter(d, dia_pesq == 1))
    purrr::imap_dfr(amostras, function(dd, nome_am) {
      rhs_com <- c("dp_pt", "surpresa", if (nome_am == "Todos os pregões") "dia_pesq", controles, fe_ciclo(dd))
      rhs_sem <- setdiff(rhs_com, "dp_pt")
      dd <- tidyr::drop_na(dd, dplyr::all_of(c(y, "dp_pt", "surpresa", controles)))
      m_com <- lm(stats::reformulate(rhs_com, y), data = dd)
      m_sem <- lm(stats::reformulate(rhs_sem, y), data = dd)
      dplyr::bind_rows(
        coef_nw(m_com, "surpresa") |> dplyr::mutate(termo = "surpresa", controle_mercado = "sim"),
        coef_nw(m_com, "dp_pt")    |> dplyr::mutate(termo = "dp_pt",    controle_mercado = "sim"),
        coef_nw(m_sem, "surpresa") |> dplyr::mutate(termo = "surpresa", controle_mercado = "não")
      ) |>
        dplyr::mutate(defasagem = defas, ativo = rot, amostra = nome_am,
                      n = nobs(m_com), n_dias_pesquisa = sum(dd$dia_pesq), .before = 1)
    })
  })
})
export_table(res_A |> format_table(4), file.path(saida_dir, "h4_A_regressao_diaria.csv"))

# ==========================================================
# Eventos, CARs e grupos de sobreposição (para não sobrepostas)
# ==========================================================
# Retornos anormais: ativo menos o previsto pelos controles, por
# ciclo, sem as noites eleitorais (igual ao 12). ΔP(PT) sem ajuste.
for (y in names(ativos_h4)) {
  base[[paste0("ar_", y)]] <- NA_real_
  for (cc in unique(base$ciclo)) {
    i <- base$ciclo == cc
    m <- lm(stats::reformulate(controles, y), data = base[i & base$noite_eleicao == 0, ])
    base[[paste0("ar_", y)]][i] <- base[[y]][i] - predict(m, newdata = base[i, ])
  }
}

janelas <- list(`antes [-3,-1]` = c(-janela_antes, -1), `dia 0` = c(0, 0),
                `[-1,+1]` = c(-1, 1), `[0,+1]` = c(0, 1), `depois [+1,+2]` = c(1, janela_depois))
janelas_h4 <- c("dia 0", "[-1,+1]", "[0,+1]")
larg_total <- janela_antes + janela_depois   # janelas completas se tocam se pos0 difere <= isso

montar_car <- function(defas) {
  ev <- eventos_por_pregao(defas)
  out <- purrr::pmap_dfr(ev, function(ciclo, pos0, n_pesquisas, surpresa) {
    bc <- base[base$ciclo == ciclo, ]
    jan <- (pos0 - janela_antes):(pos0 + janela_depois)
    fora <- any(jan < 1 | jan > nrow(bc)) ||
      any(bc$noite_eleicao[jan[jan >= 1 & jan <= nrow(bc)]] == 1)
    o <- tibble::tibble(defasagem = defas, ciclo = ciclo, pos0 = pos0, data0 = bc$data[pos0],
                        n_pesquisas = n_pesquisas, surpresa = surpresa, excluido = fora)
    for (jn in names(janelas)) {
      k <- (pos0 + janelas[[jn]][1]):(pos0 + janelas[[jn]][2])
      k <- k[k >= 1 & k <= nrow(bc)]
      o[[paste0("car_dp_pt|", jn)]] <- sum(bc$dp_pt[k])
      for (y in names(ativos_h4)) o[[paste0("car_", y, "|", jn)]] <- sum(bc[[paste0("ar_", y)]][k])
    }
    o
  })
  out |>
    dplyr::filter(!excluido) |>
    dplyr::arrange(ciclo, pos0) |>
    dplyr::group_by(ciclo) |>
    dplyr::mutate(
      # grupo: eventos cujas janelas completas se sobrepõem (em cadeia)
      grupo = cumsum(c(TRUE, diff(pos0) > larg_total)),
      # amostra não sobreposta: gulosa, em ordem cronológica
      nao_sobreposto = {
        keep <- logical(dplyr::n()); ultimo <- -Inf
        for (j in seq_along(pos0)) if (pos0[j] - ultimo > larg_total) { keep[j] <- TRUE; ultimo <- pos0[j] }
        keep
      }) |>
    dplyr::ungroup() |>
    dplyr::mutate(grupo = paste(ciclo, grupo, sep = "_"))
}
eventos <- purrr::map_dfr(defasagens, montar_car)
export_table(eventos |> format_table(4), file.path(saida_dir, "h4_eventos.csv"))

# ----------------------------------------------------------
# Bootstrap circular por blocos MÓVEIS de pregões (por ciclo)
# ----------------------------------------------------------
# Os CARs foram calculados ANTES da reamostragem. Reamostramos
# conjuntamente (surpresa, CAR ativo, CAR mercado) dos eventos
# ancorados em blocos consecutivos de dias de negociação. Isso preserva
# dependência entre eventos próximos dentro do mesmo bloco; NÃO é
# um bootstrap de toda a série diária com recálculo de CARs.
# Em 2018 a janela é reduzida para evitar a degeneração de um bloco.
# As estimativas bootstrap devem ser lidas como robustez exploratória,
# especialmente diante dos 34 pregões e 13 eventos de 2018.

n_pregoes_por_ciclo <- table(as.character(base$ciclo))

plano_blocos <- function(ciclos = names(n_pregoes_por_ciclo)) {
  tibble::tibble(ciclo = ciclos) |>
    dplyr::mutate(
      n_pregoes = as.integer(n_pregoes_por_ciclo[ciclo]),
      comprimento = pmin(
        bloco_boot,
        pmax(larg_total + 1L, floor(n_pregoes / 4L))
      ),
      comprimento = pmin(comprimento, n_pregoes),
      n_blocos_sorteados = as.integer(ceiling(n_pregoes / comprimento))
    )
}

plano <- plano_blocos()
diagnostico_boot <- eventos |>
  dplyr::filter(defasagem == defasagem_divulgacao) |>
  dplyr::group_by(ciclo) |>
  dplyr::summarise(
    n_eventos = dplyr::n(),
    n_grupos_sobrepostos = dplyr::n_distinct(grupo),
    maior_grupo_eventos = max(as.integer(table(grupo))),
    n_eventos_nao_sobrepostos = sum(nao_sobreposto),
    .groups = "drop"
  ) |>
  dplyr::right_join(plano, by = "ciclo") |>
  dplyr::arrange(ciclo)
export_table(diagnostico_boot, file.path(saida_dir, "h4_bootstrap_diagnostico.csv"))

boot_blocos <- function(d, formula, termo, B = n_boot) {
  X <- stats::model.matrix(formula, data = d)
  yv <- stats::model.response(stats::model.frame(formula, data = d))
  j <- match(termo, colnames(X))
  if (is.na(j)) stop("Termo não localizado no modelo bootstrap: ", termo)
  b_hat <- unname(stats::coef(stats::lm.fit(X, yv))[j])
  if (!is.finite(b_hat)) stop("Modelo original singular na inferência da H4: ", termo)
  info <- plano_blocos(unique(as.character(d$ciclo)))

  # Mapeia o pregão original ao índice de observação do evento.
  # Uma linha por data/posição porque os institutos foram agregados
  # previamente pela média de suas surpresas no mesmo pregão.
  mapas <- lapply(seq_len(nrow(info)), function(i) {
    cc <- info$ciclo[i]
    rows <- which(as.character(d$ciclo) == cc)
    map <- rep(NA_integer_, info$n_pregoes[i])
    if (anyDuplicated(d$pos0[rows])) {
      stop("Há mais de um evento por pregão no ciclo ", cc)
    }
    map[d$pos0[rows]] <- rows
    map
  })

  # Circular moving-block bootstrap: cada réplica sorteia vários
  # inícios independentes de blocos consecutivos em cada ciclo.
  # O número de eventos por réplica pode variar, pois alguns pregões
  # não apresentam pesquisas.
  bs <- vapply(seq_len(B), function(r) {
    ids <- unlist(lapply(seq_len(nrow(info)), function(i) {
      ncal <- info$n_pregoes[i]
      L <- info$comprimento[i]
      n_bloc <- info$n_blocos_sorteados[i]
      inicios <- sample.int(ncal, n_bloc, replace = TRUE)
      pos_sorteadas <- as.integer(unlist(lapply(inicios, function(st) {
        ((st - 1L + seq_len(L) - 1L) %% ncal) + 1L
      }), use.names = FALSE))
      # Igualar a extensão reamostrada ao nº original de pregões.
      pos_sorteadas <- head(pos_sorteadas, ncal)
      ix <- mapas[[i]][pos_sorteadas]
      ix[!is.na(ix)]
    }), use.names = FALSE)

    # Exigir amostra suficiente e presença de todos os ciclos.
    if (length(ids) <= ncol(X) + 5L ||
        any(!info$ciclo %in% as.character(d$ciclo[ids])) ||
        any(table(factor(as.character(d$ciclo[ids]), levels = info$ciclo)) < 3L)) {
      return(NA_real_)
    }
    bb <- tryCatch(stats::coef(stats::lm.fit(X[ids, , drop = FALSE], yv[ids]))[j],
                   error = function(e) NA_real_)
    if (length(bb) != 1L || !is.finite(bb)) NA_real_ else unname(bb)
  }, numeric(1))
  bs <- bs[is.finite(bs)]

  nmin <- ceiling(0.90 * B)
  nplan <- sum(info$n_blocos_sorteados)
  info_str <- paste0(info$ciclo, ":", info$n_blocos_sorteados,
                     " blocos de ", info$comprimento, " pregões",
                     collapse = "; ")
  status <- "ok_exploratorio"
  if (length(bs) < nmin || length(bs) < 100L ||
      !is.finite(stats::sd(bs)) ||
      stats::sd(bs) < 1e-8 * max(1, abs(b_hat))) status <- "bootstrap_indisponivel"

  # Teste e IC usam a MESMA distribuição centrada e a MESMA
  # regra bilateral (desvio ABSOLUTO), para não produzir decisões
  # inconsistentes entre p-valor e IC de 95%.
  if (status == "ok_exploratorio") {
    desvio <- abs(bs - mean(bs))
    q95 <- unname(stats::quantile(desvio, probs = 0.95))
    p <- (1 + sum(desvio >= abs(b_hat))) / (length(bs) + 1)
    ep <- stats::sd(bs)
    lo <- b_hat - q95
    hi <- b_hat + q95
  } else {
    p <- ep <- lo <- hi <- NA_real_
  }
  tibble::tibble(
    beta_boot_ep = ep, ic_lo_boot = lo, ic_hi_boot = hi,
    p_boot = p, n_blocos = nplan,
    n_grupos = dplyr::n_distinct(d$grupo),
    b_validas = length(bs),
    blocos_por_ciclo = info_str, bootstrap_status = status
  )
}

# Uma regressão de evento com as três inferências
regredir_evento <- function(d, y, x) {
  f <- stats::reformulate(c(x, fe_ciclo(d)), y)
  m <- lm(f, data = d)
  nw <- coef_nw(m, x[1])
  bt <- boot_blocos(d, f, x[1])
  d_ns <- dplyr::filter(d, nao_sobreposto)
  ns <- if (nrow(d_ns) >= 15) {
    m2 <- lm(stats::reformulate(c(x, fe_ciclo(d_ns)), y), data = d_ns)
    coef_nw(m2, x[1]) |> dplyr::rename(beta_ns = beta, ep_ns = ep, p_ns = p) |> dplyr::mutate(n_ns = nobs(m2))
  } else tibble::tibble(beta_ns = NA_real_, ep_ns = NA_real_, p_ns = NA_real_, n_ns = nrow(d_ns))
  dplyr::bind_cols(nw, bt, ns) |> dplyr::mutate(n_eventos = nobs(m))
}

set.seed(semente)

# ==========================================================
# (B) Estudo de eventos com controle do mercado de previsão
# ==========================================================
res_B <- purrr::map_dfr(defasagens, function(defas) {
  e <- dplyr::filter(eventos, defasagem == defas)
  purrr::map_dfr(names(janelas), function(jn) {
    purrr::imap_dfr(ativos_h4, function(rot, y) {
      d <- e |>
        dplyr::transmute(ciclo, pos0, grupo, nao_sobreposto, surpresa,
                         car = .data[[paste0("car_", y, "|", jn)]],
                         car_dp = .data[[paste0("car_dp_pt|", jn)]]) |>
        dplyr::filter(is.finite(car), is.finite(car_dp))
      if (nrow(d) < 15) return(tibble::tibble())
      dplyr::bind_rows(
        regredir_evento(d, "car", "surpresa") |> dplyr::mutate(controle_mercado = "não"),
        regredir_evento(d, "car", c("surpresa", "car_dp")) |> dplyr::mutate(controle_mercado = "sim")
      ) |>
        dplyr::mutate(defasagem = defas, ativo = rot, janela = jn, .before = 1)
    })
  })
}) |>
  dplyr::group_by(defasagem, ativo, janela) |>
  dplyr::mutate(absorvido_pelo_controle = beta[controle_mercado == "não"] - beta[controle_mercado == "sim"]) |>
  dplyr::ungroup()
export_table(res_B |> format_table(4), file.path(saida_dir, "h4_B_event_study_controlado.csv"))

# ==========================================================
# (C1) O mercado de previsão reage à surpresa das pesquisas?
# ==========================================================
res_C1 <- purrr::map_dfr(defasagens, function(defas) {
  e <- dplyr::filter(eventos, defasagem == defas)
  purrr::map_dfr(names(janelas), function(jn) {
    d <- e |> dplyr::transmute(ciclo, pos0, grupo, nao_sobreposto, surpresa,
                               car_dp = .data[[paste0("car_dp_pt|", jn)]]) |>
      dplyr::filter(is.finite(car_dp))
    regredir_evento(d, "car_dp", "surpresa") |> dplyr::mutate(defasagem = defas, janela = jn, .before = 1)
  })
})
export_table(res_C1 |> format_table(4), file.path(saida_dir, "h4_C1_mercado_reage_surpresa.csv"))

# ==========================================================
# (C2) Precedência: mercado de previsão x agregador (Granger)
# ==========================================================
# Defasagens construídas na sequência original de pregões de cada
# ciclo (base inteira, ordenada) e só depois as exclusões.
granger_seq_original <- function(dados, cause, effect, L, excluir_lag_noite = FALSE) {
  d <- add_lags(dados, c(cause, effect, "noite_eleicao"), L)   # na sequência completa
  termos <- c(lag_terms(effect, L), lag_terms(cause, L))
  d <- d |>
    dplyr::filter(noite_eleicao == 0, is.finite(p_pesq),
                  dplyr::if_all(dplyr::all_of(c(effect, termos, controles)), is.finite))
  if (excluir_lag_noite) d <- dplyr::filter(d, dplyr::if_all(dplyr::all_of(lag_terms("noite_eleicao", L)), ~ .x == 0))
  rhs <- c(termos, controles, fe_ciclo(d))
  m <- lm(stats::reformulate(rhs, effect), data = d)
  if (nobs(m) < 30) return(tibble::tibble(causa = cause, efeito = effect, L = L, n = nobs(m), F = NA_real_, p_value = NA_real_))
  w <- wald_nw(m, lag_terms(cause, L))
  tibble::tibble(causa = cause, efeito = effect, L = L, n = nobs(m), F = w$F, p_value = w$p_value)
}

res_C2 <- tibble::tibble()
if ("dp_pesq" %in% names(model_data)) {
  dg <- base   # sequência original, sem filtros
  res_C2 <- purrr::map_dfr(c(FALSE, TRUE), function(ex) purrr::map_dfr(c(1, 3, 5), function(L) dplyr::bind_rows(
    granger_seq_original(dg, "dp_pt", "dp_pesq", L, ex),
    granger_seq_original(dg, "dp_pesq", "dp_pt", L, ex)
  ) |> dplyr::mutate(amostra = if (ex) "Sem pregões com noite eleitoral nas defasagens" else "Principal"))) |>
    dplyr::mutate(direcao = dplyr::if_else(causa == "dp_pt",
                                           "Mercado de previsão → agregador",
                                           "Agregador → mercado de previsão"), .before = 1)
  export_table(res_C2 |> format_table(4), file.path(saida_dir, "h4_C2_granger_mercado_agregador.csv"))
} else message("Sem dp_pesq na base: bloco C2 pulado.")

# ==========================================================
# Tabelas compactas para o Word
# ==========================================================
estrela <- function(p) dplyr::case_when(p < 0.01 ~ "***", p < 0.05 ~ "**", p < 0.10 ~ "*", TRUE ~ "")
num <- function(x, k = 3) { x <- round(x, k); x[x == 0] <- 0; formatC(x, format = "f", digits = k, decimal.mark = ",") }
fmt <- function(b, ep, p) ifelse(is.finite(b), paste0(num(b), estrela(p), " (", num(ep), ")"), "—")
fmt_p <- function(p) ifelse(is.finite(p), num(p), "—")

tab_A <- res_A |>
  dplyr::filter(defasagem == defasagem_divulgacao, termo == "surpresa", controle_mercado == "sim") |>
  dplyr::transmute(Bloco = "A – regressão diária", Especificação = amostra, ativo,
                   `β (EP NW)` = fmt(beta, ep, p), `p bootstrap` = "—", `β não sobrepostas` = "—", N = n)
tab_B <- res_B |>
  dplyr::filter(defasagem == defasagem_divulgacao, janela %in% c("antes [-3,-1]", janelas_h4)) |>
  dplyr::transmute(Bloco = "B – estudo de eventos",
                   Especificação = paste0(janela, dplyr::if_else(controle_mercado == "sim", ", com CAR ΔP(PT)", ", sem controle")),
                   ativo, `β (EP NW)` = fmt(beta, ep, p), `p bootstrap` = fmt_p(p_boot),
                   `β não sobrepostas` = paste0(fmt(beta_ns, ep_ns, p_ns), " [n = ", n_ns, "]"), N = n_eventos)
tabela <- dplyr::bind_rows(tab_A, tab_B) |>
  tidyr::pivot_wider(names_from = ativo, values_from = c(`β (EP NW)`, `p bootstrap`, `β não sobrepostas`, N),
                     names_glue = "{ativo}: {.value}")
export_table(tabela, file.path(saida_dir, "Tabela_H4.csv"))

tab_C1 <- res_C1 |> dplyr::filter(defasagem == defasagem_divulgacao) |>
  dplyr::transmute(Janela = janela, `β da surpresa sobre CAR ΔP(PT) (EP NW)` = fmt(beta, ep, p),
                   `p bootstrap` = fmt_p(p_boot), `β não sobrepostas` = paste0(fmt(beta_ns, ep_ns, p_ns), " [n = ", n_ns, "]"),
                   Eventos = n_eventos)
export_table(tab_C1, file.path(saida_dir, "Tabela_H4_mercado_reage.csv"))

# Sensibilidade à data presumida de divulgação (β com controle, janelas da H4, e C1)
tab_data <- dplyr::bind_rows(
  res_B |> dplyr::filter(controle_mercado == "sim", janela %in% janelas_h4) |>
    dplyr::transmute(Resposta = ativo, janela, defasagem, v = fmt(beta, ep, p)),
  res_C1 |> dplyr::filter(janela %in% c("antes [-3,-1]", janelas_h4)) |>
    dplyr::transmute(Resposta = "ΔP(PT) (sem controle)", janela, defasagem, v = fmt(beta, ep, p))
) |>
  tidyr::pivot_wider(names_from = defasagem, values_from = v, names_prefix = "divulgação = fim do campo + ")
export_table(tab_data, file.path(saida_dir, "Tabela_H4_sensibilidade_data.csv"))

# ----------------------------------------------------------
# Resumo no console
# ----------------------------------------------------------
op <- options(width = 200)
cat("\n===== Eventos e plano do novo bootstrap móvel por ciclo =====\n")
print(diagnostico_boot, n = Inf)
cat("\n===== H4 – tabela compacta =====\n"); print(tabela, n = Inf)
cat("\n===== (C1) O mercado de previsão reage à surpresa? =====\n"); print(tab_C1, n = Inf)
cat("\n===== Sensibilidade à data de divulgação =====\n"); print(tab_data, n = Inf)
if (nrow(res_C2)) { cat("\n===== (C2) Granger: mercado de previsão x agregador =====\n"); print(res_C2 |> format_table(3), n = Inf) }
options(op)
cat("\nLeitura: a H4 não é rejeitada se o β da surpresa com controle do mercado não é\n",
    "significativo no dia 0, em [-1,+1] e em [0,+1] pelas três inferências (NW, bootstrap\n",
    "em blocos e janelas não sobrepostas). O β com controle é condicional ao mercado de\n",
    "previsão; não é efeito causal da pesquisa. As datas de divulgação são presumidas.\n")

message("12b_teste_h4.R concluído com sucesso.")
