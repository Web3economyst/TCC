# ============================================================
# Script  : 04c_controles_adicionais.R
#
# Objetivo:
#   Descritiva de controles que NÃO estão nos modelos principais:
#   índice global do dólar (DXY), petróleo Brent e os dias de
#   decisão de juros (Copom e Fomc). Serve para avaliar se vale a
#   pena incluí-los (robustez R15).
#
#   Um controle omitido só enviesa o coeficiente de reação se:
#     (a) move o ativo no mesmo pregão; e
#     (b) está correlacionado com ΔP(PT) no mesmo pregão.
#   As seções 2 e 3 olham (a) e (b); a 4 mostra quanto o coeficiente
#   muda quando os controles entram.
#
#   1. Séries no tempo: dólar da B3, DXY e Brent (base 100) e Selic
#      meta, com as datas do Copom.
#   2. Correlações de r_dxy e r_brent com ΔP(PT), os ativos e os
#      controles atuais (por ciclo e empilhado centrado por ciclo).
#   3. Dias de decisão de juros: variação média (em módulo) dos
#      ativos e de P(PT) nesses dias e nos demais.
#   4. Prévia da R15: coeficiente de reação com e sem os controles
#      adicionais, na mesma amostra (empilhado e em cada ciclo).
#
#   Nas seções 2 e 3 as noites eleitorais ficam de fora (mesma regra
#   do gráfico de dispersão e da CCF). A seção 4 usa a amostra do
#   modelo principal.
#
#   Horário: DXY e Brent pelo fechamento do Yahoo na mesma data do
#   pregão (como S&P, Treasury e VIX). Dia sem cotação: repete o
#   último valor (variação 0). O Brent do Yahoo (BZ=F) é o contrato
#   mais próximo: na troca de vencimento pode haver um salto.
#
# Entrada : data/processed/model_data_daily.rds
#           data/raw/controles_extras.rds (baixado aqui na 1ª vez)
# Saída   : data/processed/controles_extras_daily.rds (usado na R15 do 10)
#           output/04c_saida/controles_extras_correlacoes.csv
#           output/04c_saida/decisoes_juros_resumo.csv
#           output/04c_saida/decisoes_juros_dias.csv
#           output/04c_saida/controles_extras_previa_r15.csv
#           output/04c_saida/controles_extras_series.png
#           output/04c_saida/controles_extras_correlacoes.png
#           output/04c_saida/decisoes_juros.png
#
# Próximo script: 05_stationarity.R
# ============================================================

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

saida_dir <- saida("04c")

model_data <- load_object(model_data_file)
aviso_simulado(model_data)

BAIXAR_DE_NOVO <- FALSE
extras_file <- file.path(raw_dir, "controles_extras.rds")

# ------------------------------------------------------------
# 0. Download (Yahoo: DXY e Brent; BCB/SGS: Selic meta)
# ------------------------------------------------------------

baixar_yahoo_fech <- function(ticker, inicio, fim) {
  x <- quantmod::getSymbols(ticker, src = "yahoo", from = inicio, to = fim,
                            auto.assign = FALSE, warnings = FALSE)
  tibble::tibble(data = as.Date(zoo::index(x)), fecham = as.numeric(quantmod::Cl(x)))
}

baixar_sgs <- function(codigo, inicio, fim) {
  url <- sprintf(
    "https://api.bcb.gov.br/dados/serie/bcdata.sgs.%d/dados?formato=json&dataInicial=%s&dataFinal=%s",
    codigo, format(inicio, "%d/%m/%Y"), format(fim, "%d/%m/%Y")
  )
  x <- jsonlite::fromJSON(url)
  tibble::tibble(data = as.Date(x$data, "%d/%m/%Y"), fecham = as.numeric(x$valor))
}

if (BAIXAR_DE_NOVO || !file.exists(extras_file)) {
  message("Baixando DXY, Brent (Yahoo) e Selic meta (BCB)...")
  ini_dl <- min(ciclos$inicio_completo) - margem_download_dias
  fim_dl <- max(ciclos$fim) + 5
  extras <- purrr::imap(tickers_extras, function(tk, nome) {
    message("  ", nome, " (", tk, ")")
    tryCatch(baixar_yahoo_fech(tk, ini_dl, fim_dl),
             error = function(e) { message("  ", nome, " não baixado: ", conditionMessage(e)); NULL })
  })
  extras$selic <- tryCatch(
    purrr::pmap_dfr(ciclos, function(inicio_completo, fim, ...) {
      baixar_sgs(sgs_selic_meta, inicio_completo - margem_download_dias, fim)
    }) |> dplyr::distinct(data, .keep_all = TRUE),
    error = function(e) { message("  Selic não baixada: ", conditionMessage(e)); NULL }
  )
  attr(extras, "baixado_em") <- Sys.time()
  save_object(extras, extras_file)
} else {
  message("Controles adicionais: usando arquivo já baixado (", extras_file, ").")
  extras <- load_object(extras_file)
}
extras <- purrr::compact(extras)

# ------------------------------------------------------------
# 0b. Base: séries alinhadas aos pregões, variações e dias de decisão
# ------------------------------------------------------------

md <- model_data |> dplyr::arrange(ciclo, data)
for (nome in names(extras)) {
  serie <- extras[[nome]] |>
    dplyr::filter(is.finite(fecham)) |>
    dplyr::select(data_f = data, !!nome := fecham)
  md <- md |>
    dplyr::left_join(serie, by = dplyr::join_by(closest(data >= data_f))) |>
    dplyr::select(-data_f)
}
for (nome in c("dxy", "brent", "selic")) if (!nome %in% names(md)) md[[nome]] <- NA_real_

# Pregão em que a decisão aparece no preço (até 7 dias depois do anúncio)
pregao_efeito <- function(datas, mesmo_dia) {
  pregoes <- sort(unique(md$data))
  purrr::map(datas, function(d) {
    cand <- if (mesmo_dia) pregoes[pregoes >= d] else pregoes[pregoes > d]
    if (length(cand) && cand[1] - d <= 7) cand[1] else as.Date(NA)
  }) |> unlist() |> as.Date(origin = "1970-01-01") |> stats::na.omit()
}
dias_copom <- pregao_efeito(datas_copom, mesmo_dia = FALSE)
dias_fomc  <- pregao_efeito(datas_fomc,  mesmo_dia = TRUE)

md <- md |>
  dplyr::group_by(ciclo) |>
  dplyr::mutate(
    r_dxy   = 100 * (log(dxy) - dplyr::lag(log(dxy))),
    r_brent = 100 * (log(brent) - dplyr::lag(log(brent))),
    usd_b100   = 100 * usd / dplyr::first(stats::na.omit(usd)),
    dxy_b100   = 100 * dxy / dplyr::first(stats::na.omit(dxy)),
    brent_b100 = 100 * brent / dplyr::first(stats::na.omit(brent))
  ) |>
  dplyr::ungroup() |>
  dplyr::mutate(dia_copom = as.integer(data %in% dias_copom),
                dia_fomc  = as.integer(data %in% dias_fomc))

tem_extras <- sum(is.finite(md$r_dxy)) > 50 && sum(is.finite(md$r_brent)) > 50

# Guarda os controles adicionais por pregão para a robustez R15 (10)
save_object(dplyr::select(md, ciclo, data, r_dxy, r_brent, dia_copom, dia_fomc), extras_daily_file)
if (!tem_extras) message("DXY ou Brent sem dados suficientes: seções 2 e 4 ficam vazias.")

rotulos <- c(dp_pt = "ΔP(PT)", r_ibov = "Ibovespa", r_usd = "Dólar", d_di1 = "DI 1 ano",
             d_di5 = "DI 5 anos", r_spx = "S&P 500", d_ust10 = "Treasury 10a", r_vix = "VIX",
             r_dxy = "DXY", r_brent = "Brent")
vars_ativos <- c("dp_pt", names(respostas))

sem_noites <- md |> dplyr::filter(is.na(noite_eleicao) | noite_eleicao == 0)

# ------------------------------------------------------------
# 1. Séries no tempo
# ------------------------------------------------------------

serie <- md |>
  dplyr::select(ciclo, data, `Dólar (B3)` = usd_b100, DXY = dxy_b100, Brent = brent_b100,
                `Selic meta` = selic) |>
  tidyr::pivot_longer(-c(ciclo, data), names_to = "serie", values_to = "valor") |>
  dplyr::filter(is.finite(valor)) |>
  dplyr::mutate(painel = dplyr::if_else(serie == "Selic meta", "Selic meta (% a.a.)", "Índices (base 100)"),
                painel = factor(painel, c("Índices (base 100)", "Selic meta (% a.a.)")),
                serie = factor(serie, c("Dólar (B3)", "DXY", "Brent", "Selic meta")))

marcas_copom <- md |> dplyr::filter(dia_copom == 1) |> dplyr::select(ciclo, data)

g1 <- ggplot(serie, aes(data, valor, colour = serie)) +
  geom_vline(data = marcas_copom, aes(xintercept = data), colour = "grey75", linetype = "dotted") +
  geom_line(linewidth = 0.5) +
  facet_grid(painel ~ ciclo, scales = "free") +
  scale_colour_manual(values = c(`Dólar (B3)` = "steelblue4", DXY = "darkorange",
                                 Brent = "grey35", `Selic meta` = "firebrick"), name = NULL) +
  scale_x_date(breaks = scales::breaks_pretty(4), date_labels = "%d/%m/%y") +
  labs(x = NULL, y = NULL,
       title = "Dólar, dólar global (DXY), petróleo e Selic em cada ciclo",
       subtitle = "Base 100 no primeiro pregão de cada ciclo; linhas pontilhadas: pregões após as decisões do Copom") +
  theme_minimal(base_size = 10) +
  theme(legend.position = "bottom", panel.grid.minor = element_blank())

save_plot(g1, file.path(saida_dir, "controles_extras_series.png"), width = 11, height = 6)

# ------------------------------------------------------------
# 2. Correlações dos controles adicionais
# ------------------------------------------------------------

cor_com_p <- function(d, a, b) {
  ok <- is.finite(d[[a]]) & is.finite(d[[b]])
  if (sum(ok) < 10) return(tibble::tibble(corr = NA_real_, p_valor = NA_real_, n = sum(ok)))
  t <- stats::cor.test(d[[a]][ok], d[[b]][ok])
  tibble::tibble(corr = unname(t$estimate), p_valor = t$p.value, n = sum(ok))
}

vars_cor <- c(vars_ativos, controles)
amostras <- c(purrr::set_names(as.character(sort(unique(md$ciclo)))),
              `Empilhado (centrado)` = "empilhado")

correlacoes <- if (tem_extras) {
  purrr::imap_dfr(amostras, function(cc, rot) {
    d <- if (cc == "empilhado") {
      sem_noites |>
        dplyr::group_by(ciclo) |>
        dplyr::mutate(dplyr::across(dplyr::all_of(c(vars_cor, "r_dxy", "r_brent")),
                                    ~ .x - mean(.x, na.rm = TRUE))) |>
        dplyr::ungroup()
    } else dplyr::filter(sem_noites, ciclo == as.numeric(cc))
    tidyr::expand_grid(controle = c("r_dxy", "r_brent"), variavel = vars_cor) |>
      dplyr::mutate(amostra = rot, purrr::map2_dfr(controle, variavel, ~ cor_com_p(d, .x, .y)))
  }) |>
    dplyr::relocate(amostra)
} else tibble::tibble()

export_table(correlacoes |> format_table(3),
             file.path(saida_dir, "controles_extras_correlacoes.csv"))

if (nrow(correlacoes)) {
  g2 <- correlacoes |>
    dplyr::mutate(
      variavel = factor(rotulos[variavel], rotulos[vars_cor]),
      controle = factor(rotulos[controle], rev(rotulos[c("r_dxy", "r_brent")])),
      amostra = factor(amostra, names(amostras)),
      rotulo = paste0(formatC(corr, format = "f", digits = 2, decimal.mark = ","),
                      dplyr::case_when(p_valor < 0.01 ~ "***", p_valor < 0.05 ~ "**",
                                       p_valor < 0.10 ~ "*", TRUE ~ ""))
    ) |>
    ggplot(aes(variavel, controle, fill = corr)) +
    geom_tile(colour = "white") +
    geom_text(aes(label = rotulo), size = 3) +
    scale_fill_gradient2(low = "firebrick", mid = "white", high = "steelblue4",
                         midpoint = 0, limits = c(-1, 1), name = "Correlação") +
    facet_wrap(~ amostra, ncol = 1) +
    labs(x = NULL, y = NULL,
         title = "Correlação do DXY e do Brent com a probabilidade, os ativos e os controles atuais",
         subtitle = "Variações diárias, sem as noites eleitorais. * p < 0,10; ** p < 0,05; *** p < 0,01.\nA coluna ΔP(PT) é a condição para viés: correlação perto de zero = omitir o controle não enviesa a reação.") +
    theme_minimal(base_size = 10) +
    theme(axis.text.x = element_text(angle = 30, hjust = 1), panel.grid = element_blank())
  save_plot(g2, file.path(saida_dir, "controles_extras_correlacoes.png"), width = 10, height = 7)
}

# ------------------------------------------------------------
# 3. Dias de decisão de juros
# ------------------------------------------------------------

longo_dec <- sem_noites |>
  dplyr::select(ciclo, data, dia_copom, dia_fomc, dplyr::all_of(vars_ativos)) |>
  tidyr::pivot_longer(dplyr::all_of(vars_ativos), names_to = "variavel", values_to = "valor") |>
  dplyr::filter(is.finite(valor))

resumo_tipo <- function(d, col, tipo) {
  d |>
    dplyr::mutate(decisao = .data[[col]] == 1) |>
    dplyr::group_by(ciclo = as.character(ciclo), variavel) |>
    dplyr::summarise(
      tipo = tipo,
      dias_decisao = sum(decisao),
      media_abs_decisao = mean(abs(valor[decisao])),
      media_abs_demais  = mean(abs(valor[!decisao])),
      dp_decisao = if (sum(decisao) > 1) sd(valor[decisao]) else NA_real_,
      dp_demais  = sd(valor[!decisao]),
      .groups = "drop"
    )
}
resumo_dec <- dplyr::bind_rows(
  resumo_tipo(longo_dec, "dia_copom", "Copom"),
  resumo_tipo(longo_dec, "dia_fomc", "Fomc"),
  resumo_tipo(dplyr::mutate(longo_dec, ciclo = "Empilhado"), "dia_copom", "Copom"),
  resumo_tipo(dplyr::mutate(longo_dec, ciclo = "Empilhado"), "dia_fomc", "Fomc")
) |>
  dplyr::mutate(razao = media_abs_decisao / media_abs_demais,
                variavel_rotulo = rotulos[variavel]) |>
  dplyr::relocate(ciclo, tipo, variavel, variavel_rotulo)

export_table(resumo_dec |> format_table(3), file.path(saida_dir, "decisoes_juros_resumo.csv"))

dias_dec <- md |>
  dplyr::filter(dia_copom == 1 | dia_fomc == 1) |>
  dplyr::transmute(ciclo, data,
                   tipo = dplyr::case_when(dia_copom == 1 & dia_fomc == 1 ~ "Copom e Fomc",
                                           dia_copom == 1 ~ "Copom", TRUE ~ "Fomc"),
                   selic, dp_pt, r_ibov, r_usd, d_di1, d_di5, r_dxy, r_brent,
                   noite_eleicao)
export_table(dias_dec |> format_table(3), file.path(saida_dir, "decisoes_juros_dias.csv"))

# No gráfico, só amostras com pelo menos 3 dias de decisão (2018 tem 1
# Copom e 1 Fomc na janela; a razão com 1 dia não diz nada). A tabela
# traz todos.
g3 <- resumo_dec |>
  dplyr::filter(dias_decisao >= 3) |>
  dplyr::mutate(variavel_rotulo = factor(variavel_rotulo, rotulos[vars_ativos]),
                ciclo = factor(ciclo, c(sort(unique(as.character(md$ciclo))), "Empilhado"))) |>
  ggplot(aes(ciclo, razao, fill = tipo)) +
  geom_hline(yintercept = 1, colour = "grey40") +
  geom_col(position = position_dodge(width = 0.8), width = 0.7) +
  geom_text(aes(label = paste0("n=", dias_decisao), y = razao + 0.08),
            position = position_dodge(width = 0.8), size = 2.2) +
  scale_fill_manual(values = c(Copom = "firebrick", Fomc = "steelblue4"), name = NULL) +
  facet_wrap(~ variavel_rotulo, nrow = 1) +
  labs(x = NULL, y = "variação média em módulo: dias de decisão / demais dias",
       title = "Os dias de decisão de juros mexem mais com os ativos e com P(PT)?",
       subtitle = "1 = dia de decisão igual aos demais. Copom: pregão seguinte ao anúncio; Fomc: mesmo pregão. Sem noites eleitorais; n = número de dias de decisão;\nsó amostras com 3 dias ou mais (2018 fica de fora: 1 Copom e 1 Fomc na janela).") +
  theme_minimal(base_size = 10) +
  theme(legend.position = "bottom", panel.grid.minor = element_blank(),
        axis.text.x = element_text(angle = 30, hjust = 1))

save_plot(g3, file.path(saida_dir, "decisoes_juros.png"), width = 11, height = 4.5)

# ------------------------------------------------------------
# 4. Prévia da R15: reação com e sem os controles adicionais
# ------------------------------------------------------------
# Mesmas ordens (p, q) do ARDL empilhado, se o 09 já rodou; senão
# (0, 0), a ordem escolhida pelo BIC. As três especificações usam a
# mesma amostra (pregões com DXY e Brent).

arq_ardl <- file.path(saida("09"), "ardl_main.rds")
base_ardl <- if (file.exists(arq_ardl)) load_object(arq_ardl)$empilhado else NULL

especificacoes <- list(
  `Controles atuais`                 = list(ctrl = controles, extra = NULL),
  `+ DXY e Brent`                    = list(ctrl = c(controles, "r_dxy", "r_brent"), extra = NULL),
  `+ DXY, Brent e dias Copom/Fomc`   = list(ctrl = c(controles, "r_dxy", "r_brent"),
                                            extra = c("dia_copom", "dia_fomc"))
)

previa <- if (tem_extras) {
  d_r15 <- md |> dplyr::filter(is.finite(r_dxy), is.finite(r_brent))
  # Empilhado e cada ciclo separado (o ciclo mostra se o sinal muda
  # quando os controles entram, por exemplo em 2022)
  amostras_r15 <- c("empilhado", as.character(sort(unique(d_r15$ciclo))))
  purrr::map_dfr(amostras_r15, function(cc) {
    d_cc <- if (cc == "empilhado") d_r15 else dplyr::filter(d_r15, ciclo == as.numeric(cc))
    purrr::map_dfr(names(respostas), function(y) {
      p0 <- base_ardl[[y]]$p %||% 0; q0 <- base_ardl[[y]]$q %||% 0
      purrr::imap_dfr(especificacoes, function(e, rot) {
        # dummy sem nenhum dia de decisão na amostra sai do modelo
        extra <- e$extra[purrr::map_lgl(e$extra, ~ sum(d_cc[[.x]], na.rm = TRUE) > 0)]
        r <- tryCatch(rodar_leadlag(d_cc, y, "dp_pt", rot, p = p0, q = q0,
                                    ctrl = e$ctrl, extra = if (length(extra)) extra else NULL),
                      error = function(err) NULL)
        if (is.null(r)) return(NULL)
        cf <- dplyr::filter(r$coefs, term == "dp_pt")
        tibble::tibble(amostra = cc, y = y, ativo = respostas[[y]], especificacao = rot, p = p0, q = q0,
                       reacao = cf$estimate, ep = cf$std.error, p_valor = cf$p.value,
                       n = r$ajuste$n, r2_ajustado = r$ajuste$adj_r2)
      })
    })
  })
} else tibble::tibble()

export_table(previa |> format_table(4), file.path(saida_dir, "controles_extras_previa_r15.csv"))

# ------------------------------------------------------------
# Console
# ------------------------------------------------------------

cat("\n========== CONTROLES ADICIONAIS ==========\n")
cat("Pregões com efeito de decisão do Copom:", length(dias_copom),
    "| do Fomc:", length(dias_fomc), "\n\n")
if (nrow(correlacoes)) {
  cat("Correlação com ΔP(PT) (condição para viés):\n")
  print(correlacoes |> dplyr::filter(variavel == "dp_pt") |> format_table(3), n = Inf)
}
cat("\nDias de decisão (razão > 1 = mais movimento que nos demais dias):\n")
print(resumo_dec |> dplyr::filter(ciclo == "Empilhado") |>
        dplyr::select(tipo, variavel_rotulo, dias_decisao, media_abs_decisao, media_abs_demais, razao) |>
        format_table(3), n = Inf)
if (nrow(previa)) {
  cat("\nPrévia R15 (coeficiente de reação a ΔP(PT)):\n")
  print(previa |> dplyr::select(amostra, ativo, especificacao, reacao, ep, p_valor, n, r2_ajustado) |>
          format_table(4), n = Inf, width = Inf)
}

message("04c_controles_adicionais.R concluído com sucesso.")
