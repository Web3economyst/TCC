# Expectativas eleitorais e mercado financeiro (2018, 2022, 2026)

Pipeline em R que junta a probabilidade de vitória do PT (mercados de previsão e agregador de pesquisas) aos preços financeiros, em base diária de pregões da B3, e estima a sensibilidade dos preços por MQO com Newey-West, com ARDL, VAR e estudo de eventos como complementos.

---

## 1. Como rodar

1. Abra no RStudio a pasta do projeto (a que contém o arquivo vazio `.here`).
2. Confira que `data/raw/` tem os dados já baixados (`financeiro_yahoo.rds`, `di_b3_curva_pre.rds`, `dolar_b3.rds`, `dolar_b3_cache.rds`, `ptax_bcb.rds`) e a pasta `data/raw/eleitoral/` com os arquivos da Betfair, da Polymarket e do agregador de pesquisas.
3. Rode `source("run_all.R")`. Leva uns 15 a 20 minutos (o mais demorado é o bootstrap do VAR).

Com os `.rds` em `data/raw/`, nada é baixado de novo e os resultados são os mesmos do texto. Todos os parâmetros (datas, candidatos, defasagens, VAR, estudo de eventos) estão em `R/00_config.R`.

---

## 2. Variáveis

Todas as séries são medidas no fechamento do pregão da B3 (17h com horário de verão nos EUA, 18h sem ele). Os modelos usam as variações diárias.

| Variável no código | O que é | Fonte | Unidade |
|---|---|---|---|
| `p_pt` / `dp_pt` | Probabilidade de vitória do PT / variação diária | Betfair (2018, 2022), Polymarket (2026), último preço até o fechamento da B3 | 0–1 / p.p. |
| `p_h2h` / `dp_h2h` | Probabilidade do PT só contra o principal rival | idem | 0–1 / p.p. |
| `p_pesq` / `dp_pesq` | Probabilidade de vitória do PT no 2º turno pelo agregador de pesquisas (deslocada 1 dia, para não usar a pesquisa antes da divulgação) | Agregador do TCC | 0–1 / p.p. |
| `p_pt_fimdia` / `dp_pt_fimdia` | Probabilidade às 23h59 (robustez R7) | Betfair, Polymarket | 0–1 / p.p. |
| `r_ibov` | Retorno do Ibovespa | Yahoo `^BVSP` | % |
| `r_usd` | Retorno do dólar futuro (contrato de maior volume em aberto, preço de ajuste) | B3, arquivo de preços (BVBG-086) | % |
| `r_usd_alt` | Retorno da PTAX (robustez R9) | BCB | % |
| `d_di1` / `d_di5` | Variação das taxas prefixadas de 1 e 5 anos | B3, curva PRE (arquivo TS) | p.b. |
| `r_spx`, `d_ust10`, `r_vix` | Controles: S&P 500, Treasury 10 anos, VIX | Yahoo | %, p.b., % |
| `pos_1t`, `pos_2t_d1`, `noite_eleicao` | Dummies dos pregões seguintes às eleições | calendário | 0/1 |

Janelas da estimação principal: 2018 de 11/09/2018 a 29/10/2018; 2022 de 11/03/2021 a 31/10/2022; 2026 de 18/09/2025 a 26/10/2026. As defasagens são sempre construídas dentro de cada ciclo.

Em 2018 a janela principal começa em 11/09, primeiro pregão em que a variação de P(PT) é toda do contrato de Haddad (o contrato entra na Betfair em 10/09). A janela ampliada, de 16/08/2018 (início oficial da campanha) a 29/10/2018, só é usada na robustez R12: nela P(PT) é o contrato de Lula até a entrada do de Haddad, e a variação do dia da troca fica ausente. A troca acontece uma única vez; uma variação que misturaria dois contratos nunca entra na base.

Por que variações: a pergunta é a sensibilidade dos preços a mudanças na expectativa eleitoral, e informação nova move o preço no dia em que chega. A especificação em variações vem dessa leitura, não dos testes de raiz unitária, que servem de conferência (script 05).

---

## 3. O que ver em cada script

Cada script grava tudo o que produz (tabelas, figuras e objetos) na sua própria pasta: `output/02_saida/`, `output/03_saida/`, ..., `output/99_saida/`. O `01_import.R` não tem pasta em `output/`, porque só grava dados, em `data/raw/` e `data/processed/`. As tabelas e figuras numeradas do texto ficam em `output/13_saida/tabelas/` e `output/13_saida/figuras/`.


Os scripts `10b`, `10c` e `10d` são extensões complementares, ainda em avaliação. Eles não alteram os modelos E, E1 e D nem as robustezes, e os seus resultados não entram nas tabelas numeradas do `13` enquanto não se decidir mantê-los. O critério para manter uma extensão junta coerência econômica, graus de liberdade, estabilidade dos coeficientes, diagnósticos dos resíduos, sensibilidade aos pregões excepcionais e ajuste em amostras comparáveis; R² mais alto ou RESET não significativo, sozinhos, não bastam.

| Script | O que faz | Onde olhar |
|---|---|---|
| `00_config.R`, `00_paths.R`, `00_packages.R`, `00_functions.R` | Parâmetros, caminhos, pacotes e funções auxiliares | — |
| `01_import.R` | Lê os dados eleitorais e financeiros | console (fonte de cada série) |
| `02_cleaning.R` | Monta a base: um registro por pregão em cada ciclo | `data/processed/clean_data.rds` |
| `03_variables.R` | Variações diárias e dummies | `data/processed/model_data_daily.rds` |
| `03b_validacao_critica.R` | Para o pipeline antes das estimações se houver datas repetidas, fonte do dólar não identificada, horários de probabilidade diferentes entre ciclos, cobertura insuficiente ou amostra efetiva de E, E1 e D abaixo do mínimo; registra o N efetivo de cada modelo e a troca de contrato do PT | `output/03b_saida/validacao_critica.txt`, `amostras_efetivas.csv` |
| `04_descriptive.R` | Descritivas, séries no tempo, correlações, noites eleitorais | Tabelas 1 a 3, Figuras 1, 2 e A2 |
| `04b_probabilidade_pesquisas.R` | Conferência da probabilidade das pesquisas: resumo, saltos grandes e pesquisas que os causaram | `output/04b_saida/pesquisas_*.csv`, Figura A3 |
| `04c_controles_adicionais.R` | Descritiva de controles fora do modelo: DXY, Brent, Selic e dias de decisão do Copom e do Fomc; prévia da robustez R15. Na 1ª vez baixa os dados do Yahoo e do BCB | `output/04c_saida/controles_extras_*.csv`, `decisoes_juros_*.csv` e as figuras de mesmo nome |
| `05_stationarity.R` | ADF, PP e KPSS em nível e em variação, lidos em conjunto: evidência de estacionariedade (ADF e PP rejeitam a raiz unitária e o KPSS não rejeita a estacionariedade), evidência de raiz unitária (o contrário) ou inconclusivo. Não rejeitar a raiz unitária não classifica a série como I(1) | Tabela 4, `output/05_saida/stationarity_orders.csv` |
| `06_models.R` | Tabela principal da sensibilidade: modelos E, E1 (a probabilidade antecede o preço?) e D, MQO com Newey-West; F global clássico e Wald global com Newey-West (todas as inclinações iguais a zero) | Tabela 5, `output/06_saida/static_dynamic_global_tests.csv` |
| `06b_magnitude.R` | Quanto ΔP(PT) explica: R² com e sem ΔP(PT), efeito de 1 desvio-padrão e do percentil 95, com e sem as noites eleitorais | Tabela 6 |
| `07_diagnostics.R` | Diagnósticos de E, E1 e D, empilhado e por ciclo: Breusch-Pagan, Breusch-Godfrey dentro do ciclo, RESET clássico e RESET com Wald Newey-West (original, sem os pregões pós-1º turno e sem as influentes), VIF/GVIF, influência (DFBETAS e β sem as noites eleitorais), estabilidade dentro do ciclo, resíduos no tempo e resumo por modelo | Tabelas 10, 11, A5 e A6, Figuras 6 e A9, `output/07_saida/diagnostics_summary.csv` |
| `08_ccf_granger.R` | Correlação cruzada (figura do texto) e Granger nos dois sentidos, com os controles (apêndice) | Figuras 3 e A1, Tabela A1 |
| `09_ardl.R` | Grade do BIC do ARDL probabilidade → ativo, ARDL invertido (o preço antecede a probabilidade?) e, para o apêndice, conferência com o pacote ARDL e ARDL em níveis com teste Bounds | Tabelas 7, 8, A3 e A4, Figura 4 |
| `09b_comparacao_ciclos.R` | Reação no mesmo pregão em cada ciclo e o teste de igualdade entre 2018, 2022 e 2026 | Tabela 9, Figura 5 |
| `09c_noites_eleitorais.R` | Noites eleitorais: reação prevista pela sensibilidade da campanha (modelo reestimado sem a noite) x reação observada, com intervalo de previsão; decomposição do choque em fim de semana e apuração | Tabelas 13 e 14, Figura 7 |
| `09d_interacao_eventos.R` | Análise exploratória dos primeiros pregões após o 1º turno (um por eleição). (1) Modelo de interação: sensibilidade nos pregões comuns (β), nos pós-1º turno (β + δ) e a diferença (δ), com Newey-West por blocos; com três eventos, erros-padrão, intervalos e o teste de δ são nominais e exploratórios, não evidência de mudança de regime; se faltar o evento de algum ciclo, o modelo fica como incompleto, sem inferência. (2) Influência por evento: modelo E sem cada pregão pós-1º turno e sem os três, sobre a mesma amostra, com a diferença absoluta do β, a diferença em erros-padrão do β original (influência padronizada) e, como complemento, a variação percentual. Inclui a interação reestimada sem cada evento, só com estimativas pontuais | Tabelas A7 a A9, Figuras A10 e A11, `output/09d_saida/` |
| `09e_dummy_choque.R` | Extensão exploratória do modelo E: dummy igual a 1 no primeiro pregão após o 1º turno de cada ciclo (θ), com a mesma inclinação β para todos os pregões. Hipótese: θ = 0 (Wald com Newey-West por blocos). Compara, na mesma amostra, E, E + dummy e E + dummy + interação (o modelo do 09d), com AIC e BIC, e traz o E sem os três eventos como sensibilidade amostral. Diagnósticos de E e E + dummy (Breusch-Pagan, Breusch-Godfrey 1 a 5, RESET-HAC, VIF/GVIF, resíduos no tempo e contra os ajustados, ACF/PACF) e resíduos e influência (Cook, DFBETAS) nos três eventos. Limitações: θ e δ dependem de três pregões, a inferência deles é nominal; com a dummy a soma dos resíduos dos eventos é zero por construção; o modelo E continua sendo a referência. Usa os eventos conferidos pelo 09d | Tabelas A10 a A12, Figuras A12 a A14, `output/09e_saida/` |
| `10_robustness.R` | Exercícios de robustez (R1 a R15; a R15 usa os controles adicionais do 04c) | Tabela 12 |
| `10b_di1_dinamica.R` | Extensão complementar, só para o DI de 1 ano: modelos com 0 a 3 defasagens da variável dependente na mesma amostra (0 = E, 1 = D), ordem por BIC, β eleitoral em cada ordem e diagnósticos dos resíduos (Breusch-Godfrey 1 a 5, RESET-HAC, ACF/PACF). Empilhado, 2022 e 2026; 2018 só com graus de liberdade suficientes. A ordem não é escolhida pelo p-valor do Breusch-Godfrey | `output/10b_saida/di1_dinamica_resumo.csv` |
| `10c_nao_linearidade.R` | Extensão complementar ao modelo E: spline cúbico natural (3 gl) em ΔP(PT), com o modelo linear como caso restrito e teste Wald-HAC da não linearidade; comparação na amostra completa, sem os pregões pós-1º turno e sem cada um; respostas previstas só onde há suporte amostral; gráficos da curva e da distribuição de ΔP. Com o spline não há um β único | `output/10c_saida/nao_linear_comparacao.csv`, `nao_linear_respostas.csv`, figuras por ativo |
| `10d_lula_haddad.R` | Extensão complementar da R12, só com 2018 na janela ampliada: dummy do período de Haddad e interação com ΔP(PT) (β de Lula, β de Haddad e a diferença), com Newey-West sem cruzar a troca de contrato; N por período; comparação com a R12 de 2018 sem interação e com o modelo E original de Haddad. Inferência nominal; a diferença não é efeito causal do candidato; a probabilidade somada Lula + Haddad não é usada | `output/10d_saida/lula_haddad_tabela.csv`, `lula_haddad_periodos.csv`, figura |
| `11_var.R` | Apêndice. VAR por ciclo: Granger, impulso-resposta com bootstrap e decomposição da variância | Tabela A2, Figuras A7 e A8 |
| `12_event_study.R` | Estudo de eventos das divulgações de pesquisas do 2º turno | Tabela 15, Figura 8 |
| `13_tables_figures.R` | Gera as tabelas (CSV e LaTeX) e as figuras do texto | `output/13_saida/tabelas/`, `output/13_saida/figuras/` |
| `99_auditoria.R` | Checagem da base (horários, séries congeladas, saltos, faltantes) | `output/99_saida/auditoria_base.txt` |


Toda a inferência (p-valores e intervalos de 95%) usa o erro-padrão Newey-West e a distribuição t com os graus de liberdade do resíduo.
