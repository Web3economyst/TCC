# ============================================================
# Script  : 03b_validacao_critica.R
#
# Objetivo:
#   Conferir a base ANTES das estimações e parar o pipeline se
#   houver um problema que invalide os resultados. O relatório
#   completo de diagnósticos continua no 99_auditoria.R, no fim.
#
#   Condições que param a execução:
#     1. Datas repetidas ou fora de ordem dentro de um ciclo.
#     2. Fonte financeira não identificada: dólar principal sem
#        fonte registrada na base. (Arquivo bruto de DI ou de
#        dólar sem a fonte gravada vira aviso: arquivos salvos por
#        versões antigas do 01 não têm esse registro.)
#     3. Convenção de horário da probabilidade diferente entre os
#        ciclos, sem permitir_horario_misto = TRUE.
#     4. Cobertura insuficiente: ciclo com menos de min_obs_ciclo
#        pregões completos (ativo, ΔP(PT) e controles) em alguma
#        regressão, ou série com cobertura abaixo de
#        cobertura_minima dentro do ciclo.
#     5. Amostra efetiva dos modelos E, E1 e D (depois da
#        defasagem de 1 pregão) abaixo de min_obs_ciclo em algum
#        ciclo.
#
#   Os limites de 30 pregões e 80% são um filtro inicial de
#   qualidade da base. Não garantem precisão estatística: o
#   arquivo amostras_efetivas.csv mostra quantas observações cada
#   modelo realmente usa depois das defasagens (E/E1/D, ARDL na
#   ordem máxima e VAR), e as amostras pequenas do ARDL e do VAR
#   aparecem como aviso.
#
#   Também confere a troca de contrato do PT (2018): se a cotação
#   do pregão anterior ao início da janela principal é do mesmo
#   candidato da do primeiro pregão. Nos ciclos com troca (2018), a
#   primeira variação só fica na base se as duas cotações são do
#   candidato final e foram observadas no próprio dia; senão o 03
#   a deixa ausente. O script para se uma variação que não cumpre
#   isso estiver na base.
#
#   Não param a execução (só aparecem no relatório): base
#   simulada, pregões extremos, observações influentes e grandes
#   movimentos eleitorais. São fatos a investigar no 99, não
#   dados inválidos.
#
# Entrada : data/processed/model_data_daily.rds, data/raw/*.rds
# Saída   : output/03b_saida/validacao_critica.txt
#           output/03b_saida/cobertura_por_ciclo.csv
#           output/03b_saida/amostras_efetivas.csv
#           output/03b_saida/troca_contrato_pt.csv
#
# Próximo script: 04_descriptive.R
# ============================================================

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

saida_dir <- saida("03b")

md <- load_object(model_data_file)

falhas <- character(0)
avisos <- character(0)
falha <- function(...) falhas <<- c(falhas, paste0(...))

# ------------------------------------------------------------
# 1. Datas únicas e em ordem dentro de cada ciclo
# ------------------------------------------------------------

rep_datas <- md |> dplyr::count(ciclo, data) |> dplyr::filter(n > 1)
if (nrow(rep_datas))
  falha("Datas repetidas dentro do ciclo: ",
        paste(rep_datas$ciclo, format(rep_datas$data), collapse = "; "))

fora_ordem <- md |> dplyr::group_by(ciclo) |>
  dplyr::summarise(desordenado = is.unsorted(data, strictly = TRUE), .groups = "drop") |>
  dplyr::filter(desordenado)
if (nrow(fora_ordem))
  falha("Datas fora de ordem no(s) ciclo(s): ", paste(fora_ordem$ciclo, collapse = ", "))

# ------------------------------------------------------------
# 2. Fonte financeira identificada
# ------------------------------------------------------------

fonte_usd <- attr(md, "fonte_usd")
if (is.null(fonte_usd) || is.na(fonte_usd) || !nzchar(fonte_usd))
  falha("Fonte do dólar principal não registrada na base (atributo fonte_usd).")

fonte_bruta <- function(arq, nome) {
  if (!file.exists(arq)) return(NA_character_)
  f <- attr(load_object(arq), "fonte")
  if (is.null(f) || !nzchar(f)) {
    avisos <<- c(avisos, paste0("Arquivo de ", nome, " sem a fonte registrada (rode o 01_import.R para regravar): ", arq))
    return("não registrada no arquivo")
  }
  f
}
fonte_di  <- fonte_bruta(di_raw_file, "DI")
fonte_dol <- fonte_bruta(dolar_raw_file, "dólar da B3")

if (isTRUE(attr(md, "simulado"))) avisos <- c(avisos, "A base financeira é SIMULADA (só para teste do código).")

# ------------------------------------------------------------
# 3. Convenção de horário da probabilidade
# ------------------------------------------------------------

horarios <- md |> dplyr::distinct(ciclo, horario_p)
if (dplyr::n_distinct(horarios$horario_p) > 1) {
  txt <- paste0("Horário da probabilidade difere entre os ciclos: ",
                paste(horarios$ciclo, horarios$horario_p, sep = " = ", collapse = "; "), ".")
  if (isTRUE(permitir_horario_misto)) avisos <- c(avisos, paste(txt, "Permitido por permitir_horario_misto = TRUE."))
  else falha(txt)
}

# ------------------------------------------------------------
# 4. Cobertura mínima para cada estimação
# ------------------------------------------------------------
# O pregão seguinte ao 2º turno fica fora da conta: nele P(PT) é
# ausente por construção.

base_cob <- md |> dplyr::filter(!pos_2t)
series <- intersect(c("dp_pt", names(respostas), controles), names(md))

cobertura <- purrr::map_dfr(series, function(v) {
  base_cob |> dplyr::group_by(ciclo) |>
    dplyr::summarise(serie = v, pregoes = dplyr::n(), com_valor = sum(is.finite(.data[[v]])),
                     cobertura = com_valor / pregoes, .groups = "drop")
})

completos <- purrr::map_dfr(intersect(names(respostas), names(md)), function(y) {
  base_cob |> dplyr::group_by(ciclo) |>
    dplyr::summarise(serie = paste0("regressão de ", y), pregoes = dplyr::n(),
                     com_valor = sum(stats::complete.cases(dplyr::pick(dplyr::all_of(c(y, "dp_pt", controles))))),
                     cobertura = com_valor / pregoes, .groups = "drop")
})

cobertura <- dplyr::bind_rows(cobertura, completos) |>
  dplyr::mutate(problema = dplyr::case_when(
    grepl("^regressão", serie) & com_valor < min_obs_ciclo ~ paste0("menos de ", min_obs_ciclo, " pregões completos"),
    cobertura < cobertura_minima ~ paste0("cobertura abaixo de ", 100 * cobertura_minima, "%"),
    TRUE ~ ""))

export_table(cobertura |> format_table(3), file.path(saida_dir, "cobertura_por_ciclo.csv"))

ruins <- dplyr::filter(cobertura, problema != "")
if (nrow(ruins))
  falha("Cobertura insuficiente: ",
        paste0(ruins$ciclo, " ", ruins$serie, " (", ruins$com_valor, " de ", ruins$pregoes, "; ", ruins$problema, ")",
               collapse = "; "))

# ------------------------------------------------------------
# 5. Amostra efetiva de cada modelo, depois das defasagens
# ------------------------------------------------------------

ys <- intersect(names(respostas), names(md))
ativos_var <- intersect(names(respostas), names(md))   # ativos estimados (com o DI só se INCLUIR_DI = TRUE)
ciclos_md <- sort(unique(md$ciclo))

efetivas <- purrr::map_dfr(ciclos_md, function(cc) {
  d <- dplyr::filter(md, ciclo == cc)
  por_y <- purrr::map_dfr(ys, function(y) {
    n_e1d <- d |> add_lags(c(y, "dp_pt"), 1) |>
      tidyr::drop_na(dplyr::all_of(c(y, "dp_pt", paste0(y, "_l1"), "dp_pt_l1", controles))) |> nrow()
    n_ardl <- nrow(prepare_leadlag(d, y, "dp_pt", max_lag_y, max_lag_dp, 0, controles))
    dplyr::bind_rows(
      tibble::tibble(modelo = "E, E1 e D (06)", y = y, n_efetivo = n_e1d),
      tibble::tibble(modelo = paste0("ARDL na ordem máxima (", max_lag_y, ", ", max_lag_dp, ")"), y = y, n_efetivo = n_ardl)
    )
  })
  cont <- suppressWarnings(amostra_continua(d, c("dp_pt", ativos_var, controles), paste("VAR", cc)))
  var_l <- tibble::tibble(
    modelo = c("VAR com 1 defasagem", paste0("VAR com ", var_max_lag, " defasagens")),
    y = "todas", n_efetivo = pmax(nrow(cont) - c(1, var_max_lag), 0))
  dplyr::bind_rows(por_y, var_l) |>
    dplyr::mutate(ciclo = cc, pregoes = sum(!d$pos_2t), .before = 1)
}) |>
  dplyr::mutate(abaixo_do_minimo = n_efetivo < min_obs_ciclo)

export_table(efetivas, file.path(saida_dir, "amostras_efetivas.csv"))

ruins_e <- dplyr::filter(efetivas, abaixo_do_minimo, modelo == "E, E1 e D (06)")
if (nrow(ruins_e))
  falha("Amostra efetiva dos modelos E, E1 e D abaixo de ", min_obs_ciclo, ": ",
        paste0(ruins_e$ciclo, " ", ruins_e$y, " (", ruins_e$n_efetivo, ")", collapse = "; "))

ruins_o <- dplyr::filter(efetivas, abaixo_do_minimo, modelo != "E, E1 e D (06)")
if (nrow(ruins_o))
  avisos <- c(avisos, paste0("Amostra efetiva abaixo de ", min_obs_ciclo, " em modelos complementares: ",
                             paste0(ruins_o$ciclo, " ", ruins_o$modelo, " ", ruins_o$y, " (", ruins_o$n_efetivo, ")",
                                    collapse = "; ")))

# ------------------------------------------------------------
# 6. Troca de contrato do PT no início da janela principal
# ------------------------------------------------------------
# A primeira variação da janela usa a cotação do pregão anterior.
# Confere se as duas cotações são do mesmo contrato e do dia.

base_limpa <- load_object(clean_data_file)
troca_pt <- purrr::map_dfr(sort(unique(base_limpa$ciclo)), function(cc) {
  b <- base_limpa |> dplyr::filter(ciclo == cc) |> dplyr::arrange(data)
  i <- which(b$data >= b$inicio)[1]
  if (is.na(i) || i < 2) return(NULL)
  tibble::tibble(
    ciclo = cc,
    pregao_anterior = b$data[i - 1], cand_anterior = b$cand_pt_dia[i - 1],
    cotacao_anterior_valida = is.finite(b$p_pt[i - 1]) & b$defasagem_prob_dias[i - 1] == 0,
    primeiro_pregao = b$data[i], cand_primeiro = b$cand_pt_dia[i],
    cotacao_primeiro_valida = is.finite(b$p_pt[i]) & b$defasagem_prob_dias[i] == 0,
    # NA: sem cotação em um dos dois pregões (a variação já é ausente)
    mesmo_contrato = b$cand_pt_dia[i - 1] == b$cand_pt_dia[i],
    primeira_variacao_usada = is.finite(md$dp_pt[md$ciclo == cc & md$data == b$data[i]])[1]
  )
})
export_table(troca_pt, file.path(saida_dir, "troca_contrato_pt.csv"))

mistura <- troca_pt |> dplyr::filter(!is.na(mesmo_contrato), !mesmo_contrato)
if (nrow(mistura)) {
  avisos <- c(avisos, paste0(
    "Primeira variação de P(PT) da janela descartada por troca de contrato: ",
    paste0(mistura$ciclo, " (", format(mistura$pregao_anterior), " = ", mistura$cand_anterior, "; ",
           format(mistura$primeiro_pregao), " = ", mistura$cand_primeiro, ")", collapse = "; ")))
  if (any(mistura$primeira_variacao_usada))
    falha("Variação de P(PT) que mistura dois contratos entrou na base: ",
          paste(mistura$ciclo[mistura$primeira_variacao_usada], collapse = ", "))
}
# Ciclos com troca de contrato (2018): a primeira variação só pode
# estar na base se as duas cotações são do candidato final e do dia.
com_troca <- ciclos$ciclo[lengths(strsplit(ciclos$cand_pt, ";")) > 1]
final_de <- stats::setNames(purrr::map_chr(strsplit(ciclos$cand_pt, ";"), ~ utils::tail(.x, 1)), ciclos$ciclo)
primeira <- troca_pt |>
  dplyr::filter(ciclo %in% com_troca) |>
  dplyr::mutate(cand_final = unname(final_de[as.character(ciclo)]),
                valida = dplyr::coalesce(cand_anterior == cand_final & cand_primeiro == cand_final &
                                           cotacao_anterior_valida & cotacao_primeiro_valida, FALSE))
if (any(primeira$primeira_variacao_usada & !primeira$valida))
  falha("Primeira variação de P(PT) na base sem as duas cotações do candidato final observadas no dia: ",
        paste(primeira$ciclo[primeira$primeira_variacao_usada & !primeira$valida], collapse = ", "))
if (any(!primeira$valida))
  avisos <- c(avisos, paste0("Primeira variação de P(PT) descartada (cotação de outro contrato ou repetida de dia anterior): ",
                             paste(primeira$ciclo[!primeira$valida], collapse = ", ")))

sem_anterior <- troca_pt |> dplyr::filter(is.na(mesmo_contrato), !ciclo %in% com_troca)
if (nrow(sem_anterior))
  avisos <- c(avisos, paste0("Sem cotação de P(PT) no pregão anterior ou no primeiro pregão da janela (primeira variação ausente): ",
                             paste(sem_anterior$ciclo, collapse = ", ")))
n_trocas <- sum(md$troca_cand_pt, na.rm = TRUE)

# ------------------------------------------------------------
# Relatório e decisão
# ------------------------------------------------------------

linhas <- c(
  "VALIDAÇÃO CRÍTICA DA BASE",
  paste("Gerado em:", format(Sys.time(), "%d/%m/%Y %H:%M")),
  "",
  paste0("Fonte do dólar principal: ", fonte_usd %||% "não registrada"),
  paste0("Fonte do DI (arquivo bruto): ", fonte_di),
  paste0("Fonte do dólar da B3 (arquivo bruto): ", fonte_dol),
  paste0("Horário da probabilidade: ", paste(horarios$ciclo, horarios$horario_p, sep = " = ", collapse = "; ")),
  paste0("Mínimo de pregões completos por ciclo: ", min_obs_ciclo,
         "; cobertura mínima por série: ", 100 * cobertura_minima,
         "% (filtro inicial; ver amostras_efetivas.csv para o N de cada modelo)"),
  paste0("Variações de P(PT) descartadas por troca de contrato na janela principal: ", n_trocas),
  if (nrow(troca_pt)) paste0("Contrato do PT no início da janela: ",
                             paste0(troca_pt$ciclo, ": ", format(troca_pt$pregao_anterior), " = ", troca_pt$cand_anterior,
                                    ", ", format(troca_pt$primeiro_pregao), " = ", troca_pt$cand_primeiro, collapse = "; ")),
  "",
  if (length(avisos)) c("AVISOS (não param a execução):", paste(" -", avisos), ""),
  if (length(falhas)) c("FALHAS (param a execução):", paste(" -", falhas)) else "Nenhuma falha crítica."
)
writeLines(linhas, file.path(saida_dir, "validacao_critica.txt"))
cat(linhas, sep = "\n")

if (length(falhas))
  stop("Validação crítica reprovada (", length(falhas), " falha(s)). Veja output/03b_saida/validacao_critica.txt:\n",
       paste(" -", falhas, collapse = "\n"), call. = FALSE)

message("03b_validacao_critica.R concluído com sucesso.")
