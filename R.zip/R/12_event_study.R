# ============================================================
# Script  : 12_event_study.R
#
# Objetivo:
#   Estudo de eventos com as divulgações de pesquisas do 2º turno
#   (objetivo 5: as pesquisas trazem informação além do mercado de
#   previsão?).
#
#   Evento   : divulgação de uma pesquisa. Dia 0 = primeiro pregão
#              em ou depois de data_fim + defasagem_divulgacao dias
#              (a pesquisa costuma ser divulgada no dia seguinte ao
#              fim do campo).
#   Surpresa : margem da pesquisa − margem do agregador na véspera
#              (pontos percentuais, perspectiva do PT; arquivo
#              eventos_pesquisas.csv, gerado no script 08 do TCC).
#              Surpresa > 0 = pesquisa melhor para o PT do que o
#              esperado.
#   Retorno anormal: resíduo do ativo contra os controles
#              (S&P 500, Treasury, VIX), estimado em cada ciclo sem
#              as noites eleitorais. P(PT) entra sem ajuste.
#   Janelas  : antes [−janela_antes, −1], dia 0, depois
#              [+1, +janela_depois].
#
#   Regressão (um evento por pregão; pesquisas do mesmo dia têm a
#   surpresa média):
#     CAR_e = a_ciclo + β·surpresa_e + ε_e     (EP Newey-West)
#
#   Leitura:
#     β na janela "antes" ≠ 0 : o preço já se mexia antes da
#                               divulgação (vazamento ou o mercado
#                               anteviu a informação);
#     β no dia 0              : reação à divulgação;
#     β "depois"              : incorporação lenta.
#   Para P(PT), β no dia 0 ≈ 0 indica que o mercado de previsão já
#   tinha a informação da pesquisa.
#
#   Ficam fora os eventos cuja janela inteira toca uma noite
#   eleitoral ou sai do ciclo. Robustez: defasagem de divulgação de
#   0 e 2 dias.
#
# Entrada : data/processed/model_data_daily.rds, eventos_pesquisas.csv
# Saída   : output/12_saida/event_study_*.csv,
#           output/12_saida/event_study_coefficients.png
#
# Próximo script: 13_tables_figures.R
# ============================================================

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

saida_dir <- saida("12")

model_data <- load_object(model_data_file)
aviso_simulado(model_data)

candidatos <- unique(c(
  file.path(electoral_raw_dir, "eventos_pesquisas.csv"),
  file.path(root, "saida_mercados", "eventos_pesquisas.csv"),
  file.path(dirname(root), "saida_mercados", "eventos_pesquisas.csv"),
  file.path(root, "eventos_pesquisas.csv"),
  file.path(dirname(root), "eventos_pesquisas.csv")
))
arq_eventos <- candidatos[file.exists(candidatos)][1]

if (is.na(arq_eventos)) {
  message("eventos_pesquisas.csv não encontrado (procurado em: ",
          paste(candidatos, collapse = "; "), "). Estudo de eventos pulado.")
} else {
  message("Eventos: ", arq_eventos)
  eventos_raw <- readr::read_csv(arq_eventos, show_col_types = FALSE) |>
    dplyr::mutate(ciclo = as.character(ano), data_fim = as.Date(data_fim)) |>
    dplyr::filter(ciclo %in% as.character(unique(model_data$ciclo)), is.finite(surpresa_pp))

  ativos <- names(respostas)[purrr::map_lgl(names(respostas), ~ sum(is.finite(model_data[[.x]])) > 50)]

  # ----------------------------------------------------------
  # Retornos anormais (ativo menos o previsto pelos controles)
  # ----------------------------------------------------------
  base <- model_data |>
    dplyr::mutate(ciclo = as.character(ciclo)) |>
    dplyr::arrange(ciclo, data) |>
    dplyr::group_by(ciclo) |>
    dplyr::mutate(pos = dplyr::row_number()) |>
    dplyr::ungroup()

  for (y in ativos) {
    base[[paste0("ar_", y)]] <- NA_real_
    for (cc in unique(base$ciclo)) {
      i <- base$ciclo == cc
      est <- base[i & base$noite_eleicao == 0, ]
      m <- tryCatch(lm(stats::reformulate(controles, y), data = est), error = function(e) NULL)
      if (is.null(m)) next
      pred <- predict(m, newdata = base[i, ])
      base[[paste0("ar_", y)]][i] <- base[[y]][i] - pred
    }
  }
  vars_car <- c(dp_pt = "dp_pt", setNames(paste0("ar_", ativos), ativos))

  # ----------------------------------------------------------
  # Montagem dos eventos e das CARs
  # ----------------------------------------------------------
  montar <- function(defas) {
    ev <- eventos_raw |>
      dplyr::mutate(alvo = data_fim + defas) |>
      dplyr::rowwise() |>
      dplyr::mutate(pos0 = {
        b <- base[base$ciclo == ciclo & base$data >= alvo, ]
        if (nrow(b)) min(b$pos) else NA_integer_
      }) |>
      dplyr::ungroup() |>
      dplyr::filter(!is.na(pos0)) |>
      dplyr::group_by(ciclo, pos0) |>
      dplyr::summarise(n_pesquisas = dplyr::n(), surpresa = mean(surpresa_pp),
                       institutos = paste(unique(instituto), collapse = "; "), .groups = "drop")

    janelas <- list(antes = c(-janela_antes, -1), `dia 0` = c(0, 0), depois = c(1, janela_depois))

    purrr::pmap_dfr(ev, function(ciclo, pos0, n_pesquisas, surpresa, institutos) {
      bc <- base[base$ciclo == ciclo, ]
      jan_total <- (pos0 - janela_antes):(pos0 + janela_depois)
      fora <- any(jan_total < 1 | jan_total > nrow(bc)) ||
        any(bc$noite_eleicao[jan_total[jan_total >= 1 & jan_total <= nrow(bc)]] == 1)
      out <- tibble::tibble(ciclo = ciclo, data0 = bc$data[pos0], n_pesquisas = n_pesquisas,
                            surpresa = surpresa, excluido = fora)
      for (jn in names(janelas)) for (v in names(vars_car)) {
        k <- (pos0 + janelas[[jn]][1]):(pos0 + janelas[[jn]][2])
        k <- k[k >= 1 & k <= nrow(bc)]
        out[[paste(v, jn, sep = "|")]] <- if (length(k)) sum(bc[[vars_car[[v]]]][k]) else NA_real_
      }
      out
    }) |>
      dplyr::mutate(defasagem = defas, .before = 1)
  }

  defasagens <- unique(c(defasagem_divulgacao, defasagens_divulgacao_rob))
  eventos <- purrr::map_dfr(defasagens, montar)
  export_table(eventos |> format_table(4), file.path(saida_dir, "event_study_events.csv"))

  # ----------------------------------------------------------
  # Regressões CAR ~ surpresa
  # ----------------------------------------------------------
  longo <- eventos |>
    dplyr::filter(!excluido) |>
    tidyr::pivot_longer(dplyr::contains("|"), names_to = "chave", values_to = "car") |>
    tidyr::separate(chave, c("variavel", "janela"), sep = "\\|") |>
    dplyr::filter(is.finite(car))

  reg <- longo |>
    dplyr::group_by(defasagem, variavel, janela) |>
    dplyr::group_modify(function(d, k) {
      d <- dplyr::arrange(d, ciclo, data0)
      fe <- dplyr::n_distinct(d$ciclo) > 1
      f <- if (fe) car ~ surpresa + factor(ciclo) else car ~ surpresa
      m <- tryCatch(lm(f, data = d), error = function(e) NULL)
      if (is.null(m) || nobs(m) < 15) return(tibble::tibble())
      t <- tidy_nw(m) |> dplyr::filter(term == "surpresa")
      tibble::tibble(beta = t$estimate, ep = t$std.error, p = t$p.value,
                     lo = t$conf.low, hi = t$conf.high, n_eventos = nobs(m),
                     n_ciclos = dplyr::n_distinct(d$ciclo))
    }) |>
    dplyr::ungroup() |>
    dplyr::mutate(janela = factor(janela, c("antes", "dia 0", "depois")))

  export_table(reg |> format_table(4), file.path(saida_dir, "event_study_regressions.csv"))

  rot <- c(dp_pt = "Δ P(PT) (p.p.)", respostas)
  g <- reg |>
    dplyr::filter(defasagem == defasagem_divulgacao) |>
    dplyr::mutate(variavel = factor(rot[variavel], rot)) |>
    ggplot(aes(janela, beta)) +
    geom_hline(yintercept = 0, colour = "grey60") +
    geom_pointrange(aes(ymin = lo, ymax = hi), colour = "steelblue4") +
    facet_wrap(~ variavel, scales = "free_y", ncol = 5) +
    labs(x = NULL, y = "resposta a +1 p.p. de surpresa",
         title = "Divulgação de pesquisas do 2º turno: resposta à surpresa",
         subtitle = paste0("CAR por janela (antes = [-", janela_antes, ",-1], depois = [+1,+", janela_depois,
                           "]); efeito fixo de ciclo; IC de 95% Newey-West")) +
    theme_minimal(base_size = 9)
  save_plot(g, file.path(saida_dir, "event_study_coefficients.png"), width = 10, height = 3.5)

  cat("\n========== ESTUDO DE EVENTOS (defasagem principal) ==========\n")
  print(reg |> dplyr::filter(defasagem == defasagem_divulgacao) |> format_table(3), n = Inf, width = Inf)
  cat("\nEventos usados por ciclo:\n")
  print(eventos |> dplyr::filter(defasagem == defasagem_divulgacao) |> dplyr::count(ciclo, excluido))
}

message("12_event_study.R concluído com sucesso.")
