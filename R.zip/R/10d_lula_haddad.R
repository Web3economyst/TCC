# ============================================================
# Script  : 10d_lula_haddad.R
#
# Objetivo:
#   Extensão COMPLEMENTAR da robustez R12. A janela ampliada de
#   2018 (desde 16/08) junta dois contratos do PT: Lula, até a
#   entrada do contrato de Haddad, e Haddad depois. Pergunta: ao
#   deixar a sensibilidade ser diferente nos dois períodos, a
#   janela ampliada acrescenta informação?
#
#     y_t = a + β ΔP_t + θ H_t + δ (H_t × ΔP_t) + g'·controles_t + e_t
#
#   só com os pregões de 2018 da janela ampliada. H_t = 1 no
#   período do contrato de Haddad.
#     β      : sensibilidade no período de Lula
#     β + δ  : sensibilidade no período de Haddad
#     δ      : diferença entre os dois
#
#   A janela principal (Haddad, desde 11/09/2018), os modelos E, E1
#   e D e a R12 não mudam.
#
#   Cuidados:
#   - O contrato de cada pregão vem da base (cand_pt_dia). A troca
#     acontece uma vez; o script confere que não há volta a Lula e
#     que nenhuma variação atravessa a troca.
#   - Newey-West por blocos, com um bloco por contrato: nenhuma
#     autocovariância cruza a troca.
#   - Antes de estimar, confere se o período de Lula tem
#     observações e variação de ΔP suficientes (`min_obs_lula`
#     pregões, dos quais `min_obs_lula` com ΔP diferente de zero).
#     Se não tiver, só a parte descritiva é gravada.
#   - Comparações em amostras comuns: a R12 de 2018 sem interação e
#     a interação usam os mesmos pregões; o modelo E original de
#     Haddad é comparado com o E reestimado só nos pregões de Haddad
#     da janela ampliada.
#   - Intervalos e p-valores são NOMINAIS: cada período tem poucas
#     dezenas de pregões.
#   - δ compara dois períodos da mesma campanha, com candidatos,
#     notícias e incerteza diferentes. Não é o efeito causal da
#     identidade do candidato.
#   - A probabilidade somada Lula + Haddad NÃO é usada. O script só
#     grava a conferência dos dias em que os dois contratos têm
#     preço, para decidir depois se a soma faz sentido.
#
# Entrada : data/processed/model_data_daily_janela_completa.rds
#           data/processed/model_data_daily.rds
#           data/processed/raw_eleitoral.rds (conferência da soma)
# Saída   : output/10d_saida/lula_haddad_periodos.csv
#           output/10d_saida/lula_haddad_modelos.csv
#           output/10d_saida/lula_haddad_tabela.csv
#           output/10d_saida/lula_haddad_diagnosticos.csv
#           output/10d_saida/lula_haddad_soma_conferencia.csv
#           output/10d_saida/lula_haddad_nao_estimados.csv
#           output/10d_saida/lula_haddad_sensibilidades.png
#
# Próximo script: 11_var.R
# ============================================================

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

saida_dir <- saida("10d")

min_obs_lula <- 10

model_data <- load_object(model_data_file)
aviso_simulado(model_data)
if (!file.exists(model_data_full_file)) stop("Falta a base da janela ampliada (rode o 03_variables.R).", call. = FALSE)
completa <- load_object(model_data_full_file)

respostas_disp <- names(respostas)[purrr::map_lgl(names(respostas), ~ sum(is.finite(model_data[[.x]])) > 50)]

# Ciclo com troca de contrato e os dois candidatos
cand_lista <- strsplit(ciclos$cand_pt, ";")
ciclo_troca <- ciclos$ciclo[lengths(cand_lista) > 1]
if (length(ciclo_troca) != 1) stop("Esperado exatamente um ciclo com troca de contrato do PT.", call. = FALSE)
cands <- cand_lista[[which(ciclos$ciclo == ciclo_troca)]]
cand_inicial <- cands[1]; cand_final <- utils::tail(cands, 1)

# ------------------------------------------------------------
# 1. Períodos e conferências
# ------------------------------------------------------------

base18 <- completa |>
  dplyr::filter(ciclo == ciclo_troca) |>
  dplyr::arrange(data) |>
  dplyr::mutate(periodo = dplyr::case_when(cand_pt_dia == cand_inicial ~ cand_inicial,
                                           cand_pt_dia == cand_final ~ cand_final),
                haddad = as.integer(periodo == cand_final))

# Sem volta ao contrato inicial depois da troca; nenhuma variação
# de P(PT) atravessa a troca
primeira_final <- min(base18$data[base18$periodo %in% cand_final])
stopifnot(!any(base18$periodo %in% cand_inicial & base18$data > primeira_final),
          !any(is.finite(base18$dp_pt) & base18$cand_pt_dia != dplyr::lag(base18$cand_pt_dia), na.rm = TRUE))

# Amostra de cada ativo: a mesma regra do modelo E (defasagem de 1
# pregão dentro do ciclo), aplicada à janela ampliada de 2018
amostra_18 <- function(y) {
  base18 |>
    add_lags(c(y, "dp_pt"), 1) |>
    tidyr::drop_na(dplyr::all_of(c(y, "dp_pt", paste0(y, "_l1"), "dp_pt_l1", controles, "periodo"))) |>
    dplyr::mutate(dp_haddad = dp_pt * haddad)
}
amostras <- purrr::map(respostas_disp, amostra_18) |> setNames(respostas_disp)

periodos <- purrr::imap_dfr(amostras, function(d, y) {
  d |> dplyr::group_by(periodo) |>
    dplyr::summarise(primeiro_pregao = min(data), ultimo_pregao = max(data), n = dplyr::n(),
                     n_dp_diferente_de_zero = sum(dp_pt != 0),
                     dp_media = mean(dp_pt), dp_desvio = stats::sd(dp_pt),
                     dp_min = min(dp_pt), dp_max = max(dp_pt),
                     y_media = mean(.data[[y]]), y_desvio = stats::sd(.data[[y]]),
                     correlacao_dp_y = if (stats::sd(dp_pt) > 0) stats::cor(dp_pt, .data[[y]]) else NA_real_,
                     .groups = "drop") |>
    dplyr::mutate(y = y, .before = 1)
}) |>
  dplyr::mutate(periodo = factor(periodo, c(cand_inicial, cand_final))) |>
  dplyr::arrange(y, periodo)

export_table(periodos |> format_table(3), file.path(saida_dir, "lula_haddad_periodos.csv"))

# O período de Lula permite identificar a inclinação?
identificavel <- periodos |>
  dplyr::filter(periodo == cand_inicial) |>
  dplyr::transmute(y, n_lula = n, n_dp_nao_zero = n_dp_diferente_de_zero,
                   ok = n >= min_obs_lula & n_dp_diferente_de_zero >= min_obs_lula)
identificavel <- tibble::tibble(y = respostas_disp) |> dplyr::left_join(identificavel, by = "y") |>
  dplyr::mutate(dplyr::across(c(n_lula, n_dp_nao_zero), ~ tidyr::replace_na(.x, 0L)), ok = tidyr::replace_na(ok, FALSE))

nao_estimados <- identificavel |> dplyr::filter(!ok) |>
  dplyr::transmute(y, n_lula, n_dp_nao_zero,
                   motivo = paste0("período de ", cand_inicial, " com menos de ", min_obs_lula,
                                   " pregões, ou menos de ", min_obs_lula, " com ΔP diferente de zero: só descritiva"))
export_table(nao_estimados, file.path(saida_dir, "lula_haddad_nao_estimados.csv"))
if (nrow(nao_estimados))
  warning("Interação Lula-Haddad não estimada (só descritiva) em: ", paste(nao_estimados$y, collapse = ", "), call. = FALSE)

# ------------------------------------------------------------
# 2. Modelos
# ------------------------------------------------------------

f_e   <- function(y) stats::reformulate(c("dp_pt", controles), y)
f_int <- function(y) stats::reformulate(c("dp_pt", "haddad", "dp_haddad", controles), y)

# Newey-West sem cruzar a troca de contrato (um bloco por período)
vcov_periodo <- function(m, d) {
  if (dplyr::n_distinct(d$periodo) > 1) vcov_nw_blocos(m, as.character(d$periodo), lag = nw_lag) else vcov_nw(m)
}

linha_beta <- function(m, V, termo = "dp_pt") {
  est <- coef(m)[[termo]]; ep <- sqrt(V[termo, termo]); tc <- ic_t(m)
  tibble::tibble(estimativa = est, ep_hac = ep, p_nominal = 2 * stats::pt(-abs(est / ep), df = df.residual(m)),
                 ic_inf = est - tc * ep, ic_sup = est + tc * ep)
}

ajuste <- function(m, V) tibble::tibble(n = nobs(m), adj_r2 = summary(m)$adj.r.squared, bic = BIC(m),
                                        nw_lag = nw_lag_usado(V))

modelos <- list(); dados_m <- list()

resultado <- purrr::map_dfr(respostas_disp, function(y) {
  d <- amostras[[y]]
  d_h <- dplyr::filter(d, periodo == cand_final)
  d_l <- dplyr::filter(d, periodo == cand_inicial)
  out <- list()

  # (a) Modelo E original: janela principal de Haddad (igual ao 06, ciclo de 2018)
  d_orig <- model_data |> dplyr::filter(ciclo == ciclo_troca) |> add_lags(c(y, "dp_pt"), 1) |>
    tidyr::drop_na(dplyr::all_of(c(y, "dp_pt", paste0(y, "_l1"), "dp_pt_l1", controles)))
  m <- lm(f_e(y), data = d_orig); V <- vcov_nw(m)
  out$a <- dplyr::bind_cols(tibble::tibble(especificacao = "E original: janela principal (Haddad)", parametro = "β Haddad"),
                            linha_beta(m, V), ajuste(m, V))

  # (b) O mesmo modelo E só nos pregões de Haddad da janela ampliada
  if (nrow(d_h) > length(controles) + 2) {
    m <- lm(f_e(y), data = d_h); V <- vcov_nw(m)
    out$b <- dplyr::bind_cols(tibble::tibble(especificacao = "E só nos pregões de Haddad da janela ampliada", parametro = "β Haddad"),
                              linha_beta(m, V), ajuste(m, V)) |>
      dplyr::mutate(mesmos_pregoes_do_original = identical(d_h$data, d_orig$data))
  }

  # (c) R12 de 2018, sem interação: janela ampliada, um β só
  m_r12 <- lm(f_e(y), data = d); V_r12 <- vcov_periodo(m_r12, d)
  modelos[[paste(y, "R12 2018 sem interação")]] <<- m_r12; dados_m[[paste(y, "R12 2018 sem interação")]] <<- d
  out$c <- dplyr::bind_cols(tibble::tibble(especificacao = "R12 de 2018 sem interação: janela ampliada", parametro = "β único"),
                            linha_beta(m_r12, V_r12), ajuste(m_r12, V_r12))

  # (d) Interação Lula-Haddad, na mesma amostra de (c)
  if (isTRUE(identificavel$ok[identificavel$y == y])) {
    X <- stats::model.matrix(f_int(y), d)
    if (qr(X)$rank == ncol(X)) {
      m <- lm(f_int(y), data = d); V <- vcov_periodo(m, d); tc <- ic_t(m); gl <- df.residual(m)
      modelos[[paste(y, "interação Lula-Haddad")]] <<- m; dados_m[[paste(y, "interação Lula-Haddad")]] <<- d
      est_h <- coef(m)[["dp_pt"]] + coef(m)[["dp_haddad"]]
      # Var(β + δ) = Var(β) + Var(δ) + 2 Cov(β, δ)
      ep_h <- sqrt(V["dp_pt", "dp_pt"] + V["dp_haddad", "dp_haddad"] + 2 * V["dp_pt", "dp_haddad"])
      aj <- ajuste(m, V)
      out$d <- dplyr::bind_rows(
        dplyr::bind_cols(tibble::tibble(especificacao = "Interação Lula-Haddad: janela ampliada", parametro = "β Lula"),
                         linha_beta(m, V, "dp_pt"), aj),
        dplyr::bind_cols(tibble::tibble(especificacao = "Interação Lula-Haddad: janela ampliada", parametro = "β Haddad (β + δ)",
                                        estimativa = est_h, ep_hac = ep_h,
                                        p_nominal = 2 * stats::pt(-abs(est_h / ep_h), df = gl),
                                        ic_inf = est_h - tc * ep_h, ic_sup = est_h + tc * ep_h), aj),
        dplyr::bind_cols(tibble::tibble(especificacao = "Interação Lula-Haddad: janela ampliada", parametro = "δ (Haddad − Lula)"),
                         linha_beta(m, V, "dp_haddad"), aj),
        dplyr::bind_cols(tibble::tibble(especificacao = "Interação Lula-Haddad: janela ampliada", parametro = "θ (dummy Haddad)"),
                         linha_beta(m, V, "haddad"), aj)
      ) |> dplyr::mutate(n_lula = nrow(d_l), n_haddad = nrow(d_h))
    } else {
      nao_estimados <<- dplyr::bind_rows(nao_estimados, tibble::tibble(
        y = y, n_lula = nrow(d_l), n_dp_nao_zero = sum(d_l$dp_pt != 0), motivo = "matriz de regressores sem posto completo"))
    }
  }
  dplyr::bind_rows(out) |> dplyr::mutate(y = y, .before = 1)
})

export_table(nao_estimados, file.path(saida_dir, "lula_haddad_nao_estimados.csv"))
export_table(resultado |> format_table(4), file.path(saida_dir, "lula_haddad_modelos.csv"))

# Tabela da interação, uma linha por ativo
fmt <- function(x, d = 3) formatC(x, format = "f", digits = d, decimal.mark = ",")
cel <- function(e, ep) paste0(fmt(e), " (", fmt(ep), ")")
ic  <- function(a, b) paste0("[", fmt(a), "; ", fmt(b), "]")
pega <- function(y_, espec, par, col) {
  v <- resultado[[col]][resultado$y == y_ & grepl(espec, resultado$especificacao, fixed = TRUE) & resultado$parametro == par]
  if (length(v)) v[1] else NA_real_
}
tabela <- purrr::map_dfr(respostas_disp, function(y) {
  tem <- any(resultado$y == y & resultado$parametro == "β Lula")
  tibble::tibble(
    Ativo = unname(respostas[y]),
    `N Lula` = identificavel$n_lula[identificavel$y == y],
    `N Haddad` = sum(amostras[[y]]$periodo == cand_final),
    `β Lula` = if (tem) cel(pega(y, "Interação", "β Lula", "estimativa"), pega(y, "Interação", "β Lula", "ep_hac")) else "não estimado",
    `IC nominal 95% β Lula` = if (tem) ic(pega(y, "Interação", "β Lula", "ic_inf"), pega(y, "Interação", "β Lula", "ic_sup")) else "--",
    `β Haddad` = if (tem) cel(pega(y, "Interação", "β Haddad (β + δ)", "estimativa"), pega(y, "Interação", "β Haddad (β + δ)", "ep_hac")) else "não estimado",
    `IC nominal 95% β Haddad` = if (tem) ic(pega(y, "Interação", "β Haddad (β + δ)", "ic_inf"), pega(y, "Interação", "β Haddad (β + δ)", "ic_sup")) else "--",
    `δ (Haddad − Lula)` = if (tem) cel(pega(y, "Interação", "δ (Haddad − Lula)", "estimativa"), pega(y, "Interação", "δ (Haddad − Lula)", "ep_hac")) else "--",
    `p nominal de δ` = if (tem) fmt(pega(y, "Interação", "δ (Haddad − Lula)", "p_nominal")) else "--",
    `β R12 2018 sem interação` = cel(pega(y, "R12 de 2018", "β único", "estimativa"), pega(y, "R12 de 2018", "β único", "ep_hac")),
    `β E original (Haddad)` = cel(pega(y, "E original", "β Haddad", "estimativa"), pega(y, "E original", "β Haddad", "ep_hac")),
    Nota = "inferência nominal (amostras pequenas); δ não é efeito causal do candidato"
  )
})
export_table(tabela, file.path(saida_dir, "lula_haddad_tabela.csv"))

# ------------------------------------------------------------
# 3. Diagnósticos na amostra comum (R12 de 2018 x interação)
# ------------------------------------------------------------

diagnosticos <- purrr::imap_dfr(modelos, function(m, nm) {
  d <- dados_m[[nm]]
  bg <- purrr::map_dfr(c(1, 5), ~ bg_ciclo(m, as.character(d$periodo), .x))
  rs <- reset_um(m, d)
  tibble::tibble(y = sub(" .*", "", nm), especificacao = sub("^[^ ]+ ", "", nm), n = nobs(m),
                 parametros = length(coef(m)), obs_por_parametro = nobs(m) / length(coef(m)),
                 adj_r2 = summary(m)$adj.r.squared, bic = BIC(m),
                 p_bg_ordem1 = bg$p_value[1], p_bg_ordem5 = bg$p_value[2],
                 p_reset_classico = rs$p_reset, p_reset_hac = rs$p_reset_hac)
})
export_table(diagnosticos |> format_table(4), file.path(saida_dir, "lula_haddad_diagnosticos.csv"))

# ------------------------------------------------------------
# 4. Conferência para uma eventual soma Lula + Haddad (não usada)
# ------------------------------------------------------------
# Só descreve os dias em que os dois contratos têm preço no mesmo
# arquivo. A soma só faria sentido se os dois fossem resultados
# mutuamente exclusivos do mesmo mercado, com a mesma convenção de
# preço; isso precisa ser conferido na fonte antes de qualquer uso.

soma <- tryCatch({
  bruto <- load_object(electoral_raw_file)$diario
  bruto |>
    dplyr::filter(ciclo == ciclo_troca, nome_clean %in% c(cand_inicial, cand_final)) |>
    dplyr::group_by(data, nome_clean) |>
    dplyr::summarise(prob = dplyr::last(prob_norm), .groups = "drop") |>
    tidyr::pivot_wider(names_from = nome_clean, values_from = prob) |>
    dplyr::arrange(data)
}, error = function(e) NULL)
if (!is.null(soma) && all(c(cand_inicial, cand_final) %in% names(soma))) {
  soma <- soma |>
    dplyr::mutate(ambos_com_preco = is.finite(.data[[cand_inicial]]) & is.finite(.data[[cand_final]]),
                  soma = dplyr::if_else(ambos_com_preco, .data[[cand_inicial]] + .data[[cand_final]], NA_real_),
                  uso = "não usada nos modelos; conferir na fonte se são resultados mutuamente exclusivos do mesmo mercado")
  export_table(soma |> format_table(4), file.path(saida_dir, "lula_haddad_soma_conferencia.csv"))
  message("Dias com os dois contratos com preço: ", sum(soma$ambos_com_preco),
          ". A probabilidade somada NÃO foi usada.")
} else message("Conferência da soma Lula + Haddad não gerada (arquivo bruto sem os dois contratos).")

# ------------------------------------------------------------
# 5. Gráfico: sensibilidades por período e referências
# ------------------------------------------------------------

gd <- resultado |>
  dplyr::filter(parametro %in% c("β Lula", "β Haddad (β + δ)", "β único", "β Haddad"),
                !grepl("só nos pregões", especificacao)) |>
  dplyr::mutate(rotulo = dplyr::case_when(
    parametro == "β Lula" ~ "Lula\n(interação)",
    parametro == "β Haddad (β + δ)" ~ "Haddad\n(interação)",
    parametro == "β único" ~ "R12 2018\nsem interação",
    TRUE ~ "Haddad\n(E original)"),
    rotulo = factor(rotulo, c("Lula\n(interação)", "Haddad\n(interação)", "R12 2018\nsem interação", "Haddad\n(E original)")),
    grupo = ifelse(grepl("interação\\)$", as.character(rotulo)), "interação", "referência"),
    ativo = factor(unname(respostas[y]), unname(respostas[respostas_disp])))
if (nrow(gd)) {
  n_txt <- paste0(sub(" \\(.*", "", unname(respostas[identificavel$y])), ": ", identificavel$n_lula, " pregões de Lula",
                  collapse = "; ")
  g <- ggplot2::ggplot(gd, ggplot2::aes(rotulo, estimativa, colour = grupo)) +
    ggplot2::geom_hline(yintercept = 0, colour = "grey50") +
    ggplot2::geom_pointrange(ggplot2::aes(ymin = ic_inf, ymax = ic_sup), size = 0.4) +
    ggplot2::scale_colour_manual(values = c(`interação` = "firebrick", `referência` = "steelblue4"), guide = "none") +
    ggplot2::facet_wrap(~ ativo, scales = "free_y", nrow = 1) +
    ggplot2::labs(x = NULL, y = "resposta a +1 p.p. em P(PT)",
                  title = paste0("Sensibilidade em ", ciclo_troca, ": períodos de Lula e de Haddad"),
                  subtitle = "Intervalos nominais de 95% (Newey-West). Amostras pequenas: leitura exploratória; a diferença não é efeito causal do candidato.",
                  caption = paste0("Janela ampliada de ", ciclo_troca, ". ", n_txt, ".")) +
    ggplot2::theme_minimal(base_size = 9) + ggplot2::theme(panel.grid.minor = ggplot2::element_blank())
  save_plot(g, file.path(saida_dir, "lula_haddad_sensibilidades.png"), width = 12, height = 4.2)
}

cat("\n========== PERÍODOS (janela ampliada de ", ciclo_troca, ") ==========\n", sep = "")
print(periodos |> dplyr::select(y, periodo, primeiro_pregao, ultimo_pregao, n, n_dp_diferente_de_zero, dp_desvio,
                                correlacao_dp_y) |> format_table(3), n = Inf, width = Inf)
cat("\n========== MODELOS ==========\n")
print(resultado |> dplyr::select(y, especificacao, parametro, estimativa, ep_hac, p_nominal, ic_inf, ic_sup, n, adj_r2, bic) |>
        format_table(3), n = Inf, width = Inf)
cat("\n========== DIAGNÓSTICOS NA AMOSTRA COMUM ==========\n")
print(diagnosticos |> format_table(3), n = Inf, width = Inf)
if (nrow(nao_estimados)) { cat("\nNão estimados (só descritiva):\n"); print(nao_estimados, width = Inf) }
message("10d_lula_haddad.R concluído com sucesso.")
