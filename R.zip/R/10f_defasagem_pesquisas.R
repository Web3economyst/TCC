# ============================================================
# Script  : 10f_defasagem_pesquisas.R
#
# Objetivo:
#   Robustez da data de entrada das pesquisas. Na base principal, a
#   pesquisa com fim de campo no dia D entra na série em D + 1
#   (defasagem_divulgacao = 1 no 00_config.R). Aqui a probabilidade
#   do agregador é reconstruída com defasagens de 0, 1 e 2 dias, e as
#   robustezes R5 (pesquisas no lugar do mercado) e R6 (mercado +
#   pesquisas) são reestimadas com cada uma.
#
#   Leitura:
#     0 dia : a pesquisa conta no próprio pregão do fim do campo. Para
#             as divulgadas à noite (caso usual), isso usa uma
#             informação que ainda não era pública no fechamento da B3,
#             o que tende a FAVORECER a associação com os preços.
#     1 dia : base principal (deve reproduzir a Tabela 6).
#     2 dias: para as pesquisas divulgadas um dia depois do fim do
#             campo (ex.: BTG/FSB de 14/10/2018, divulgada em 15/10).
#   Se a R5 continua sem associação com 0, 1 e 2 dias, a conclusão
#   sobre as pesquisas não depende da regra de entrada.
#
#   Não altera a base nem os outros scripts.
#
# Entrada : data/processed/model_data_daily.rds, output/09_saida/ardl_main.rds,
#           painel das pesquisas (arquivo_painel_pesquisas, script 08 do TCC)
# Saída   : output/10f_saida/defasagem_pesquisas.csv
# ============================================================

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

saida_dir <- saida("10f")

model_data <- load_object(model_data_file)
aviso_simulado(model_data)
base_ardl <- load_object(file.path(saida("09"), "ardl_main.rds"))$empilhado
options(tcc.defasagem_reacao = resolver_reacao(model_data))

# Painel do agregador (mesma busca do 01_import.R)
locais_painel <- c(electoral_raw_dir, root, dirname(root),
                   file.path(root, "saida_mercados"), file.path(dirname(root), "saida_mercados"))
achados <- file.path(locais_painel, arquivo_painel_pesquisas)
if (!any(file.exists(achados))) stop("Painel das pesquisas não encontrado: ", arquivo_painel_pesquisas)
painel <- readr::read_csv(achados[file.exists(achados)][1], show_col_types = FALSE) |>
  dplyr::transmute(ciclo = ano, data = as.Date(data), p_pesq) |>
  dplyr::filter(is.finite(p_pesq))

# Reconstrói p_pesq e dp_pesq com a defasagem L (mesma regra do 02 e do 03)
com_defasagem <- function(L) {
  model_data |>
    dplyr::select(-dplyr::any_of(c("p_pesq", "dp_pesq"))) |>
    dplyr::arrange(ciclo, data) |>
    dplyr::left_join(painel |> dplyr::transmute(ciclo, data_pesq = data + L, p_pesq),
                     by = dplyr::join_by(ciclo, closest(data >= data_pesq))) |>
    dplyr::mutate(p_pesq = dplyr::if_else(data > data_2t, NA_real_, p_pesq)) |>   # sem pesquisa depois do 2º turno
    dplyr::select(-data_pesq) |>
    dplyr::group_by(ciclo) |>
    dplyr::mutate(dp_pesq = 100 * (p_pesq - dplyr::lag(p_pesq))) |>
    dplyr::ungroup()
}

linha <- function(r, L, rob) {
  co <- tidy_nw(r$modelo)
  x <- if (rob == "R5") "dp_pesq" else "dp_pt"
  b <- co[co$term == x, ]
  tibble::tibble(defasagem_dias = L, robustez = rob, y = r$y, n = nobs(r$modelo),
                 coef = b$estimate, ep = b$std.error, p_valor = b$p.value,
                 p_wald_pesquisas = if (!is.null(r$wald_extra)) r$wald_extra$p_value else NA_real_)
}

res <- purrr::map_dfr(c(0, 1, 2), function(L) {
  d <- com_defasagem(L)
  dpq <- d |> dplyr::filter(is.finite(p_pesq))
  purrr::map_dfr(c("r_ibov", "r_usd"), function(y) {
    p0 <- base_ardl[[y]]$p; q0 <- base_ardl[[y]]$q
    r5 <- rodar_leadlag(dpq, y, "dp_pesq", "R5", p0, q0)
    r6 <- rodar_leadlag(dpq |> add_lags("dp_pesq", 1), y, "dp_pt", "R6", p0, q0,
                        extra = c("dp_pesq", "dp_pesq_l1"))
    dplyr::bind_rows(linha(r5, L, "R5"), linha(r6, L, "R6"))
  })
})

export_table(res |> format_table(4), file.path(saida_dir, "defasagem_pesquisas.csv"))

cat("\n========== DEFASAGEM DE ENTRADA DAS PESQUISAS ==========\n")
cat("R5: coef = variação da probabilidade das pesquisas. R6: coef = mercado de previsão;",
    "p_wald_pesquisas = Wald conjunto das pesquisas (t e t-1).\n")
print(res |> format_table(3), n = Inf, width = Inf)
message("10f_defasagem_pesquisas.R concluído com sucesso.")
