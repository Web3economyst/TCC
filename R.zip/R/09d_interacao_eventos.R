# ============================================================
# Script  : 09d_interacao_eventos.R
#
# Objetivo:
#   Investigar, de forma EXPLORATÓRIA, se o primeiro pregão após o
#   1º turno de cada eleição (2018, 2022 e 2026) se comporta de modo
#   diferente dos pregões comuns de campanha. Duas análises
#   complementares; nenhuma altera os modelos E, E1 e D, a amostra
#   principal ou as robustezes.
#
#   1. Modelo de interação (amostra empilhada do modelo E):
#
#        y_t = a_ciclo + β ΔP_t + θ D_t + δ (D_t × ΔP_t)
#              + g'·controles_t + e_t
#
#      D_t = 1 só no primeiro pregão após o 1º turno.
#        β      : sensibilidade nos pregões comuns
#        β + δ  : sensibilidade nos pregões pós-1º turno
#        δ      : diferença de inclinação (H0: δ = 0)
#        θ      : deslocamento do retorno nesses pregões
#      Erros-padrão Newey-West por blocos (não cruzam a fronteira
#      entre ciclos); Var(β + δ) inclui a covariância entre os dois.
#
#      LIMITAÇÃO: há um evento por eleição, três no total. θ e δ são
#      identificados por três observações; o Newey-West não corrige
#      a falta de observações nesse grupo. Erros-padrão, intervalos
#      e p-valores desses termos são NOMINAIS, sem garantia de
#      cobertura de 95%. O Wald de δ é referência exploratória, não
#      evidência de mudança de regime; δ impreciso também não prova
#      que os regimes são iguais. A leitura deve se apoiar mais na
#      estabilidade dos coeficientes entre os eventos (análises 2 e
#      3) do que no p-valor da interação.
#      A estimação completa exige um evento válido em cada ciclo;
#      se faltar algum, o modelo fica como incompleto, sem inferência.
#
#   2. Influência por evento (leave-one-event-out) no modelo E:
#      E0 (todos os pregões), sem o evento de 2018, sem o de 2022,
#      sem o de 2026 e sem os três. A amostra do modelo E é montada
#      primeiro, com as defasagens; só depois os pregões saem, sem
#      recalcular nada. Mede sensibilidade à exclusão, não
#      contribuição causal do evento. Medidas: diferença absoluta do
#      β (principal), a mesma diferença em erros-padrão do β original
#      (influência padronizada, para comparar ativos) e a variação
#      percentual (complementar).
#
#   3. Estabilidade da interação: o modelo de interação reestimado
#      sem cada evento (dois eventos restantes). Com dois eventos, D
#      e D×ΔP ajustam essas duas observações exatamente; só as
#      estimativas pontuais são reportadas, sem p-valor. Se a matriz
#      de regressores não tiver posto completo, o resultado é
#      registrado como não estimável.
#
# Entrada : data/processed/model_data_daily.rds
#           output/06_saida/static_dynamic_models.rds (conferência)
# Saída   : output/09d_saida/interacao_coeficientes.csv
#           output/09d_saida/interacao_tabela.csv
#           output/09d_saida/eventos_verificacao.csv
#           output/09d_saida/leave_one_event_out.csv
#           output/09d_saida/interacao_estabilidade.csv
#           output/09d_saida/interacao_beta_comum_evento.png
#           output/09d_saida/leave_one_event_out.png
#
# Próximo script: 10_robustness.R
# ============================================================

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

saida_dir <- saida("09d")

model_data <- load_object(model_data_file)
aviso_simulado(model_data)

respostas_disp <- names(respostas)[purrr::map_lgl(names(respostas), ~ sum(is.finite(model_data[[.x]])) > 50)]
anos <- sort(unique(model_data$ciclo))

# ------------------------------------------------------------
# 1. Amostra do modelo E e os eventos
# ------------------------------------------------------------

# Mesma amostra do 06 (modelo E): defasagem de 1 pregão dentro do
# ciclo e linhas completas em y, ΔP, as duas defasagens e os
# controles. As exclusões das seções seguintes partem dela.
amostra_e <- function(y) {
  model_data |>
    add_lags(c(y, "dp_pt"), 1) |>
    tidyr::drop_na(dplyr::all_of(c(y, "dp_pt", paste0(y, "_l1"), "dp_pt_l1", controles))) |>
    dplyr::mutate(pos_primeiro_turno = as.integer(pos_1t == 1),
                  dp_evento = dp_pt * pos_primeiro_turno)
}

formula_e <- function(y) stats::reformulate(c("dp_pt", controles, "factor(ciclo)"), y)
formula_int <- function(y) stats::reformulate(c("dp_pt", "pos_primeiro_turno", "dp_evento", controles, "factor(ciclo)"), y)

# Primeiro pregão depois do 1º turno pelo calendário de pregões da
# base (não o dia seguinte do calendário civil)
esperado <- model_data |>
  dplyr::group_by(ciclo) |>
  dplyr::summarise(data_1t = data_1t[1], pregao_esperado = min(data[data > data_1t]), .groups = "drop")

amostras <- purrr::map(respostas_disp, amostra_e) |> setNames(respostas_disp)

# Conferência com o 06: mesma amostra e mesmo β do modelo E
arq_06 <- file.path(saida("06"), "static_dynamic_models.rds")
modelos_06 <- if (file.exists(arq_06)) load_object(arq_06) else NULL

eventos <- purrr::imap_dfr(amostras, function(d, y) {
  ev <- d |> dplyr::filter(pos_primeiro_turno == 1) |>
    dplyr::select(ciclo, data, dp_pt, retorno = dplyr::all_of(y))
  esperado |>
    dplyr::left_join(ev |> dplyr::count(ciclo, name = "eventos_na_amostra"), by = "ciclo") |>
    dplyr::left_join(ev |> dplyr::group_by(ciclo) |> dplyr::slice(1) |> dplyr::ungroup(), by = "ciclo") |>
    dplyr::mutate(y = y, .before = 1,
                  eventos_na_amostra = tidyr::replace_na(eventos_na_amostra, 0L),
                  data_confere = !is.na(data) & data == pregao_esperado,
                  valido = eventos_na_amostra == 1 & data_confere,
                  n_amostra_e = nrow(d))
})

export_table(eventos |> format_table(4), file.path(saida_dir, "eventos_verificacao.csv"))

# Um evento válido por ciclo é condição para falar em "três eventos"
tres_eventos <- eventos |> dplyr::group_by(y) |>
  dplyr::summarise(n_eventos = sum(valido), completos = all(valido) & dplyr::n() == length(anos), .groups = "drop")
if (any(!tres_eventos$completos))
  warning("Não há exatamente um primeiro pregão pós-1º turno válido por ciclo em: ",
          paste(tres_eventos$y[!tres_eventos$completos], collapse = ", "),
          ". Nesses ativos o modelo de interação não é uma comparação de três eventos.", call. = FALSE)

if (!is.null(modelos_06)) {
  for (y in respostas_disp) {
    m06 <- modelos_06[[paste0("empilhado__", y, "__E")]]
    stopifnot(nobs(m06) == nrow(amostras[[y]]),
              isTRUE(all.equal(unname(coef(m06)["dp_pt"]),
                               unname(coef(lm(formula_e(y), data = amostras[[y]]))["dp_pt"]))))
  }
  message("Amostra e β do modelo E conferem com o 06.")
}

# ------------------------------------------------------------
# 2. Modelo de interação
# ------------------------------------------------------------

# O modelo só é estimado se a matriz de regressores tiver posto
# completo e todos os coeficientes forem identificados
estimavel <- function(f, d) {
  X <- stats::model.matrix(f, data = d)
  qr(X)$rank == ncol(X) && nrow(X) > ncol(X)
}

estimar_interacao <- function(y, d, rotulo, com_inferencia = TRUE) {
  n_ev <- sum(d$pos_primeiro_turno)
  vazio <- tibble::tibble(y = y, amostra = rotulo, n = nrow(d), n_eventos = n_ev, estimavel = FALSE)
  if (n_ev < 2 || !estimavel(formula_int(y), d)) return(vazio)
  m <- lm(formula_int(y), data = d)
  if (anyNA(coef(m))) return(vazio)
  b <- coef(m)
  out <- tibble::tibble(y = y, amostra = rotulo, n = nobs(m), n_eventos = n_ev, estimavel = TRUE,
                        beta_comum = b[["dp_pt"]], delta = b[["dp_evento"]],
                        beta_evento = b[["dp_pt"]] + b[["dp_evento"]], theta = b[["pos_primeiro_turno"]])
  if (!com_inferencia) return(out)
  V <- vcov_nw(m); tc <- ic_t(m); gl <- df.residual(m)
  ep <- function(v) sqrt(v)
  # Var(β + δ) = Var(β) + Var(δ) + 2 Cov(β, δ)
  var_evento <- V["dp_pt", "dp_pt"] + V["dp_evento", "dp_evento"] + 2 * V["dp_pt", "dp_evento"]
  w <- wald_nw(m, "dp_evento")
  pv <- function(est, e) 2 * stats::pt(-abs(est / e), df = gl)
  out |> dplyr::mutate(
    ep_beta_comum = ep(V["dp_pt", "dp_pt"]), p_beta_comum = pv(beta_comum, ep_beta_comum),
    ic_beta_comum_inf = beta_comum - tc * ep_beta_comum, ic_beta_comum_sup = beta_comum + tc * ep_beta_comum,
    ep_delta = ep(V["dp_evento", "dp_evento"]),
    wald_delta_F = w$F, p_wald_delta_exploratorio = w$p_value,
    cov_beta_delta = V["dp_pt", "dp_evento"],
    ep_beta_evento = ep(var_evento),
    ic_beta_evento_inf = beta_evento - tc * ep_beta_evento, ic_beta_evento_sup = beta_evento + tc * ep_beta_evento,
    ep_theta = ep(V["pos_primeiro_turno", "pos_primeiro_turno"]), p_theta_exploratorio = pv(theta, ep_theta),
    nw_lag = nw_lag_usado(V), gl_residuo = gl
  )
}

# A estimação completa (com erros-padrão, intervalos e Wald) exige um
# evento válido em cada ciclo. Se faltar algum, o modelo fica
# registrado como incompleto: sem inferência, fora da tabela e do
# gráfico. (Com dois eventos, D e D×ΔP ajustam as duas observações
# exatamente.)
interacao <- purrr::map_dfr(respostas_disp, function(y) {
  completo <- isTRUE(tres_eventos$completos[tres_eventos$y == y])
  estimar_interacao(y, amostras[[y]], "amostra do modelo E", com_inferencia = completo) |>
    dplyr::mutate(comparacao_de_tres_eventos = completo,
                  situacao = dplyr::case_when(
                    !estimavel ~ "não estimável",
                    completo ~ "completo: um evento válido por ciclo; inferência exploratória",
                    TRUE ~ "incompleto: falta evento válido em algum ciclo; sem inferência"))
})
if (!"ep_beta_comum" %in% names(interacao)) interacao$ep_beta_comum <- NA_real_

export_table(interacao |> format_table(4), file.path(saida_dir, "interacao_coeficientes.csv"))

fmt <- function(x, d = 3) formatC(x, format = "f", digits = d, decimal.mark = ",")
# Os erros-padrão, o intervalo e o p-valor desta tabela são NOMINAIS:
# θ e δ dependem de três pregões, e o Newey-West não corrige a falta
# de observações nesse grupo. Não há garantia de cobertura de 95%.
interacao_tabela <- interacao |>
  dplyr::filter(estimavel, comparacao_de_tres_eventos, is.finite(ep_beta_comum)) |>
  dplyr::transmute(
    Ativo = unname(respostas[y]),
    `β comum` = paste0(fmt(beta_comum), " (", fmt(ep_beta_comum), ")"),
    `δ interação` = paste0(fmt(delta), " (", fmt(ep_delta), ")"),
    `β evento` = fmt(beta_evento),
    `IC nominal de 95% do β evento` = paste0("[", fmt(ic_beta_evento_inf), "; ", fmt(ic_beta_evento_sup), "]"),
    N = n,
    `θ dummy` = paste0(fmt(theta), " (", fmt(ep_theta), ")"),
    `p Wald de δ (exploratório)` = fmt(p_wald_delta_exploratorio),
    `Eventos` = n_eventos, `Defasagens NW` = nw_lag,
    Nota = "inferência nominal, sem garantia de cobertura (três eventos)"
  )
export_table(interacao_tabela, file.path(saida_dir, "interacao_tabela.csv"))

# ------------------------------------------------------------
# 3. Influência por evento no modelo E (leave-one-event-out)
# ------------------------------------------------------------
# A exclusão é feita sobre a amostra já montada: as defasagens e os
# controles dos pregões que ficam não mudam.

loeo <- purrr::map_dfr(respostas_disp, function(y) {
  d <- amostras[[y]]
  ev <- d |> dplyr::filter(pos_primeiro_turno == 1) |> dplyr::select(ciclo, data)
  cenarios <- c(list(list(rotulo = "E0: todos os pregões", fora = rep(FALSE, nrow(d)), evento = NA)),
                purrr::map(seq_len(nrow(ev)), function(i)
                  list(rotulo = paste0("E-", ev$ciclo[i], ": sem o pós-1º turno de ", ev$ciclo[i]),
                       fora = d$ciclo == ev$ciclo[i] & d$data == ev$data[i], evento = ev$ciclo[i])),
                if (nrow(ev) > 1) list(list(rotulo = "E-sem-eventos: sem os pós-1º turno",
                                            fora = d$pos_primeiro_turno == 1, evento = NA)))
  purrr::map_dfr(cenarios, function(cn) {
    m <- lm(formula_e(y), data = d[!cn$fora, ])
    V <- vcov_nw(m)
    t <- tidy_nw(m) |> dplyr::filter(term == "dp_pt")
    tibble::tibble(y = y, especificacao = cn$rotulo, evento_excluido = cn$evento,
                   n = nobs(m), excluidas = sum(cn$fora),
                   beta = t$estimate, ep_hac = t$std.error, p_value = t$p.value,
                   ic_inf = t$conf.low, ic_sup = t$conf.high, nw_lag = nw_lag_usado(V))
  }) |>
    dplyr::mutate(
      beta_original = beta[1], ep_original = ep_hac[1],
      # Medida principal: diferença absoluta entre os coeficientes
      delta_beta = beta - beta_original,
      # Influência padronizada: a mesma diferença em erros-padrão do β
      # original. Não é teste de significância; serve para comparar a
      # influência entre ativos, que têm unidades diferentes.
      influencia_padronizada = delta_beta / ep_original,
      # Variação percentual: só complementar. Com β original perto de
      # zero, qualquer mudança vira um percentual enorme. O corte de um
      # erro-padrão (|β| > 1 EP) é apenas uma convenção descritiva para
      # não mostrar o percentual nesses casos; não é critério estatístico.
      pct_interpretavel = abs(beta_original) > ep_original,
      influencia_pct = dplyr::if_else(pct_interpretavel & excluidas > 0,
                                      100 * abs(delta_beta) / abs(beta_original), NA_real_),
      conferencia_n = n == n[1] - excluidas
    )
})
stopifnot(all(loeo$conferencia_n))

export_table(loeo |> dplyr::select(-conferencia_n) |> format_table(4),
             file.path(saida_dir, "leave_one_event_out.csv"))

# ------------------------------------------------------------
# 4. Estabilidade do modelo de interação (sem cada evento)
# ------------------------------------------------------------
# Só estimativas pontuais: com dois eventos, D e D×ΔP ajustam as
# duas observações exatamente, e erro-padrão ou p-valor desses
# termos não têm leitura.

estabilidade <- purrr::map_dfr(respostas_disp, function(y) {
  d <- amostras[[y]]
  ev <- d |> dplyr::filter(pos_primeiro_turno == 1) |> dplyr::select(ciclo, data)
  dplyr::bind_rows(
    estimar_interacao(y, d, "interação completa", com_inferencia = FALSE),
    purrr::map_dfr(seq_len(nrow(ev)), function(i)
      estimar_interacao(y, d[!(d$ciclo == ev$ciclo[i] & d$data == ev$data[i]), ],
                        paste0("interação sem ", ev$ciclo[i]), com_inferencia = FALSE))
  )
}) |>
  dplyr::mutate(situacao = dplyr::if_else(estimavel, "estimado (só estimativas pontuais)", "não estimável"))

export_table(estabilidade |> format_table(4), file.path(saida_dir, "interacao_estabilidade.csv"))

# ------------------------------------------------------------
# 5. Gráficos
# ------------------------------------------------------------

rot_y <- function(y) factor(unname(respostas[y]), unname(respostas[respostas_disp]))

# 5.1 Sensibilidade por tipo de pregão
g1d <- interacao |> dplyr::filter(estimavel, comparacao_de_tres_eventos, is.finite(ep_beta_comum)) |>
  dplyr::select(y, n, n_eventos, beta_comum, ic_beta_comum_inf, ic_beta_comum_sup,
                beta_evento, ic_beta_evento_inf, ic_beta_evento_sup)
if (nrow(g1d)) {
  # Número de pregões de cada grupo, por ativo, na legenda inferior
  n_par <- paste0(g1d$n - g1d$n_eventos, " comuns e ", g1d$n_eventos, " pós-primeiro turno")
  n_txt <- if (length(unique(n_par)) == 1) paste0("em cada ativo, ", n_par[1]) else
    paste(strwrap(paste0(sub(" \\(.*", "", unname(respostas[g1d$y])), ": ", n_par, collapse = "; "), 150),
          collapse = "\n")
  g1d <- dplyr::bind_rows(
    g1d |> dplyr::transmute(y, tipo = "Pregões comuns",
                            b = beta_comum, lo = ic_beta_comum_inf, hi = ic_beta_comum_sup),
    g1d |> dplyr::transmute(y, tipo = "Pós-primeiro turno",
                            b = beta_evento, lo = ic_beta_evento_inf, hi = ic_beta_evento_sup)
  ) |> dplyr::mutate(ativo = rot_y(y), evento = tipo == "Pós-primeiro turno",
                     tipo = factor(tipo, c("Pregões comuns", "Pós-primeiro turno")))
  g1 <- ggplot2::ggplot(g1d, ggplot2::aes(tipo, b, colour = evento)) +
    ggplot2::geom_hline(yintercept = 0, colour = "grey50") +
    ggplot2::geom_pointrange(ggplot2::aes(ymin = lo, ymax = hi), size = 0.4) +
    ggplot2::scale_colour_manual(values = c(`FALSE` = "steelblue4", `TRUE` = "firebrick"), guide = "none") +
    ggplot2::facet_wrap(~ ativo, scales = "free", nrow = 1) +
    ggplot2::labs(x = NULL, y = "resposta a +1 p.p. em P(PT)",
                  title = "Sensibilidade por tipo de pregão (modelo de interação)",
                  subtitle = paste("Intervalos nominais de 95% (Newey-West). O grupo pós-primeiro turno tem um pregão por",
                                   "eleição: o intervalo dele não tem garantia de cobertura e é só exploratório."),
                  caption = paste0("Número de pregões: ", n_txt, ".")) +
    ggplot2::theme_minimal(base_size = 9) + ggplot2::theme(panel.grid.minor = ggplot2::element_blank())
  save_plot(g1, file.path(saida_dir, "interacao_beta_comum_evento.png"), width = 11, height = 4)
}

# 5.2 Influência dos eventos individuais (mesma escala dentro de cada ativo)
g2d <- loeo |>
  dplyr::mutate(ativo = rot_y(y),
                rotulo = factor(sub(":.*", "", especificacao), unique(sub(":.*", "", especificacao))),
                completo = excluidas == 0)
g2 <- ggplot2::ggplot(g2d, ggplot2::aes(rotulo, beta, colour = completo)) +
  ggplot2::geom_hline(yintercept = 0, colour = "grey50") +
  ggplot2::geom_hline(data = dplyr::filter(g2d, completo), ggplot2::aes(yintercept = beta),
                      linetype = 2, colour = "black", linewidth = 0.3) +
  ggplot2::geom_pointrange(ggplot2::aes(ymin = ic_inf, ymax = ic_sup), size = 0.4) +
  ggplot2::scale_colour_manual(values = c(`TRUE` = "black", `FALSE` = "steelblue4"), guide = "none") +
  ggplot2::facet_wrap(~ ativo, scales = "free_y", nrow = 1) +
  ggplot2::labs(x = NULL, y = "β de ΔP(PT) no modelo E",
                title = "Influência de cada pregão pós-1º turno no β do modelo E",
                subtitle = "E0: todos os pregões (linha tracejada). Demais: modelo E sem o pregão indicado. IC de 95% Newey-West.") +
  ggplot2::theme_minimal(base_size = 9) +
  ggplot2::theme(panel.grid.minor = ggplot2::element_blank(),
                 axis.text.x = ggplot2::element_text(angle = 30, hjust = 1))
save_plot(g2, file.path(saida_dir, "leave_one_event_out.png"), width = 11, height = 4.5)

# ------------------------------------------------------------
# Console
# ------------------------------------------------------------

cat("\n========== EVENTOS (primeiro pregão após o 1º turno) ==========\n")
print(eventos |> dplyr::select(y, ciclo, data_1t, pregao_esperado, data, eventos_na_amostra, valido, dp_pt, retorno) |>
        format_table(3), n = Inf, width = Inf)
cat("\n========== LEAVE-ONE-EVENT-OUT (modelo E) ==========\n")
print(loeo |> dplyr::select(y, especificacao, n, beta, ep_hac, p_value, ic_inf, ic_sup, delta_beta,
                            influencia_padronizada, influencia_pct) |>
        format_table(3), n = Inf, width = Inf)
cat("\n========== ESTABILIDADE DA INTERAÇÃO (só estimativas pontuais) ==========\n")
print(estabilidade |> format_table(3), n = Inf, width = Inf)
cat("\n========== MODELO DE INTERAÇÃO (exploratório: três eventos) ==========\n")
print(interacao_tabela, n = Inf, width = Inf)
cat("Inferência nominal: três eventos não garantem a cobertura dos intervalos. Ver a estabilidade acima.\n")
if (any(!interacao$comparacao_de_tres_eventos)) {
  cat("\nModelos incompletos (sem inferência):\n")
  print(interacao |> dplyr::filter(!comparacao_de_tres_eventos) |> dplyr::select(y, n_eventos, situacao))
}
message("09d_interacao_eventos.R concluído com sucesso.")
