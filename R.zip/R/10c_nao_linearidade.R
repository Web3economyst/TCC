# ============================================================
# Script  : 10c_nao_linearidade.R
#
# Objetivo:
#   Extensão COMPLEMENTAR ao modelo E: a relação entre ΔP(PT) e os
#   preços é linear, ou muda para os grandes choques de
#   probabilidade?
#
#     y_t = a_ciclo + f(ΔP_t) + g'·controles_t + e_t
#
#   f é um spline cúbico natural com 3 graus de liberdade
#   (splines::ns). O modelo E do 06 não muda.
#
#   Como o teste é montado. O espaço do spline natural contém a
#   reta. A base do spline é reescrita como
#       ΔP_t  +  dois termos ortogonais à reta (nl1, nl2),
#   que gera exatamente o mesmo ajuste do ns(ΔP, 3). Assim o modelo
#   linear é o caso restrito nl1 = nl2 = 0, e a não linearidade é
#   testada por Wald com Newey-West por blocos nesses dois termos.
#
#   O que sai:
#   1. Linear x spline na mesma amostra do modelo E: N, R² ajustado,
#      BIC, Wald-HAC da não linearidade, Breusch-Godfrey e RESET-HAC.
#   2. A mesma comparação sem os três primeiros pregões pós-1º turno
#      e sem cada um deles (o resultado depende de um evento?).
#   3. Resposta prevista a mudanças de ΔP em relação a ΔP = 0, com
#      intervalo nominal de 95%. Os controles entram de forma
#      aditiva, então a resposta a ΔP não depende do valor em que
#      eles são fixados. Só são reportadas mudanças dentro da região
#      com suporte: aquelas para as quais há pelo menos
#      `min_obs_suporte` pregões com ΔP igual ou mais extremo, do
#      mesmo lado. Nada é extrapolado além do maior choque observado.
#   4. Gráfico por ativo: curva do spline e reta do modelo E, com a
#      distribuição dos ΔP observados.
#
#   Leitura: com o spline não existe um β único; a resposta marginal
#   depende do tamanho de ΔP. O objetivo não é obter um RESET não
#   significativo, e sim ver se há uma não linearidade que seja
#   interpretável e estável. Um Wald significativo que desaparece
#   sem um único pregão não é evidência de não linearidade geral.
#
# Entrada : data/processed/model_data_daily.rds
# Saída   : output/10c_saida/nao_linear_comparacao.csv
#           output/10c_saida/nao_linear_respostas.csv
#           output/10c_saida/nao_linear_suporte.csv
#           output/10c_saida/nao_linear_nao_estimados.csv
#           output/10c_saida/nao_linear_{ativo}.png
#
# Próximo script: 10d_lula_haddad.R
# ============================================================

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

saida_dir <- saida("10c")

model_data <- load_object(model_data_file)
aviso_simulado(model_data)

respostas_disp <- names(respostas)[purrr::map_lgl(names(respostas), ~ sum(is.finite(model_data[[.x]])) > 50)]
gl_spline <- 3
mudancas_pp <- c(-10, -5, -2, -1, 1, 2, 5, 10)   # mudanças de ΔP (p.p.) a reportar, se tiverem suporte
min_obs_suporte <- 10                            # pregões com ΔP igual ou mais extremo, do mesmo lado

# Limites da região com suporte: o min_obs_suporte-ésimo menor e o
# min_obs_suporte-ésimo maior ΔP da amostra
limites_suporte <- function(x) {
  o <- sort(x); n <- length(o); k <- min(min_obs_suporte, n)
  c(o[k], o[n - k + 1])
}

# Mesma amostra do modelo E (06)
amostra_e <- function(y) {
  model_data |>
    add_lags(c(y, "dp_pt"), 1) |>
    tidyr::drop_na(dplyr::all_of(c(y, "dp_pt", paste0(y, "_l1"), "dp_pt_l1", controles)))
}

# ------------------------------------------------------------
# 1. Base do spline: reta + termos não lineares
# ------------------------------------------------------------
# Devolve uma função que, para um vetor de ΔP, calcula nl1 e nl2 com
# os nós e a rotação definidos na amostra de estimação.

base_nao_linear <- function(x) {
  B <- splines::ns(x, df = gl_spline)
  L <- cbind(1, x)
  proj <- solve(crossprod(L), crossprod(L, B))        # parte linear de cada coluna da base
  R <- B - L %*% proj
  sv <- svd(R)
  k <- gl_spline - 1
  if (sv$d[k] < 1e-8 * sv$d[1]) stop("base do spline sem ", k, " termos não lineares independentes")
  rot <- sv$v[, seq_len(k), drop = FALSE]
  escala <- apply(R %*% rot, 2, stats::sd)
  f <- function(xn) {
    Bn <- stats::predict(B, xn)
    Z <- sweep((Bn - cbind(1, xn) %*% proj) %*% rot, 2, escala, "/")
    colnames(Z) <- paste0("nl", seq_len(k)); Z
  }
  attr(f, "nos") <- c(attr(B, "Boundary.knots")[1], attr(B, "knots"), attr(B, "Boundary.knots")[2])
  f
}

termos_nl <- paste0("nl", seq_len(gl_spline - 1))
formula_linear <- function(y) stats::reformulate(c("dp_pt", controles, "factor(ciclo)"), y)
formula_spline <- function(y) stats::reformulate(c("dp_pt", termos_nl, controles, "factor(ciclo)"), y)

# ------------------------------------------------------------
# 2. Estimação em uma amostra
# ------------------------------------------------------------

estimar <- function(y, d, rotulo) {
  base <- tryCatch(base_nao_linear(d$dp_pt), error = function(e) conditionMessage(e))
  if (is.character(base)) return(list(ok = FALSE, motivo = base, y = y, amostra = rotulo, n = nrow(d)))
  d <- dplyr::bind_cols(d, tibble::as_tibble(base(d$dp_pt)))
  X <- stats::model.matrix(formula_spline(y), d)
  if (qr(X)$rank < ncol(X))
    return(list(ok = FALSE, motivo = "matriz de regressores sem posto completo", y = y, amostra = rotulo, n = nrow(d)))
  m_lin <- lm(formula_linear(y), data = d)
  m_spl <- lm(formula_spline(y), data = d)
  # O ajuste tem de ser o do ns(ΔP, 3) original
  m_ns <- lm(stats::update(formula_linear(y), . ~ . - dp_pt + splines::ns(dp_pt, df = gl_spline)), data = d)
  stopifnot(isTRUE(all.equal(unname(fitted(m_spl)), unname(fitted(m_ns)), tolerance = 1e-6)))
  list(ok = TRUE, y = y, amostra = rotulo, d = d, base = base, linear = m_lin, spline = m_spl, V = vcov_nw(m_spl))
}

resumir <- function(r) {
  if (!r$ok) return(NULL)
  w <- wald_nw(r$spline, termos_nl)
  linha <- function(m, nome) {
    bg <- purrr::map_dfr(c(1, 5), ~ bg_ciclo(m, as.character(r$d$ciclo), .x))
    rs <- reset_um(m, r$d)
    tibble::tibble(y = r$y, amostra = r$amostra, modelo = nome, n = nobs(m),
                   adj_r2 = summary(m)$adj.r.squared, bic = BIC(m),
                   p_bg_ordem1 = bg$p_value[1], p_bg_ordem5 = bg$p_value[2], p_reset_hac = rs$p_reset_hac)
  }
  b <- tidy_nw(r$linear) |> dplyr::filter(term == "dp_pt")
  dplyr::bind_rows(
    linha(r$linear, "linear (modelo E)") |>
      dplyr::mutate(beta_linear = b$estimate, ep_beta_linear = b$std.error),
    linha(r$spline, "spline natural, 3 gl") |>
      dplyr::mutate(wald_nao_linear_F = w$F, p_wald_nao_linear = w$p_value, nw_lag = nw_lag_usado(r$V))
  )
}

# Resposta prevista a uma mudança de ΔP, em relação a ΔP = 0:
# f(x) - f(0), com erro-padrão pela matriz Newey-West
resposta <- function(r, x) {
  b <- coef(r$spline)[c("dp_pt", termos_nl)]
  V <- r$V[c("dp_pt", termos_nl), c("dp_pt", termos_nl)]
  G <- cbind(x, r$base(x)) - matrix(c(0, r$base(0)), nrow = length(x), ncol = length(b), byrow = TRUE)
  tc <- ic_t(r$spline)
  est <- as.numeric(G %*% b); ep <- sqrt(rowSums((G %*% V) * G))
  tibble::tibble(dp = x, resposta_spline = est, ep = ep, ic_inf = est - tc * ep, ic_sup = est + tc * ep,
                 resposta_linear = unname(coef(r$linear)["dp_pt"]) * x)
}

# ------------------------------------------------------------
# 3. Rodar: amostra completa, sem os pós-1º turno e sem cada um
# ------------------------------------------------------------

resultados <- list(); nao_estimados <- list()
for (y in respostas_disp) {
  d <- amostra_e(y)
  ev <- d |> dplyr::filter(pos_1t == 1) |> dplyr::select(ciclo, data)
  cenarios <- c(list(`amostra completa` = rep(FALSE, nrow(d))),
                if (nrow(ev) > 1) list(`sem os pós-1º turno` = d$pos_1t == 1),
                purrr::map(seq_len(nrow(ev)), ~ d$ciclo == ev$ciclo[.x] & d$data == ev$data[.x]) |>
                  setNames(paste0("sem o pós-1º turno de ", ev$ciclo)))
  for (cn in names(cenarios)) {
    r <- estimar(y, d[!cenarios[[cn]], ], cn)
    if (r$ok) resultados[[paste(y, cn, sep = "__")]] <- r else
      nao_estimados[[paste(y, cn)]] <- tibble::tibble(y = y, amostra = cn, n = r$n, motivo = r$motivo)
  }
}

nao_estimados <- dplyr::bind_rows(nao_estimados)
if (!nrow(nao_estimados)) nao_estimados <- tibble::tibble(y = character(0), amostra = character(0),
                                                          n = integer(0), motivo = character(0))
export_table(nao_estimados, file.path(saida_dir, "nao_linear_nao_estimados.csv"))

comparacao <- purrr::map_dfr(resultados, resumir)
export_table(comparacao |> format_table(4), file.path(saida_dir, "nao_linear_comparacao.csv"))

# ------------------------------------------------------------
# 4. Suporte amostral e respostas previstas
# ------------------------------------------------------------

suporte <- purrr::map_dfr(resultados, function(r) {
  x <- r$d$dp_pt
  tibble::tibble(y = r$y, amostra = r$amostra, n = length(x),
                 dp_min = min(x), suporte_inf = limites_suporte(x)[1], dp_p25 = unname(stats::quantile(x, 0.25)),
                 dp_mediana = stats::median(x), dp_p75 = unname(stats::quantile(x, 0.75)),
                 suporte_sup = limites_suporte(x)[2], dp_max = max(x),
                 n_abs_maior_2 = sum(abs(x) > 2), n_abs_maior_5 = sum(abs(x) > 5), n_abs_maior_10 = sum(abs(x) > 10),
                 nos_do_spline = paste(formatC(attr(r$base, "nos"), format = "f", digits = 2), collapse = "; "))
})
export_table(suporte |> format_table(3), file.path(saida_dir, "nao_linear_suporte.csv"))

respostas_tab <- purrr::map_dfr(resultados, function(r) {
  x <- r$d$dp_pt
  lim <- limites_suporte(x)
  resposta(r, mudancas_pp) |>
    dplyr::mutate(y = r$y, amostra = r$amostra, .before = 1) |>
    dplyr::mutate(
      n_obs_ate_essa_mudanca = purrr::map_int(dp, ~ if (.x > 0) sum(x >= .x) else sum(x <= .x)),
      regiao = dplyr::case_when(dp < min(x) | dp > max(x) ~ "fora do intervalo observado: não reportado",
                                dp < lim[1] | dp > lim[2] ~ paste0("pouco suporte (menos de ", min_obs_suporte,
                                                                   " pregões tão extremos): não reportado"),
                                TRUE ~ "com suporte"),
      dplyr::across(c(resposta_spline, ep, ic_inf, ic_sup), ~ dplyr::if_else(regiao == "com suporte", .x, NA_real_)),
      diferenca_spline_menos_linear = resposta_spline - resposta_linear)
})
export_table(respostas_tab |> format_table(4), file.path(saida_dir, "nao_linear_respostas.csv"))

# ------------------------------------------------------------
# 5. Gráficos: curva estimada e distribuição dos choques
# ------------------------------------------------------------

for (y in respostas_disp) {
  rs <- resultados[paste(y, c("amostra completa", "sem os pós-1º turno"), sep = "__")]
  rs <- rs[!purrr::map_lgl(rs, is.null)]
  if (!length(rs)) next
  curvas <- purrr::map_dfr(rs, function(r) {
    x <- r$d$dp_pt
    resposta(r, seq(min(x), max(x), length.out = 200)) |>
      dplyr::mutate(amostra = r$amostra,
                    suporte = dp >= limites_suporte(x)[1] & dp <= limites_suporte(x)[2])
  })
  obs <- rs[[1]]$d
  lim <- limites_suporte(obs$dp_pt)
  g_curva <- ggplot2::ggplot(curvas, ggplot2::aes(dp, resposta_spline, colour = amostra, fill = amostra)) +
    ggplot2::annotate("rect", xmin = lim[1], xmax = lim[2], ymin = -Inf, ymax = Inf, fill = "grey92") +
    ggplot2::geom_hline(yintercept = 0, colour = "grey50") +
    ggplot2::geom_ribbon(ggplot2::aes(ymin = ic_inf, ymax = ic_sup), alpha = 0.15, colour = NA) +
    ggplot2::geom_line(linewidth = 0.6) +
    ggplot2::geom_line(data = dplyr::filter(curvas, amostra == "amostra completa"),
                       ggplot2::aes(y = resposta_linear), colour = "black", linetype = 2, linewidth = 0.4) +
    ggplot2::scale_colour_manual(values = c(`amostra completa` = "steelblue4", `sem os pós-1º turno` = "darkorange3"), name = NULL) +
    ggplot2::scale_fill_manual(values = c(`amostra completa` = "steelblue4", `sem os pós-1º turno` = "darkorange3"), name = NULL) +
    ggplot2::labs(x = NULL, y = paste0("resposta em relação a ΔP = 0\n", respostas[[y]]),
                  title = paste0("Resposta estimada a ΔP(PT): spline natural (3 gl) e reta do modelo E - ", respostas[[y]]),
                  subtitle = paste0("Faixa cinza: região com suporte (pelo menos ", min_obs_suporte,
                                    " pregões com ΔP igual ou mais extremo). Tracejado: modelo E linear.\n",
                                    "Intervalos nominais de 95% (Newey-West). Fora da faixa cinza a curva depende de poucos pregões.")) +
    ggplot2::theme_minimal(base_size = 9) + ggplot2::theme(legend.position = "top")
  g_dist <- ggplot2::ggplot(obs, ggplot2::aes(dp_pt)) +
    ggplot2::geom_histogram(bins = 80, fill = "grey45") +
    ggplot2::geom_rug(data = dplyr::filter(obs, pos_1t == 1), colour = "firebrick", linewidth = 0.8, length = grid::unit(0.25, "npc")) +
    ggplot2::scale_y_continuous(trans = "log1p", breaks = c(0, 1, 5, 20, 100, 400)) +
    ggplot2::coord_cartesian(xlim = range(curvas$dp)) +
    ggplot2::labs(x = "ΔP(PT) no pregão (p.p.)", y = "pregões (escala log)",
                  caption = "Distribuição dos ΔP observados. Traços vermelhos: pregões seguintes ao 1º turno.") +
    ggplot2::theme_minimal(base_size = 9)
  g <- patchwork::wrap_plots(g_curva, g_dist, ncol = 1, heights = c(3, 1))
  save_plot(g, file.path(saida_dir, paste0("nao_linear_", y, ".png")), width = 9, height = 7)
}

cat("\n========== LINEAR x SPLINE (amostra completa e sem os pós-1º turno) ==========\n")
print(comparacao |> dplyr::filter(amostra %in% c("amostra completa", "sem os pós-1º turno")) |>
        dplyr::select(y, amostra, modelo, n, adj_r2, bic, p_wald_nao_linear, p_bg_ordem1, p_bg_ordem5, p_reset_hac) |>
        format_table(3), n = Inf, width = Inf)
cat("\n========== WALD-HAC DA NÃO LINEARIDADE, por amostra (estabilidade) ==========\n")
print(comparacao |> dplyr::filter(modelo != "linear (modelo E)") |>
        dplyr::select(y, amostra, n, p_wald_nao_linear) |>
        tidyr::pivot_wider(names_from = amostra, values_from = c(n, p_wald_nao_linear)) |> format_table(3), width = Inf)
cat("\n========== RESPOSTAS PREVISTAS (amostra completa; só mudanças com suporte) ==========\n")
print(respostas_tab |> dplyr::filter(amostra == "amostra completa") |>
        dplyr::select(y, dp, resposta_linear, resposta_spline, ic_inf, ic_sup, n_obs_ate_essa_mudanca, regiao) |>
        format_table(3), n = Inf, width = Inf)
if (nrow(nao_estimados)) { cat("\nNão estimados:\n"); print(nao_estimados, width = Inf) }
message("10c_nao_linearidade.R concluído com sucesso.")
