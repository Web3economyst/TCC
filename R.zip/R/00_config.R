# ============================================================
# Script  : 00_config.R
#
# Objetivo:
#   Concentrar TODAS as escolhas do projeto num lugar só:
#   ciclos eleitorais, janelas, candidatos, ativos e parâmetros
#   dos modelos. Qualquer decisão metodológica que mude
#   resultado deve estar aqui, e não espalhada pelos scripts.
# ============================================================

# ------------------------------------------------------------
# 1. Ciclos eleitorais
# ------------------------------------------------------------
#
# Variável eleitoral principal: P(PT) = probabilidade, no mercado
# de previsão, de o candidato do PT vencer a eleição presidencial.
# É o mesmo conceito nos três ciclos (Haddad em 2018, Lula em 2022 e
# 2026), o que permite empilhar os ciclos e dá uma interpretação
# econômica única ao coeficiente.
#
# prob_norm já vem normalizada (soma 1 entre todos os candidatos)
# nos arquivos diários do TCC. Em 2018, cand_pt = "lula;haddad" quer
# dizer: em cada dia vale o ÚLTIMO nome da lista que tem preço (02,
# montar_prob). Na janela principal (desde 11/09/2018) isso é sempre
# Haddad, como nas pesquisas; o contrato de Lula, com a candidatura
# já indeferida, não entra. Lula só aparece na robustez R12 (desde
# 16/08/2018), antes de o contrato de Haddad existir (10/09/2018).
#
# inicio: primeiro dia da janela principal, com mercado de previsão
#         líquido.
#   2018: 11/09/2018, oficialização de Fernando Haddad como candidato
#         do PT. Antes disso, a Betfair só listava o contrato de Lula
#         (candidatura indeferida pelo TSE em 31/08/2018); o de Haddad
#         só passou a ser negociado em 10/09/2018. Até lá, P(PT) mediria
#         a chance de Lula, e não a do partido, e a entrada do contrato
#         de Haddad criaria um salto artificial na série. Começar em
#         11/09 garante que o pregão anterior (10/09) já tem os dois
#         contratos.
#   2022: 11/03/2021, três dias depois de o STF devolver os
#         direitos políticos de Lula (08/03/2021).
#   2026: início da série Polymarket (18/09/2025).
# fim: primeiro dia útil da B3 depois do 2º turno (dia em que o
#      mercado financeiro reage ao resultado).
# inicio_completo: início da janela usada só na robustez R12
#      (em 2018, 16/08/2018, início oficial da campanha, com P(PT)
#      medida só pelo contrato de Lula até 09/09; nos demais ciclos,
#      igual a inicio). Entre maio e meados de agosto a Betfair quase
#      não teve negociação (volume zero na maioria dos dias).
# arquivo_corte: arquivo diário com o preço do mercado de previsão no
#      horário de fechamento da B3 (mesmo formato do arquivo diário:
#      nome_clean, data_brt, prob_norm). Em 2018 e 2022 ele é gerado
#      pelos scripts de extração da Betfair com o corte no horário da
#      B3; se não existir, usa-se o fechamento do dia (23h59) e o
#      pipeline avisa. Em 2026 o corte é feito aqui mesmo, a partir da
#      série horária da Polymarket (NA = gerar a partir da série horária).

ciclos <- tibble::tribble(
  ~ciclo, ~arquivo,                  ~cand_pt,        ~cand_rival,  ~pt_venceu, ~data_1t,     ~data_2t,     ~inicio,      ~fim,         ~inicio_completo, ~arquivo_corte,
  2018,   "betfair_2018_diario.csv", "lula;haddad",   "bolsonaro",  0,          "2018-10-07", "2018-10-28", "2018-09-11", "2018-10-29", "2018-08-16",     "betfair_2018_diario_fechamento_b3.csv",
  2022,   "betfair_2022_diario.csv", "lula",          "bolsonaro",  1,          "2022-10-02", "2022-10-30", "2021-03-11", "2022-10-31", "2021-03-11",     "betfair_2022_diario_fechamento_b3.csv",
  2026,   "mercado_2026_diario.csv", "lula",          "flavio",     1,          "2026-10-04", "2026-10-25", "2025-09-18", "2026-10-26", "2025-09-18",     NA
) |>
  dplyr::mutate(dplyr::across(c(data_1t, data_2t, inicio, fim, inicio_completo), as.Date))

# Painel do script 08 (probabilidade das pesquisas, p_pesq).
# Opcional: se o arquivo não existir, as análises com pesquisas
# são puladas.
arquivo_painel_pesquisas <- "painel_diario.csv"

# ------------------------------------------------------------
# 1b. Horário de referência
# ------------------------------------------------------------
#
# Todas as séries são medidas no fechamento da B3, no fim da tarde:
#   - Ibovespa: fechamento do pregão regular de ações;
#   - S&P 500, VIX e Treasury: fechamento de Nova York, que cai no
#     mesmo horário (a B3 acompanha o horário de NY);
#   - DI e dólar: taxas e preços de ajuste da B3, apurados no fim do
#     pregão de derivativos (um pouco antes do fechamento de ações);
#   - mercado de previsão: último preço até o horário de fechamento da
#     B3 do mesmo dia (horario_probabilidade = "fechamento_b3").
#
# Horário de fechamento do pregão regular de ações (Brasília): 17h
# quando os EUA estão no horário de verão e 18h fora dele (a B3 ajusta
# o horário ao de Nova York). "auto" aplica essa regra a cada data;
# um número (ex.: 17) fixa o horário.
hora_corte_b3 <- "auto"

# "fechamento_b3": probabilidade no horário de fechamento da B3
#                  (principal; em 2018 e 2022 depende dos arquivos
#                  arquivo_corte, ver acima).
# "fim_do_dia"   : último preço do dia (23h59), como nos arquivos
#                  diários originais (robustez R7).
horario_probabilidade <- "fechamento_b3"

# Se horario_probabilidade = "fechamento_b3" e algum ciclo não tiver
# o arquivo no horário da B3, o 02_cleaning.R PARA com erro: a
# probabilidade das 23h59 é posterior ao fechamento do preço que o
# modelo explica e não substitui a do horário da B3. Para rodar
# mesmo assim, misturando os dois horários de propósito, mude para
# TRUE (o 02 avisa quais ciclos ficaram com 23h59, a coluna
# horario_p registra, e defasagem_reacao = "auto" passa a tratar
# t e t-1 como reação).
permitir_horario_misto <- FALSE

# Validação crítica (03b_validacao_critica.R): o pipeline para se
# algum ciclo tiver menos pregões completos do que min_obs_ciclo em
# alguma regressão, ou se a cobertura de uma série dentro do ciclo
# (pregões com valor / pregões da janela) ficar abaixo de
# cobertura_minima.
min_obs_ciclo    <- 30
cobertura_minima <- 0.80

# Tolerância (minutos) para a série horária da Polymarket: o registro
# das 17h é gravado alguns segundos depois das 17:00:00.
tolerancia_horaria_min <- 5

# Série horária e lista de mercados da Polymarket (2026)
arquivo_polymarket_horario  <- "polymarket_serie_horaria.csv"
arquivo_polymarket_mercados <- "polymarket_mercados.csv"
# Padrões (regex, sem acento para não depender do encoding do sistema)
padroes_polymarket_h2h <- c(pt = "Lula da Silva", rival = "^Fl.+vio Bolsonaro")

# ------------------------------------------------------------
# 2. Mercado financeiro
# ------------------------------------------------------------
#
# Yahoo Finance (via quantmod). Fechamento diário.
#   ibov  : Ibovespa (pontos)
#   usdbrl: dólar em reais (R$/US$) — alta = real se desvalorizando
#   spx   : S&P 500 (controle externo de ações)
#   ust10 : Treasury de 10 anos (% a.a.; ^TNX) — controle de juros EUA
#   vix   : VIX (controle de aversão global a risco)

tickers_yahoo <- c(
  ibov   = "^BVSP",
  usdbrl = "BRL=X",
  spx    = "^GSPC",
  ust10  = "^TNX",
  vix    = "^VIX"
)

# DI: curva PRE da B3 (taxas referenciais construídas a partir dos
# contratos futuros de DI1), baixada com o pacote rb3.
# Vértices em dias úteis: 252 = 1 ano ("DI curto"), 1260 = 5 anos
# ("DI longo").
vertices_di <- c(di1 = 252, di5 = 1260)

# PTAX (BCB/SGS, série 1 — dólar venda, diário): robustez para o
# câmbio. A PTAX é fixada entre 10h e 13h, não no fechamento.
sgs_ptax <- 1

# Dólar no fechamento: preço de ajuste do dólar futuro da B3 (arquivo
# de preços de mercado BVBG-086; ver 01_import.R, bloco C3). É o preço
# apurado no fim do pregão de derivativos, junto com o DI.

# Fonte do dólar no modelo principal.
#   "b3"   : dólar da B3 no fechamento (principal; mesmo horário do DI).
#   "ptax" : PTAX do BCB (fixada entre 10h e 13h; robustez R9).
#   "yahoo": BRL=X do Yahoo. No teste com os dados reais, faltaram ~14%
#            dos pregões, inclusive TODOS os pós-eleição.
fonte_dolar <- "b3"

# Margem de dias antes do início de cada ciclo para baixar dados
# (necessário para calcular variações e defasagens no 1º dia).
margem_download_dias <- 30

# ------------------------------------------------------------
# 3. Modelos
# ------------------------------------------------------------

# Juros futuros (DI de 1 e 5 anos) como variáveis dependentes.
#   FALSE (padrão, como no texto): os modelos, diagnósticos e tabelas
#         rodam só para o Ibovespa e o dólar.
#   TRUE : o DI volta como exercício complementar, em todos os
#          scripts que estimam modelos. Não muda nenhum resultado do
#          Ibovespa e do dólar (cada ativo é estimado separadamente).
# O DI continua sendo lido e montado na base (01 a 03) nos dois casos.
INCLUIR_DI <- FALSE

# Variáveis dependentes (respostas do mercado financeiro)
respostas <- c(
  r_ibov = "Ibovespa (retorno, %)",
  r_usd  = "Dólar (variação, %)"
)
if (INCLUIR_DI) respostas <- c(respostas,
  d_di1  = "DI 1 ano (variação, p.b.)",
  d_di5  = "DI 5 anos (variação, p.b.)"
)

# Controles externos (contemporâneos)
controles <- c("r_spx", "d_ust10", "r_vix")

# Controles adicionais (descritiva do 04c; candidatos à robustez R15).
# Não entram nos modelos principais.
#   dxy  : índice do dólar contra seis moedas desenvolvidas (ICE)
#   brent: petróleo Brent, contrato futuro mais próximo (ICE)
tickers_extras <- c(dxy = "DX-Y.NYB", brent = "BZ=F")
sgs_selic_meta <- 432   # Selic meta (% a.a.), BCB/SGS

# Dias de decisão de juros (data do anúncio).
#   Copom: anúncio por volta das 18h30, depois do fechamento da B3;
#          o efeito aparece no pregão SEGUINTE.
#   Fomc : anúncio às 14h de Nova York, antes do fechamento da B3;
#          o efeito aparece no MESMO pregão.
datas_copom <- as.Date(c(
  "2018-09-19", "2018-10-31",
  "2021-03-17", "2021-05-05", "2021-06-16", "2021-08-04", "2021-09-22", "2021-10-27", "2021-12-08",
  "2022-02-02", "2022-03-16", "2022-05-04", "2022-06-15", "2022-08-03", "2022-09-21", "2022-10-26",
  "2025-09-17", "2025-11-05", "2025-12-10",
  "2026-01-28", "2026-03-18", "2026-04-29", "2026-06-17", "2026-08-05", "2026-09-16", "2026-11-04"
))
datas_fomc <- as.Date(c(
  "2018-09-26",
  "2021-03-17", "2021-04-28", "2021-06-16", "2021-07-28", "2021-09-22", "2021-11-03", "2021-12-15",
  "2022-01-26", "2022-03-16", "2022-05-04", "2022-06-15", "2022-07-27", "2022-09-21",
  "2025-09-17", "2025-10-29", "2025-12-10",
  "2026-01-28", "2026-03-18", "2026-04-29", "2026-06-17", "2026-07-29", "2026-09-16"
))

# Pregão seguinte ao 2º turno. Nesse dia o mercado de previsão já foi
# liquidado e P(PT) seria o RESULTADO (1 se o PT venceu, 0 se perdeu),
# e não uma probabilidade: a variação mediria a resolução da incerteza,
# e não uma mudança de expectativa.
#   FALSE: P(PT) fica NA nesse pregão e o dia sai dos modelos (principal).
#          O resultado fica guardado em p_pt_res / dp_pt_res, usados só na
#          tabela das noites eleitorais e na robustez R14.
#   TRUE : P(PT) = resultado nesse pregão (especificação antiga).
incluir_resultado_2t <- FALSE

# Defasagens máximas na seleção do ARDL (dias úteis)
max_lag_y  <- 5
max_lag_dp <- 5
# Mínimo de defasagens da variável explicativa. Com 0, o BIC escolhe q
# livremente entre 0 e 5: se escolher q = 0, a probabilidade dos dias
# anteriores não acrescenta informação para prever o preço (não há
# antecedência), e o bloco de antecedência fica vazio (NA nas tabelas).
min_lag_dp <- 0

# O ARDL tem UMA variável endógena e só usa valores contemporâneos e
# passados dos regressores: não há leads. A pergunta "o mercado se
# mexe antes?" (retroalimentação) é respondida (i) pelo ARDL no
# sentido inverso (ΔP(PT) como dependente e o ativo como regressor) e
# (ii) pelo VAR (script 11), em que todas as variáveis são endógenas.
n_leads <- 0

# Estudo de evento das pesquisas (script 12)
# Data do evento = primeiro pregão em ou depois de (fim do campo + defasagem).
defasagem_divulgacao      <- 1          # principal
defasagens_divulgacao_rob <- c(0, 2)    # robustez
janela_antes  <- 3                       # pregões antes do evento
janela_depois <- 2                       # pregões depois do evento

# VAR (script 11)
var_max_lag  <- 5
var_n_ahead  <- 10                       # horizonte da impulso-resposta (pregões)
var_boot     <- 2000                     # réplicas bootstrap dos intervalos

# Bloco de "reação" do ARDL: até que defasagem de ΔP conta como reação.
#   0      : só o mesmo dia (t). É o certo quando a probabilidade é medida
#            no fechamento da B3, no mesmo horário dos preços.
#   1      : t e t-1. É o certo quando a probabilidade é do fim do dia
#            (23h59): a notícia da noite só chega ao preço no dia seguinte.
#   "auto" : 0 se todos os ciclos têm a probabilidade no fechamento da
#            B3; 1 se algum ciclo ficou com o fim do dia.
# A antecedência são as defasagens seguintes (t-1 em diante, se 0;
# t-2 em diante, se 1).
defasagem_reacao <- "auto"

# Defasagens máximas na correlação cruzada e no Granger
max_lag_ccf     <- 10
lags_granger    <- 1:5

# Newey-West: NULL = escolha automática do pacote sandwich
nw_lag <- NULL

# Janela "campanha": últimos N dias úteis antes do 1º turno + entre turnos
dias_campanha <- 120
