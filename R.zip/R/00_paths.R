# ============================================================
# Projeto : Eleições, mercados de previsão e mercado financeiro
#           (TCC — Gabriel, Economia/UFRGS)
#
# Script  : 00_paths.R
#
# Objetivo:
#   Definir todos os diretórios e arquivos utilizados no projeto.
#   Dados em data/raw e data/processed; saídas em output/, com uma
#   pasta por script (output/02_saida, output/03_saida, ...).
#
# Dependências:
#   Pacote here (a raiz do projeto é a pasta que contém o
#   arquivo vazio ".here").
# ============================================================

root <- here::here()

# ------------------------------------------------------------
# Dados
# ------------------------------------------------------------

raw_dir           <- file.path(root, "data", "raw")
electoral_raw_dir <- file.path(raw_dir, "eleitoral")      # CSVs Betfair/Polymarket e painel do script 08
processed_dir     <- file.path(root, "data", "processed")

# Se os CSVs eleitorais não estiverem em data/raw/eleitoral, procura
# na própria raiz do projeto e na pasta acima dela (ex.: pasta_dados).
if (!file.exists(file.path(electoral_raw_dir, "betfair_2018_diario.csv"))) {
  for (alt in c(file.path(root, "pasta_dados"), root, dirname(root), file.path(dirname(root), "pasta_dados"))) {
    if (file.exists(file.path(alt, "betfair_2018_diario.csv"))) {
      message("CSVs eleitorais encontrados em: ", alt)
      electoral_raw_dir <- alt
      break
    }
  }
}

# ------------------------------------------------------------
# Saídas
# ------------------------------------------------------------

output_dir <- file.path(root, "output")

# Cada script grava as suas saídas (tabelas, figuras e objetos) na
# sua própria pasta: output/02_saida, output/03_saida, ...
# saida("06") devolve o caminho de output/06_saida e cria a pasta.
# Um script que lê o resultado de outro usa a pasta de quem gerou:
# por exemplo, o 07 lê os modelos em saida("06").
saida <- function(script) {
  d <- file.path(output_dir, paste0(script, "_saida"))
  dir.create(d, recursive = TRUE, showWarnings = FALSE)
  d
}

log_dir <- file.path(root, "logs")

# ------------------------------------------------------------
# Arquivos
# ------------------------------------------------------------

# Brutos (gerados pelo 01_import.R)
yahoo_raw_file  <- file.path(raw_dir, "financeiro_yahoo.rds")
di_raw_file     <- file.path(raw_dir, "di_b3_curva_pre.rds")
ptax_raw_file   <- file.path(raw_dir, "ptax_bcb.rds")
dolar_raw_file  <- file.path(raw_dir, "dolar_b3.rds")
electoral_raw_file <- file.path(processed_dir, "raw_eleitoral.rds")

# Processados
clean_data_file <- file.path(processed_dir, "clean_data.rds")
model_data_file <- file.path(processed_dir, "model_data_daily.rds")
model_data_full_file <- file.path(processed_dir, "model_data_daily_janela_completa.rds")  # robustez R12
extras_daily_file <- file.path(processed_dir, "controles_extras_daily.rds")         # 04c -> robustez R15

# ------------------------------------------------------------
# Criar diretórios caso não existam
# ------------------------------------------------------------

dirs <- c(raw_dir, electoral_raw_dir, processed_dir, output_dir, log_dir)

invisible(lapply(dirs, dir.create, recursive = TRUE, showWarnings = FALSE))
