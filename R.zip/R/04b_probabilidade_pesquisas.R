# ============================================================
# Script  : 04b_probabilidade_pesquisas.R
#
# Objetivo:
#   Conferir a probabilidade de vitória do PT implícita nas pesquisas
#   (p_pesq, agregador local linear do script 08 do TCC), como ela
#   entra na base (deslocada defasagem_divulgacao dias; NA depois do
#   2º turno).
#
#   1. Resumo por ciclo: pregões com valor, primeiro e último, dias sem
#      mudança, intervalo típico entre mudanças, saltos grandes.
#   2. Saltos grandes (|ΔP pesquisas| >= limite_salto_pp): em cada um,
#      quais pesquisas entraram desde o pregão anterior (fim do campo +
#      defasagem no intervalo) e quanto mudou a margem do agregador.
#   3. Gráfico: probabilidade das pesquisas x mercado de previsão, com
#      as datas de entrada das pesquisas.
#
#   Lista de pesquisas: eventos_pesquisas.csv (script 08 do TCC). Esse
#   arquivo não traz as pesquisas dos últimos 7 dias do ciclo nem as
#   cujas janelas cruzam o 1º turno; um salto sem pesquisa listada
#   pode vir de uma dessas.
#
# Entrada : data/processed/model_data_daily.rds, eventos_pesquisas.csv
# Saída   : output/04b_saida/pesquisas_resumo.csv
#           output/04b_saida/pesquisas_saltos.csv
#           output/04b_saida/pesquisas_vs_mercado.png
#
# Próximo script: 05_stationarity.R
# ============================================================

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

saida_dir <- saida("04b")

model_data <- load_object(model_data_file)
aviso_simulado(model_data)

limite_salto_pp <- 10   # salto grande: 10 p.p. ou mais em um pregão

if (!"p_pesq" %in% names(model_data) || sum(is.finite(model_data$p_pesq)) == 0) {
  message("Sem probabilidade das pesquisas na base; 04b pulado.")
} else {

  md <- model_data |>
    dplyr::arrange(ciclo, data) |>
    dplyr::group_by(ciclo) |>
    dplyr::mutate(data_ant = dplyr::lag(data)) |>
    dplyr::ungroup()

  # ----------------------------------------------------------
  # 1. Resumo por ciclo
  # ----------------------------------------------------------
  resumo <- md |>
    dplyr::filter(is.finite(p_pesq)) |>
    dplyr::group_by(ciclo) |>
    dplyr::summarise(
      pregoes_ciclo = NA_integer_,
      pregoes_com_valor = dplyr::n(),
      primeiro = min(data), ultimo = max(data),
      dias_sem_mudanca = sum(is.finite(dp_pesq) & abs(dp_pesq) < 1e-8),
      pct_sem_mudanca = 100 * mean(is.finite(dp_pesq) & abs(dp_pesq) < 1e-8),
      mudancas = sum(is.finite(dp_pesq) & abs(dp_pesq) >= 1e-8),
      dp_variacao_pp = sd(dp_pesq, na.rm = TRUE),
      saltos_grandes = sum(abs(dp_pesq) >= limite_salto_pp, na.rm = TRUE),
      maior_salto_pp = dp_pesq[which.max(abs(dp_pesq))],
      .groups = "drop"
    ) |>
    dplyr::mutate(pregoes_ciclo = as.integer(table(model_data$ciclo)[as.character(ciclo)]),
                  .after = ciclo)

  export_table(resumo |> format_table(), file.path(saida_dir, "pesquisas_resumo.csv"))

  # ----------------------------------------------------------
  # 2. Saltos grandes e pesquisas que os produziram
  # ----------------------------------------------------------
  candidatos <- unique(c(
    file.path(electoral_raw_dir, "eventos_pesquisas.csv"),
    file.path(root, "saida_mercados", "eventos_pesquisas.csv"),
    file.path(dirname(root), "saida_mercados", "eventos_pesquisas.csv"),
    file.path(root, "eventos_pesquisas.csv"),
    file.path(dirname(root), "eventos_pesquisas.csv")
  ))
  arq_eventos <- candidatos[file.exists(candidatos)][1]
  pesq <- if (!is.na(arq_eventos)) {
    readr::read_csv(arq_eventos, show_col_types = FALSE) |>
      dplyr::transmute(ciclo = ano, instituto, data_inicio = as.Date(data_inicio),
                       data_fim = as.Date(data_fim),
                       entra = data_fim + defasagem_divulgacao,   # data em que entra na série
                       margem_pp = 100 * margem, margem_agregador_antes_pp = 100 * margem_antes,
                       surpresa_pp)
  } else NULL

  saltos <- md |>
    dplyr::filter(is.finite(dp_pesq), abs(dp_pesq) >= limite_salto_pp) |>
    dplyr::transmute(ciclo, data, data_ant,
                     p_pesq_antes = p_pesq - dp_pesq / 100, p_pesq = p_pesq, dp_pesq,
                     dias_desde_pregao_anterior = as.integer(data - data_ant))

  if (!is.null(pesq) && nrow(saltos)) {
    saltos <- saltos |>
      dplyr::left_join(pesq, by = dplyr::join_by(ciclo, data_ant < entra, data >= entra)) |>
      dplyr::group_by(ciclo, data) |>
      dplyr::mutate(pesquisas_no_intervalo = sum(!is.na(instituto))) |>
      dplyr::ungroup()
  }

  export_table(saltos |> format_table(), file.path(saida_dir, "pesquisas_saltos.csv"))

  # ----------------------------------------------------------
  # 3. Gráfico: pesquisas x mercado de previsão
  # ----------------------------------------------------------
  serie <- md |>
    dplyr::select(ciclo, data, `Mercado de previsão` = p_pt, `Pesquisas (agregador)` = p_pesq) |>
    tidyr::pivot_longer(-c(ciclo, data), names_to = "fonte", values_to = "p") |>
    dplyr::filter(is.finite(p))

  g <- ggplot(serie, aes(data, 100 * p, colour = fonte)) +
    geom_line(linewidth = 0.5) +
    scale_colour_manual(values = c(`Mercado de previsão` = "steelblue4",
                                   `Pesquisas (agregador)` = "darkorange"), name = NULL) +
    facet_wrap(~ ciclo, scales = "free_x", nrow = 1) +
    scale_x_date(date_labels = "%d/%m/%y") +
    labs(x = NULL, y = "P(PT) (%)",
         title = "Probabilidade de vitória do PT: pesquisas x mercado de previsão",
         subtitle = paste0("Traços na base: datas em que as pesquisas entram na série (fim do campo + ",
                           defasagem_divulgacao, " dia). Pesquisas: só o confronto do 2º turno.")) +
    theme_minimal(base_size = 10) + theme(legend.position = "bottom", panel.grid.minor = element_blank())
  if (!is.null(pesq)) {
    janelas <- md |> dplyr::group_by(ciclo) |> dplyr::summarise(ini = min(data), fim = max(data))
    marcas <- pesq |>
      dplyr::inner_join(janelas, by = "ciclo") |>
      dplyr::filter(entra >= ini, entra <= fim)
    g <- g + geom_rug(data = marcas, aes(x = entra), inherit.aes = FALSE,
                      sides = "b", alpha = 0.5, colour = "grey30")
  }

  save_plot(g, file.path(saida_dir, "pesquisas_vs_mercado.png"), width = 11, height = 4.5)

  cat("\n========== PROBABILIDADE DAS PESQUISAS ==========\n")
  print(resumo)
  cat("\nSaltos de", limite_salto_pp, "p.p. ou mais e pesquisas que entraram desde o pregão anterior:\n")
  print(saltos, n = Inf, width = Inf)
}

message("04b_probabilidade_pesquisas.R concluído com sucesso.")
