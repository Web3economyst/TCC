# ============================================================
# Script  : 10_robustness.R
#
# Objetivo:
#   Verificar se as conclusões do ARDL probabilidade -> ativo (09)
#   se mantêm sob mudanças metodologicamente justificadas. Como no
#   MEFA, o objetivo não é procurar significância, e sim ver se a
#   resposta à pergunta (reação na hora / antecedência) muda.
#
#   R1  sem as noites eleitorais (e a janela de defasagens que as
#       contém): os dois maiores choques não dominam?
#   R2  com dummies dos pregões seguintes ao 1º e ao 2º turno
#   R3  probabilidade PT x principal rival (p_h2h) em vez de P(PT)
#   R4  só a fase de campanha (últimos `dias_campanha` pregões antes
#       do 1º turno + entre turnos)
#   R5  probabilidade das PESQUISAS em vez do mercado de previsão
#   R6  mercado de previsão + pesquisas juntos: as pesquisas trazem
#       informação para os preços além do que o mercado de previsão
#       já tem? (liga o resultado ao agregador do TCC)
#   R5b pesquisas medidas pela variação da MARGEM do agregador (p.p.
#       de votos válidos), sem a conversão em probabilidade. A
#       conversão não é linear: satura quando a margem é grande e
#       amplifica quando a disputa é apertada. Mesmo alinhamento
#       temporal de p_pesq (fim do campo + defasagem_divulgacao)
#   R5c pesquisas medidas pela SURPRESA (margem da pesquisa menos a
#       margem do agregador na véspera do fim do campo, em p.p.), só
#       nos pregões em que entra pesquisa; com mais de uma pesquisa no
#       pregão, usa a média. Só a resposta contemporânea (sem
#       defasagens da surpresa). As pesquisas vêm do
#       eventos_pesquisas.csv, que não traz as pesquisas cuja janela
#       cruza o 1º turno nem as dos 7 dias finais do painel
#   Na R5b e na R5c o coeficiente é por p.p. de margem, e não por p.p.
#   de probabilidade: não é comparável em magnitude ao da R0 e da R5
#   R7  probabilidade no fim do dia (23h59) em vez do fechamento da
#       B3, nos ciclos com as duas versões: com o preço da noite, parte
#       do efeito deve passar de t para t-1 (notícia da noite). Mesmos
#       pregões nas duas; reação = t na R7a e t e t-1 na R7b
#   R8  sem observações influentes (regra do MEFA)
#   R9  dólar pela PTAX (10h-13h) em vez do dólar da B3 no fechamento
#   R10 Newey-West com 10 defasagens fixas
#   R11 defasagens escolhidas por AIC em vez de BIC
#   R15 controles adicionais: DXY, Brent e dias de Copom/Fomc (do 04c)
#   R14 inclui o pregão seguinte ao 2º turno, com P(PT) = resultado
#   R13 q fixo em 3: teste explícito de antecedência (t-1 a t-3),
#       mesmo quando o BIC livre escolhe q = 0
#   R12 2018 desde o início oficial da campanha (16/08/2018), com
#       P(PT) medida só pelo contrato de Lula até 09/09 e sem a
#       variação de 10/09 (dia em que o contrato de Haddad entra)
#
# Entrada : data/processed/model_data_daily.rds, output/09_saida/ardl_main.rds
# Saída   : output/10_saida/robustness_summary.csv (+ detalhes)
#
# Próximo script: 10b_di1_dinamica.R
# ============================================================

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

saida_dir <- saida("10")

model_data <- load_object(model_data_file)
aviso_simulado(model_data)
base_ardl <- load_object(file.path(saida("09"), "ardl_main.rds"))$empilhado
defasagem_reacao_efetiva <- resolver_reacao(model_data)
options(tcc.defasagem_reacao = defasagem_reacao_efetiva)
rot_blocos <- rotulos_blocos(defasagem_reacao_efetiva)

tem_dados <- function(d, v, n = 60) v %in% names(d) && sum(is.finite(d[[v]])) >= n

# Resumo de um resultado em uma linha
resumir <- function(r, robustez) {
  if (is.null(r)) return(NULL)
  pf <- r$perfil
  pega <- function(b, col) pf[[col]][pf$chave == b]
  co <- r$coefs
  tibble::tibble(
    robustez = robustez, y = r$y, x = r$x, n = r$ajuste$n,
    nw_lag = r$ajuste$nw_lag %||% nw_lag_usado(vcov_nw(r$modelo)),
    p = r$p, q = r$q,
    theta_t   = co$estimate[co$j == 0],  p_t   = co$p.value[co$j == 0],
    theta_t1  = if (any(co$j == 1)) co$estimate[co$j == 1] else NA_real_,
    p_t1      = if (any(co$j == 1)) co$p.value[co$j == 1] else NA_real_,
    soma_hora = pega("reacao", "soma"),
    p_hora = pega("reacao", "p_soma"),
    soma_atraso2 = pega("antecedencia", "soma"),
    p_atraso2 = pega("antecedencia", "p_wald"),
    soma_total = pega("total", "soma"),
    p_total = pega("total", "p_soma"),
    lr = r$lr$lr,
    p_wald_extra = if (!is.null(r$wald_extra)) r$wald_extra$p_value else NA_real_
  )
}

seguro <- function(expr) tryCatch(expr, error = function(e) {
  message("  (pulado: ", conditionMessage(e), ")"); NULL
})

resultados <- list()
add <- function(r, nome) {
  if (!is.null(r)) resultados[[length(resultados) + 1]] <<- resumir(r, nome)
}

# Controles adicionais do 04c (DXY, Brent, dias de Copom e Fomc), para a R15
extras_d <- if (file.exists(extras_daily_file)) load_object(extras_daily_file) else NULL
if (is.null(extras_d)) message("Sem ", extras_daily_file, ": rode o 04c antes para ter a R15.")

# Pesquisas em margem e em surpresa, para a R5b e a R5c
locais_pesq <- c(electoral_raw_dir, root, dirname(root),
                 file.path(root, "saida_mercados"), file.path(dirname(root), "saida_mercados"))
achar_pesq <- function(arq) {
  a <- file.path(locais_pesq, arq)
  if (any(file.exists(a))) a[file.exists(a)][1] else NA_character_
}
arq_painel_pesq <- achar_pesq(arquivo_painel_pesquisas)
arq_eventos_pesq <- achar_pesq("eventos_pesquisas.csv")

if (!is.na(arq_painel_pesq) && "p_pesq" %in% names(model_data)) {
  margem_dia <- readr::read_csv(arq_painel_pesq, show_col_types = FALSE) |>
    dplyr::transmute(ciclo = ano, data_pesq = as.Date(data) + defasagem_divulgacao, margem_pesq) |>
    dplyr::filter(is.finite(margem_pesq))
  model_data <- model_data |>
    dplyr::left_join(margem_dia, by = dplyr::join_by(ciclo, closest(data >= data_pesq))) |>
    dplyr::select(-data_pesq) |>
    dplyr::arrange(ciclo, data) |>
    dplyr::group_by(ciclo) |>
    dplyr::mutate(margem_pesq = dplyr::if_else(is.finite(p_pesq), margem_pesq, NA_real_),
                  dm_pesq = 100 * (margem_pesq - dplyr::lag(margem_pesq))) |>
    dplyr::ungroup()
} else message("Sem o painel das pesquisas: R5b não é estimada.")

if (!is.na(arq_eventos_pesq)) {
  eventos_pesq <- readr::read_csv(arq_eventos_pesq, show_col_types = FALSE) |>
    dplyr::transmute(ciclo = ano, entra = as.Date(data_fim) + defasagem_divulgacao, surpresa_pp) |>
    dplyr::filter(is.finite(surpresa_pp))
  surpresa_dia <- model_data |>
    dplyr::arrange(ciclo, data) |>
    dplyr::group_by(ciclo) |>
    dplyr::mutate(data_ant = dplyr::lag(data)) |>
    dplyr::ungroup() |>
    dplyr::filter(!is.na(data_ant)) |>
    dplyr::select(ciclo, data, data_ant) |>
    dplyr::inner_join(eventos_pesq, by = dplyr::join_by(ciclo, data_ant < entra, data >= entra)) |>
    dplyr::group_by(ciclo, data) |>
    dplyr::summarise(surp_pesq = mean(surpresa_pp), n_pesq_dia = dplyr::n(), .groups = "drop")
  model_data <- model_data |>
    dplyr::left_join(surpresa_dia, by = c("ciclo", "data")) |>
    dplyr::mutate(n_pesq_dia = tidyr::replace_na(n_pesq_dia, 0L))
} else message("Sem eventos_pesquisas.csv: R5c não é estimada.")

for (y in names(base_ardl)) {
  message("Robustez para ", y)
  b <- base_ardl[[y]]; p0 <- b$p; q0 <- b$q

  add(b, "R0 base")

  # R1: exclui as observações cuja janela [t-max(p,q), t] contém noite
  # eleitoral (a noite não entra nem como y nem como defasagem)
  jan <- max(p0, q0)
  d1 <- model_data |>
    dplyr::group_by(ciclo) |>
    dplyr::mutate(i = dplyr::row_number(),
                  perto = purrr::map_lgl(i, function(t) any(noite_eleicao[pmax(1, t - jan):t] == 1))) |>
    dplyr::ungroup()
  # As defasagens são calculadas ANTES de excluir, para não emendar
  # dias que não são consecutivos
  d1 <- d1 |> add_lags(c(y, "dp_pt"), max(p0, q0, 1))
  r1 <- seguro({
    dd <- d1 |> dplyr::filter(!perto) |>
      tidyr::drop_na(dplyr::all_of(c(y, "dp_pt", lag_terms(y, p0), lag_terms("dp_pt", q0), controles)))
    m <- lm(formula_leadlag(y, "dp_pt", p0, q0, 0, controles), data = dd)
    list(rotulo = "R1", y = y, x = "dp_pt", p = p0, q = q0, modelo = m,
         perfil = profile_leadlag(m, "dp_pt", q0),
         coefs = tidy_nw(m) |> dplyr::filter(term %in% c("dp_pt", lag_terms("dp_pt", q0))) |>
           dplyr::mutate(j = term_j(term, "dp_pt")),
         lr = tibble::tibble(lr = NA_real_), ajuste = tibble::tibble(n = nobs(m)))
  })
  add(r1, "R1 sem noites eleitorais")

  # R2: dummies dos pregões seguintes ao 1º e ao 2º turno (absorvem o
  # nível do retorno nesses dias, mantendo-os na amostra)
  # (sem o pós-2º turno na amostra, só a binária do pós-1º turno varia)
  dum <- c("pos_1t", "pos_2t_d1")[c(TRUE, incluir_resultado_2t)]
  add(seguro(rodar_leadlag(model_data, y, "dp_pt", "R2", p0, q0, extra = dum)),
      if (incluir_resultado_2t) "R2 dummies pós 1º e 2º turno" else "R2 dummy pós 1º turno")

  # R3: disputa direta
  if (tem_dados(model_data, "dp_h2h"))
    add(seguro(rodar_leadlag(model_data, y, "dp_h2h", "R3", p0, q0)), "R3 P(PT x rival)")

  # R4: fase de campanha
  dc <- model_data |> dplyr::filter(campanha == 1)
  add(seguro(rodar_leadlag(dc, y, "dp_pt", "R4", p0, q0)), "R4 só campanha")

  # R5 e R6: pesquisas
  if (tem_dados(model_data, "dp_pesq")) {
    dpq <- model_data |> dplyr::filter(is.finite(p_pesq))
    add(seguro(rodar_leadlag(dpq, y, "dp_pesq", "R5", p0, q0)), "R5 pesquisas no lugar do mercado")
    dpq2 <- dpq |> add_lags("dp_pesq", 1)
    add(seguro(rodar_leadlag(dpq2, y, "dp_pt", "R6", p0, q0, extra = c("dp_pesq", "dp_pesq_l1"))),
        "R6 mercado + pesquisas (Wald pesquisas)")
  }

  # R5b: variação da margem do agregador no lugar da probabilidade
  if (tem_dados(model_data, "dm_pesq"))
    add(seguro(rodar_leadlag(model_data |> dplyr::filter(is.finite(margem_pesq)), y, "dm_pesq", "R5b", p0, q0)),
        "R5b pesquisas: variação da margem (p.p.)")

  # R5c: surpresa das pesquisas, só nos pregões em que entra pesquisa.
  # As defasagens de y são calculadas antes de filtrar os pregões
  if (tem_dados(model_data, "surp_pesq", 30)) {
    r5c <- seguro({
      dd <- model_data |> add_lags(y, max(p0, 1)) |>
        dplyr::filter(n_pesq_dia > 0) |>
        tidyr::drop_na(dplyr::all_of(c(y, "surp_pesq", lag_terms(y, p0), controles)))
      m <- lm(formula_leadlag(y, "surp_pesq", p0, 0, 0, controles), data = dd)
      list(rotulo = "R5c", y = y, x = "surp_pesq", p = p0, q = 0, modelo = m,
           perfil = profile_leadlag(m, "surp_pesq", 0),
           coefs = tidy_nw(m) |> dplyr::filter(term == "surp_pesq") |>
             dplyr::mutate(j = term_j(term, "surp_pesq")),
           lr = tibble::tibble(lr = NA_real_), ajuste = tibble::tibble(n = nobs(m)))
    })
    add(r5c, "R5c pesquisas: surpresa nos pregões com pesquisa (p.p.)")
  }

  # R7: probabilidade com o último preço do dia (23h59) em vez do
  # fechamento da B3, nos ciclos que têm as duas versões.
  # Amostra pareada: um pregão só entra se as duas medidas existem
  # nele (a outra vira NA, sem retirar a linha, para a defasagem
  # continuar sendo o pregão anterior). As duas rodam com t-1
  # (q = max(q0, 1)), logo exigem as mesmas defasagens.
  # Bloco de reação de cada uma: R7a, fechamento da B3 -> só t;
  # R7b, 23h59 -> t e t-1 (a notícia da noite chega ao preço em t+1).
  d7 <- model_data |>
    dplyr::filter(horario_p == "fechamento_b3") |>
    dplyr::mutate(ambas = is.finite(dp_pt) & is.finite(dp_pt_fimdia),
                  dp_pt = dplyr::if_else(ambas, dp_pt, NA_real_),
                  dp_pt_fimdia = dplyr::if_else(ambas, dp_pt_fimdia, NA_real_)) |>
    dplyr::select(-ambas)
  if (tem_dados(d7, "dp_pt_fimdia")) {
    anos7 <- paste(sort(unique(d7$ciclo[is.finite(d7$dp_pt_fimdia)])), collapse = "+")
    q7 <- max(q0, 1)
    r7a <- seguro(rodar_leadlag(d7, y, "dp_pt", "R7a", p0, q7, r = 0))
    r7b <- seguro(rodar_leadlag(d7, y, "dp_pt_fimdia", "R7b", p0, q7, r = 1))
    if (!is.null(r7a) && !is.null(r7b)) stopifnot(identical(r7a$amostra_usada, r7b$amostra_usada))
    add(r7a, paste0("R7a ", anos7, " P(PT) no fechamento da B3 (q = ", q7, "; reação = t)"))
    add(r7b, paste0("R7b ", anos7, " P(PT) no fim do dia (23h59) (q = ", q7, "; reação = t e t-1)"))
  }

  # R8: sem observações influentes (atípica E influente no modelo base)
  r8 <- seguro({
    m <- b$modelo; n <- nobs(m); k <- length(coef(m))
    rem <- (abs(rstudent(m)) > 2 | hatvalues(m) > 2 * k / n) &
           (cooks.distance(m) > 4 / n | abs(dffits(m)) > 2 * sqrt(k / n))
    fora <- b$amostra_usada[rem, ]
    message("  R8: ", sum(rem), " observações removidas")
    d8 <- prepare_leadlag(model_data, y, "dp_pt", max(p0, 1), max(q0, 1), 0, controles) |>
      dplyr::anti_join(fora, by = c("ciclo", "data"))
    m8 <- lm(formula_leadlag(y, "dp_pt", p0, q0, 0, controles), data = d8)
    list(rotulo = "R8", y = y, x = "dp_pt", p = p0, q = q0, modelo = m8,
         perfil = profile_leadlag(m8, "dp_pt", q0),
         coefs = tidy_nw(m8) |> dplyr::filter(term %in% c("dp_pt", lag_terms("dp_pt", q0))) |>
           dplyr::mutate(j = term_j(term, "dp_pt")),
         lr = tibble::tibble(lr = NA_real_), ajuste = tibble::tibble(n = nobs(m8)))
  })
  add(r8, "R8 sem influentes")

  # R9: dólar pela outra fonte
  if (y == "r_usd" && tem_dados(model_data, "r_usd_alt")) {
    add(seguro(rodar_leadlag(model_data, "r_usd_alt", "dp_pt", "R9", p0, q0)),
        paste("R9 dólar", c(ptax = "PTAX (10h-13h)", usd_b3 = "B3 no fechamento",
                             usdbrl = "Yahoo")[[attr(model_data, "fonte_usd_alt") %||% "ptax"]]))
  }

  # R10: Newey-West com 10 defasagens (pedidas na chamada)
  r10 <- seguro(rodar_leadlag(model_data, y, "dp_pt", "R10", p0, q0, lag_nw = 10))
  if (!is.null(r10)) stopifnot(r10$ajuste$nw_lag == 10)
  add(r10, "R10 Newey-West lag 10")

  # R11: AIC
  add(seguro(rodar_leadlag(model_data, y, "dp_pt", "R11", criterion = "AIC")), "R11 seleção por AIC")

  # R12: janela completa de 2018
  if (file.exists(model_data_full_file))
    add(seguro(rodar_leadlag(load_object(model_data_full_file), y, "dp_pt", "R12", p0, q0)),
        "R12 2018 desde 16/08 (início da campanha)")

  # R13: q fixo em 3. Com o BIC livre (min_lag_dp = 0), ele pode escolher
  # q = 0 e o bloco de antecedência fica vazio; aqui as defasagens t-1 a
  # t-3 entram sempre, para medir o tamanho, o sinal e o Wald conjunto.
  add(seguro(rodar_leadlag(model_data, y, "dp_pt", "R13", p0, 3)),
      "R13 q fixo em 3 (antecedência t-1 a t-3)")

  # R14: inclui o pregão seguinte ao 2º turno, com P(PT) = resultado (1/0)
  # (especificação antiga; mistura probabilidade e resultado)
  if (!incluir_resultado_2t)
    add(seguro(rodar_leadlag(model_data, y, "dp_pt_res", "R14", p0, q0)),
        "R14 com o pregão pós-2º turno (P = resultado)")

  # R15: controles adicionais (04c). DXY e Brent entram como controles
  # contemporâneos; os dias de decisão do Copom e do Fomc, como dummies.
  # Mesma amostra para todos: só pregões com DXY e Brent.
  if (!is.null(extras_d)) {
    d15 <- model_data |>
      dplyr::left_join(extras_d, by = c("ciclo", "data")) |>
      dplyr::filter(is.finite(r_dxy), is.finite(r_brent))
    add(seguro(rodar_leadlag(d15, y, "dp_pt", "R15", p0, q0,
                             ctrl = c(controles, "r_dxy", "r_brent"),
                             extra = c("dia_copom", "dia_fomc"))),
        "R15 controles adicionais (DXY, Brent, Copom e Fomc)")
  }
}

robustez <- dplyr::bind_rows(resultados)

export_table(robustez |> format_table(4), file.path(saida_dir, "robustness_summary.csv"))

# Versão compacta para o texto: sinal e significância por bloco
estrela <- function(p) dplyr::case_when(is.na(p) ~ "", p < .01 ~ "***", p < .05 ~ "**", p < .10 ~ "*", TRUE ~ "")
compacta <- robustez |>
  dplyr::transmute(
    robustez, y, n, `defasagens NW` = nw_lag,
    `coef. t`   = paste0(sprintf("%.3f", theta_t), estrela(p_t)),
    `coef. t-1` = paste0(sprintf("%.3f", theta_t1), estrela(p_t1)),
    reacao      = paste0(sprintf("%.3f", soma_hora), estrela(p_hora)),
    antecedencia = paste0(sprintf("%.3f", soma_atraso2), estrela(p_atraso2)),
    `Wald extras (p): R2 e R15 dummies, R6 pesquisas` = sprintf("%.3f", p_wald_extra)
  ) |>
  dplyr::rename(!!rot_blocos[["reacao"]] := reacao, !!rot_blocos[["antecedencia"]] := antecedencia)
export_table(compacta, file.path(saida_dir, "robustness_compact.csv"))

cat("\n========== ROBUSTEZ ==========\n")
print(compacta, n = Inf, width = Inf)
message("10_robustness.R concluído com sucesso.")
