# ============================================================
# Script  : 10_robustness.R
#
# Objetivo:
#   Verificar se as conclusões do ARDL probabilidade -> ativo (09)
#   se mantêm sob mudanças metodologicamente justificadas. Como no
#   MEFA, o objetivo não é procurar significância, e sim ver se a
#   resposta à pergunta (reação na hora / antecedência) muda.
#
#   R1  sem as noites eleitorais (e a janela de defasagens que as
#       contém): os dois maiores choques não dominam?
#   R2  com dummies dos pregões seguintes ao 1º e ao 2º turno
#   R3  probabilidade PT x principal rival (p_h2h) em vez de P(PT)
#   R4  só a fase de campanha (últimos `dias_campanha` pregões antes
#       do 1º turno + entre turnos)
#   R5  probabilidade das PESQUISAS em vez do mercado de previsão
#   R6  mercado de previsão + pesquisas juntos: as pesquisas trazem
#       informação para os preços além do que o mercado de previsão
#       já tem? (liga o resultado ao agregador do TCC)
#   R7  probabilidade no fim do dia (23h59) em vez do fechamento da
#       B3, nos ciclos com as duas versões: com o preço da noite, parte
#       do efeito deve passar de t para t-1 (notícia da noite). Mesmos
#       pregões nas duas; reação = t na R7a e t e t-1 na R7b
#   R8  sem observações influentes (regra do MEFA)
#   R9  dólar pela PTAX (10h-13h) em vez do dólar da B3 no fechamento
#   R10 Newey-West com 10 defasagens fixas
#   R11 defasagens escolhidas por AIC em vez de BIC
#   R14 inclui o pregão seguinte ao 2º turno, com P(PT) = resultado
#   R13 q fixo em 3: teste explícito de antecedência (t-1 a t-3),
#       mesmo quando o BIC livre escolhe q = 0
#   R12 2018 desde o início oficial da campanha (16/08/2018), com
#       P(PT) medida só pelo contrato de Lula até 09/09 e sem a
#       variação de 10/09 (dia em que o contrato de Haddad entra)
#
# Entrada : data/processed/model_data_daily.rds, output/09_saida/ardl_main.rds
# Saída   : output/10_saida/robustness_summary.csv (+ detalhes)
#
# Próximo script: 10b_di1_dinamica.R
# ============================================================

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

saida_dir <- saida("10")

model_data <- load_object(model_data_file)
aviso_simulado(model_data)
base_ardl <- load_object(file.path(saida("09"), "ardl_main.rds"))$empilhado
defasagem_reacao_efetiva <- resolver_reacao(model_data)
options(tcc.defasagem_reacao = defasagem_reacao_efetiva)
rot_blocos <- rotulos_blocos(defasagem_reacao_efetiva)

tem_dados <- function(d, v, n = 60) v %in% names(d) && sum(is.finite(d[[v]])) >= n

# Resumo de um resultado em uma linha
resumir <- function(r, robustez) {
  if (is.null(r)) return(NULL)
  pf <- r$perfil
  pega <- function(b, col) pf[[col]][pf$chave == b]
  co <- r$coefs
  tibble::tibble(
    robustez = robustez, y = r$y, x = r$x, n = r$ajuste$n,
    nw_lag = r$ajuste$nw_lag %||% nw_lag_usado(vcov_nw(r$modelo)),
    p = r$p, q = r$q,
    theta_t   = co$estimate[co$j == 0],  p_t   = co$p.value[co$j == 0],
    theta_t1  = if (any(co$j == 1)) co$estimate[co$j == 1] else NA_real_,
    p_t1      = if (any(co$j == 1)) co$p.value[co$j == 1] else NA_real_,
    soma_hora = pega("reacao", "soma"),
    p_hora = pega("reacao", "p_soma"),
    soma_atraso2 = pega("antecedencia", "soma"),
    p_atraso2 = pega("antecedencia", "p_wald"),
    soma_total = pega("total", "soma"),
    p_total = pega("total", "p_soma"),
    lr = r$lr$lr,
    p_wald_extra = if (!is.null(r$wald_extra)) r$wald_extra$p_value else NA_real_
  )
}

seguro <- function(expr) tryCatch(expr, error = function(e) {
  message("  (pulado: ", conditionMessage(e), ")"); NULL
})

resultados <- list()
add <- function(r, nome) {
  if (!is.null(r)) resultados[[length(resultados) + 1]] <<- resumir(r, nome)
}

for (y in names(base_ardl)) {
  message("Robustez para ", y)
  b <- base_ardl[[y]]; p0 <- b$p; q0 <- b$q

  add(b, "R0 base")

  # R1: exclui as observações cuja janela [t-max(p,q), t] contém noite
  # eleitoral (a noite não entra nem como y nem como defasagem)
  jan <- max(p0, q0)
  d1 <- model_data |>
    dplyr::group_by(ciclo) |>
    dplyr::mutate(i = dplyr::row_number(),
                  perto = purrr::map_lgl(i, function(t) any(noite_eleicao[pmax(1, t - jan):t] == 1))) |>
    dplyr::ungroup()
  # As defasagens são calculadas ANTES de excluir, para não emendar
  # dias que não são consecutivos
  d1 <- d1 |> add_lags(c(y, "dp_pt"), max(p0, q0, 1))
  r1 <- seguro({
    dd <- d1 |> dplyr::filter(!perto) |>
      tidyr::drop_na(dplyr::all_of(c(y, "dp_pt", lag_terms(y, p0), lag_terms("dp_pt", q0), controles)))
    m <- lm(formula_leadlag(y, "dp_pt", p0, q0, 0, controles), data = dd)
    list(rotulo = "R1", y = y, x = "dp_pt", p = p0, q = q0, modelo = m,
         perfil = profile_leadlag(m, "dp_pt", q0),
         coefs = tidy_nw(m) |> dplyr::filter(term %in% c("dp_pt", lag_terms("dp_pt", q0))) |>
           dplyr::mutate(j = term_j(term, "dp_pt")),
         lr = tibble::tibble(lr = NA_real_), ajuste = tibble::tibble(n = nobs(m)))
  })
  add(r1, "R1 sem noites eleitorais")

  # R2: dummies dos pregões seguintes ao 1º e ao 2º turno (absorvem o
  # nível do retorno nesses dias, mantendo-os na amostra)
  # (sem o pós-2º turno na amostra, só a binária do pós-1º turno varia)
  dum <- c("pos_1t", "pos_2t_d1")[c(TRUE, incluir_resultado_2t)]
  add(seguro(rodar_leadlag(model_data, y, "dp_pt", "R2", p0, q0, extra = dum)),
      if (incluir_resultado_2t) "R2 dummies pós 1º e 2º turno" else "R2 dummy pós 1º turno")

  # R3: disputa direta
  if (tem_dados(model_data, "dp_h2h"))
    add(seguro(rodar_leadlag(model_data, y, "dp_h2h", "R3", p0, q0)), "R3 P(PT x rival)")

  # R4: fase de campanha
  dc <- model_data |> dplyr::filter(campanha == 1)
  add(seguro(rodar_leadlag(dc, y, "dp_pt", "R4", p0, q0)), "R4 só campanha")

  # R5 e R6: pesquisas
  if (tem_dados(model_data, "dp_pesq")) {
    dpq <- model_data |> dplyr::filter(is.finite(p_pesq))
    add(seguro(rodar_leadlag(dpq, y, "dp_pesq", "R5", p0, q0)), "R5 pesquisas no lugar do mercado")
    dpq2 <- dpq |> add_lags("dp_pesq", 1)
    add(seguro(rodar_leadlag(dpq2, y, "dp_pt", "R6", p0, q0, extra = c("dp_pesq", "dp_pesq_l1"))),
        "R6 mercado + pesquisas (Wald pesquisas)")
  }

  # R7: probabilidade com o último preço do dia (23h59) em vez do
  # fechamento da B3, nos ciclos que têm as duas versões.
  # Amostra pareada: um pregão só entra se as duas medidas existem
  # nele (a outra vira NA, sem retirar a linha, para a defasagem
  # continuar sendo o pregão anterior). As duas rodam com t-1
  # (q = max(q0, 1)), logo exigem as mesmas defasagens.
  # Bloco de reação de cada uma: R7a, fechamento da B3 -> só t;
  # R7b, 23h59 -> t e t-1 (a notícia da noite chega ao preço em t+1).
  d7 <- model_data |>
    dplyr::filter(horario_p == "fechamento_b3") |>
    dplyr::mutate(ambas = is.finite(dp_pt) & is.finite(dp_pt_fimdia),
                  dp_pt = dplyr::if_else(ambas, dp_pt, NA_real_),
                  dp_pt_fimdia = dplyr::if_else(ambas, dp_pt_fimdia, NA_real_)) |>
    dplyr::select(-ambas)
  if (tem_dados(d7, "dp_pt_fimdia")) {
    anos7 <- paste(sort(unique(d7$ciclo[is.finite(d7$dp_pt_fimdia)])), collapse = "+")
    q7 <- max(q0, 1)
    r7a <- seguro(rodar_leadlag(d7, y, "dp_pt", "R7a", p0, q7, r = 0))
    r7b <- seguro(rodar_leadlag(d7, y, "dp_pt_fimdia", "R7b", p0, q7, r = 1))
    if (!is.null(r7a) && !is.null(r7b)) stopifnot(identical(r7a$amostra_usada, r7b$amostra_usada))
    add(r7a, paste0("R7a ", anos7, " P(PT) no fechamento da B3 (q = ", q7, "; reação = t)"))
    add(r7b, paste0("R7b ", anos7, " P(PT) no fim do dia (23h59) (q = ", q7, "; reação = t e t-1)"))
  }

  # R8: sem observações influentes (atípica E influente no modelo base)
  r8 <- seguro({
    m <- b$modelo; n <- nobs(m); k <- length(coef(m))
    rem <- (abs(rstudent(m)) > 2 | hatvalues(m) > 2 * k / n) &
           (cooks.distance(m) > 4 / n | abs(dffits(m)) > 2 * sqrt(k / n))
    fora <- b$amostra_usada[rem, ]
    message("  R8: ", sum(rem), " observações removidas")
    d8 <- prepare_leadlag(model_data, y, "dp_pt", max(p0, 1), max(q0, 1), 0, controles) |>
      dplyr::anti_join(fora, by = c("ciclo", "data"))
    m8 <- lm(formula_leadlag(y, "dp_pt", p0, q0, 0, controles), data = d8)
    list(rotulo = "R8", y = y, x = "dp_pt", p = p0, q = q0, modelo = m8,
         perfil = profile_leadlag(m8, "dp_pt", q0),
         coefs = tidy_nw(m8) |> dplyr::filter(term %in% c("dp_pt", lag_terms("dp_pt", q0))) |>
           dplyr::mutate(j = term_j(term, "dp_pt")),
         lr = tibble::tibble(lr = NA_real_), ajuste = tibble::tibble(n = nobs(m8)))
  })
  add(r8, "R8 sem influentes")

  # R9: dólar pela outra fonte
  if (y == "r_usd" && tem_dados(model_data, "r_usd_alt")) {
    add(seguro(rodar_leadlag(model_data, "r_usd_alt", "dp_pt", "R9", p0, q0)),
        paste("R9 dólar", c(ptax = "PTAX (10h-13h)", usd_b3 = "B3 no fechamento",
                             usdbrl = "Yahoo")[[attr(model_data, "fonte_usd_alt") %||% "ptax"]]))
  }

  # R10: Newey-West com 10 defasagens (pedidas na chamada)
  r10 <- seguro(rodar_leadlag(model_data, y, "dp_pt", "R10", p0, q0, lag_nw = 10))
  if (!is.null(r10)) stopifnot(r10$ajuste$nw_lag == 10)
  add(r10, "R10 Newey-West lag 10")

  # R11: AIC
  add(seguro(rodar_leadlag(model_data, y, "dp_pt", "R11", criterion = "AIC")), "R11 seleção por AIC")

  # R12: janela completa de 2018
  if (file.exists(model_data_full_file))
    add(seguro(rodar_leadlag(load_object(model_data_full_file), y, "dp_pt", "R12", p0, q0)),
        "R12 2018 desde 16/08 (início da campanha)")

  # R13: q fixo em 3. Com o BIC livre (min_lag_dp = 0), ele pode escolher
  # q = 0 e o bloco de antecedência fica vazio; aqui as defasagens t-1 a
  # t-3 entram sempre, para medir o tamanho, o sinal e o Wald conjunto.
  add(seguro(rodar_leadlag(model_data, y, "dp_pt", "R13", p0, 3)),
      "R13 q fixo em 3 (antecedência t-1 a t-3)")

  # R14: inclui o pregão seguinte ao 2º turno, com P(PT) = resultado (1/0)
  # (especificação antiga; mistura probabilidade e resultado)
  if (!incluir_resultado_2t)
    add(seguro(rodar_leadlag(model_data, y, "dp_pt_res", "R14", p0, q0)),
        "R14 com o pregão pós-2º turno (P = resultado)")
}

robustez <- dplyr::bind_rows(resultados)

# 6 casas: a Tabela 6 (script 13) arredonda para 3 casas a partir deste
# arquivo; com 4 casas, o β do R7b (Ibovespa) era gravado como -0,0985
# e saía -0,098 na tabela (duplo arredondamento), em vez de -0,099.
export_table(robustez |> format_table(6), file.path(saida_dir, "robustness_summary.csv"))

# Versão compacta para o texto: sinal e significância por bloco.
# "--": a coluna não se aplica (ex.: sem t-1 quando q = 0; Wald
# extras só na R2 e na R6).
estrela <- function(p) dplyr::case_when(is.na(p) ~ "", p < .01 ~ "***", p < .05 ~ "**", p < .10 ~ "*", TRUE ~ "")
fmt <- function(x, p) ifelse(is.finite(x), paste0(sprintf("%.3f", x), estrela(p)), "--")
compacta <- robustez |>
  dplyr::transmute(
    robustez, y, n, `defasagens NW` = nw_lag,
    `coef. t`    = fmt(theta_t, p_t),
    `coef. t-1`  = fmt(theta_t1, p_t1),
    reacao       = fmt(soma_hora, p_hora),
    antecedencia = fmt(soma_atraso2, p_atraso2),
    `Wald extras (p): R2 dummies, R6 pesquisas` = ifelse(is.finite(p_wald_extra), sprintf("%.3f", p_wald_extra), "--")
  ) |>
  dplyr::rename(!!rot_blocos[["reacao"]] := reacao, !!rot_blocos[["antecedencia"]] := antecedencia)
export_table(compacta, file.path(saida_dir, "robustness_compact.csv"))

cat("\n========== ROBUSTEZ ==========\n")
print(compacta, n = Inf, width = Inf)
message("10_robustness.R concluído com sucesso.")
