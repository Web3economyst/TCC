# ============================================================
# Script  : 10b_di1_dinamica.R
#
# Objetivo:
#   Extensão COMPLEMENTAR, só para o DI de 1 ano. Os modelos E e D
#   do 06 deixam autocorrelação nos resíduos desse ativo (Breusch-
#   Godfrey do 07). Pergunta: uma estrutura autorregressiva um
#   pouco maior, com até três defasagens da variável dependente,
#   explica essa dependência? E o β eleitoral muda com ela?
#
#     ΔDI1_t = a_ciclo + Σ_{i=1..p} φ_i ΔDI1_{t−i} + β ΔP_t
#              + g'·controles_t + e_t ,   p = 0, 1, 2, 3
#
#   p = 0 é o modelo E e p = 1 é o modelo D, reestimados aqui na
#   mesma amostra dos demais (a que tem as três defasagens), para
#   que BIC, R² e β sejam comparáveis. Os modelos E, E1 e D do 06
#   não mudam.
#
#   Amostras: ciclos empilhados (Newey-West por blocos), 2022 e
#   2026. 2018 só entra se tiver pelo menos `min_obs_por_parametro`
#   observações por parâmetro no modelo maior; senão fica registrado
#   como não estimado.
#
#   Ordem por BIC na amostra comum. A ordem NÃO é escolhida pelo
#   p-valor do Breusch-Godfrey. Para cada ordem saem o BG de 1 a 5,
#   o RESET-HAC e a ACF/PACF dos resíduos.
#
#   Leitura: com a variável dependente defasada, autocorrelação
#   remanescente nos resíduos torna o MQO inconsistente. Se o BG
#   continuar rejeitando na ordem escolhida, isso é uma limitação da
#   especificação dinâmica, registrada na coluna `limitacao`, e os
#   coeficientes dela não devem ser lidos como estimativa final.
#
# Entrada : data/processed/model_data_daily.rds
#           output/06_saida/static_dynamic_coefficients.csv (referência)
# Saída   : output/10b_saida/di1_dinamica_modelos.csv
#           output/10b_saida/di1_dinamica_diagnosticos.csv
#           output/10b_saida/di1_dinamica_resumo.csv
#           output/10b_saida/di1_dinamica_nao_estimados.csv
#           output/10b_saida/di1_dinamica_acf_pacf_{amostra}.png
#
# Próximo script: 10c_nao_linearidade.R
# ============================================================

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

saida_dir <- saida("10b")

model_data <- load_object(model_data_file)
aviso_simulado(model_data)

y <- "d_di1"
p_max <- 3
min_obs_por_parametro <- 10

amostras <- c(list(empilhado = model_data),
              split(model_data, model_data$ciclo) |> setNames(as.character(sort(unique(model_data$ciclo)))))

# Amostra comum a todas as ordens: as três defasagens de y dentro do
# ciclo, ΔP e os controles
preparar <- function(d) {
  d |> add_lags(y, p_max) |>
    tidyr::drop_na(dplyr::all_of(c(y, lag_terms(y, p_max), "dp_pt", controles)))
}

formula_p <- function(p, fe) {
  stats::reformulate(c(lag_terms(y, p), "dp_pt", controles, if (fe) "factor(ciclo)"), y)
}

# ------------------------------------------------------------
# 1. Estimação por amostra e ordem
# ------------------------------------------------------------

nao_estimados <- list()
modelos <- list()
dados <- list()

for (a in names(amostras)) {
  d <- preparar(amostras[[a]])
  fe <- dplyr::n_distinct(d$ciclo) > 1
  k_maior <- length(c(lag_terms(y, p_max), "dp_pt", controles)) + if (fe) dplyr::n_distinct(d$ciclo) else 1
  if (nrow(d) < min_obs_por_parametro * k_maior) {
    nao_estimados[[a]] <- tibble::tibble(
      amostra = a, n = nrow(d), parametros_modelo_maior = k_maior,
      motivo = paste0("graus de liberdade insuficientes: menos de ", min_obs_por_parametro,
                      " observações por parâmetro com ", p_max, " defasagens"))
    next
  }
  dados[[a]] <- d
  for (p in 0:p_max) modelos[[paste(a, p, sep = "__")]] <- lm(formula_p(p, fe), data = d)
}

nao_estimados <- dplyr::bind_rows(nao_estimados)
if (!nrow(nao_estimados)) nao_estimados <- tibble::tibble(amostra = character(0), n = integer(0),
                                                          parametros_modelo_maior = numeric(0), motivo = character(0))
export_table(nao_estimados, file.path(saida_dir, "di1_dinamica_nao_estimados.csv"))

info <- tibble::tibble(nome = names(modelos)) |>
  tidyr::separate(nome, c("amostra", "p"), sep = "__", remove = FALSE, convert = TRUE) |>
  dplyr::mutate(modelo = dplyr::case_when(p == 0 ~ "E (p = 0)", p == 1 ~ "D (p = 1)", TRUE ~ paste0("AR(", p, ")")))

# ------------------------------------------------------------
# 2. Coeficientes, ajuste e ordem escolhida por BIC
# ------------------------------------------------------------

coefs <- purrr::pmap_dfr(info, function(nome, amostra, p, modelo) {
  m <- modelos[[nome]]
  t <- tidy_nw(m)
  V <- vcov_nw(m)
  b <- t[t$term == "dp_pt", ]
  ar <- t[t$term %in% lag_terms(y, p_max), ]
  phi <- function(j, col) { v <- ar[[col]][ar$term == paste0(y, "_l", j)]; if (length(v)) v else NA_real_ }
  soma_phi <- if (p > 0) sum(coef(m)[lag_terms(y, p)]) else 0
  tibble::tibble(
    amostra = amostra, modelo = modelo, p = p, n = nobs(m),
    beta = b$estimate, ep_hac = b$std.error, p_beta = b$p.value, ic_inf = b$conf.low, ic_sup = b$conf.high,
    phi1 = phi(1, "estimate"), ep_phi1 = phi(1, "std.error"), p_phi1 = phi(1, "p.value"),
    phi2 = phi(2, "estimate"), ep_phi2 = phi(2, "std.error"), p_phi2 = phi(2, "p.value"),
    phi3 = phi(3, "estimate"), ep_phi3 = phi(3, "std.error"), p_phi3 = phi(3, "p.value"),
    soma_phi = soma_phi, efeito_acumulado = b$estimate / (1 - soma_phi),
    p_wald_defasagens = if (p > 0) wald_nw(m, lag_terms(y, p))$p_value else NA_real_,
    bic = BIC(m), adj_r2 = summary(m)$adj.r.squared, nw_lag = nw_lag_usado(V)
  )
}) |>
  dplyr::group_by(amostra) |>
  dplyr::mutate(
    escolhido_bic = bic == min(bic),
    delta_bic = bic - min(bic),
    # Mudança do β em relação ao modelo E na mesma amostra
    beta_E_mesma_amostra = beta[p == 0], ep_E_mesma_amostra = ep_hac[p == 0],
    delta_beta_vs_E = beta - beta_E_mesma_amostra,
    delta_beta_em_ep_de_E = delta_beta_vs_E / ep_E_mesma_amostra
  ) |>
  dplyr::ungroup()

# β dos modelos E e D do 06 (amostra completa do 06), só como referência
arq_06 <- file.path(saida("06"), "static_dynamic_coefficients.csv")
if (file.exists(arq_06)) {
  ref <- readr::read_csv(arq_06, show_col_types = FALSE) |>
    dplyr::filter(y == "d_di1", term == "dp_pt", espec %in% c("E", "D")) |>
    dplyr::transmute(amostra = as.character(amostra), p = ifelse(espec == "E", 0L, 1L), beta_no_06 = estimate)
  coefs <- dplyr::left_join(coefs, ref, by = c("amostra", "p"))
}

export_table(coefs |> format_table(4), file.path(saida_dir, "di1_dinamica_modelos.csv"))

# ------------------------------------------------------------
# 3. Diagnósticos de cada ordem: BG 1 a 5 e RESET
# ------------------------------------------------------------

diag <- purrr::pmap_dfr(info, function(nome, amostra, p, modelo) {
  m <- modelos[[nome]]; d <- dados[[amostra]]
  bg <- purrr::map_dfr(1:5, ~ bg_ciclo(m, as.character(d$ciclo), .x)) |>
    dplyr::select(ordem, p_value) |>
    tidyr::pivot_wider(names_from = ordem, values_from = p_value, names_prefix = "p_bg_ordem")
  rs <- reset_um(m, d)
  dplyr::bind_cols(tibble::tibble(amostra = amostra, modelo = modelo, p = p, n = nobs(m)), bg,
                   rs |> dplyr::select(p_reset_classico = p_reset, f_reset_hac, p_reset_hac))
}) |>
  dplyr::mutate(bg_rejeita_alguma_ordem = dplyr::if_any(dplyr::starts_with("p_bg_ordem"), ~ .x < 0.05))

export_table(diag |> format_table(4), file.path(saida_dir, "di1_dinamica_diagnosticos.csv"))

# ------------------------------------------------------------
# 4. Resumo: E, D e a ordem escolhida, com a limitação registrada
# ------------------------------------------------------------

resumo <- coefs |>
  dplyr::filter(p %in% c(0, 1) | escolhido_bic) |>
  dplyr::left_join(diag |> dplyr::select(amostra, p, p_bg_ordem1, p_bg_ordem5, bg_rejeita_alguma_ordem, p_reset_hac),
                   by = c("amostra", "p")) |>
  dplyr::mutate(limitacao = dplyr::case_when(
    p > 0 & bg_rejeita_alguma_ordem ~ "BG ainda rejeita: com y defasado e erro autocorrelacionado, o MQO é inconsistente; não interpretar como estimativa final",
    p == 0 & bg_rejeita_alguma_ordem ~ "BG rejeita: β segue consistente, e a inferência usa Newey-West",
    TRUE ~ "BG não rejeita nas ordens 1 a 5")) |>
  dplyr::select(amostra, modelo, p, escolhido_bic, n, beta, ep_hac, p_beta, delta_beta_vs_E, delta_beta_em_ep_de_E,
                soma_phi, efeito_acumulado, bic, delta_bic, adj_r2, p_bg_ordem1, p_bg_ordem5, p_reset_hac, limitacao)

export_table(resumo |> format_table(4), file.path(saida_dir, "di1_dinamica_resumo.csv"))

# ------------------------------------------------------------
# 5. ACF e PACF dos resíduos, por ordem, dentro de cada ciclo
# ------------------------------------------------------------

for (a in names(dados)) {
  d <- dados[[a]]; cc <- as.character(d$ciclo); cs <- sort(unique(cc))
  save_base_plot({
    par(mfrow = c(2 * length(cs), p_max + 1), mar = c(3.5, 3.5, 2.5, 0.8), cex = 0.5)
    for (k in cs) {
      for (p in 0:p_max) acf(residuals(modelos[[paste(a, p, sep = "__")]])[cc == k], lag.max = 20,
                             main = paste0("ACF - ", k, " - p = ", p), las = 1)
      for (p in 0:p_max) pacf(residuals(modelos[[paste(a, p, sep = "__")]])[cc == k], lag.max = 20,
                              main = paste0("PACF - ", k, " - p = ", p), las = 1)
    }
  }, filename = file.path(saida_dir, paste0("di1_dinamica_acf_pacf_", a, ".png")),
  width = 3200, height = 1100 * length(cs))
}

cat("\n========== DI 1 ANO: E, D e ordem escolhida por BIC ==========\n")
print(resumo |> dplyr::select(-limitacao) |> format_table(3), n = Inf, width = Inf)
cat("\nLimitações registradas:\n")
print(resumo |> dplyr::select(amostra, modelo, limitacao), n = Inf, width = Inf)
if (nrow(nao_estimados)) { cat("\nNão estimados:\n"); print(nao_estimados, width = Inf) }
message("10b_di1_dinamica.R concluído com sucesso.")
