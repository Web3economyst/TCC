# ============================================================
# Script  : 07_diagnostics.R
#
# Objetivo:
#   Avaliar os modelos E, E1 e D do 06_models.R, na amostra
#   empilhada e em cada ciclo, sem alterar nenhum deles. Cada
#   etapa responde a uma pergunta:
#
#   3.  Gráficos de resíduos (x ajustados, QQ-plot, histograma,
#       ACF/PACF e resíduos no tempo): há algo visível que os
#       testes não mostram? Os maiores erros estão em pregões
#       específicos? Há períodos de volatilidade mais alta?
#   4.  Breusch-Godfrey dentro do ciclo, ordens 1 a 5.
#       H0: sem autocorrelação até a ordem testada.
#   4b. Breusch-Pagan (studentizado).
#       H0: homocedasticidade. Rejeitar não invalida o MQO: a
#       inferência principal usa Newey-West, que admite
#       heterocedasticidade. O teste supõe erros sem
#       autocorrelação; com autocorrelação, o p-valor é só
#       indicativo. É um diagnóstico, não prova de que o único
#       problema dos resíduos é heterocedasticidade.
#   5.  RESET de Ramsey. H0: os termos quadrático e cúbico dos
#       valores ajustados não acrescentam explicação. Versão
#       clássica (F do MQO, referência) e versão HAC (Wald com
#       Newey-West na mesma regressão auxiliar), coerente com a
#       inferência da regressão principal.
#   5b. VIF / GVIF: há forte associação linear entre os
#       regressores, em especial entre os controles financeiros?
#       Mede perda de precisão; não há limite universal (5 ou 10
#       não são regra) e nenhuma variável é retirada.
#   6.  Influência (Cook, DFBETAS de ΔP(PT) e β reestimado sem as
#       noites eleitorais): o coeficiente de ΔP(PT) depende de
#       poucos pregões?
#   6b. Investigação do RESET: a rejeição é geral ou vem dos
#       grandes choques eleitorais? O teste é repetido sem os
#       pregões pós-1º turno (mesma regra do 06b) e sem as
#       observações influentes. Nenhum termo novo é acrescentado
#       aos modelos.
#   7.  Estabilidade dentro de cada ciclo (CUSUM, MOSUM e
#       Bai-Perron): a sensibilidade muda ao longo do ciclo?
#   7b. Resumo por ativo, amostra e modelo, com o F global
#       clássico e o Wald global com Newey-West (H0: todas as
#       inclinações são zero).
#
#   Os testes descrevem sinais de problema. Não rejeitar H0 não
#   comprova que as hipóteses de Gauss-Markov valem.
#
#   A igualdade da sensibilidade ENTRE os ciclos é testada no
#   09b_comparacao_ciclos.R.
#
#   Os diagnósticos temporais respeitam os limites entre os
#   ciclos: o último pregão de um ciclo nunca é tratado como
#   vizinho do primeiro pregão do seguinte.
#
# Entrada : output/06_saida/static_dynamic_models.rds
#           data/processed/model_data_daily.rds
# Saída   : output/07_saida/diagnostics_*.csv
#           output/07_saida/diag_*.png
#           output/07_saida/diagnostics_*.rds
#
# Próximo script: 08_ccf_granger.R
# ============================================================

# ------------------------------------------------------------
# 1. Inicialização
# ------------------------------------------------------------

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

saida_dir <- saida("07")

# ------------------------------------------------------------
# 2. Carregar modelos e recuperar as datas
# ------------------------------------------------------------

modelos <- load_object(file.path(saida("06"), "static_dynamic_models.rds"))
model_data <- load_object(model_data_file)
aviso_simulado(model_data)

info_modelos <- tibble::tibble(nome = names(modelos)) |>
  tidyr::separate(nome, c("amostra", "y", "espec"), sep = "__", remove = FALSE)

# Mesma amostra usada no 06 (estimar): defasagem de 1 dentro do
# ciclo e exclusão das linhas sem y, ΔP, as duas defasagens e os
# controles. Devolve ciclo, data e noite eleitoral de cada linha.
amostra_modelo <- function(amostra, y) {
  d <- if (amostra == "empilhado") model_data else dplyr::filter(model_data, as.character(ciclo) == amostra)
  d |>
    add_lags(c(y, "dp_pt"), 1) |>
    tidyr::drop_na(dplyr::all_of(c(y, "dp_pt", paste0(y, "_l1"), "dp_pt_l1", controles))) |>
    dplyr::select(ciclo, data, noite_eleicao)
}

datas <- purrr::pmap(info_modelos, function(nome, amostra, y, espec) {
  a <- amostra_modelo(amostra, y)
  stopifnot(nrow(a) == nobs(modelos[[nome]]))
  a
}) |> setNames(info_modelos$nome)

ciclos <- sort(unique(as.character(model_data$ciclo)))
empilhados <- info_modelos |> dplyr::filter(amostra == "empilhado")

# Linhas da base usadas em cada modelo, com todas as colunas (para
# reestimar o mesmo modelo sem alguns pregões)
dados_modelo <- function(amostra, y) {
  d <- if (amostra == "empilhado") model_data else dplyr::filter(model_data, as.character(ciclo) == amostra)
  d |>
    add_lags(c(y, "dp_pt"), 1) |>
    tidyr::drop_na(dplyr::all_of(c(y, "dp_pt", paste0(y, "_l1"), "dp_pt_l1", controles)))
}

# ------------------------------------------------------------
# 3. Diagnósticos gráficos (modelos empilhados)
# ------------------------------------------------------------

# 3.1 Resíduos x ajustados, QQ-plot e histograma (escala de densidade)
purrr::walk(empilhados$nome, function(nm) {
  m <- modelos[[nm]]; e <- residuals(m)
  save_base_plot({
    par(mfrow = c(1, 3), mar = c(4, 4, 3, 1), cex = 0.6)
    plot(fitted(m), e, pch = 19, cex = 0.4, xlab = "Valores ajustados", ylab = "Resíduos",
         main = "Resíduos x ajustados", las = 1)
    abline(h = 0, col = "red", lty = 2)
    qqnorm(e, pch = 19, cex = 0.4, main = "QQ-plot dos resíduos",
           xlab = "Quantis teóricos", ylab = "Quantis amostrais", las = 1)
    qqline(e, col = "red3", lwd = 2)
    hist(e, breaks = "FD", probability = TRUE, col = "grey85", border = "white",
         main = "Histograma dos resíduos", xlab = "Resíduos", ylab = "Densidade", las = 1)
    lines(density(e), col = "blue", lwd = 2)
    curve(dnorm(x, mean = mean(e), sd = sd(e)), add = TRUE, col = "red", lty = 2, lwd = 2)
    legend("topright", legend = c("Densidade kernel", "Normal"), col = c("blue", "red"),
           lwd = 2, lty = c(1, 2), bty = "n")
  }, filename = file.path(saida_dir, paste0("diag_", gsub("__", "_", nm), "_residuos.png")),
  width = 2700, height = 900)
})

# 3.2 ACF e PACF dos resíduos, separadas por ciclo
purrr::walk(empilhados$nome, function(nm) {
  e <- residuals(modelos[[nm]]); cc <- as.character(datas[[nm]]$ciclo)
  save_base_plot({
    par(mfrow = c(2, length(ciclos)), mar = c(4, 4, 3, 1), cex = 0.6)
    for (k in ciclos) acf(e[cc == k], lag.max = 20, main = paste("ACF -", k), las = 1)
    for (k in ciclos) pacf(e[cc == k], lag.max = 20, main = paste("PACF -", k), las = 1)
  }, filename = file.path(saida_dir, paste0("diag_", gsub("__", "_", nm), "_acf_pacf.png")),
  width = 2700, height = 1600)
})

# 3.3 Resíduos no tempo: um arquivo por ativo, uma linha por modelo
# (E, E1, D) e uma coluna por ciclo. Em vermelho, o pregão seguinte
# ao 1º turno; linhas tracejadas nas datas do 1º e do 2º turno.
datas_eleicao <- model_data |>
  dplyr::distinct(ciclo, data_1t, data_2t) |>
  tidyr::pivot_longer(c(data_1t, data_2t), names_to = "turno", values_to = "data")

purrr::walk(unique(empilhados$y), function(yy) {
  nomes <- empilhados$nome[empilhados$y == yy]
  d <- purrr::map_dfr(nomes, function(nm) {
    tibble::tibble(espec = info_modelos$espec[info_modelos$nome == nm],
                   ciclo = datas[[nm]]$ciclo, data = datas[[nm]]$data,
                   noite_eleicao = datas[[nm]]$noite_eleicao, residuo = residuals(modelos[[nm]]))
  }) |> dplyr::mutate(espec = factor(espec, c("E", "E1", "D")))
  g <- ggplot2::ggplot(d, ggplot2::aes(data, residuo)) +
    ggplot2::geom_vline(data = datas_eleicao, ggplot2::aes(xintercept = data),
                        linetype = 2, colour = "grey55", linewidth = 0.3) +
    ggplot2::geom_hline(yintercept = 0, colour = "black", linewidth = 0.3) +
    ggplot2::geom_segment(ggplot2::aes(xend = data, y = 0, yend = residuo), colour = "grey45", linewidth = 0.25) +
    ggplot2::geom_point(data = dplyr::filter(d, noite_eleicao == 1), colour = "firebrick", size = 1.6) +
    ggplot2::facet_grid(espec ~ ciclo, scales = "free_x") +
    ggplot2::labs(title = paste0("Resíduos no tempo - ", respostas[[yy]], " (modelos empilhados)"),
                  subtitle = "Ponto vermelho: pregão seguinte ao 1º turno. Tracejado: datas do 1º e do 2º turno.",
                  x = NULL, y = "Resíduo") +
    ggplot2::theme_minimal(base_size = 9)
  save_plot(g, file.path(saida_dir, paste0("diag_", yy, "_residuos_tempo.png")), width = 11, height = 6)
})

message("Gráficos de resíduos gerados.")

# ------------------------------------------------------------
# 4. Autocorrelação: Breusch-Godfrey dentro do ciclo
# ------------------------------------------------------------
# Resíduo defasado DENTRO do ciclo.
# Regressão auxiliar do resíduo sobre os regressores e as
# defasagens do resíduo; LM = n·R² ~ qui-quadrado(ordem).
# H0: ausência de autocorrelação até a ordem testada.
# Ordens 1 a 5 (até uma semana de pregões), para ver a
# sensibilidade à escolha da ordem.
# (bg_ciclo está no 00_functions.R, seção 7d)

bg_results <- tidyr::expand_grid(nome = info_modelos$nome, ordem = 1:5) |>
  dplyr::mutate(res = purrr::map2(nome, ordem, function(nm, o) {
    bg_ciclo(modelos[[nm]], as.character(datas[[nm]]$ciclo), o) |> dplyr::select(-ordem)
  })) |>
  tidyr::unnest(res) |>
  dplyr::left_join(info_modelos, by = "nome")

# ------------------------------------------------------------
# 4b. Heterocedasticidade: Breusch-Pagan (studentizado)
# ------------------------------------------------------------
# H0: homocedasticidade (a variância do erro não depende dos
# regressores). Rejeitar não invalida o MQO nem o β: a inferência
# principal usa Newey-West, que admite heterocedasticidade.
# O teste supõe erros sem autocorrelação; se houver, o p-valor é
# só indicativo (ver o Breusch-Godfrey da seção 4).

bp_results <- purrr::map_dfr(info_modelos$nome, function(nm) {
  t <- lmtest::bptest(modelos[[nm]])
  tibble::tibble(nome = nm, n = nobs(modelos[[nm]]), estatistica = unname(t$statistic),
                 gl = unname(t$parameter), p_value = t$p.value,
                 decisao_5pct = ifelse(t$p.value < 0.05, "rejeita homocedasticidade",
                                       "não rejeita homocedasticidade"))
}) |> dplyr::left_join(info_modelos, by = "nome")

# ------------------------------------------------------------
# 5. Especificação funcional: RESET de Ramsey
# ------------------------------------------------------------
# H0: os termos ŷ² e ŷ³ não acrescentam poder explicativo.
# Duas versões do mesmo teste:
#   clássico : lmtest::resettest, F com a covariância do MQO. A
#              distribuição de referência supõe erros homocedásticos
#              e sem autocorrelação; fica como referência.
#   HAC      : a mesma regressão auxiliar (modelo + ŷ² + ŷ³), com os
#              dois termos testados em conjunto por Wald com
#              Newey-West (vcov_nw: por blocos na amostra empilhada).
#              É a inferência coerente com a da regressão principal.
# ŷ entra dividido pelo seu desvio-padrão, só por estabilidade
# numérica; o teste não muda com essa escala.
# m: modelo; d: as linhas da base usadas em m, na mesma ordem.

# (reset_um está no 00_functions.R, seção 7d)

reset_results <- purrr::pmap_dfr(info_modelos, function(nome, amostra, y, espec) {
  t <- reset_um(modelos[[nome]], dados_modelo(amostra, y))
  tibble::tibble(nome = nome, estatistica = t$f_reset, p_value = t$p_reset,
                 estatistica_hac = t$f_reset_hac, p_value_hac = t$p_reset_hac)
}) |> dplyr::left_join(info_modelos, by = "nome")

# ------------------------------------------------------------
# 5b. Multicolinearidade: VIF / GVIF
# ------------------------------------------------------------
# VIF de cada regressor. Com o fator de ciclo (vários graus de
# liberdade), car::vif() devolve a GVIF; a medida comparável entre
# termos é GVIF^(1/(2·gl)), que para um regressor simples é a raiz
# do VIF: quantas vezes o erro-padrão é maior do que seria com
# regressores não correlacionados (ep_inflado_pct, em %).
# r2_auxiliar: R² do regressor contra os demais (1 - 1/VIF).
# Não há limite universal. maior_do_modelo marca o termo mais
# afetado em cada modelo; nada é retirado.

vif_results <- purrr::map_dfr(info_modelos$nome, function(nm) {
  v <- tryCatch(car::vif(modelos[[nm]]), error = function(e) NULL)
  if (is.null(v)) return(NULL)
  out <- if (is.matrix(v)) {
    tibble::tibble(variavel = rownames(v), gvif = v[, "GVIF"], gl = v[, "Df"],
                   gvif_ajustado = v[, "GVIF^(1/(2*Df))"])
  } else {
    tibble::tibble(variavel = names(v), gvif = unname(v), gl = 1, gvif_ajustado = sqrt(unname(v)))
  }
  out |> dplyr::mutate(nome = nm, .before = 1,
                       r2_auxiliar = dplyr::if_else(gl == 1, 1 - 1 / gvif, NA_real_),
                       ep_inflado_pct = 100 * (gvif_ajustado - 1),
                       maior_do_modelo = gvif_ajustado == max(gvif_ajustado))
}) |> dplyr::left_join(info_modelos, by = "nome") |>
  dplyr::select(nome, amostra, y, espec, variavel, gvif, gl, gvif_ajustado, ep_inflado_pct, r2_auxiliar,
                maior_do_modelo)

# ------------------------------------------------------------
# 6. Observações influentes (com a data de cada pregão)
# ------------------------------------------------------------
# Cook, leverage, resíduo studentizado, DFFITS e DFBETAS de ΔP(PT).
# Nada é excluído aqui: a regra "atípica e influente" só marca as
# observações; a exclusão é feita na robustez R8 (10_robustness.R).

influencia <- purrr::map_dfr(info_modelos$nome, function(nm) {
  m <- modelos[[nm]]; n <- nobs(m); k <- length(coef(m))
  dfb <- dfbetas(m)
  tibble::tibble(
    nome = nm,
    ciclo = datas[[nm]]$ciclo, data = datas[[nm]]$data, noite_eleicao = datas[[nm]]$noite_eleicao,
    cook = cooks.distance(m), leverage = hatvalues(m),
    studentizado = rstudent(m), dffits = dffits(m),
    dfbeta_dp_pt = if ("dp_pt" %in% colnames(dfb)) dfb[, "dp_pt"] else NA_real_
  ) |>
    dplyr::mutate(
      atipica   = abs(studentizado) > 2 | leverage > 2 * k / n,
      influente = cook > 4 / n | abs(dffits) > 2 * sqrt(k / n),
      marcada   = atipica & influente,
      dfbeta_alto = abs(dfbeta_dp_pt) > 2 / sqrt(n)
    )
}) |> dplyr::left_join(info_modelos, by = "nome")

resumo_influencia <- influencia |>
  dplyr::group_by(nome, amostra, y, espec) |>
  dplyr::summarise(n = dplyr::n(), atipicas = sum(atipica), influentes = sum(influente),
                   marcadas = sum(marcada),
                   noites_marcadas = sum(marcada & noite_eleicao == 1),
                   dfbeta_alto = sum(dfbeta_alto, na.rm = TRUE),
                   noites_dfbeta_alto = sum(dfbeta_alto & noite_eleicao == 1, na.rm = TRUE),
                   .groups = "drop")

# Pregões que mais mexem no β de ΔP(PT) (modelos empilhados)
top_dfbeta <- influencia |>
  dplyr::filter(amostra == "empilhado") |>
  dplyr::group_by(nome) |>
  dplyr::slice_max(abs(dfbeta_dp_pt), n = 10, with_ties = FALSE) |>
  dplyr::ungroup() |>
  dplyr::select(nome, y, espec, ciclo, data, noite_eleicao, dfbeta_dp_pt, cook, studentizado)

# Quanto o β de ΔP(PT) muda sem as noites eleitorais (modelo E
# empilhado): amostra completa, sem cada noite e sem todas.
beta_sem_noites <- purrr::map_dfr(empilhados$nome[empilhados$espec == "E"], function(nm) {
  m <- modelos[[nm]]; y <- info_modelos$y[info_modelos$nome == nm]
  d <- model_data |>
    add_lags(c(y, "dp_pt"), 1) |>
    tidyr::drop_na(dplyr::all_of(c(y, "dp_pt", paste0(y, "_l1"), "dp_pt_l1", controles)))
  stopifnot(nrow(d) == nobs(m))
  dfb <- dfbetas(m)[, "dp_pt"]
  linha <- function(rotulo, fora, dfbetas_noite = NA_real_) {
    mm <- lm(formula(m), data = d[!fora, ])
    t <- tidy_nw(mm) |> dplyr::filter(term == "dp_pt")
    tibble::tibble(y = y, amostra = rotulo, n = nobs(mm), beta = t$estimate, ep = t$std.error,
                   p_value = t$p.value, conf.low = t$conf.low, conf.high = t$conf.high,
                   dfbetas_noite = dfbetas_noite)
  }
  noites <- which(d$noite_eleicao == 1)
  dplyr::bind_rows(
    linha("amostra completa", rep(FALSE, nrow(d))),
    purrr::map_dfr(noites, function(i)
      linha(paste0("sem a noite de ", format(d$data[i], "%d/%m/%Y")), seq_len(nrow(d)) == i, dfb[i])),
    if (length(noites) > 1) linha("sem todas as noites", d$noite_eleicao == 1)
  ) |>
    dplyr::mutate(variacao_pct = 100 * (beta / beta[1] - 1))
})

# Gráficos de Cook e DFBETAS de ΔP(PT), modelos empilhados,
# com os pregões no eixo do tempo de cada ciclo
purrr::walk(empilhados$nome, function(nm) {
  d <- influencia |> dplyr::filter(nome == nm)
  n <- nrow(d)
  g <- ggplot2::ggplot(d, ggplot2::aes(data)) +
    ggplot2::geom_segment(ggplot2::aes(xend = data, y = 0, yend = dfbeta_dp_pt,
                                       colour = noite_eleicao == 1)) +
    ggplot2::geom_hline(yintercept = c(-2, 2) / sqrt(n), linetype = 2, colour = "red") +
    ggplot2::scale_colour_manual(values = c(`FALSE` = "grey40", `TRUE` = "firebrick"),
                                 labels = c("Pregão comum", "Noite eleitoral"), name = NULL) +
    ggplot2::facet_wrap(~ ciclo, scales = "free_x", nrow = 1) +
    ggplot2::labs(title = paste("DFBETAS de ΔP(PT) -", nm), x = NULL, y = "DFBETAS") +
    ggplot2::theme_minimal() + ggplot2::theme(legend.position = "bottom")
  save_plot(g, file.path(saida_dir, paste0("diag_", gsub("__", "_", nm), "_dfbetas.png")),
            width = 10, height = 4)
  g2 <- ggplot2::ggplot(d, ggplot2::aes(data)) +
    ggplot2::geom_segment(ggplot2::aes(xend = data, y = 0, yend = cook,
                                       colour = noite_eleicao == 1)) +
    ggplot2::geom_hline(yintercept = 4 / n, linetype = 2, colour = "red") +
    ggplot2::scale_colour_manual(values = c(`FALSE` = "grey40", `TRUE` = "firebrick"),
                                 labels = c("Pregão comum", "Noite eleitoral"), name = NULL) +
    ggplot2::facet_wrap(~ ciclo, scales = "free_x", nrow = 1) +
    ggplot2::labs(title = paste("Distância de Cook -", nm), x = NULL, y = "Cook") +
    ggplot2::theme_minimal() + ggplot2::theme(legend.position = "bottom")
  save_plot(g2, file.path(saida_dir, paste0("diag_", gsub("__", "_", nm), "_cook.png")),
            width = 10, height = 4)
})

message("Diagnósticos de influência gerados.")

# ------------------------------------------------------------
# 6b. Investigação do RESET
# ------------------------------------------------------------
# O RESET é repetido em três versões de cada modelo, sem mudar a
# especificação:
#   amostra original;
#   sem os pregões seguintes ao 1º turno (mesma regra do 06b:
#     noite_eleicao == 0);
#   sem as observações influentes (Cook > 4/n ou |DFBETAS de
#     ΔP(PT)| > 2/√n, calculados na seção 6).
# Em cada versão: F, p-valor, N e o coeficiente de ΔP(PT) com
# Newey-West. Se a rejeição some sem as noites, a não linearidade
# está concentrada nos grandes choques eleitorais; se continua, é
# geral. Os pregões extremos seguem na regressão principal.

versoes_reset <- c("amostra original", "sem pregões pós-1º turno", "sem observações influentes")

reset_investigacao <- purrr::pmap_dfr(info_modelos, function(nome, amostra, y, espec) {
  m <- modelos[[nome]]; n <- nobs(m)
  d <- dados_modelo(amostra, y)
  inf <- influencia[influencia$nome == nome, ]
  stopifnot(nrow(d) == n, identical(d$data, inf$data))
  fora <- list(rep(FALSE, n), d$noite_eleicao == 1,
               inf$cook > 4 / n | dplyr::coalesce(inf$dfbeta_alto, FALSE))
  purrr::map2_dfr(fora, versoes_reset, function(f, rotulo) {
    dd <- d[!f, ]
    mm <- if (any(f)) lm(formula(m), data = dd) else m
    b <- tidy_nw(mm) |> dplyr::filter(term == "dp_pt")
    dplyr::bind_cols(
      tibble::tibble(nome = nome, amostra = amostra, y = y, espec = espec, versao = rotulo,
                     n = nobs(mm), removidas = sum(f)),
      reset_um(mm, dd),
      tibble::tibble(beta_dp_pt = b$estimate, ep_nw = b$std.error, p_beta = b$p.value)
    )
  })
}) |>
  dplyr::mutate(rejeita_5pct = p_reset < 0.05, rejeita_5pct_hac = p_reset_hac < 0.05)

# Versão HAC do RESET nas três amostras, lado a lado
reset_resumo_hac <- reset_investigacao |>
  dplyr::select(nome, versao, p_reset_hac) |>
  tidyr::pivot_wider(names_from = versao, values_from = p_reset_hac) |>
  dplyr::rename(p_hac_original = `amostra original`, p_hac_sem_pos_1t = `sem pregões pós-1º turno`,
                p_hac_sem_influentes = `sem observações influentes`)

reset_resumo <- reset_investigacao |>
  dplyr::select(nome, amostra, y, espec, versao, p_reset) |>
  tidyr::pivot_wider(names_from = versao, values_from = p_reset) |>
  dplyr::rename(p_original = `amostra original`, p_sem_pos_1t = `sem pregões pós-1º turno`,
                p_sem_influentes = `sem observações influentes`) |>
  dplyr::mutate(leitura = dplyr::case_when(
    is.na(p_original) ~ "teste não calculado",
    p_original >= 0.05 ~ "não rejeita na amostra original",
    p_sem_pos_1t < 0.05 & p_sem_influentes < 0.05 ~ "continua rejeitando sem os pregões pós-1º turno e sem as influentes",
    p_sem_pos_1t < 0.05 ~ "continua rejeitando sem os pregões pós-1º turno; deixa de rejeitar sem as influentes",
    p_sem_influentes < 0.05 ~ "deixa de rejeitar sem os pregões pós-1º turno; continua sem as influentes",
    TRUE ~ "deixa de rejeitar sem os pregões pós-1º turno e sem as influentes")) |>
  dplyr::rename(leitura_classico = leitura) |>
  dplyr::left_join(reset_resumo_hac, by = "nome") |>
  dplyr::mutate(classico_e_hac_concordam = (p_original < 0.05) == (p_hac_original < 0.05))

# ------------------------------------------------------------
# 7. Estabilidade dentro de cada ciclo
# ------------------------------------------------------------
# CUSUM e MOSUM (com p-valor) e
# Bai-Perron, só no modelo E e só nos ciclos com observações
# suficientes (pelo menos 15 por parâmetro).
min_obs_por_parametro <- 15

modelos_ciclo_e <- info_modelos |> dplyr::filter(amostra != "empilhado", espec == "E")

estab_dentro <- purrr::pmap_dfr(modelos_ciclo_e, function(nome, amostra, y, espec) {
  m <- modelos[[nome]]; mf <- m$model; k <- length(coef(m)); n <- nobs(m)
  if (n < min_obs_por_parametro * k) {
    return(tibble::tibble(nome = nome, ciclo = amostra, y = y, n = n, k = k,
                          cusum_p = NA_real_, mosum_p = NA_real_,
                          bp_quebras = NA_integer_, bp_datas = "amostra pequena"))
  }
  f <- formula(m)
  cus <- strucchange::efp(f, data = mf, type = "OLS-CUSUM")
  mos <- strucchange::efp(f, data = mf, type = "OLS-MOSUM", h = 0.15)
  bp  <- tryCatch(strucchange::breakpoints(f, data = mf, h = 0.15), error = function(e) NULL)
  nq  <- if (is.null(bp)) NA_integer_ else {
    b <- strucchange::breakpoints(bp)$breakpoints; if (all(is.na(b))) 0L else length(b)
  }
  dts <- if (is.null(bp) || is.na(nq) || nq == 0) "" else
    paste(format(datas[[nome]]$data[strucchange::breakpoints(bp)$breakpoints]), collapse = "; ")

  save_base_plot({
    par(mfrow = c(1, 2), mar = c(4, 4, 3, 1), cex = 0.6)
    plot(cus, main = paste("CUSUM -", amostra, y))
    plot(mos, main = paste("MOSUM -", amostra, y))
  }, filename = file.path(saida_dir, paste0("diag_", amostra, "_", y, "_E_cusum_mosum.png")),
  width = 2400, height = 900)

  tibble::tibble(nome = nome, ciclo = amostra, y = y, n = n, k = k,
                 cusum_p = strucchange::sctest(cus)$p.value,
                 mosum_p = strucchange::sctest(mos)$p.value,
                 bp_quebras = nq, bp_datas = dts)
})

message("Testes de estabilidade concluídos.")

# ------------------------------------------------------------
# 7b. Testes globais e resumo dos diagnósticos
# ------------------------------------------------------------
# Testes globais (teste_global, 00_functions.R): H0 = todos os
# coeficientes de inclinação são zero, sem o intercepto e os
# efeitos fixos de ciclo. F clássico (descritivo) e Wald com
# Newey-West. É o teste do conjunto, não do coeficiente de ΔP(PT).

globais <- purrr::map_dfr(info_modelos$nome, function(nm) {
  teste_global(modelos[[nm]]) |> dplyr::mutate(nome = nm, .before = 1)
})

# Uma linha por ativo, amostra (empilhado ou ciclo) e modelo.
# Todos os valores são p-valores, salvo indicação. Nível de 5%.
resumo_diagnosticos <- info_modelos |>
  dplyr::left_join(globais |> dplyr::select(nome, n, gl_inclinacoes = gl1, f_classico, p_f_classico = p_classico,
                                            f_wald_nw, p_wald_nw, nw_lag), by = "nome") |>
  dplyr::left_join(bp_results |> dplyr::select(nome, p_breusch_pagan = p_value), by = "nome") |>
  dplyr::left_join(bg_results |> dplyr::filter(ordem %in% c(1, 5)) |>
                     dplyr::select(nome, ordem, p_value) |>
                     tidyr::pivot_wider(names_from = ordem, values_from = p_value, names_prefix = "p_bg_ordem"),
                   by = "nome") |>
  dplyr::left_join(reset_resumo |> dplyr::select(nome, p_reset = p_original, p_reset_sem_pos_1t = p_sem_pos_1t,
                                                 p_reset_sem_influentes = p_sem_influentes,
                                                 p_reset_hac = p_hac_original), by = "nome") |>
  dplyr::left_join(vif_results |> dplyr::filter(maior_do_modelo) |> dplyr::group_by(nome) |> dplyr::slice(1) |>
                     dplyr::ungroup() |>
                     dplyr::select(nome, maior_gvif_ajustado = gvif_ajustado, variavel_maior_gvif = variavel),
                   by = "nome") |>
  dplyr::mutate(especificacao = purrr::map_chr(nome, ~ paste(deparse(formula(modelos[[.x]]), width.cutoff = 500),
                                                            collapse = " ")))

# ------------------------------------------------------------
# 8. Exportar resultados
# ------------------------------------------------------------

export_table(bg_results |> format_table(4), file.path(saida_dir, "diagnostics_breusch_godfrey.csv"))
export_table(reset_results |> format_table(4), file.path(saida_dir, "diagnostics_reset.csv"))
export_table(bp_results |> format_table(4), file.path(saida_dir, "diagnostics_breusch_pagan.csv"))
export_table(vif_results |> format_table(4), file.path(saida_dir, "diagnostics_vif.csv"))
export_table(reset_investigacao |> format_table(4), file.path(saida_dir, "diagnostics_reset_investigacao.csv"))
export_table(reset_resumo |> format_table(4), file.path(saida_dir, "diagnostics_reset_resumo.csv"))
export_table(globais |> format_table(4), file.path(saida_dir, "diagnostics_global_tests.csv"))
export_table(resumo_diagnosticos |> format_table(4), file.path(saida_dir, "diagnostics_summary.csv"))
export_table(influencia |> dplyr::filter(marcada | dfbeta_alto) |> format_table(4),
             file.path(saida_dir, "diagnostics_influential_obs.csv"))
export_table(resumo_influencia, file.path(saida_dir, "diagnostics_influence_summary.csv"))
export_table(top_dfbeta |> format_table(4), file.path(saida_dir, "diagnostics_top_dfbetas.csv"))
export_table(beta_sem_noites |> format_table(4), file.path(saida_dir, "diagnostics_beta_sem_noites.csv"))
export_table(estab_dentro |> format_table(4), file.path(saida_dir, "diagnostics_stability_within.csv"))

# ------------------------------------------------------------
# 9. Salvar objetos
# ------------------------------------------------------------

save_object(
  list(breusch_godfrey = bg_results, breusch_pagan = bp_results, reset = reset_results,
       reset_investigacao = reset_investigacao, vif = vif_results, testes_globais = globais,
       resumo = resumo_diagnosticos, estabilidade_dentro = estab_dentro),
  file.path(saida_dir, "diagnostics_results.rds")
)
save_object(influencia, file.path(saida_dir, "diagnostics_influence.rds"))

cat("\n========== BREUSCH-GODFREY (empilhado, dentro do ciclo) ==========\n")
print(bg_results |> dplyr::filter(amostra == "empilhado") |>
        dplyr::select(y, espec, ordem, lm, p_value) |> format_table(3), n = Inf)
cat("\n========== RESET ==========\n")
print(reset_results |> dplyr::filter(amostra == "empilhado") |>
        dplyr::select(y, espec, estatistica, p_value, estatistica_hac, p_value_hac) |> format_table(3), n = Inf)
cat("\n========== RESET: original, sem pregões pós-1º turno e sem influentes (empilhado) ==========\n")
print(reset_investigacao |> dplyr::filter(amostra == "empilhado") |>
        dplyr::select(y, espec, versao, n, f_reset, p_reset, rejeita_5pct, f_reset_hac, p_reset_hac,
                      rejeita_5pct_hac, beta_dp_pt, ep_nw) |>
        format_table(3), n = Inf, width = Inf)
cat("\nModelos que continuam rejeitando o RESET sem os pregões pós-1º turno:\n")
print(reset_resumo |> dplyr::filter(p_original < 0.05, p_sem_pos_1t < 0.05) |>
        dplyr::select(amostra, y, espec, p_original, p_sem_pos_1t, p_sem_influentes,
                      p_hac_original, p_hac_sem_pos_1t) |> format_table(3), n = Inf)
cat("\nModelos em que o RESET clássico e o RESET HAC discordam a 5% (amostra original):\n")
print(reset_resumo |> dplyr::filter(!classico_e_hac_concordam) |>
        dplyr::select(amostra, y, espec, p_original, p_hac_original) |> format_table(3), n = Inf)
cat("\n========== BREUSCH-PAGAN (empilhado) ==========\n")
print(bp_results |> dplyr::filter(amostra == "empilhado") |>
        dplyr::select(y, espec, estatistica, gl, p_value, decisao_5pct) |> format_table(3), n = Inf)
cat("\n========== VIF / GVIF: termo mais afetado de cada modelo ==========\n")
print(vif_results |> dplyr::filter(maior_do_modelo) |>
        dplyr::select(amostra, y, espec, variavel, gvif, gl, gvif_ajustado, ep_inflado_pct) |>
        format_table(3), n = Inf)
cat("\n========== TESTES GLOBAIS (inclinações = 0), empilhado ==========\n")
print(globais |> dplyr::left_join(info_modelos, by = "nome") |> dplyr::filter(amostra == "empilhado") |>
        dplyr::select(y, espec, n, gl1, f_classico, p_classico, f_wald_nw, p_wald_nw) |> format_table(3), n = Inf)
cat("\n========== INFLUÊNCIA ==========\n"); print(resumo_influencia, n = Inf)
cat("\n========== β DE ΔP(PT) SEM AS NOITES ELEITORAIS (modelo E) ==========\n")
print(beta_sem_noites |> format_table(3), n = Inf, width = Inf)
cat("\n========== ESTABILIDADE DENTRO DO CICLO (modelo E) ==========\n"); print(estab_dentro, n = Inf)
message("07_diagnostics.R concluído com sucesso.")
