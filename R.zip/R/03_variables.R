# ============================================================
# Script  : 03_variables.R
#
# Objetivo:
#   Construir as variáveis dos modelos. Tudo em VARIAÇÃO diária
#   (os níveis de preços e da probabilidade são persistentes;
#   ver 05_stationarity.R), sempre dentro de cada ciclo.
#
# Dicionário (t = pregão da B3):
#
#   dp_pt      : 100 × [P(PT)_t − P(PT)_{t−1}]   (pontos de probabilidade, p.p.)
#   dp_h2h     : idem para P(PT)/(P(PT)+P(rival))
#   dp_pt_fimdia : idem, com o último preço do dia (23h59; robustez R7)
#   dp_pesq    : idem para a probabilidade das pesquisas (script 08)
#
#   r_ibov     : 100 × Δ log Ibovespa              (%)
#   r_usd      : 100 × Δ log dólar (R$/US$)        (%; > 0 = real se desvaloriza)
#                fonte definida em fonte_dolar (00_config.R; padrão: B3
#                no fechamento)
#   r_usd_alt  : o mesmo com a PTAX (robustez R9)
#   d_di1      : 10.000 × Δ DI 1 ano               (pontos-base)
#   d_di5      : 10.000 × Δ DI 5 anos              (pontos-base)
#   d_slope    : d_di5 − d_di1                     (inclinação, p.b.)
#
#   r_spx      : 100 × Δ log S&P 500               (%)
#   d_ust10    : 100 × Δ Treasury 10 anos          (pontos-base)
#   r_vix      : 100 × Δ log VIX                   (%)
#
#   pos_1t     : 1 no 1º pregão após o 1º turno
#   pos_2t_d1  : 1 no 1º pregão após o 2º turno
#   entre_turnos : 1 entre o 1º e o 2º turno
#   campanha   : 1 nos últimos `dias_campanha` pregões antes do 1º
#                turno e entre turnos
#
# Entrada : data/processed/clean_data.rds
# Saída   : data/processed/model_data_daily.rds
#
# Próximo script: 03b_validacao_critica.R
# ============================================================

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

saida_dir <- saida("03")

base <- load_object(clean_data_file)
aviso_simulado(base)

dlog <- function(x) 100 * (log(x) - log(dplyr::lag(x)))
dif  <- function(x, escala = 1) escala * (x - dplyr::lag(x))

# Dólar principal e alternativo. Se o dólar da B3 não estiver
# disponível, cai para a PTAX e avisa.
fonte_usd <- fonte_dolar
if (fonte_usd == "b3" && sum(is.finite(base$usd_b3)) == 0) {
  message("Dólar da B3 indisponível: usando a PTAX como dólar principal.")
  fonte_usd <- "ptax"
}
serie_usd <- c(b3 = "usd_b3", ptax = "ptax", yahoo = "usdbrl")
alt_usd   <- if (fonte_usd == "ptax") (if (sum(is.finite(base$usd_b3)) > 0) "usd_b3" else "usdbrl") else "ptax"
message("Dólar principal: ", serie_usd[[fonte_usd]], "; alternativo (R9): ", alt_usd)

# Ciclos com troca de contrato do PT (cand_pt com mais de um nome) e
# o candidato que vale depois da troca (o último da lista)
cand_lista   <- strsplit(ciclos$cand_pt, ";")
ciclo_troca  <- stats::setNames(lengths(cand_lista) > 1, ciclos$ciclo)
cand_final   <- stats::setNames(purrr::map_chr(cand_lista, ~ utils::tail(.x, 1)), ciclos$ciclo)

model_data <- base |>
  dplyr::arrange(ciclo, data) |>
  dplyr::mutate(
    usd     = .data[[serie_usd[[fonte_usd]]]],
    usd_alt = .data[[alt_usd]]
  ) |>
  dplyr::group_by(ciclo) |>
  dplyr::mutate(
    # Níveis em log (para estacionariedade e ARDL em níveis)
    l_ibov = log(ibov), l_usd = log(usd), l_spx = log(spx), l_vix = log(vix),

    # Eleitoral
    dp_pt      = dif(p_pt, 100),
    dp_pt_res  = dif(p_pt_res, 100),   # com o resultado no pós-2º turno (tabela das noites e R14)
    dp_h2h     = dif(p_h2h, 100),
    dp_pt_fimdia  = dif(p_pt_fimdia, 100),
    dp_h2h_fimdia = dif(p_h2h_fimdia, 100),
    dp_pesq    = dif(p_pesq, 100),

    # Troca de contrato do PT (2018: Lula -> Haddad). Se o pregão usa a
    # cotação de um candidato e o anterior a de outro, a diferença
    # mistura dois contratos e não é variação de expectativa: fica NA.
    # Vale também para o primeiro pregão da janela principal
    # (11/09/2018), cuja variação usa a cotação de 10/09.
    troca_cand_pt        = dplyr::coalesce(cand_pt_dia != dplyr::lag(cand_pt_dia), FALSE),
    troca_cand_pt_fimdia = dplyr::coalesce(cand_pt_dia_fimdia != dplyr::lag(cand_pt_dia_fimdia), FALSE),
    dplyr::across(c(dp_pt, dp_pt_res, dp_h2h), ~ dplyr::if_else(troca_cand_pt, NA_real_, .x)),
    dplyr::across(c(dp_pt_fimdia, dp_h2h_fimdia), ~ dplyr::if_else(troca_cand_pt_fimdia, NA_real_, .x)),

    # Primeira variação da janela principal nos ciclos com troca de
    # contrato (2018: 11/09 menos 10/09). Só vale se as DUAS cotações
    # são do candidato final (Haddad) e foram observadas no próprio
    # dia (não repetidas de um dia anterior). Senão, fica NA. O início
    # da janela não muda.
    primeiro_pregao = data == min(data[data >= inicio]),
    cot_final_do_dia        = dplyr::coalesce(cand_pt_dia == cand_final[as.character(ciclo)] &
                                                defasagem_prob_dias == 0, FALSE),
    cot_final_do_dia_fimdia = dplyr::coalesce(cand_pt_dia_fimdia == cand_final[as.character(ciclo)] &
                                                defasagem_prob_dias_fimdia == 0, FALSE),
    primeira_dp_invalida        = ciclo_troca[as.character(ciclo)] & primeiro_pregao &
      !(cot_final_do_dia & dplyr::lag(cot_final_do_dia, default = FALSE)),
    primeira_dp_invalida_fimdia = ciclo_troca[as.character(ciclo)] & primeiro_pregao &
      !(cot_final_do_dia_fimdia & dplyr::lag(cot_final_do_dia_fimdia, default = FALSE)),
    dplyr::across(c(dp_pt, dp_pt_res, dp_h2h), ~ dplyr::if_else(primeira_dp_invalida, NA_real_, .x)),
    dplyr::across(c(dp_pt_fimdia, dp_h2h_fimdia), ~ dplyr::if_else(primeira_dp_invalida_fimdia, NA_real_, .x)),

    # Brasil
    r_ibov  = dlog(ibov),
    r_usd     = dlog(usd),
    r_usd_alt = dlog(usd_alt),
    d_di1   = dif(di1, 1e4),
    d_di5   = dif(di5, 1e4),
    d_slope = d_di5 - d_di1,

    # Controles externos
    r_spx   = dlog(spx),
    d_ust10 = dif(ust10, 100),
    r_vix   = dlog(vix),

    # Calendário eleitoral
    pos_1t       = as.integer(data > data_1t & dplyr::lag(data) <= data_1t),
    pos_2t_d1    = as.integer(data > data_2t & dplyr::lag(data) <= data_2t),
    entre_turnos = as.integer(data > data_1t & data <= data_2t),
    pregoes_ate_1t = rev(cumsum(rev(data <= data_1t))) * (data <= data_1t),
    campanha     = as.integer((data <= data_1t & pregoes_ate_1t <= dias_campanha) | entre_turnos == 1),
    noite_eleicao = as.integer(pos_1t == 1 | pos_2t_d1 == 1),

    ano = lubridate::year(data), mes = lubridate::month(data)
  ) |>
  # Dólar: se o Yahoo não tem cotação num pregão da B3, o 02 repete o
  # último valor; a variação daquele dia vira 0 e a do dia seguinte
  # acumula dois dias, caindo no dia errado. Esses dois dias ficam NA.
  dplyr::mutate(
    usd_falha = usdbrl_repetido | dplyr::lag(usdbrl_repetido, default = FALSE),
    # Dólar da B3: retorno do mesmo contrato futuro (ajuste de hoje / de ontem)
    r_usd     = if (fonte_usd == "b3") r_dol else r_usd,
    r_usd_alt = if (alt_usd == "usd_b3") r_dol else r_usd_alt,
    r_usd     = if (fonte_usd == "yahoo") dplyr::if_else(usd_falha, NA_real_, r_usd) else r_usd,
    r_usd_alt = if (alt_usd == "usdbrl") dplyr::if_else(usd_falha, NA_real_, r_usd_alt) else r_usd_alt
  ) |>
  dplyr::ungroup() |>
  dplyr::mutate(dplyr::across(c(pos_1t, pos_2t_d1), ~ tidyr::replace_na(.x, 0L)))

# Janela completa (só para a robustez R12): sem o pregão auxiliar.
# Em 2018, começa em 16/08 (início da campanha). O contrato de Haddad
# só entra na Betfair em 10/09/2018: a variação de P(PT) nesse dia
# reflete a listagem, e não notícia, e fica NA.
dia_listagem_haddad <- as.Date("2018-09-10")
model_data_full <- model_data |>
  dplyr::filter(data >= inicio_completo) |>
  dplyr::mutate(dplyr::across(c(dp_pt, dp_h2h, dp_pt_fimdia),
                              ~ dplyr::if_else(data == dia_listagem_haddad, NA_real_, .x)))

# Janela principal: remove o pregão auxiliar e, em 2018, o período
# antes da candidatura de Haddad (antes de 11/09/2018)
model_data <- model_data |> dplyr::filter(data >= inicio)

# ------------------------------------------------------------
# Validações
# ------------------------------------------------------------

cat("\n========== OBSERVAÇÕES POR CICLO ==========\n")
print(model_data |> dplyr::count(ciclo))

cat("\n========== MISSING (variações) ==========\n")
print(check_missing(model_data |> dplyr::select(dp_pt, dp_h2h, dp_pesq, r_ibov, r_usd,
                                                d_di1, d_di5, r_spx, d_ust10, r_vix)))

# Variações descartadas por troca de contrato do PT, ou por cotação
# inválida na primeira variação, dentro da janela principal
trocas <- model_data |> dplyr::filter(troca_cand_pt | primeira_dp_invalida) |>
  dplyr::select(ciclo, data, cand_pt_dia, defasagem_prob_dias, troca_cand_pt, primeira_dp_invalida)
if (nrow(trocas)) {
  cat("\n========== VARIAÇÕES DE P(PT) DESCARTADAS (troca de contrato ou cotação inválida) ==========\n")
  print(trocas)
}

# Movimentos extremos para conferência manual (erro de dado?)
extremos <- model_data |>
  dplyr::filter(abs(r_ibov) > 5 | abs(r_usd) > 4 | abs(d_di1) > 60 | abs(dp_pt) > 20) |>
  dplyr::select(ciclo, data, dp_pt, r_ibov, r_usd, d_di1, d_di5, noite_eleicao)
export_table(extremos, file.path(saida_dir, "movimentos_extremos.csv"))

cat("\n========== DIAS DE NOITE ELEITORAL ==========\n")
print(model_data |> dplyr::filter(noite_eleicao == 1) |>
        dplyr::select(ciclo, data, p_pt, dp_pt, r_ibov, r_usd, d_di1))

attr(model_data, "simulado") <- attr(base, "simulado")
attr(model_data, "fonte_usd") <- serie_usd[[fonte_usd]]
attr(model_data, "fonte_usd_alt") <- alt_usd
attr(model_data_full, "simulado") <- attr(base, "simulado")
save_object(model_data, model_data_file)
save_object(model_data_full, model_data_full_file)

message("03_variables.R concluído com sucesso.")
