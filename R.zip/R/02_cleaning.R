# ============================================================
# Script  : 02_cleaning.R
#
# Objetivo:
#   Construir a BASE INTEGRADA diária: um registro por pregão da
#   B3 dentro de cada ciclo eleitoral, com a probabilidade
#   eleitoral e os preços financeiros alinhados no mesmo dia.
#
# Decisões de alinhamento (todas documentadas no README):
#
#   1. Calendário = pregões da B3 (dias com fechamento do Ibovespa).
#
#   2. Horário de referência = fechamento da B3. A probabilidade
#      eleitoral no pregão d é o último preço até o fechamento da B3
#      no dia d (horario_probabilidade = "fechamento_b3"). Se algum
#      ciclo não tiver o arquivo no horário da B3, o script PARA: a
#      probabilidade das 23h59 é posterior ao fechamento do preço e
#      não entra no lugar da outra sem decisão explícita
#      (permitir_horario_misto, no 00_config.R). A coluna horario_p
#      registra o horário usado em cada ciclo. A versão do fim do
#      dia fica sempre em p_pt_fimdia (robustez R7).
#
#   3. Fins de semana e feriados: o mercado de previsão negocia,
#      a B3 não. Como P(PT) é lida no mesmo horário de referência
#      em todo pregão, a variação de segunda-feira vai do
#      fechamento da B3 de sexta ao fechamento da B3 de segunda e
#      inclui o que foi negociado no fim de semana. Nos ciclos com
#      horário do fim do dia, vai do fim de sexta ao fim de
#      segunda. Feriados da B3 seguem a mesma regra: a variação
#      acumula até o pregão seguinte.
#
#   4. 1º pregão após o 2º turno: o mercado de previsão já foi
#      liquidado. P(PT), P(h2h) e a probabilidade das pesquisas
#      ficam NA (incluir_resultado_2t = FALSE no 00_config), e o
#      pregão sai dos modelos. O resultado (1 se o PT venceu, 0
#      caso contrário) fica em p_pt_res, usado no 09c (noites
#      eleitorais) e na robustez R14.
#
#   5. Séries dos EUA (S&P, Treasury, VIX) em feriados americanos
#      com pregão na B3: repete-se o último valor (variação 0). A
#      coluna {serie}_repetido marca esses dias.
#
# Entrada : data/processed/raw_eleitoral.rds, data/raw/*.rds
# Saída   : data/processed/clean_data.rds
#           output/02_saida/dicionario_dados.csv
#           output/02_saida/cobertura_por_ciclo.csv
#
# Próximo script: 03_variables.R
# ============================================================

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

saida_dir <- saida("02")

# ------------------------------------------------------------
# 1. Carregar dados brutos
# ------------------------------------------------------------

raw_eleitoral <- load_object(electoral_raw_file)
yahoo <- load_object(yahoo_raw_file)
aviso_simulado(yahoo)

di <- if (file.exists(di_raw_file)) {
  load_object(di_raw_file)
} else if (file.exists(file.path(raw_dir, "di_manual.csv"))) {
  readr::read_csv(file.path(raw_dir, "di_manual.csv"), show_col_types = FALSE) |>
    dplyr::mutate(data = as.Date(data))
} else {
  message("Sem dados de DI: d_di1 e d_di5 ficarão ausentes.")
  NULL
}

ptax <- if (file.exists(ptax_raw_file)) load_object(ptax_raw_file) else NULL
dolar_b3 <- if (file.exists(dolar_raw_file)) load_object(dolar_raw_file) else NULL

# ------------------------------------------------------------
# 2. Probabilidade eleitoral diária por ciclo
# ------------------------------------------------------------

montar_prob <- function(fonte) purrr::pmap_dfr(ciclos, function(ciclo, cand_pt, cand_rival, ...) {
  pt <- strsplit(cand_pt, ";")[[1]]
  if (is.null(fonte) || !nrow(fonte) || !any(fonte$ciclo == ciclo)) return(NULL)
  fonte |>
    dplyr::filter(.data$ciclo == !!ciclo) |>
    dplyr::group_by(data, nome_clean) |>
    dplyr::summarise(prob = dplyr::last(prob_norm), .groups = "drop") |>
    # Candidato do PT em cada dia. Se cand_pt lista mais de um nome
    # (2018: "lula;haddad"), a troca acontece UMA vez: o candidato
    # seguinte da lista passa a valer no primeiro dia em que o
    # contrato dele tem preço (Haddad entra na Betfair em 10/09/2018)
    # e vale até o fim do ciclo. Depois da troca, se o contrato dele
    # ficar sem preço num dia, P(PT) fica ausente nesse dia; o
    # contrato anterior (Lula, candidatura indeferida) não volta.
    (\(tab) {
      entrada <- purrr::map(pt, function(nm) {
        dd <- tab$data[tab$nome_clean == nm & is.finite(tab$prob)]
        if (length(dd)) min(dd) else as.Date(NA)
      }) |> purrr::reduce(c)
      entrada[1] <- as.Date("1900-01-01")
      if (length(pt) > 1) message("  ", ciclo, ": candidato do PT e data de entrada do contrato: ",
                                  paste(pt[-1], format(entrada[-1]), collapse = "; "))
      tab |>
        dplyr::group_by(data) |>
        dplyr::mutate(cand_pt_dia = pt[max(which(!is.na(entrada) & entrada <= data[1]))]) |>
        dplyr::ungroup()
    })() |>
    dplyr::group_by(data) |>
    dplyr::summarise(
      cand_pt_dia = cand_pt_dia[1],
      p_pt    = {
        v <- prob[nome_clean == cand_pt_dia[1] & is.finite(prob)]
        if (length(v)) v[1] else NA_real_
      },
      # Rival sem cotação válida no dia (ausente, não numérica ou
      # não positiva): p_rival fica ausente, nunca zero.
      p_rival = {
        v <- prob[nome_clean == cand_rival]
        v <- v[is.finite(v) & v > 0]
        if (length(v)) sum(v) else NA_real_
      },
      .groups = "drop"
    ) |>
    dplyr::mutate(
      ciclo = ciclo,
      # Disputa direta PT x principal rival (robustez)
      p_h2h = dplyr::if_else(is.finite(p_pt) & is.finite(p_rival) & (p_pt + p_rival) > 0,
                             p_pt / (p_pt + p_rival), NA_real_)
    )
})

prob_fimdia <- montar_prob(raw_eleitoral$diario)
prob_corte  <- montar_prob(raw_eleitoral$corte)
ciclos_corte <- if (horario_probabilidade == "fechamento_b3" && !is.null(prob_corte) && nrow(prob_corte))
  unique(prob_corte$ciclo) else numeric(0)

# O modelo principal exige o mesmo horário em todos os ciclos
ciclos_sem_corte <- if (horario_probabilidade == "fechamento_b3") setdiff(ciclos$ciclo, ciclos_corte) else numeric(0)
if (length(ciclos_sem_corte)) {
  aviso_horario <- paste0(
    "Sem probabilidade no horário de fechamento da B3 para o(s) ciclo(s) ",
    paste(sort(ciclos_sem_corte), collapse = ", "),
    ". A probabilidade das 23h59 é posterior ao fechamento dos preços e não foi usada no lugar. ",
    "Opções: (1) colocar o arquivo do horário da B3 desses ciclos em data/raw/eleitoral; ",
    "(2) usar horario_probabilidade <- \"fim_do_dia\" para todos os ciclos; ",
    "(3) permitir_horario_misto <- TRUE para misturar os dois horários (00_config.R).")
  if (!isTRUE(permitir_horario_misto)) stop(aviso_horario, call. = FALSE)
  warning("HORÁRIOS MISTURADOS (permitir_horario_misto = TRUE). ", aviso_horario, call. = FALSE)
}

# Principal: horário da B3; fim do dia só se horario_probabilidade =
# "fim_do_dia" ou, ciclo a ciclo, com permitir_horario_misto = TRUE
if (is.null(prob_fimdia) || !nrow(prob_fimdia))
  stop("Nenhum arquivo diário de probabilidade (23h59) foi lido em data/raw/eleitoral.", call. = FALSE)
prob_diaria <- dplyr::bind_rows(
  if (length(ciclos_corte)) dplyr::filter(prob_corte, ciclo %in% ciclos_corte),
  dplyr::filter(prob_fimdia, !ciclo %in% ciclos_corte)
)

# Dias, depois da troca de candidato, em que o contrato vigente ficou sem preço
sem_preco <- prob_diaria |> dplyr::filter(!is.finite(p_pt)) |> dplyr::count(ciclo, cand_pt_dia, name = "dias_sem_preco")
if (nrow(sem_preco)) {
  warning("P(PT) ausente em dias com o contrato vigente sem preço (não substituído por outro contrato):\n",
          paste(utils::capture.output(print(as.data.frame(sem_preco))), collapse = "\n"), call. = FALSE)
}
message("Probabilidade no horário de fechamento da B3: ",
        if (length(ciclos_corte)) paste(sort(ciclos_corte), collapse = ", ") else "nenhum ciclo",
        ". Fim do dia: ", paste(setdiff(ciclos$ciclo, ciclos_corte), collapse = ", "), ".")

# ------------------------------------------------------------
# 3. Calendário: pregões da B3 dentro de cada ciclo
# ------------------------------------------------------------

dias_b3 <- yahoo$ibov |> dplyr::filter(is.finite(fecham)) |> dplyr::pull(data)

calendario <- purrr::pmap_dfr(ciclos, function(ciclo, inicio, inicio_completo, fim, data_1t, data_2t, pt_venceu, ...) {
  # Monta a janela completa (inicio_completo); a principal (inicio) é
  # recortada no 03. Inclui um pregão antes para que a 1ª variação exista.
  ini <- min(inicio, inicio_completo)
  anteriores <- dias_b3[dias_b3 < ini]
  d <- c(if (length(anteriores)) max(anteriores), dias_b3[dias_b3 >= ini & dias_b3 <= fim])
  tibble::tibble(ciclo = ciclo, data = d, data_1t = data_1t, data_2t = data_2t,
                 pt_venceu = pt_venceu, inicio = inicio, inicio_completo = ini)
})


base <- calendario |>
  dplyr::left_join(
    prob_diaria |> dplyr::rename(data_prob = data),
    by = dplyr::join_by(ciclo, closest(data >= data_prob))
  ) |>
  dplyr::mutate(
    # Regra 4: no pregão seguinte ao 2º turno o mercado de previsão já
    # foi liquidado. O resultado (1/0) fica em p_pt_res, para a tabela das
    # noites eleitorais e a robustez R14; P(PT) fica NA, para os modelos
    # não misturarem probabilidade com resultado (incluir_resultado_2t).
    pos_2t = data > data_2t,
    p_pt_res = dplyr::if_else(pos_2t, as.numeric(pt_venceu), p_pt),
    p_pt   = dplyr::if_else(pos_2t, if (incluir_resultado_2t) as.numeric(pt_venceu) else NA_real_, p_pt),
    p_h2h  = dplyr::if_else(pos_2t, if (incluir_resultado_2t) as.numeric(pt_venceu) else NA_real_, p_h2h),
    defasagem_prob_dias = as.integer(data - data_prob),
    horario_p = dplyr::if_else(ciclo %in% ciclos_corte, "fechamento_b3", "fim_do_dia")
  ) |>
  dplyr::select(-data_prob) |>
  # Versão do fim do dia (23h59), para a robustez R7
  dplyr::left_join(
    prob_fimdia |> dplyr::select(ciclo, data_prob = data, p_pt_fimdia = p_pt, p_h2h_fimdia = p_h2h,
                                 cand_pt_dia_fimdia = cand_pt_dia),
    by = dplyr::join_by(ciclo, closest(data >= data_prob))
  ) |>
  dplyr::mutate(defasagem_prob_dias_fimdia = as.integer(data - data_prob),
                p_pt_fimdia  = dplyr::if_else(pos_2t, if (incluir_resultado_2t) as.numeric(pt_venceu) else NA_real_, p_pt_fimdia),
                p_h2h_fimdia = dplyr::if_else(pos_2t, if (incluir_resultado_2t) as.numeric(pt_venceu) else NA_real_, p_h2h_fimdia)) |>
  dplyr::select(-data_prob)

# ------------------------------------------------------------
# 4. Probabilidade das pesquisas (script 08) — opcional
# ------------------------------------------------------------

# O agregador atualiza a estimativa na data de FIM DO CAMPO, mas a
# pesquisa só é divulgada depois (em geral no dia seguinte). Para que a
# série só use o que era público no pregão, a data é deslocada em
# defasagem_divulgacao dias (00_config.R; a mesma regra do estudo de
# eventos).
if (!is.null(raw_eleitoral$pesquisas)) {
  base <- base |>
    dplyr::left_join(
      raw_eleitoral$pesquisas |>
        dplyr::transmute(ciclo, data_pesq = data + defasagem_divulgacao, p_pesq) |>
        dplyr::filter(is.finite(p_pesq)),
      by = dplyr::join_by(ciclo, closest(data >= data_pesq))
    ) |>
    # Depois do 2º turno não há pesquisa: o pregão seguinte fica NA.
    # (Pôr o resultado, 0 ou 1, faria a "pesquisa" acertar a eleição no
    # mesmo dia que o mercado e criaria correlação artificial.)
    dplyr::mutate(p_pesq = dplyr::if_else(pos_2t, NA_real_, p_pesq)) |>
    dplyr::select(-data_pesq)
} else {
  base$p_pesq <- NA_real_
}

# ------------------------------------------------------------
# 6. Mercado financeiro
# ------------------------------------------------------------

for (nome in names(yahoo)) {
  serie <- yahoo[[nome]] |>
    dplyr::filter(is.finite(fecham)) |>
    dplyr::select(data_f = data, !!nome := fecham)
  base <- base |>
    dplyr::left_join(serie, by = dplyr::join_by(closest(data >= data_f))) |>
    dplyr::mutate("{nome}_repetido" := data_f < data) |>
    dplyr::select(-data_f)
}

if (!is.null(di)) {
  base <- base |>
    dplyr::left_join(di |> dplyr::select(data, di1, di5), by = "data")
} else {
  base$di1 <- NA_real_; base$di5 <- NA_real_
}

if (!is.null(ptax)) {
  base <- base |> dplyr::left_join(ptax |> dplyr::rename(ptax = valor), by = "data")
} else base$ptax <- NA_real_

if (!is.null(dolar_b3)) {
  base <- base |> dplyr::left_join(dolar_b3 |> dplyr::select(data, usd_b3, r_dol), by = "data")
} else { base$usd_b3 <- NA_real_; base$r_dol <- NA_real_ }

base <- base |>
  dplyr::arrange(ciclo, data) |>
  dplyr::select(ciclo, data, inicio, inicio_completo, data_1t, data_2t, pt_venceu, pos_2t,
                horario_p, cand_pt_dia, cand_pt_dia_fimdia,
                p_pt, p_pt_res, p_rival, p_h2h, p_pt_fimdia, p_h2h_fimdia, p_pesq, defasagem_prob_dias,
                defasagem_prob_dias_fimdia,
                ibov, usd_b3, r_dol, usdbrl, di1, di5, ptax, spx, ust10, vix,
                dplyr::ends_with("_repetido"))

# ------------------------------------------------------------
# 7. Validações
# ------------------------------------------------------------

stopifnot(!anyDuplicated(base[c("ciclo", "data")]))

checar_intervalo <- function(x, lo, hi, nome) {
  ruim <- sum(is.finite(x) & (x < lo | x > hi))
  if (ruim > 0) warning(nome, ": ", ruim, " valores fora de [", lo, ", ", hi, "]")
}
checar_intervalo(base$p_pt, 0, 1, "p_pt")
checar_intervalo(base$di1, 0.005, 0.40, "di1 (decimal)")
checar_intervalo(base$di5, 0.005, 0.40, "di5 (decimal)")
checar_intervalo(base$usdbrl, 2, 10, "usdbrl")
checar_intervalo(base$usd_b3, 2, 10, "usd_b3")

# Dias em que a probabilidade ficou velha (mais de 3 dias sem dado)
velhas <- base |> dplyr::filter(defasagem_prob_dias > 3, data >= inicio)
if (nrow(velhas)) {
  message(nrow(velhas), " pregões com P(PT) defasada mais de 3 dias (ver cobertura_por_ciclo.csv).")
}

cobertura <- base |>
  dplyr::filter(data >= inicio) |>
  dplyr::group_by(ciclo) |>
  dplyr::summarise(
    primeiro_pregao = min(data), ultimo_pregao = max(data), pregoes = dplyr::n(),
    horario_p = dplyr::first(horario_p),
    dplyr::across(c(p_pt, p_h2h, p_pt_fimdia, p_pesq, ibov, usd_b3, usdbrl, di1, di5, ptax, spx, ust10, vix),
                  ~ sum(is.finite(.x)), .names = "n_{.col}"),
    p_pt_defasada_3d = sum(defasagem_prob_dias > 3, na.rm = TRUE),
    us_repetido = sum(spx_repetido, na.rm = TRUE),
    dolar_yahoo_faltando = sum(usdbrl_repetido, na.rm = TRUE),
    .groups = "drop"
  )

export_table(cobertura, file.path(saida_dir, "cobertura_por_ciclo.csv"))

# ------------------------------------------------------------
# 8. Dicionário de dados (fonte, unidade, frequência, período)
# ------------------------------------------------------------

periodo_txt <- function(v) {
  base |> dplyr::filter(is.finite(.data[[v]]), data >= inicio) |>
    dplyr::summarise(p = paste(format(min(data), "%d/%m/%Y"), "a", format(max(data), "%d/%m/%Y"))) |>
    dplyr::pull(p)
}

fonte_di_txt <- if (!is.null(di) && !is.null(attr(di, "fonte"))) attr(di, "fonte") else
  "B3, Taxas Referenciais (via rb3), flat-forward"
fonte_dol_txt <- if (!is.null(dolar_b3)) attr(dolar_b3, "fonte") else "não disponível"
horario_txt <- paste0("Último preço até o fechamento da B3 (",
                      if (length(ciclos_corte)) paste(sort(ciclos_corte), collapse = ", ") else "nenhum ciclo",
                      if (length(setdiff(ciclos$ciclo, ciclos_corte)))
                        paste0("); fechamento do dia em ", paste(setdiff(ciclos$ciclo, ciclos_corte), collapse = ", ")) else ")")

dicionario <- tibble::tribble(
  ~variavel, ~descricao, ~fonte, ~unidade,
  "p_pt",   "Probabilidade de vitória do candidato do PT (Haddad em 2018; Lula em 2022 e 2026)",
            paste0("Betfair Exchange (2018, 2022); Polymarket (2026). Preço normalizado entre candidatos. ", horario_txt), "probabilidade (0-1)",
  "p_h2h",  "Probabilidade PT / (PT + principal rival)", "idem", "probabilidade (0-1)",
  "p_pt_fimdia", "P(PT) com o último preço do dia (23h59), robustez", "idem, arquivos diários", "probabilidade (0-1)",
  "p_pesq", "Probabilidade de vitória do PT implícita no agregador de pesquisas (script 08)", "Pesquisas registradas no TSE; agregador local linear", "probabilidade (0-1)",
  "ibov",   "Ibovespa, fechamento", "Yahoo Finance (^BVSP)", "pontos",
  "usd_b3", "Dólar no fechamento da B3 (preço de ajuste do dólar futuro, nível encadeado)", fonte_dol_txt, "R$/US$",
  "usdbrl", "Dólar comercial, fechamento", "Yahoo Finance (BRL=X)", "R$/US$",
  "di1",    "Taxa prefixada de 1 ano (252 du)", fonte_di_txt, "decimal a.a. (base 252)",
  "di5",    "Taxa prefixada de 5 anos (1260 du)", "idem", "decimal a.a. (base 252)",
  "ptax",   "Dólar PTAX venda (fixada entre 10h e 13h)", "BCB/SGS série 1", "R$/US$",
  "spx",    "S&P 500, fechamento", "Yahoo Finance (^GSPC)", "pontos",
  "ust10",  "Treasury de 10 anos", "Yahoo Finance (^TNX)", "% a.a.",
  "vix",    "Índice de volatilidade VIX", "Yahoo Finance (^VIX)", "pontos"
) |>
  dplyr::mutate(
    frequencia = "diária (pregões da B3)",
    periodo = purrr::map_chr(variavel, ~ tryCatch(periodo_txt(.x), error = function(e) NA_character_)),
    n = purrr::map_int(variavel, ~ sum(is.finite(base[[.x]]) & base$data >= base$inicio))
  )

export_table(dicionario, file.path(saida_dir, "dicionario_dados.csv"))

# ------------------------------------------------------------
# 9. Verificações e salvar
# ------------------------------------------------------------

cat("\n========== COBERTURA ==========\n"); print(cobertura, width = Inf)
cat("\n========== MISSING ==========\n");  print(check_missing(base))

attr(base, "simulado") <- attr(yahoo, "simulado")
save_object(base, clean_data_file)

message("02_cleaning.R concluído com sucesso.")
