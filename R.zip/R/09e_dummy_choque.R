# ============================================================
# Script  : 09e_dummy_choque.R
#
# Objetivo:
#   Extensão EXPLORATÓRIA do modelo E. Pergunta: no primeiro pregão
#   após o 1º turno, os ativos têm um movimento extraordinário que
#   a variação da probabilidade e os controles não explicam?
#
#     y_t = a_ciclo + β ΔP_t + θ D_t + g'·controles_t + e_t
#
#   D_t = 1 só no primeiro pregão após o 1º turno de cada ciclo.
#     β : sensibilidade comum a todos os pregões, inclusive os três
#         eventos. Aqui a inclinação NÃO muda nos eventos; isso é o
#         modelo de interação do 09d.
#     θ : deslocamento do retorno nesses três pregões (H0: θ = 0).
#
#   O modelo E continua sendo a especificação de referência. Nada
#   nos modelos E, E1 e D, no 09d ou nas robustezes é alterado.
#
#   Modelos comparados, por ativo:
#     E                      modelo principal
#     E + D                  E com a dummy dos eventos
#     E + D + interação      o modelo do 09d (D e D×ΔP)
#     E sem os três eventos  sensibilidade amostral
#   Os três primeiros usam exatamente a amostra do modelo E; AIC e
#   BIC são comparáveis entre eles. O quarto tem outra amostra: AIC
#   e BIC dele não são comparados com os demais.
#
#   Testes (Wald com Newey-West por blocos):
#     θ = 0 no modelo E + D;
#     δ = 0 ao passar de E + D para E + D + interação.
#
#   LIMITAÇÃO: θ e δ são identificados por três pregões, um por
#   eleição. Erros-padrão, intervalos e p-valores desses termos são
#   nominais e exploratórios, não inferência confirmatória. A
#   mudança do β ao incluir a dummy não é uma contribuição causal da
#   dummy. Diagnóstico que deixa de rejeitar não valida o modelo.
#
#   Com a dummy, a soma dos resíduos dos três eventos é zero por
#   construção: ela tira a média dos erros desses pregões, mas pode
#   só redistribuir os erros entre eles (ver a tabela e a figura
#   dos resíduos nos eventos).
#
#   Eventos: os identificados e conferidos pelo 09d
#   (eventos_verificacao.csv). Se faltar ou sobrar evento em algum
#   ciclo, os modelos com dummy não são estimados para o ativo.
#
# Entrada : data/processed/model_data_daily.rds
#           output/09d_saida/eventos_verificacao.csv
#           output/09d_saida/interacao_coeficientes.csv (conferência)
#           output/06_saida/static_dynamic_models.rds (conferência)
# Saída   : output/09e_saida/dummy_modelos.csv
#           output/09e_saida/dummy_testes.csv
#           output/09e_saida/dummy_diagnosticos.csv
#           output/09e_saida/dummy_vif.csv
#           output/09e_saida/dummy_eventos_residuos_influencia.csv
#           output/09e_saida/dummy_nao_estimados.csv
#           output/09e_saida/dummy_betas.png
#           output/09e_saida/dummy_residuos_eventos.png
#           output/09e_saida/dummy_{ativo}_residuos_tempo.png
#           output/09e_saida/dummy_{ativo}_residuos_ajustados.png
#           output/09e_saida/dummy_{ativo}_acf_pacf.png
#
# Próximo script: 10_robustness.R
# ============================================================

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

saida_dir <- saida("09e")

model_data <- load_object(model_data_file)
aviso_simulado(model_data)

respostas_disp <- names(respostas)[purrr::map_lgl(names(respostas), ~ sum(is.finite(model_data[[.x]])) > 50)]
anos <- sort(unique(model_data$ciclo))

arq_eventos <- file.path(saida("09d"), "eventos_verificacao.csv")
if (!file.exists(arq_eventos))
  stop("Falta output/09d_saida/eventos_verificacao.csv: rode o 09d_interacao_eventos.R antes.", call. = FALSE)
eventos <- readr::read_csv(arq_eventos, show_col_types = FALSE) |>
  dplyr::mutate(data = as.Date(data), valido = as.logical(valido))

# ------------------------------------------------------------
# 1. Amostra do modelo E e a dummy
# ------------------------------------------------------------
# A amostra do modelo E é montada primeiro (mesma regra do 06). A
# dummy é só uma coluna a mais: nenhuma linha entra ou sai.

amostra_e <- function(y) {
  ev <- eventos |> dplyr::filter(.data$y == !!y, valido) |> dplyr::select(ciclo, data) |>
    dplyr::mutate(pos_primeiro_turno = 1L)
  model_data |>
    add_lags(c(y, "dp_pt"), 1) |>
    tidyr::drop_na(dplyr::all_of(c(y, "dp_pt", paste0(y, "_l1"), "dp_pt_l1", controles))) |>
    dplyr::left_join(ev, by = c("ciclo", "data")) |>
    dplyr::mutate(pos_primeiro_turno = tidyr::replace_na(pos_primeiro_turno, 0L),
                  dp_evento = dp_pt * pos_primeiro_turno)
}
amostras <- purrr::map(respostas_disp, amostra_e) |> setNames(respostas_disp)

# Um evento válido por ciclo, segundo a conferência do 09d
completo <- purrr::map_lgl(respostas_disp, function(y) {
  e <- eventos[eventos$y == y, ]
  nrow(e) == length(anos) && all(e$valido) && sum(amostras[[y]]$pos_primeiro_turno) == length(anos)
}) |> setNames(respostas_disp)

nao_estimados <- tibble::tibble(y = names(completo)[!completo],
                                motivo = "falta ou sobra evento válido em algum ciclo: modelos com dummy não estimados")
export_table(nao_estimados, file.path(saida_dir, "dummy_nao_estimados.csv"))
if (nrow(nao_estimados))
  warning("Sem um primeiro pregão pós-1º turno válido por ciclo em: ", paste(nao_estimados$y, collapse = ", "),
          ". Modelos com dummy não estimados nesses ativos.", call. = FALSE)

f_e   <- function(y) stats::reformulate(c("dp_pt", controles, "factor(ciclo)"), y)
f_d   <- function(y) stats::reformulate(c("dp_pt", "pos_primeiro_turno", controles, "factor(ciclo)"), y)
f_int <- function(y) stats::reformulate(c("dp_pt", "pos_primeiro_turno", "dp_evento", controles, "factor(ciclo)"), y)

rot_e <- "E"; rot_d <- "E + D"; rot_i <- "E + D + interação"; rot_s <- "E sem os três eventos"

# ------------------------------------------------------------
# 2. Estimação
# ------------------------------------------------------------

modelos <- list(); dados <- list()
for (y in respostas_disp) {
  d <- amostras[[y]]
  modelos[[paste(y, rot_e, sep = "__")]] <- lm(f_e(y), data = d); dados[[paste(y, rot_e, sep = "__")]] <- d
  if (completo[[y]]) {
    modelos[[paste(y, rot_d, sep = "__")]] <- lm(f_d(y), data = d);   dados[[paste(y, rot_d, sep = "__")]] <- d
    modelos[[paste(y, rot_i, sep = "__")]] <- lm(f_int(y), data = d); dados[[paste(y, rot_i, sep = "__")]] <- d
    ds <- d[d$pos_primeiro_turno == 0, ]
    modelos[[paste(y, rot_s, sep = "__")]] <- lm(f_e(y), data = ds);  dados[[paste(y, rot_s, sep = "__")]] <- ds
  }
}

# Conferência com o 06 (N e β do modelo E) e com o 09d (interação)
arq_06 <- file.path(saida("06"), "static_dynamic_models.rds")
if (file.exists(arq_06)) {
  m06 <- load_object(arq_06)
  for (y in respostas_disp) {
    a <- m06[[paste0("empilhado__", y, "__E")]]; b <- modelos[[paste(y, rot_e, sep = "__")]]
    stopifnot(nobs(a) == nobs(b), isTRUE(all.equal(unname(coef(a)["dp_pt"]), unname(coef(b)["dp_pt"]))))
  }
  message("N e β do modelo E conferem com o 06.")
}
arq_09d <- file.path(saida("09d"), "interacao_coeficientes.csv")
if (file.exists(arq_09d)) {
  i9 <- readr::read_csv(arq_09d, show_col_types = FALSE)
  for (y in respostas_disp[completo]) {
    b <- coef(modelos[[paste(y, rot_i, sep = "__")]]); r <- i9[i9$y == y, ]
    if (nrow(r) == 1 && isTRUE(r$estimavel))
      stopifnot(abs(b[["dp_pt"]] - r$beta_comum) < 1e-3, abs(b[["dp_evento"]] - r$delta) < 1e-3)
  }
  message("Modelo de interação confere com o 09d.")
}

info <- tibble::tibble(nome = names(modelos)) |>
  tidyr::separate(nome, c("y", "modelo"), sep = "__", remove = FALSE) |>
  dplyr::mutate(modelo = factor(modelo, c(rot_e, rot_d, rot_i, rot_s)))

# ------------------------------------------------------------
# 3. Tabela dos modelos
# ------------------------------------------------------------

tabela <- purrr::pmap_dfr(info, function(nome, y, modelo) {
  m <- modelos[[nome]]; d <- dados[[nome]]
  V <- vcov_nw(m); t <- tidy_nw(m); g <- teste_global(m); s <- summary(m)
  pega <- function(termo, col) { v <- t[[col]][t$term == termo]; if (length(v)) v else NA_real_ }
  mesma_amostra <- as.character(modelo) != rot_s
  tibble::tibble(
    y = y, modelo = as.character(modelo), n = nobs(m), n_eventos = sum(d$pos_primeiro_turno),
    beta = pega("dp_pt", "estimate"), ep_beta = pega("dp_pt", "std.error"),
    t_beta = pega("dp_pt", "statistic"), p_beta = pega("dp_pt", "p.value"),
    ic_beta_inf = pega("dp_pt", "conf.low"), ic_beta_sup = pega("dp_pt", "conf.high"),
    theta = pega("pos_primeiro_turno", "estimate"), ep_theta = pega("pos_primeiro_turno", "std.error"),
    p_theta_nominal = pega("pos_primeiro_turno", "p.value"),
    delta = pega("dp_evento", "estimate"), ep_delta = pega("dp_evento", "std.error"),
    p_delta_nominal = pega("dp_evento", "p.value"),
    r2 = s$r.squared, adj_r2 = s$adj.r.squared,
    aic = if (mesma_amostra) AIC(m) else NA_real_, bic = if (mesma_amostra) BIC(m) else NA_real_,
    aic_bic_comparaveis = mesma_amostra,
    f_global_classico = g$f_classico, p_f_global_classico = g$p_classico,
    wald_global_hac = g$f_wald_nw, p_wald_global_hac = g$p_wald_nw, gl_global = g$gl1,
    nw_lag = nw_lag_usado(V)
  )
}) |>
  dplyr::group_by(y) |>
  dplyr::mutate(
    beta_E = beta[modelo == rot_e], ep_beta_E = ep_beta[modelo == rot_e],
    # Mudança do β em relação ao modelo E. Não é contribuição causal
    # da dummy. O percentual só aparece quando o β do E supera um
    # erro-padrão em módulo (convenção descritiva).
    delta_beta_vs_E = beta - beta_E,
    delta_beta_em_ep_de_E = delta_beta_vs_E / ep_beta_E,
    delta_beta_pct = dplyr::if_else(abs(beta_E) > ep_beta_E & modelo != rot_e,
                                    100 * delta_beta_vs_E / abs(beta_E), NA_real_),
    delta_bic_vs_E = bic - bic[modelo == rot_e]
  ) |>
  dplyr::ungroup() |>
  dplyr::mutate(nota = dplyr::case_when(
    modelo == rot_e ~ "especificação de referência",
    modelo == rot_s ~ "sensibilidade amostral: AIC e BIC não comparáveis com os demais",
    TRUE ~ "exploratório: θ e δ identificados por três pregões; inferência nominal"))

export_table(tabela |> format_table(4), file.path(saida_dir, "dummy_modelos.csv"))

# ------------------------------------------------------------
# 4. Testes dos termos dos eventos (exploratórios)
# ------------------------------------------------------------

testes <- purrr::map_dfr(respostas_disp[completo], function(y) {
  md <- modelos[[paste(y, rot_d, sep = "__")]]; mi <- modelos[[paste(y, rot_i, sep = "__")]]
  wt <- wald_nw(md, "pos_primeiro_turno"); wd <- wald_nw(mi, "dp_evento")
  n_ev <- sum(amostras[[y]]$pos_primeiro_turno)
  dplyr::bind_rows(
    tibble::tibble(y = y, teste = "θ = 0 no modelo E + D", F = wt$F, p_nominal = wt$p_value, n = nobs(md),
                   nw_lag = nw_lag_usado(vcov_nw(md))),
    tibble::tibble(y = y, teste = "δ = 0 ao passar de E + D para E + D + interação", F = wd$F, p_nominal = wd$p_value,
                   n = nobs(mi), nw_lag = nw_lag_usado(vcov_nw(mi)))
  ) |> dplyr::mutate(eventos = n_ev,
                     leitura = "exploratório: identificado por três pregões")
})
export_table(testes |> format_table(4), file.path(saida_dir, "dummy_testes.csv"))

# ------------------------------------------------------------
# 5. Diagnósticos residuais: E x E + D, na mesma amostra
# ------------------------------------------------------------

info_diag <- info |> dplyr::filter(as.character(modelo) %in% c(rot_e, rot_d))

diagnosticos <- purrr::pmap_dfr(info_diag, function(nome, y, modelo) {
  m <- modelos[[nome]]; d <- dados[[nome]]
  bp <- lmtest::bptest(m)
  bg <- purrr::map_dfr(1:5, ~ bg_ciclo(m, as.character(d$ciclo), .x)) |>
    dplyr::select(ordem, p_value) |>
    tidyr::pivot_wider(names_from = ordem, values_from = p_value, names_prefix = "p_bg_ordem")
  rs <- reset_um(m, d)
  e <- residuals(m); ev <- d$pos_primeiro_turno == 1
  dplyr::bind_cols(
    tibble::tibble(y = y, modelo = as.character(modelo), n = nobs(m),
                   p_breusch_pagan = bp$p.value), bg,
    tibble::tibble(p_reset_classico = rs$p_reset, f_reset_hac = rs$f_reset_hac, p_reset_hac = rs$p_reset_hac,
                   # média condicional e dispersão dos resíduos
                   media_residuo_eventos = mean(e[ev]), soma_residuo_eventos = sum(e[ev]),
                   raiz_eqm_eventos = sqrt(mean(e[ev]^2)), dp_residuo_pregoes_comuns = stats::sd(e[!ev]))
  )
})
export_table(diagnosticos |> format_table(4), file.path(saida_dir, "dummy_diagnosticos.csv"))

# VIF / GVIF (sem limite automático; ep_inflado_pct = aumento do erro-padrão)
vif_tab <- purrr::pmap_dfr(info_diag, function(nome, y, modelo) {
  v <- tryCatch(car::vif(modelos[[nome]]), error = function(e) NULL)
  if (is.null(v)) return(NULL)
  tibble::tibble(y = y, modelo = as.character(modelo), variavel = rownames(v), gvif = v[, "GVIF"], gl = v[, "Df"],
                 gvif_ajustado = v[, "GVIF^(1/(2*Df))"], ep_inflado_pct = 100 * (gvif_ajustado - 1))
})
export_table(vif_tab |> format_table(4), file.path(saida_dir, "dummy_vif.csv"))

# Resíduos e influência nos três eventos, antes e depois da dummy
eventos_tab <- purrr::pmap_dfr(info_diag, function(nome, y, modelo) {
  m <- modelos[[nome]]; d <- dados[[nome]]; ev <- which(d$pos_primeiro_turno == 1)
  if (!length(ev)) return(NULL)
  n <- nobs(m); dfb <- dfbetas(m)[, "dp_pt"]; obs <- d[[y]][ev]
  tibble::tibble(y = y, modelo = as.character(modelo), ciclo = d$ciclo[ev], data = d$data[ev],
                 dp_pt = d$dp_pt[ev], observado = obs, ajustado = fitted(m)[ev], residuo = residuals(m)[ev],
                 residuo_em_dp_dos_comuns = residuals(m)[ev] / stats::sd(residuals(m)[-ev]),
                 leverage = hatvalues(m)[ev], cook = cooks.distance(m)[ev], cook_acima_de_4_n = cooks.distance(m)[ev] > 4 / n,
                 dfbetas_dp_pt = dfb[ev], dfbetas_acima_de_2_raiz_n = abs(dfb[ev]) > 2 / sqrt(n))
})
export_table(eventos_tab |> format_table(4), file.path(saida_dir, "dummy_eventos_residuos_influencia.csv"))

# ------------------------------------------------------------
# 6. Gráficos
# ------------------------------------------------------------

rot_y <- function(y) factor(unname(respostas[y]), unname(respostas[respostas_disp]))

# 6.1 Betas eleitorais: E, E + D e interação (pregões comuns e eventos)
arq_int <- file.path(saida("09d"), "interacao_coeficientes.csv")
gb <- tabela |> dplyr::filter(modelo %in% c(rot_e, rot_d)) |>
  dplyr::transmute(y, rotulo = modelo, b = beta, lo = ic_beta_inf, hi = ic_beta_sup, tipo = "sensibilidade comum")
gi <- tabela |> dplyr::filter(modelo == rot_i) |>
  dplyr::transmute(y, rotulo = "Interação\ncomuns (β)", b = beta, lo = ic_beta_inf, hi = ic_beta_sup,
                   tipo = "sensibilidade comum")
if (file.exists(arq_int)) {
  i9 <- readr::read_csv(arq_int, show_col_types = FALSE)
  if (all(c("beta_evento", "ic_beta_evento_inf") %in% names(i9)))
    gi <- dplyr::bind_rows(gi, i9 |> dplyr::filter(estimavel, is.finite(ic_beta_evento_inf), y %in% respostas_disp[completo]) |>
                             dplyr::transmute(y, rotulo = "Interação\neventos (β + δ)", b = beta_evento,
                                              lo = ic_beta_evento_inf, hi = ic_beta_evento_sup,
                                              tipo = "só os três eventos"))
}
gb <- dplyr::bind_rows(gb, gi) |>
  dplyr::mutate(ativo = rot_y(y),
                rotulo = factor(rotulo, c(rot_e, rot_d, "Interação\ncomuns (β)", "Interação\neventos (β + δ)")))
g1 <- ggplot2::ggplot(gb, ggplot2::aes(rotulo, b, colour = tipo)) +
  ggplot2::geom_hline(yintercept = 0, colour = "grey50") +
  ggplot2::geom_pointrange(ggplot2::aes(ymin = lo, ymax = hi), size = 0.4) +
  ggplot2::scale_colour_manual(values = c(`sensibilidade comum` = "steelblue4", `só os três eventos` = "firebrick"), name = NULL) +
  ggplot2::facet_wrap(~ ativo, scales = "free_y", nrow = 1) +
  ggplot2::labs(x = NULL, y = "β de ΔP(PT): resposta a +1 p.p.",
                title = "Sensibilidade eleitoral: modelo E, E com dummy e modelo de interação",
                subtitle = paste("Intervalos nominais de 95% (Newey-West), mesma amostra nos três modelos.",
                                 "O β dos eventos depende de três pregões e é só exploratório.")) +
  ggplot2::theme_minimal(base_size = 9) +
  ggplot2::theme(legend.position = "bottom", panel.grid.minor = ggplot2::element_blank())
save_plot(g1, file.path(saida_dir, "dummy_betas.png"), width = 12, height = 4.5)

# 6.2 Resíduos nos três eventos, E x E + D
if (nrow(eventos_tab)) {
  g3 <- eventos_tab |>
    dplyr::mutate(ativo = rot_y(y), evento = paste0("pós-1º turno\n", ciclo), modelo = factor(modelo, c(rot_e, rot_d))) |>
    ggplot2::ggplot(ggplot2::aes(evento, residuo, fill = modelo)) +
    ggplot2::geom_hline(yintercept = 0, colour = "grey50") +
    ggplot2::geom_col(position = ggplot2::position_dodge(width = 0.7), width = 0.65) +
    ggplot2::scale_fill_manual(values = c("grey45", "firebrick"), name = NULL) +
    ggplot2::facet_wrap(~ ativo, scales = "free_y", nrow = 1) +
    ggplot2::labs(x = NULL, y = "resíduo (unidade do ativo)",
                  title = "Resíduos nos três primeiros pregões pós-1º turno: modelo E e E com dummy",
                  subtitle = paste("Com a dummy, a soma dos três resíduos é zero por construção: ela tira a média do erro desses pregões,",
                                   "mas pode só redistribuir o erro entre eles.")) +
    ggplot2::theme_minimal(base_size = 9) +
    ggplot2::theme(legend.position = "bottom", panel.grid.minor = ggplot2::element_blank())
  save_plot(g3, file.path(saida_dir, "dummy_residuos_eventos.png"), width = 12, height = 4.5)
}

# 6.3 Por ativo: resíduos no tempo, resíduos x ajustados e ACF/PACF
datas_eleicao <- model_data |> dplyr::distinct(ciclo, data_1t, data_2t) |>
  tidyr::pivot_longer(c(data_1t, data_2t), names_to = "turno", values_to = "data")

for (y in respostas_disp[completo]) {
  nomes <- paste(y, c(rot_e, rot_d), sep = "__")
  r <- purrr::map_dfr(nomes, function(nm) {
    d <- dados[[nm]]
    tibble::tibble(modelo = sub(".*__", "", nm), ciclo = d$ciclo, data = d$data, evento = d$pos_primeiro_turno == 1,
                   residuo = residuals(modelos[[nm]]), ajustado = fitted(modelos[[nm]]))
  }) |> dplyr::mutate(modelo = factor(modelo, c(rot_e, rot_d)))

  g2 <- ggplot2::ggplot(r, ggplot2::aes(data, residuo)) +
    ggplot2::geom_vline(data = datas_eleicao, ggplot2::aes(xintercept = data), linetype = 2, colour = "grey55", linewidth = 0.3) +
    ggplot2::geom_hline(yintercept = 0, colour = "black", linewidth = 0.3) +
    ggplot2::geom_segment(ggplot2::aes(xend = data, y = 0, yend = residuo), colour = "grey45", linewidth = 0.25) +
    ggplot2::geom_point(data = dplyr::filter(r, evento), colour = "firebrick", size = 1.6) +
    ggplot2::facet_grid(modelo ~ ciclo, scales = "free_x") +
    ggplot2::labs(title = paste0("Resíduos no tempo: modelo E e E com dummy - ", respostas[[y]]),
                  subtitle = "Ponto vermelho: primeiro pregão após o 1º turno. Tracejado: datas do 1º e do 2º turno.",
                  x = NULL, y = "Resíduo") +
    ggplot2::theme_minimal(base_size = 9)
  save_plot(g2, file.path(saida_dir, paste0("dummy_", y, "_residuos_tempo.png")), width = 11, height = 5)

  g4 <- ggplot2::ggplot(r, ggplot2::aes(ajustado, residuo)) +
    ggplot2::geom_hline(yintercept = 0, colour = "red", linetype = 2) +
    ggplot2::geom_point(colour = "grey40", size = 0.6, alpha = 0.6) +
    ggplot2::geom_point(data = dplyr::filter(r, evento), colour = "firebrick", size = 2) +
    ggplot2::geom_smooth(method = "loess", formula = y ~ x, se = FALSE, colour = "steelblue4", linewidth = 0.5) +
    ggplot2::facet_wrap(~ modelo, scales = "free_x") +
    ggplot2::labs(title = paste0("Resíduos x valores ajustados - ", respostas[[y]]),
                  subtitle = "Ponto vermelho: primeiro pregão após o 1º turno. Linha azul: média local.",
                  x = "Valores ajustados", y = "Resíduo") +
    ggplot2::theme_minimal(base_size = 9)
  save_plot(g4, file.path(saida_dir, paste0("dummy_", y, "_residuos_ajustados.png")), width = 10, height = 4.5)

  cs <- sort(unique(as.character(r$ciclo)))
  save_base_plot({
    par(mfrow = c(4, length(cs)), mar = c(3.5, 3.5, 2.5, 0.8), cex = 0.5)
    for (md in c(rot_e, rot_d)) {
      for (k in cs) acf(r$residuo[r$modelo == md & r$ciclo == k], lag.max = 20, main = paste0("ACF - ", md, " - ", k), las = 1)
      for (k in cs) pacf(r$residuo[r$modelo == md & r$ciclo == k], lag.max = 20, main = paste0("PACF - ", md, " - ", k), las = 1)
    }
  }, filename = file.path(saida_dir, paste0("dummy_", y, "_acf_pacf.png")), width = 2700, height = 3000)
}

# ------------------------------------------------------------
# Console
# ------------------------------------------------------------

cat("\n========== MODELOS (mesma amostra em E, E + D e E + D + interação) ==========\n")
print(tabela |> dplyr::select(y, modelo, n, n_eventos, beta, ep_beta, p_beta, theta, ep_theta, p_theta_nominal,
                              adj_r2, bic, delta_bic_vs_E, delta_beta_vs_E, delta_beta_em_ep_de_E) |>
        format_table(3), n = Inf, width = Inf)
cat("\n========== TESTES DOS TERMOS DOS EVENTOS (exploratórios) ==========\n")
print(testes |> format_table(3), n = Inf, width = Inf)
cat("\n========== DIAGNÓSTICOS: E x E + D ==========\n")
print(diagnosticos |> format_table(3), n = Inf, width = Inf)
cat("\n========== RESÍDUOS E INFLUÊNCIA NOS TRÊS EVENTOS ==========\n")
print(eventos_tab |> dplyr::select(y, modelo, ciclo, data, dp_pt, residuo, residuo_em_dp_dos_comuns, cook, dfbetas_dp_pt) |>
        format_table(3), n = Inf, width = Inf)
if (nrow(nao_estimados)) { cat("\nNão estimados:\n"); print(nao_estimados, width = Inf) }
message("09e_dummy_choque.R concluído com sucesso.")
