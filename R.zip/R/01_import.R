# ============================================================
# Script  : 01_import.R
#
# Objetivo:
#   Reunir os dados brutos, sem transformação:
#
#   A. Mercados de previsão (Betfair 2018/2022, Polymarket 2026):
#      arquivos diários do TCC em data/raw/eleitoral/.
#      Opcionais: painel do script 08 (probabilidade das
#      pesquisas) e série horária da Polymarket.
#
#   B. Mercado financeiro (Yahoo Finance, via quantmod):
#      Ibovespa, dólar, S&P 500, Treasury 10 anos e VIX.
#
#   C. Curva de juros PRE da B3 (DI), via pacote rb3.
#
#   C3. Dólar: preço de ajuste do dólar futuro, do arquivo de preços
#       de mercado da B3 (BVBG-086). O ajuste é apurado entre 15h50 e
#       16h, antes do fechamento do pregão (ver o texto, subseção 3.3.3).
#
#   D. PTAX (BCB/SGS 1), para robustez do câmbio.
#
# Regra de reprodutibilidade:
#   Os downloads só são refeitos se BAIXAR_DE_NOVO = TRUE ou se o
#   arquivo bruto não existir. Assim a base fica congelada na data
#   do download (registrada em attr(x, "baixado_em")).
#
# Entrada : data/raw/eleitoral/*.csv e internet
# Saída   : data/raw/financeiro_yahoo.rds
#           data/raw/di_b3_curva_pre.rds
#           data/raw/dolar_b3.rds
#           data/raw/ptax_bcb.rds
#           data/processed/raw_eleitoral.rds
#
# Próximo script: 02_cleaning.R
# ============================================================

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

BAIXAR_DE_NOVO <- FALSE

periodo_download <- c(
  inicio = min(ciclos$inicio_completo) - margem_download_dias,
  fim    = max(ciclos$fim) + 5
)

# ------------------------------------------------------------
# A. Mercados de previsão
# ------------------------------------------------------------

ler_arquivo_eleitoral <- function(arquivo, ciclo) {
  caminho <- file.path(electoral_raw_dir, arquivo)
  if (!file.exists(caminho)) stop("Arquivo eleitoral não encontrado: ", caminho)
  readr::read_csv(caminho, show_col_types = FALSE) |>
    dplyr::transmute(
      ciclo      = ciclo,
      data       = as.Date(data_brt),
      nome_clean = nome_clean,
      prob_norm  = prob_norm
    )
}

eleitoral_diario <- purrr::map2_dfr(ciclos$arquivo, ciclos$ciclo, ler_arquivo_eleitoral)

# Painel do script 08 (opcional): probabilidade das pesquisas
# Procura o painel na pasta eleitoral e nas pastas de saída do script 08
locais_painel <- c(electoral_raw_dir, root, dirname(root),
                   file.path(root, "saida_mercados"), file.path(dirname(root), "saida_mercados"))
achados <- file.path(locais_painel, arquivo_painel_pesquisas)
caminho_painel <- if (any(file.exists(achados))) achados[file.exists(achados)][1] else achados[1]
painel_pesquisas <- if (file.exists(caminho_painel)) {
  readr::read_csv(caminho_painel, show_col_types = FALSE) |>
    dplyr::transmute(ciclo = ano, data = as.Date(data), p_pesq, q_merc_08 = q_merc)
} else {
  message("Painel das pesquisas não encontrado (", caminho_painel,
          "). Análises com pesquisas serão puladas.")
  NULL
}

# ------------------------------------------------------------
# A2. Probabilidade no horário de fechamento da B3
# ------------------------------------------------------------
# Os arquivos diários acima trazem o último preço do dia (23h59). Para
# medir a probabilidade no mesmo horário dos preços financeiros, usa-se
# o último preço até o fechamento da B3 (hora_fechamento_b3()).
#
# 2026: calculado aqui a partir da série horária da Polymarket, com a
#       mesma regra do script de extração (polymarket_2026_extracao.R):
#       preço de cada candidato no corte; dia sem atualização repete o
#       anterior; cada candidato entra do 1º preço até o fechamento do
#       seu mercado; probabilidade = preço / soma dos preços do dia.
# 2018 e 2022: arquivos arquivo_corte (00_config.R), gerados pelos
#       scripts de extração da Betfair com o mesmo corte. Se não
#       existirem, esses ciclos ficam com o fechamento do dia.

polymarket_diario_corte <- function(arq_horario, arq_mercados, ciclo) {
  fuso <- "America/Sao_Paulo"
  h <- readr::read_csv(arq_horario, show_col_types = FALSE) |>
    dplyr::mutate(
      datahora = lubridate::with_tz(as.POSIXct(as.numeric(ts), origin = "1970-01-01", tz = "UTC"), fuso),
      data = lubridate::as_date(datahora),
      corte = lubridate::make_datetime(lubridate::year(data), lubridate::month(data), lubridate::day(data),
                                       hora_fechamento_b3(data), tz = fuso),
      nome_clean = dplyr::case_when(grepl(padroes_polymarket_h2h[["pt"]], candidato) ~ "lula",
                                    grepl(padroes_polymarket_h2h[["rival"]], candidato) ~ "flavio",
                                    TRUE ~ candidato)
    )
  mercados <- if (file.exists(arq_mercados)) {
    readr::read_csv(arq_mercados, show_col_types = FALSE) |>
      dplyr::transmute(candidato,
                       fim = lubridate::as_date(lubridate::with_tz(
                         lubridate::ymd_hms(fechado_em, tz = "UTC", quiet = TRUE), fuso)))
  } else {
    message("  ", arq_mercados, " não encontrado: cada candidato vai até o último dia da série.")
    tibble::tibble(candidato = character(), fim = as.Date(character()))
  }
  # A série horária tem um registro por hora, gravado alguns segundos
  # depois da hora cheia (ex.: 17:00:41). A tolerância faz o registro da
  # própria hora do fechamento entrar no corte.
  no_corte <- h |>
    dplyr::filter(datahora <= corte + tolerancia_horaria_min * 60) |>
    dplyr::arrange(nome_clean, datahora) |>
    dplyr::group_by(nome_clean, data) |>
    dplyr::summarise(preco = dplyr::last(preco), .groups = "drop")
  periodo <- h |>
    dplyr::group_by(candidato, nome_clean) |>
    dplyr::summarise(inicio = min(data), .groups = "drop") |>
    dplyr::left_join(mercados, by = "candidato") |>
    dplyr::mutate(fim = dplyr::coalesce(fim, max(h$data)))
  periodo |>
    dplyr::mutate(data = purrr::map2(inicio, fim, ~ seq(.x, .y, by = "day"))) |>
    tidyr::unnest(data) |>
    dplyr::select(nome_clean, data) |>
    dplyr::left_join(no_corte, by = c("nome_clean", "data")) |>
    dplyr::arrange(nome_clean, data) |>
    dplyr::group_by(nome_clean) |>
    tidyr::fill(preco, .direction = "down") |>
    dplyr::group_by(data) |>
    dplyr::mutate(prob_norm = preco / sum(preco, na.rm = TRUE)) |>
    dplyr::ungroup() |>
    dplyr::filter(is.finite(prob_norm)) |>
    dplyr::transmute(ciclo = ciclo, data, nome_clean, prob_norm)
}

eleitoral_corte <- list()
for (i in seq_len(nrow(ciclos))) {
  cc <- ciclos$ciclo[i]; arq <- ciclos$arquivo_corte[i]
  if (is.na(arq)) {
    arq_h <- file.path(electoral_raw_dir, arquivo_polymarket_horario)
    if (file.exists(arq_h)) {
      eleitoral_corte[[as.character(cc)]] <- tryCatch(
        polymarket_diario_corte(arq_h, file.path(electoral_raw_dir, arquivo_polymarket_mercados), cc),
        error = function(e) { message("  ", cc, ": falha no corte da série horária (", conditionMessage(e), ")"); NULL })
    }
  } else if (file.exists(file.path(electoral_raw_dir, arq))) {
    eleitoral_corte[[as.character(cc)]] <- ler_arquivo_eleitoral(arq, cc)
  }
  status <- if (is.null(eleitoral_corte[[as.character(cc)]])) "fechamento do dia (23h59); sem arquivo no horário da B3" else "horário de fechamento da B3"
  message(">>> Probabilidade ", cc, ": ", status)
}
eleitoral_corte <- dplyr::bind_rows(eleitoral_corte)

raw_eleitoral <- list(
  diario    = eleitoral_diario,     # fechamento do dia (23h59)
  corte     = eleitoral_corte,      # horário de fechamento da B3 (ciclos disponíveis)
  pesquisas = painel_pesquisas
)

save_object(raw_eleitoral, electoral_raw_file)

# ------------------------------------------------------------
# B. Yahoo Finance
# ------------------------------------------------------------

baixar_yahoo <- function(ticker) {
  x <- quantmod::getSymbols(ticker, src = "yahoo",
                            from = periodo_download[["inicio"]],
                            to   = periodo_download[["fim"]],
                            auto.assign = FALSE, warnings = FALSE)
  tibble::tibble(
    data   = as.Date(zoo::index(x)),
    fecham = as.numeric(quantmod::Cl(x)),
    volume = suppressWarnings(as.numeric(quantmod::Vo(x)))
  )
}

if (BAIXAR_DE_NOVO || !file.exists(yahoo_raw_file)) {
  message("Baixando séries do Yahoo Finance...")
  yahoo <- purrr::imap(tickers_yahoo, function(tk, nome) {
    message("  ", nome, " (", tk, ")")
    baixar_yahoo(tk)
  })
  attr(yahoo, "baixado_em") <- Sys.time()
  attr(yahoo, "tickers") <- tickers_yahoo
  save_object(yahoo, yahoo_raw_file)
} else {
  message("Yahoo: usando arquivo já baixado (", yahoo_raw_file, ").")
  yahoo <- load_object(yahoo_raw_file)
}

# Calendário de pregões da B3 = dias com fechamento do Ibovespa
dias_b3 <- yahoo$ibov |>
  dplyr::filter(is.finite(fecham)) |>
  dplyr::pull(data)

dias_ciclos <- purrr::pmap(ciclos, function(inicio_completo, fim, ...) {
  dias_b3[dias_b3 >= inicio_completo - 10 & dias_b3 <= fim]
}) |> unlist() |> as.Date() |> unique() |> sort()

# ------------------------------------------------------------
# C. Curva PRE da B3 (DI) via rb3
# ------------------------------------------------------------
#
# rb3 baixa um arquivo por pregão (taxas referenciais da B3) e
# guarda num cache local; a primeira execução pode levar alguns
# minutos. Depois disso fica rápido.
#
# Para cada pregão interpolamos a curva (flat-forward) nos
# vértices de 252 e 1260 dias úteis.

baixar_di_rb3 <- function(datas) {
  if (!requireNamespace("rb3", quietly = TRUE)) {
    stop("Pacote rb3 não instalado (install.packages('rb3')).")
  }
  versao <- utils::packageVersion("rb3")
  message("rb3 versão ", versao)
  ns <- asNamespace("rb3")

  if (exists("fetch_marketdata", envir = ns)) {
    # API nova (rb3 >= 0.1.0): baixa um arquivo por pregão, em blocos
    options(rb3.cachedir = file.path(raw_dir, "rb3_cache"))
    blocos <- split(datas, ceiling(seq_along(datas) / 50))
    for (i in seq_along(blocos)) {
      message("  DI: bloco ", i, "/", length(blocos), " (", min(blocos[[i]]), " a ", max(blocos[[i]]), ")")
      rb3::fetch_marketdata("b3-reference-rates", refdate = blocos[[i]], throttle = TRUE)
    }
    curva <- rb3::yc_brl_get() |>
      dplyr::filter(refdate >= !!min(datas), refdate <= !!max(datas)) |>
      dplyr::collect()
  } else if (exists("yc_mget", envir = ns)) {
    # API antiga (rb3 0.0.x): uma chamada por ciclo
    message("  rb3 antigo: usando yc_mget()")
    curva <- purrr::map_dfr(split(datas, format(datas, "%Y")), function(d) {
      rb3::yc_mget(first_date = min(d), last_date = max(d))
    })
  } else {
    stop("Esta versão do rb3 (", versao, ") não tem fetch_marketdata() nem yc_mget().")
  }

  if (!nrow(curva)) stop("rb3 não devolveu nenhuma curva para as datas pedidas.")
  if (!all(c("refdate", "biz_days", "r_252") %in% names(curva))) {
    stop("Colunas inesperadas na curva do rb3: ", paste(names(curva), collapse = ", "))
  }

  out <- curva |>
    dplyr::mutate(refdate = as.Date(refdate)) |>
    dplyr::filter(refdate %in% datas) |>
    dplyr::group_by(data = refdate) |>
    dplyr::summarise(
      n_vertices = dplyr::n(),
      di1 = interp_flat_forward(biz_days, r_252, vertices_di[["di1"]]),
      di5 = interp_flat_forward(biz_days, r_252, vertices_di[["di5"]]),
      .groups = "drop"
    )
  message("  DI: ", sum(is.finite(out$di1)), " de ", length(datas), " pregões com taxa de 1 ano.")
  # Taxa em decimal (ex.: 0,13). Se vier em % (ex.: 13), converte.
  if (median(out$di1, na.rm = TRUE) > 1) out <- dplyr::mutate(out, di1 = di1 / 100, di5 = di5 / 100)
  out
}

# ------------------------------------------------------------
# C1. DI direto da B3 (sem rb3) — fonte principal
# ------------------------------------------------------------
# A B3 descontinuou a antiga página "Taxas Referenciais", que é a que
# o rb3 do CRAN usa (por isso o rb3 falhava). Os mesmos dados estão
# agora no arquivo diário "Mercado de Derivativos - Taxas de Mercado
# para Swaps" (TSaammdd.ex_), da página "Pesquisa por pregão". Este
# bloco baixa esse arquivo, abre (zip dentro de zip) e lê a curva PRE
# (DI x pré), em layout de largura fixa — mesma leitura do rb3 em
# desenvolvimento. Taxa em % a.a. base 252 com 7 casas decimais.

pasta_ts_b3 <- file.path(raw_dir, "b3_taxas_swaps")

descompactar_recursivo <- function(arq) {
  eh_zip <- function(f) identical(readBin(f, "raw", 2), charToRaw("PK")) ||
    !inherits(try(utils::unzip(f, list = TRUE), silent = TRUE), "try-error")
  if (length(arq) == 1 && file.exists(arq) && eh_zip(arq)) {
    destino <- paste0(arq, ".d")
    descompactar_recursivo(suppressWarnings(utils::unzip(arq, exdir = destino)))
  } else arq
}

ler_ts_b3 <- function(arq) {
  larguras <- readr::fwf_widths(
    c(6, 3, 2, 8, 2, 5, 15, 5, 5, 1, 14, 1, 5),
    c("seq", "seq_compl", "regtype", "refdate", "curve_type", "curve_name", "description",
      "cur_days", "biz_days", "sign", "rate", "vertex_type", "vertex_code")
  )
  x <- readr::read_fwf(arq, larguras, col_types = readr::cols(.default = "c"),
                       locale = readr::locale(encoding = "latin1"), progress = FALSE)
  tibble::tibble(
    refdate    = as.Date(x$refdate, "%Y%m%d"),
    curve_name = trimws(x$curve_name),
    biz_days   = as.integer(x$biz_days),
    r_252      = as.numeric(paste0(x$sign, x$rate)) / 1e9   # % com 7 casas -> decimal
  )
}

baixar_di_b3 <- function(datas) {
  dir.create(pasta_ts_b3, showWarnings = FALSE, recursive = TRUE)
  res <- vector("list", length(datas))
  falhas <- 0; seguidas <- 0; motivo <- ""
  baixar_um <- function(url, arq) {
    tryCatch({
      r <- httr::GET(url, httr::write_disk(arq, overwrite = TRUE), httr::timeout(30))
      if (httr::status_code(r) != 200) paste("HTTP", httr::status_code(r))
      else if (file.size(arq) <= 100) "arquivo vazio"
      else "ok"
    }, error = function(e) conditionMessage(e))
  }
  for (i in seq_along(datas)) {
    d <- datas[i]
    if (i %% 25 == 0) message("  DI B3: ", i, "/", length(datas), " pregões (", falhas, " falhas até agora)")
    arq <- file.path(pasta_ts_b3, paste0("TS", format(d, "%y%m%d"), ".zip"))
    if (!file.exists(arq) || file.size(arq) < 100) {
      url <- paste0("https://www.b3.com.br/pesquisapregao/download?filelist=TS", format(d, "%y%m%d"), ".ex_")
      st <- baixar_um(url, arq)
      if (st != "ok") {            # espera e tenta mais uma vez (a B3 limita downloads seguidos)
        Sys.sleep(if (seguidas >= 3) 30 else 3)
        st <- baixar_um(url, arq)
      }
      if (st != "ok") {
        falhas <- falhas + 1; seguidas <- seguidas + 1; unlink(arq)
        motivo <- paste(st, "em", format(d))
        message("  falha B3 (", motivo, ")")
        if (seguidas >= 15) {
          message("  15 falhas seguidas: parando. Os arquivos já baixados ficam guardados; ",
                  "rode o 01_import.R de novo mais tarde para continuar de onde parou.")
          break
        }
        next
      }
      seguidas <- 0
      Sys.sleep(1.5)   # pausa entre downloads para a B3 não bloquear
    }
    f <- descompactar_recursivo(arq)
    f <- f[file.exists(f) & !dir.exists(f)]
    if (!length(f)) { falhas <- falhas + 1; next }
    res[[i]] <- tryCatch(
      ler_ts_b3(f[1]) |> dplyr::filter(curve_name == "PRE", refdate == d),
      error = function(e) NULL
    )
    if (is.null(res[[i]]) || !nrow(res[[i]])) falhas <- falhas + 1
  }
  curva <- dplyr::bind_rows(res)
  message("  DI B3: ", dplyr::n_distinct(curva$refdate), " de ", length(datas),
          " pregões lidos (", falhas, " falhas).")
  if (!nrow(curva)) stop("Nenhum arquivo TS da B3 pôde ser lido. Último motivo: ", motivo)
  curva |>
    dplyr::group_by(data = refdate) |>
    dplyr::summarise(
      n_vertices = dplyr::n(),
      di1 = interp_flat_forward(biz_days, r_252, vertices_di[["di1"]]),
      di5 = interp_flat_forward(biz_days, r_252, vertices_di[["di5"]]),
      .groups = "drop"
    )
}

# ------------------------------------------------------------
# C2. Alternativa sem rb3: taxas do Tesouro Direto (prefixados)
# ------------------------------------------------------------
# Se o rb3 falhar, usa o CSV público do Tesouro Transparente com as
# taxas diárias dos títulos (mesmo arquivo usado pelo pacote
# GetTDData). Usa os prefixados (LTN e NTN-F), "Taxa Compra Manhã",
# e interpola (flat-forward) em 1 e 5 anos. Os dias úteis são
# aproximados por dias corridos × 252/365. É uma proxy da curva de
# juros prefixada; o texto deve dizer que a fonte é o Tesouro Direto.

url_tesouro <- "https://www.tesourotransparente.gov.br/ckan/dataset/df56aa42-484a-4a59-8184-7676580c81e3/resource/796d2059-14e9-44e3-80c9-2d9e30b405c1/download/precotaxatesourodireto.csv"

baixar_di_tesouro <- function(datas, arquivo_local = file.path(raw_dir, "precotaxatesourodireto.csv")) {
  if (!file.exists(arquivo_local)) {
    message("  Baixando CSV do Tesouro Direto (dezenas de MB)...")
    utils::download.file(url_tesouro, arquivo_local, mode = "wb", quiet = FALSE)
  }
  td <- utils::read.csv2(arquivo_local, stringsAsFactors = FALSE, check.names = FALSE)
  names(td)[1] <- sub("^\ufeff", "", names(td)[1])
  names(td) <- tolower(gsub("[ ._]+", "_", iconv(names(td), to = "ASCII//TRANSLIT")))
  precisa <- c("tipo_titulo", "data_base", "data_vencimento", "taxa_compra_manha")
  if (!all(precisa %in% names(td))) {
    stop("CSV do Tesouro com colunas inesperadas: ", paste(names(td), collapse = ", "))
  }
  td |>
    dplyr::transmute(
      tipo = trimws(tipo_titulo),
      data = as.Date(data_base, "%d/%m/%Y"),
      venc = as.Date(data_vencimento, "%d/%m/%Y"),
      taxa = suppressWarnings(as.numeric(taxa_compra_manha)) / 100
    ) |>
    dplyr::filter(tipo %in% c("Tesouro Prefixado", "Tesouro Prefixado com Juros Semestrais"),
                  data %in% datas, is.finite(taxa), taxa > 0, venc > data) |>
    dplyr::mutate(du = as.numeric(venc - data) * 252 / 365) |>
    dplyr::group_by(data) |>
    dplyr::summarise(
      n_vertices = dplyr::n(),
      di1 = interp_flat_forward(du, taxa, vertices_di[["di1"]]),
      di5 = interp_flat_forward(du, taxa, vertices_di[["di5"]]),
      .groups = "drop"
    )
}

# Um arquivo de DI salvo vazio (de uma tentativa anterior que falhou)
# não conta: nesse caso baixa de novo. Para trocar a fonte (ex.: sair
# do Tesouro Direto para a B3), apague data/raw/di_b3_curva_pre.rds.
di_valido <- file.exists(di_raw_file) &&
  sum(is.finite(load_object(di_raw_file)$di1)) > 0
if (file.exists(di_raw_file) && !di_valido) {
  message("O arquivo de DI existente está vazio; tentando baixar de novo.")
}

# Se o arquivo salvo não veio da B3 (ex.: plano B do Tesouro Direto),
# tenta de novo a B3 a cada execução; se a B3 falhar, mantém o que já
# existe.
di_eh_b3 <- di_valido && grepl("^B3", attr(load_object(di_raw_file), "fonte") %||% "B3")
if (di_valido && !di_eh_b3) {
  message("O DI salvo veio de: ", attr(load_object(di_raw_file), "fonte"),
          ". Tentando trocar pela curva da B3...")
}

if (BAIXAR_DE_NOVO || !di_valido || !di_eh_b3) {
  message("Baixando curva PRE da B3 (", length(dias_ciclos), " pregões)...")
  # 1º: arquivo diário da B3 (TS), baixado direto
  di <- tryCatch(baixar_di_b3(dias_ciclos), error = function(e) {
    message("Falha no download direto da B3: ", conditionMessage(e))
    NULL
  })
  fonte_di <- "B3 - Taxas de Mercado para Swaps (arquivo TS, curva PRE/DI x pré); flat-forward em 252 e 1260 du"
  if (!is.null(di) && sum(is.finite(di$di1)) < 0.9 * length(dias_ciclos)) {
    message("B3 incompleta (", sum(is.finite(di$di1)), " de ", length(dias_ciclos),
            " pregões). Não vou usar uma curva pela metade; rode o 01 de novo depois para completar.")
    di <- NULL
  }
  # 2º: rb3
  if (is.null(di)) {
    message("Tentando pelo rb3...")
    di_rb3 <- tryCatch(baixar_di_rb3(dias_ciclos), error = function(e) {
      message("Falha no download do DI pelo rb3: ", conditionMessage(e))
      NULL
    })
    if (!is.null(di_rb3) && sum(is.finite(di_rb3$di1)) > sum(is.finite(di$di1 %||% numeric(0)))) {
      di <- di_rb3
      fonte_di <- "B3 - curva PRE (DI x pré), via rb3; flat-forward em 252 e 1260 du"
    }
  }
  if ((is.null(di) || sum(is.finite(di$di1)) == 0) && di_valido) {
    message("B3 e rb3 falharam; mantendo o DI já salvo (", attr(load_object(di_raw_file), "fonte"), ").")
    di <- NULL
  } else if (is.null(di) || sum(is.finite(di$di1)) == 0) {
    message("Tentando a alternativa: taxas dos prefixados do Tesouro Direto...")
    di <- tryCatch(baixar_di_tesouro(dias_ciclos), error = function(e) {
      message("Falha também no Tesouro Direto: ", conditionMessage(e),
              "\nO pipeline segue sem juros. Alternativa manual: salve data/raw/di_manual.csv ",
              "com colunas data (AAAA-MM-DD), di1, di5 (taxas em decimal, ex. 0.1325).")
      NULL
    })
    fonte_di <- "Tesouro Direto (Tesouro Prefixado/LTN e NTN-F, taxa de compra manhã), flat-forward em 1 e 5 anos"
    if (!is.null(di)) message("  Tesouro: ", sum(is.finite(di$di1)), " pregões com taxa de 1 ano, ",
                              sum(is.finite(di$di5)), " com 5 anos.")
  }
  if (!is.null(di) && sum(is.finite(di$di1)) == 0) {
    message("O rb3 respondeu, mas nenhuma taxa de DI foi calculada. ",
            "Nada foi salvo. Veja as mensagens acima.")
    di <- NULL
  }
  if (!is.null(di)) {
    attr(di, "baixado_em") <- Sys.time()
    attr(di, "fonte") <- fonte_di
    save_object(di, di_raw_file)
  }
} else {
  message("DI: usando arquivo já baixado (", di_raw_file, ").")
}
if (file.exists(di_raw_file)) message(">>> Fonte do DI em uso: ", attr(load_object(di_raw_file), "fonte"))

# ------------------------------------------------------------
# C3. Dólar no fechamento: preço de ajuste do dólar futuro (B3)
# ------------------------------------------------------------
# O arquivo TS (do DI) não traz um dólar de fechamento: a curva "PTX"
# parte da PTAX (13h) e a "DOL" é cupom cambial. O fechamento está no
# arquivo diário de preços de mercado da B3 (BVBG-086, "PR"), com o
# preço de ajuste de cada contrato futuro, apurado pela B3 entre 15h50 e 16h
# (média ponderada dos negócios da janela), e não no fechamento do pregão.
#
# Para cada pregão:
#   - pega os contratos futuros de dólar (DOL + mês + ano, ex. DOLX22);
#   - descarta os que vencem em até dias_min_vencimento dias (perto do
#     vencimento o ajuste converge para a PTAX);
#   - fica com o de maior número de contratos em aberto;
#   - retorno do dia = 100 × log(ajuste de hoje / ajuste de ontem) do
#     MESMO contrato (o arquivo traz os dois), sem salto de rolagem.
# O nível (R$/US$) é encadeado a partir desses retornos, ancorado no
# ajuste do primeiro dia de cada trecho contínuo.
#
# O arquivo PR é grande (todos os ativos da B3). Depois de lido, só as
# linhas do dólar ficam guardadas (cache em data/raw/dolar_b3_cache.rds)
# e o arquivo é apagado (manter_arquivos_pr = FALSE).

pasta_pr_b3 <- file.path(raw_dir, "b3_precos_mercado")
cache_pr_file <- file.path(raw_dir, "dolar_b3_cache.rds")
manter_arquivos_pr <- FALSE
dias_min_vencimento <- 5

extrair_dol_pr <- function(arq_xml) {
  txt <- readr::read_file(arq_xml)
  tag <- function(bloco, nome) {
    stringi::stri_match_first_regex(bloco, paste0("<(?:\\w+:)?", nome, "(?:\\s[^>]*)?>([^<]*)</"))[, 2]
  }
  ini <- stringi::stri_locate_all_regex(txt, "<(?:\\w+:)?PricRpt[\\s>]")[[1]][, 1]
  fim <- stringi::stri_locate_all_regex(txt, "</(?:\\w+:)?PricRpt>")[[1]][, 2]
  tk  <- stringi::stri_locate_all_regex(txt, "<(?:\\w+:)?TckrSymb>DOL[FGHJKMNQUVXZ][0-9]{2}</")[[1]][, 1]
  if (!length(ini) || all(is.na(tk))) return(NULL)
  i <- findInterval(tk, ini)
  blocos <- stringi::stri_sub(txt, ini[i], fim[findInterval(tk, fim) + 1])
  tibble::tibble(
    data       = as.Date(tag(blocos, "Dt")),
    contrato   = tag(blocos, "TckrSymb"),
    ajuste     = as.numeric(tag(blocos, "AdjstdQt")),
    ajuste_ant = as.numeric(tag(blocos, "PrvsAdjstdQt")),
    em_aberto  = as.numeric(tag(blocos, "OpnIntrst")),
    negocios   = as.numeric(tag(blocos, "FinInstrmQty")),
    dias_venc  = as.numeric(tag(blocos, "DaysToSttlm"))
  )
}

ler_pr_dia <- function(d) {
  dir.create(pasta_pr_b3, showWarnings = FALSE, recursive = TRUE)
  arq <- file.path(pasta_pr_b3, paste0("PR", format(d, "%y%m%d"), ".zip"))
  if (!file.exists(arq) || file.size(arq) < 100) {
    url <- paste0("https://www.b3.com.br/pesquisapregao/download?filelist=PR", format(d, "%y%m%d"), ".zip")
    ok <- FALSE
    for (tentativa in 1:2) {
      ok <- tryCatch({
        r <- httr::GET(url, httr::write_disk(arq, overwrite = TRUE), httr::timeout(120))
        httr::status_code(r) == 200 && file.size(arq) > 100
      }, error = function(e) FALSE)
      if (ok) break
      Sys.sleep(5)
    }
    Sys.sleep(1.5)
    if (!ok) { unlink(arq); return(NULL) }
  }
  f <- descompactar_recursivo(arq)
  f <- f[file.exists(f) & !dir.exists(f)]
  xml <- sort(f[grepl("\\.xml$", f, ignore.case = TRUE)], decreasing = TRUE)
  out <- if (length(xml)) tryCatch(extrair_dol_pr(xml[1]), error = function(e) NULL) else NULL
  if (!manter_arquivos_pr) { unlink(arq); unlink(paste0(arq, ".d"), recursive = TRUE) }
  out
}

baixar_dolar_b3 <- function(datas) {
  cache <- if (file.exists(cache_pr_file)) readRDS(cache_pr_file) else
    tibble::tibble(data_pedida = as.Date(character()))
  faltam <- setdiff(datas, cache$data_pedida) |> as.Date(origin = "1970-01-01")
  message("  Dólar futuro B3: ", length(datas) - length(faltam), " pregões já no cache; baixando ",
          length(faltam), " arquivos de preços (PR).")
  novos <- list(); seguidas <- 0
  for (i in seq_along(faltam)) {
    d <- faltam[i]
    if (i %% 25 == 0) {
      message("  Dólar futuro B3: ", i, "/", length(faltam))
      cache <- dplyr::bind_rows(cache, dplyr::bind_rows(novos)); novos <- list()
      saveRDS(cache, cache_pr_file)                       # guarda o progresso
    }
    x <- ler_pr_dia(d)
    if (is.null(x) || !nrow(x)) {
      seguidas <- seguidas + 1
      message("  sem dólar futuro em ", format(d))
      if (seguidas >= 15) {
        message("  15 falhas seguidas: parando. O que já foi lido fica no cache; rode o 01 de novo para continuar.")
        break
      }
      next
    }
    seguidas <- 0
    novos[[length(novos) + 1]] <- dplyr::mutate(x, data_pedida = d)
  }
  cache <- dplyr::bind_rows(cache, dplyr::bind_rows(novos))
  saveRDS(cache, cache_pr_file)

  # Vencimento pelo código do contrato (DOL + letra do mês + ano): o
  # dólar futuro vence no 1º dia útil do mês. Aproxima-se pelo dia 1º;
  # contratos a até dias_min_vencimento dias do vencimento (ou vencidos)
  # ficam de fora: no vencimento o ajuste vira a PTAX e não muda.
  meses <- c(F = 1, G = 2, H = 3, J = 4, K = 5, M = 6, N = 7, Q = 8, U = 9, V = 10, X = 11, Z = 12)
  cache <- cache |>
    dplyr::mutate(vencimento = as.Date(sprintf("20%s-%02d-01", substr(contrato, 5, 6),
                                               meses[substr(contrato, 4, 4)])))
  esc <- cache |>
    dplyr::filter(data_pedida %in% datas, is.finite(ajuste), is.finite(ajuste_ant), ajuste > 0, ajuste_ant > 0,
                  as.numeric(vencimento - data_pedida) > dias_min_vencimento) |>
    dplyr::group_by(data = data_pedida) |>
    dplyr::slice_max(dplyr::coalesce(em_aberto, negocios, 0), n = 1, with_ties = FALSE) |>
    dplyr::ungroup() |>
    dplyr::arrange(data) |>
    dplyr::mutate(r_dol = 100 * log(ajuste / ajuste_ant))
  if (!nrow(esc)) stop("nenhum contrato de dólar futuro lido")

  # Nível encadeado, ancorado no ajuste do 1º dia de cada trecho contínuo
  # (dias seguidos do calendário de pregões pedido)
  # (novo trecho se faltou um pregão no meio ou se passou mais de 10 dias,
  # como entre um ciclo e outro)
  pos <- match(esc$data, sort(datas))
  trecho <- cumsum(c(TRUE, diff(pos) != 1 | as.numeric(diff(esc$data)) > 10))
  esc <- esc |>
    dplyr::mutate(trecho = trecho) |>
    dplyr::group_by(trecho) |>
    dplyr::mutate(usd_b3 = dplyr::first(ajuste) / 1000 *
                    exp((cumsum(r_dol) - dplyr::first(r_dol)) / 100)) |>
    dplyr::ungroup()
  # Escala: ajuste em pontos por US$ 1.000 (ex. 5257,1); se vier por US$ 1, não divide
  if (stats::median(esc$usd_b3) < 0.02) esc$usd_b3 <- esc$usd_b3 * 1000
  message("  Dólar futuro B3: ", nrow(esc), " de ", length(datas), " pregões (mediana R$ ",
          format(round(stats::median(esc$usd_b3), 4), decimal.mark = ","), "/US$; maior variação diária ",
          format(round(max(abs(esc$r_dol)), 2), decimal.mark = ","), "%).")
  esc <- esc |> dplyr::select(data, usd_b3, r_dol, contrato, vencimento, ajuste, ajuste_ant, em_aberto, dias_venc)
  attr(esc, "versao") <- 2
  esc
}

# Teste de consistência: em pregões seguidos o dólar quase nunca varia
# mais de 5% num dia; se isso acontece com frequência, a série está errada
dolar_ok <- function(x) {
  if (!identical(attr(x, "versao"), 2)) return(FALSE)   # versão anterior: refaz (a partir do cache, sem baixar)
  mean(!is.finite(x$r_dol) | abs(x$r_dol) > 5) <= 0.01
}
if (file.exists(dolar_raw_file) && !dolar_ok(load_object(dolar_raw_file))) {
  message("O dólar da B3 salvo é de uma versão anterior ou não passa no teste; refazendo.")
  unlink(dolar_raw_file)
}

if (BAIXAR_DE_NOVO || !file.exists(dolar_raw_file)) {
  message("Dólar no fechamento: preço de ajuste do dólar futuro da B3 (arquivos PR)...")
  dolar_b3 <- tryCatch(baixar_dolar_b3(dias_ciclos), error = function(e) {
    message("Dólar futuro da B3 não disponível: ", conditionMessage(e), ". O dólar principal fica a PTAX.")
    NULL
  })
  if (!is.null(dolar_b3) && sum(is.finite(dolar_b3$usd_b3)) < 0.9 * length(dias_ciclos)) {
    message("Dólar futuro incompleto (", nrow(dolar_b3), " de ", length(dias_ciclos),
            " pregões). Rode o 01 de novo para completar; por ora o dólar principal fica a PTAX.")
    dolar_b3 <- NULL
  }
  if (!is.null(dolar_b3) && !dolar_ok(dolar_b3)) {
    message("O dólar futuro lido não passou no teste de consistência; o dólar principal fica a PTAX.")
    dolar_b3 <- NULL
  }
  if (!is.null(dolar_b3)) {
    attr(dolar_b3, "versao") <- 2
    attr(dolar_b3, "baixado_em") <- Sys.time()
    attr(dolar_b3, "fonte") <- paste0("B3 - Arquivo de Preços de Mercado (BVBG-086): preço de ajuste do dólar futuro ",
                                      "(DOL, contrato com mais posições em aberto, fora da semana do vencimento); ",
                                      "retorno no mesmo contrato, nível encadeado")
    save_object(dolar_b3, dolar_raw_file)
  }
} else {
  message("Dólar futuro B3: usando arquivo já salvo (", dolar_raw_file, ").")
}

# ------------------------------------------------------------
# D. PTAX (BCB/SGS) — opcional
# ------------------------------------------------------------
# API pública do BCB. Consultas diárias são limitadas a 10 anos
# por chamada; aqui fazemos uma por ciclo.

baixar_sgs <- function(codigo, inicio, fim) {
  url <- sprintf(
    "https://api.bcb.gov.br/dados/serie/bcdata.sgs.%d/dados?formato=json&dataInicial=%s&dataFinal=%s",
    codigo, format(inicio, "%d/%m/%Y"), format(fim, "%d/%m/%Y")
  )
  x <- jsonlite::fromJSON(url)
  tibble::tibble(data = as.Date(x$data, "%d/%m/%Y"),
                 valor = as.numeric(x$valor))
}

if (BAIXAR_DE_NOVO || !file.exists(ptax_raw_file)) {
  ptax <- tryCatch(
    purrr::pmap_dfr(ciclos, function(inicio_completo, fim, ...) {
      baixar_sgs(sgs_ptax, inicio_completo - margem_download_dias, fim)
    }) |> dplyr::distinct(data, .keep_all = TRUE),
    error = function(e) {
      message("PTAX não baixada (", conditionMessage(e), "). Sem PTAX, o dólar principal fica vazio: troque fonte_dolar para \"yahoo\" no 00_config.R.")
      NULL
    }
  )
  if (!is.null(ptax)) {
    attr(ptax, "baixado_em") <- Sys.time()
    save_object(ptax, ptax_raw_file)
  }
}

message("01_import.R concluído com sucesso.")
