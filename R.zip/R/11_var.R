# ============================================================
# Script  : 11_var.R
#
# Objetivo:
#   VAR em variações, ciclo a ciclo. No ARDL (09) só o ativo é
#   endógeno; aqui TODAS as variáveis são endógenas e cada uma é
#   explicada pelas defasagens de todas:
#
#     Z_t = c + A_1 Z_{t-1} + ... + A_p Z_{t-p} + B·controles_t + u_t
#     Z_t = (ΔP(PT), dólar, DI 1 ano, DI 5 anos, Ibovespa)'
#
#   Papel no texto: apêndice. A precedência é lida no E1 (06) e no
#   ARDL invertido (09); o VAR confirma com todas as variáveis
#   endógenas.
#
#   O VAR responde à pergunta da retroalimentação: um choque nos
#   preços muda a probabilidade nos dias seguintes? E, ao mesmo
#   tempo, como um choque na probabilidade se propaga para os preços.
#
#   1. Defasagem p por BIC (SC), até var_max_lag.
#   2. Estimação com os controles (S&P 500, Treasury, VIX) como
#      exógenos.
#   3. Diagnósticos, cada um com a sua pergunta:
#        raízes      : o VAR é estável (a impulso-resposta converge)?
#        Portmanteau : as defasagens escolhidas bastam?
#        ARCH        : os resíduos têm volatilidade agrupada? O
#                      bootstrap do pacote vars sorteia os resíduos
#                      como independentes; se o ARCH rejeitar, os
#                      intervalos da impulso-resposta podem estar
#                      estreitos demais.
#   4. Causalidade de Granger dentro do VAR, nos dois sentidos, e
#      Wald par a par em cada equação (Newey-West).
#   5. Funções impulso-resposta ortogonalizadas (Cholesky), com IC
#      de 95% por bootstrap. Ordenação principal: P(PT) primeiro
#      (a probabilidade pode afetar os preços no mesmo dia; os preços
#      só afetam P(PT) a partir do dia seguinte). Robustez: P(PT) por
#      último, e P(PT) primeiro com dummies das noites eleitorais.
#   6. Decomposição da variância (FEVD).
#
#   Por que ciclo a ciclo: o VAR trata a amostra como uma série
#   contínua; ligar o fim de 2018 ao começo de 2021 não faz sentido.
#
# Entrada : data/processed/model_data_daily.rds
# Saída   : output/11_saida/var_*.rds, output/11_saida/var_*.csv,
#           output/11_saida/var_*.png
#
# Próximo script: 12_event_study.R
# ============================================================

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

saida_dir <- saida("11")

if (!requireNamespace("vars", quietly = TRUE)) install.packages("vars")

model_data <- load_object(model_data_file)
aviso_simulado(model_data)
set.seed(20261118)

ativos <- intersect(c("r_usd", "d_di1", "d_di5", "r_ibov"), names(model_data))
ativos <- ativos[purrr::map_lgl(ativos, ~ sum(is.finite(model_data[[.x]])) > 50)]
anos <- sort(unique(as.character(model_data$ciclo)))

ordenacoes <- list(
  "P primeiro"              = list(ordem = c("dp_pt", ativos), dummies = FALSE),
  "P por último"            = list(ordem = c(ativos, "dp_pt"), dummies = FALSE),
  "P primeiro + dummies noites" = list(ordem = c("dp_pt", ativos), dummies = TRUE)
)

# ------------------------------------------------------------
# Estimação
# ------------------------------------------------------------

estimar_var <- function(cc, spec) {
  # Pregões completos e consecutivos (ver amostra_continua no 00_functions.R)
  d <- model_data |>
    dplyr::filter(ciclo == cc) |>
    amostra_continua(c(spec$ordem, controles, "pos_1t", "pos_2t_d1"), paste("VAR", cc))
  perdas <- perdas_amostra(d)
  d <- dplyr::select(d, dplyr::all_of(c(spec$ordem, controles, "pos_1t", "pos_2t_d1")))
  Y <- as.data.frame(d[spec$ordem])
  ex <- controles
  if (spec$dummies) ex <- c(ex, names(d)[names(d) %in% c("pos_1t", "pos_2t_d1") &
                                           purrr::map_lgl(names(d), ~ sum(d[[.x]] != 0) > 0)])
  X <- as.matrix(d[ex])
  # Defasagem máxima limitada pelo tamanho do ciclo: pelo menos 3
  # observações por parâmetro em cada equação (2018 tem ~50 pregões)
  k <- ncol(Y); n_obs <- nrow(Y)
  lag_max <- max(1, min(var_max_lag, floor(((n_obs - var_max_lag) / 3 - 1 - ncol(X)) / k)))
  sel <- vars::VARselect(Y, lag.max = lag_max, type = "const", exogen = X)
  p <- max(1, unname(sel$selection["SC(n)"]))
  # do.call grava a matriz de exógenas dentro da chamada; sem isso o
  # bootstrap do vars::irf (que usa update()) não encontra o objeto X
  v <- do.call(vars::VAR, list(y = Y, p = p, type = "const", exogen = X))
  list(ciclo = cc, var = v, p = p, selecao = sel, n = nrow(Y) - p, exogenas = ex, perdas = perdas)
}

message("VAR por ciclo...")
modelos <- list()
for (cc in anos) for (nm in names(ordenacoes)) {
  r <- tryCatch(estimar_var(cc, ordenacoes[[nm]]), error = function(e) {
    message("  VAR ", cc, " / ", nm, " pulado: ", conditionMessage(e)); NULL
  })
  if (!is.null(r)) modelos[[paste(cc, nm, sep = " | ")]] <- c(r, ordenacao = nm)
}

# ------------------------------------------------------------
# 1–3. Ordens e diagnósticos
# ------------------------------------------------------------

diag_var <- purrr::imap_dfr(modelos, function(m, k) {
  v <- m$var
  pt <- tryCatch(vars::serial.test(v, lags.pt = 10, type = "PT.adjusted")$serial, error = function(e) NULL)
  ar <- tryCatch(vars::arch.test(v, lags.multi = 5, multivariate.only = TRUE)$arch.mul, error = function(e) NULL)
  tibble::tibble(
    ciclo = m$ciclo, ordenacao = m$ordenacao, p = m$p, n = m$n,
    obs_disponiveis = m$perdas$obs_disponiveis, obs_usadas = m$perdas$obs_usadas,
    obs_descartadas = m$perdas$obs_descartadas, perda_pct = m$perdas$perda_pct, lacunas = m$perdas$lacunas,
    exogenas = paste(m$exogenas, collapse = ", "),
    raiz_max = max(vars::roots(v)), estavel = max(vars::roots(v)) < 1,
    portmanteau10_p = as.numeric(pt$p.value %||% NA_real_)[1],
    arch5_p = as.numeric(ar$p.value %||% NA_real_)[1]
  )
})
export_table(diag_var |> format_table(4), file.path(saida_dir, "var_orders_diagnostics.csv"))
export_table(diag_var |> dplyr::select(ciclo, ordenacao, obs_disponiveis, obs_usadas, obs_descartadas,
                                       perda_pct, lacunas) |> format_table(2),
             file.path(saida_dir, "var_perdas_amostra_continua.csv"))

# ------------------------------------------------------------
# 4. Causalidade dentro do VAR
# ------------------------------------------------------------
# (a) Granger em bloco (vars::causality, com matriz robusta HC):
#     P(PT) -> todos os ativos; todos os ativos -> P(PT).
# (b) Wald par a par, em cada equação, com Newey-West:
#     na equação do ativo, as defasagens de ΔP(PT) são nulas?
#     na equação de ΔP(PT), as defasagens do ativo são nulas?

principais <- modelos[purrr::map_chr(modelos, "ordenacao") == "P primeiro"]

causal <- purrr::map_dfr(principais, function(m) {
  v <- m$var
  f <- function(cause, sentido) {
    r <- tryCatch(vars::causality(v, cause = cause, vcovHC = sandwich::vcovHC(v)),
                  error = function(e) tryCatch(vars::causality(v, cause = cause), error = function(e) NULL))
    if (is.null(r)) return(NULL)
    tibble::tibble(ciclo = m$ciclo, sentido = sentido,
                   F_granger = as.numeric(r$Granger$statistic)[1], p_granger = as.numeric(r$Granger$p.value)[1],
                   chi2_instantanea = as.numeric(r$Instant$statistic)[1], p_instantanea = as.numeric(r$Instant$p.value)[1])
  }
  dplyr::bind_rows(f("dp_pt", "P(PT) -> ativos"), f(ativos, "ativos -> P(PT)"))
})
export_table(causal |> format_table(4), file.path(saida_dir, "var_causality.csv"))

# Reestima a equação como lm comum (mesmos regressores do VAR), para
# poder usar o Newey-West do sandwich
refit_eq <- function(v, eq) {
  dm <- v$datamat; K <- v$K
  df <- data.frame(y = dm[[eq]], dm[, -(1:K), drop = FALSE], check.names = FALSE)
  lm(y ~ 0 + ., data = df)
}

par_a_par <- purrr::map_dfr(principais, function(m) {
  v <- m$var; p <- m$p
  eq_p <- refit_eq(v, "dp_pt")
  purrr::map_dfr(ativos, function(a) {
    eq_a <- refit_eq(v, a)
    vazio_w <- tibble::tibble(n_terms = NA, F = NA_real_, df1 = NA_real_, p_value = NA_real_)
    vazio_s <- tibble::tibble(soma = NA_real_, ep = NA_real_, p_value = NA_real_)
    w1 <- tryCatch(wald_nw(eq_a, paste0("dp_pt.l", 1:p)), error = function(e) vazio_w)
    w2 <- tryCatch(wald_nw(eq_p, paste0(a, ".l", 1:p)), error = function(e) vazio_w)
    s1 <- tryCatch(sum_nw(eq_a, paste0("dp_pt.l", 1:p)), error = function(e) vazio_s)
    s2 <- tryCatch(sum_nw(eq_p, paste0(a, ".l", 1:p)), error = function(e) vazio_s)
    tibble::tibble(
      ciclo = m$ciclo, ativo = a, p = p,
      soma_P_no_ativo = s1$soma, p_P_no_ativo = w1$p_value,
      soma_ativo_no_P = s2$soma, p_ativo_no_P = w2$p_value
    )
  })
})
export_table(par_a_par |> format_table(4), file.path(saida_dir, "var_pairwise_wald.csv"))

# ------------------------------------------------------------
# 5. Impulso-resposta
# ------------------------------------------------------------
# Choque em P(PT): reescalado para +1 p.p. no impacto (divide pela
# resposta de P(PT) a si mesma em h = 0), na mesma unidade do ARDL.
# Choque no ativo: 1 desvio-padrão do choque ortogonal do ativo
# (o desvio-padrão fica na coluna dp_choque).
# Respostas cumulativas: efeito acumulado sobre o NÍVEL do preço
# (retornos e variações somados até h).

irf_long <- function(m, impulso, respostas_, cumul) {
  ir <- vars::irf(m$var, impulse = impulso, response = respostas_, n.ahead = var_n_ahead,
                  ortho = TRUE, cumulative = cumul, boot = TRUE, runs = var_boot, ci = 0.95)
  purrr::map_dfr(c(irf = "irf", lo = "Lower", hi = "Upper"), function(k) {
    tibble::as_tibble(ir[[k]][[impulso]]) |> dplyr::mutate(h = 0:var_n_ahead) |>
      tidyr::pivot_longer(-h, names_to = "resposta", values_to = "valor")
  }, .id = "tipo") |>
    tidyr::pivot_wider(names_from = tipo, values_from = valor) |>
    dplyr::mutate(impulso = impulso, cumulativa = cumul)
}

message("Impulso-resposta com bootstrap (", var_boot, " repetições)...")
irfs <- purrr::imap_dfr(modelos, function(m, k) {
  message("  ", k)
  sd_p <- vars::irf(m$var, impulse = "dp_pt", response = "dp_pt", n.ahead = 1,
                    ortho = TRUE, boot = FALSE)$irf$dp_pt[1, 1]
  sd_a <- purrr::map_dbl(ativos, ~ vars::irf(m$var, impulse = .x, response = .x, n.ahead = 1,
                                             ortho = TRUE, boot = FALSE)$irf[[.x]][1, 1]) |>
    setNames(ativos)
  dplyr::bind_rows(
    irf_long(m, "dp_pt", ativos, FALSE), irf_long(m, "dp_pt", ativos, TRUE),
    purrr::map_dfr(ativos, ~ dplyr::bind_rows(irf_long(m, .x, "dp_pt", FALSE),
                                              irf_long(m, .x, "dp_pt", TRUE)))
  ) |>
    dplyr::mutate(
      dp_choque = dplyr::if_else(impulso == "dp_pt", sd_p, sd_a[impulso]),
      escala = dplyr::if_else(impulso == "dp_pt", 1 / sd_p, 1),
      dplyr::across(c(irf, lo, hi), ~ .x * escala),
      unidade_choque = dplyr::if_else(impulso == "dp_pt", "+1 p.p. em P(PT)", "1 d.p. do ativo"),
      ciclo = m$ciclo, ordenacao = m$ordenacao, .before = 1
    ) |>
    dplyr::select(-escala)
})
export_table(irfs |> format_table(4), file.path(saida_dir, "var_irf.csv"))

# Resumo: impacto (h=0), h=1 e acumulado em h=5 e h=10
irf_resumo <- irfs |>
  dplyr::filter((!cumulativa & h %in% 0:1) | (cumulativa & h %in% c(5, var_n_ahead))) |>
  dplyr::mutate(horizonte = dplyr::if_else(cumulativa, paste0("acumulado h=", h), paste0("h=", h)),
                signif = (lo > 0 | hi < 0)) |>
  dplyr::select(ciclo, ordenacao, impulso, resposta, horizonte, irf, lo, hi, signif, dp_choque)
export_table(irf_resumo |> format_table(4), file.path(saida_dir, "var_irf_summary.csv"))

rot <- c(dp_pt = "Δ P(PT)", respostas)
plot_irf <- function(d, titulo, ylab, faceta) {
  ggplot(d, aes(h, irf)) +
    geom_hline(yintercept = 0, colour = "grey60") +
    geom_ribbon(aes(ymin = lo, ymax = hi), fill = "steelblue", alpha = 0.25) +
    geom_line(colour = "steelblue4") + geom_point(size = 0.8, colour = "steelblue4") +
    facet_grid(stats::as.formula(paste(faceta, "~ ciclo")), scales = "free_y") +
    scale_x_continuous(breaks = seq(0, var_n_ahead, 2)) +
    labs(x = "pregões após o choque", y = ylab, title = titulo,
         subtitle = "VAR por ciclo, Cholesky com P(PT) primeiro; IC de 95% por bootstrap") +
    theme_minimal(base_size = 9)
}

g1 <- irfs |>
  dplyr::filter(ordenacao == "P primeiro", impulso == "dp_pt", cumulativa) |>
  dplyr::mutate(resposta = factor(rot[resposta], rot)) |>
  plot_irf("Resposta acumulada dos preços a um choque de +1 p.p. em P(PT)",
           "efeito acumulado", "resposta")
save_plot(g1, file.path(saida_dir, "var_irf_p_to_assets.png"), width = 9, height = 8)

g2 <- irfs |>
  dplyr::filter(ordenacao == "P primeiro", impulso != "dp_pt", !cumulativa) |>
  dplyr::mutate(impulso = factor(rot[impulso], rot)) |>
  plot_irf("Resposta de Δ P(PT) a choques nos preços (retroalimentação)",
           "p.p. de P(PT) por 1 d.p. de choque no ativo", "impulso")
save_plot(g2, file.path(saida_dir, "var_irf_assets_to_p.png"), width = 9, height = 8)

# ------------------------------------------------------------
# 6. Decomposição da variância
# ------------------------------------------------------------

fevd_tab <- purrr::map_dfr(principais, function(m) {
  fv <- vars::fevd(m$var, n.ahead = var_n_ahead)
  purrr::imap_dfr(fv, function(mat, resp) {
    tibble::as_tibble(mat) |> dplyr::mutate(h = seq_len(nrow(mat))) |>
      dplyr::filter(h %in% c(1, 5, var_n_ahead)) |>
      tidyr::pivot_longer(-h, names_to = "choque", values_to = "parcela") |>
      dplyr::mutate(ciclo = m$ciclo, resposta = resp, .before = 1)
  })
}) |>
  dplyr::filter((resposta != "dp_pt" & choque == "dp_pt") | (resposta == "dp_pt" & choque != "dp_pt"))
export_table(fevd_tab |> format_table(4), file.path(saida_dir, "var_fevd.csv"))

save_object(modelos, file.path(saida_dir, "var_models.rds"))

cat("\n========== VAR: ordens e diagnósticos ==========\n"); print(diag_var, width = Inf)
cat("\n========== VAR: causalidade (P primeiro) ==========\n"); print(causal |> format_table(3), width = Inf)
cat("\n========== VAR: Wald par a par ==========\n"); print(par_a_par |> format_table(3), width = Inf)
message("11_var.R concluído com sucesso.")
