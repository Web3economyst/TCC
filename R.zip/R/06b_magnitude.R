# ============================================================
# Script  : 06b_magnitude.R
#
# Objetivo:
#   Medir QUANTO as expectativas eleitorais movem os preços. O
#   06 dá a resposta a +1 p.p. em P(PT); aqui o β vira tamanho:
#
#   1. Parcela da variação diária explicada. Modelo E (06) com e
#      sem ΔP(PT), na mesma amostra:
#        r2_sem     : R² só com controles (e efeito fixo de ciclo)
#        r2_com     : R² com ΔP(PT)
#        r2_ganho   : r2_com − r2_sem
#        r2_parcial : (SQR_sem − SQR_com) / SQR_sem, a parcela do
#                     que os controles NÃO explicam que ΔP(PT)
#                     explica
#   2. Efeito de um movimento típico. β × desvio-padrão de ΔP(PT),
#      na unidade do ativo, e como fração do desvio-padrão do
#      próprio ativo (efeito_dp_relativo). Também para um movimento
#      grande: β × percentil 95 de |ΔP(PT)|.
#
#   3. Divisão do R² do modelo E entre três grupos (decomposição
#      de Shapley): ΔP(PT), os controles internacionais (S&P 500,
#      Treasury 10 anos e VIX, juntos) e o efeito fixo de ciclo. É a
#      divisão descrita na subseção 3.4.1 do texto. O β padronizado
#      de cada variável vai num arquivo à parte.
#
#   Tudo é calculado na amostra completa e sem as noites
#   eleitorais, empilhado e ciclo a ciclo. Os desvios-padrão são
#   os da amostra de estimação; no empilhado, calculados em torno
#   da média de cada ciclo (coerente com o efeito fixo).
#
# Entrada : data/processed/model_data_daily.rds
# Saída   : output/06b_saida/magnitude.csv
#           output/06b_saida/decomposicao_r2.csv
#           output/06b_saida/beta_padronizado.csv
#
# A Tabela 2 do texto (modelo E e modelo E + dummy) usa a mesma
# decomposição, calculada no 09e, onde está a dummy.
#
# Próximo script: 07_diagnostics.R
# ============================================================

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

saida_dir <- saida("06b")

model_data <- load_object(model_data_file)
aviso_simulado(model_data)

respostas_disp <- names(respostas)[purrr::map_lgl(names(respostas), ~ sum(is.finite(model_data[[.x]])) > 50)]
amostras <- c(list(empilhado = model_data),
              split(model_data, model_data$ciclo) |> setNames(as.character(sort(unique(model_data$ciclo)))))

# Desvio-padrão em torno da média de cada ciclo
dp_dentro <- function(v, g) {
  z <- v - ave(v, g)
  sqrt(sum(z^2) / (length(v) - dplyr::n_distinct(g)))
}

medir <- function(d, y, noites) {
  fe <- dplyr::n_distinct(d$ciclo) > 1
  # Mesma amostra do 06
  d <- d |> add_lags(c(y, "dp_pt"), 1) |>
    tidyr::drop_na(dplyr::all_of(c(y, "dp_pt", paste0(y, "_l1"), "dp_pt_l1", controles)))
  if (noites == "sem noites eleitorais") d <- dplyr::filter(d, noite_eleicao == 0)
  rhs_sem <- c(controles, if (fe) "factor(ciclo)")
  m_sem <- lm(stats::reformulate(rhs_sem, y), data = d)
  m_com <- lm(stats::reformulate(c("dp_pt", rhs_sem), y), data = d)
  t <- tidy_nw(m_com) |> dplyr::filter(term == "dp_pt")
  sq_sem <- sum(residuals(m_sem)^2); sq_com <- sum(residuals(m_com)^2)
  dp_x <- dp_dentro(d$dp_pt, d$ciclo); dp_y <- dp_dentro(d[[y]], d$ciclo)
  p95_x <- unname(stats::quantile(abs(d$dp_pt), 0.95))
  tibble::tibble(
    n = nobs(m_com), beta = t$estimate, ep = t$std.error, p_value = t$p.value,
    r2_sem = summary(m_sem)$r.squared, r2_com = summary(m_com)$r.squared,
    r2_ganho = r2_com - r2_sem, r2_parcial = (sq_sem - sq_com) / sq_sem,
    dp_dp_pt = dp_x, dp_y = dp_y,
    efeito_1dp = t$estimate * dp_x,
    efeito_1dp_inf = t$conf.low * dp_x, efeito_1dp_sup = t$conf.high * dp_x,
    efeito_dp_relativo = t$estimate * dp_x / dp_y,
    p95_abs_dp_pt = p95_x, efeito_p95 = t$estimate * p95_x
  )
}

magnitude <- tidyr::expand_grid(amostra = names(amostras), y = respostas_disp,
                                noites = c("amostra completa", "sem noites eleitorais")) |>
  dplyr::mutate(res = purrr::pmap(list(amostra, y, noites), function(a, y, nt) medir(amostras[[a]], y, nt))) |>
  tidyr::unnest(res)

export_table(magnitude |> format_table(4), file.path(saida_dir, "magnitude.csv"))

cat("\n========== MAGNITUDE (empilhado) ==========\n")
print(magnitude |> dplyr::filter(amostra == "empilhado") |>
        dplyr::select(y, noites, n, beta, r2_sem, r2_com, r2_ganho, r2_parcial,
                      dp_dp_pt, efeito_1dp, efeito_dp_relativo, efeito_p95) |>
        format_table(3), n = Inf, width = Inf)

# ------------------------------------------------------------
# 3. Divisão do R² entre ΔP(PT), controles e ciclo; β padronizado
# ------------------------------------------------------------
# Decomposição de Shapley (LMG): o R² do modelo E é repartido entre
# três grupos de regressores, como na subseção 3.4.1 do texto:
#   dp_pt      ΔP(PT)
#   controles  S&P 500, Treasury 10 anos e VIX, como um bloco
#   ciclo      efeito fixo de ciclo (só no empilhado)
# A parcela de cada grupo é o ganho médio de R² ao incluí-lo, sobre
# todas as ordens possíveis de entrada; as parcelas somam o R² do
# modelo E. A função shapley_r2() está no 00_functions.R.
#
# β padronizado: β × DP(x) / DP(y), com os desvios-padrão em torno
# da média de cada ciclo (como na seção 1). Mede quanto y se move,
# em desvios-padrão, quando x se move um desvio-padrão, com as
# demais variáveis fixas.
#
# Mesma amostra do 06 e da seção 1, empilhado e ciclo a ciclo, com
# e sem as noites eleitorais.

amostra_06 <- function(d, y, noites) {
  d <- d |> add_lags(c(y, "dp_pt"), 1) |>
    tidyr::drop_na(dplyr::all_of(c(y, "dp_pt", paste0(y, "_l1"), "dp_pt_l1", controles)))
  if (noites == "sem noites eleitorais") d <- dplyr::filter(d, noite_eleicao == 0)
  d
}

decompor <- function(d, y, noites) {
  fe <- dplyr::n_distinct(d$ciclo) > 1
  d <- amostra_06(d, y, noites)
  grupos <- c(list(dp_pt = "dp_pt", controles = controles), if (fe) list(ciclo = "factor(ciclo)"))
  m <- lm(stats::reformulate(unlist(grupos), y), data = d)
  parcela <- shapley_r2(d, y, grupos)
  tibble::tibble(
    n = nobs(m), r2_modelo = summary(m)$r.squared,
    grupo = names(parcela),
    parcela_r2 = unname(parcela),                 # escala 0-1
    parcela_pp = 100 * unname(parcela),           # pontos percentuais do R² (como na Tabela 2)
    pct_do_r2 = 100 * unname(parcela) / summary(m)$r.squared
  )
}

padronizar <- function(d, y, noites) {
  fe <- dplyr::n_distinct(d$ciclo) > 1
  d <- amostra_06(d, y, noites)
  regressores <- c("dp_pt", controles)
  m <- lm(stats::reformulate(c(regressores, if (fe) "factor(ciclo)"), y), data = d)
  dp_y <- dp_dentro(d[[y]], d$ciclo)
  tibble::tibble(variavel = regressores,
                 beta = unname(coef(m)[regressores]),
                 beta_padronizado = vapply(regressores, function(x)
                   unname(coef(m)[x]) * dp_dentro(d[[x]], d$ciclo) / dp_y, numeric(1)))
}

grade <- tidyr::expand_grid(amostra = names(amostras), y = respostas_disp,
                            noites = c("amostra completa", "sem noites eleitorais"))

decomposicao <- grade |>
  dplyr::mutate(res = purrr::pmap(list(amostra, y, noites), function(a, y, nt) decompor(amostras[[a]], y, nt))) |>
  tidyr::unnest(res)
beta_pad <- grade |>
  dplyr::mutate(res = purrr::pmap(list(amostra, y, noites), function(a, y, nt) padronizar(amostras[[a]], y, nt))) |>
  tidyr::unnest(res)

export_table(decomposicao |> format_table(4), file.path(saida_dir, "decomposicao_r2.csv"))
export_table(beta_pad |> format_table(4), file.path(saida_dir, "beta_padronizado.csv"))

cat("\n========== DIVISÃO DO R² (empilhado, em p.p.) ==========\n")
print(decomposicao |> dplyr::filter(amostra == "empilhado") |>
        dplyr::select(y, noites, grupo, parcela_pp, pct_do_r2) |>
        format_table(2), n = Inf, width = Inf)
message("06b_magnitude.R concluído com sucesso.")
