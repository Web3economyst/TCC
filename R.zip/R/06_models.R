# ============================================================
# Script  : 06_models.R
#
# Objetivo:
#   Apresentar, lado a lado, a especificação principal e duas
#   variações com uma defasagem, para cada resposta do mercado
#   financeiro. As três são casos particulares do ARDL do 09, em
#   que o BIC escolheu p = q = 0 (a especificação E):
#
#   (E) estática, especificação principal = ARDL(0,0):
#       y_t = a_ciclo + b·ΔP(PT)_t + g'·controles_t + e_t
#
#   (E1) com ΔP(PT)_{t-1} = ARDL(0,1):
#       y_t = a_ciclo + b0·ΔP(PT)_t + b1·ΔP(PT)_{t-1} + g'·controles_t + e_t
#       Testa se a probabilidade do pregão anterior ainda explica
#       o preço, isto é, se a informação chega com atraso (H2).
#
#   (D) dinâmica, com y_{t-1} = ARDL(1,0):
#       y_t = a_ciclo + r·y_{t-1} + b·ΔP(PT)_t + g'·controles_t + e_t
#
#   y ∈ {r_ibov, r_usd, d_di1, d_di5}; controles = S&P 500,
#   Treasury 10 anos e VIX. a_ciclo = efeito fixo de ciclo
#   (cada eleição tem sua média). Erros-padrão Newey-West.
#
#   Interpretação de b: variação de y associada a +1 p.p. na
#   probabilidade de vitória do PT, controlando o cenário externo.
#   É uma sensibilidade condicional, e não um efeito causal.
#
# Entrada : data/processed/model_data_daily.rds
# Saída   : output/06_saida/static_dynamic_models.rds
#           output/06_saida/static_dynamic_*.csv
#           output/06_saida/modelo_E_completo.csv
#           output/06_saida/modelo_E_summary.txt
#
# Próximo script: 06b_magnitude.R
# ============================================================

source("R/00_paths.R")
source("R/00_config.R")
source("R/00_packages.R")
source("R/00_functions.R")

saida_dir <- saida("06")

model_data <- load_object(model_data_file)
aviso_simulado(model_data)

respostas_disp <- names(respostas)[purrr::map_lgl(names(respostas), ~ sum(is.finite(model_data[[.x]])) > 50)]
amostras <- c(list(empilhado = model_data),
              split(model_data, model_data$ciclo) |> setNames(as.character(sort(unique(model_data$ciclo)))))

# ------------------------------------------------------------
# 1. Estimar
# ------------------------------------------------------------

estimar <- function(d, y, espec) {
  fe <- dplyr::n_distinct(d$ciclo) > 1
  # Mesma amostra nas três especificações (para comparar R², AIC, BIC)
  d <- d |> add_lags(c(y, "dp_pt"), 1) |>
    tidyr::drop_na(dplyr::all_of(c(y, "dp_pt", paste0(y, "_l1"), "dp_pt_l1", controles)))
  rhs <- switch(espec,
                E  = c("dp_pt", controles),
                E1 = c("dp_pt", "dp_pt_l1", controles),
                D  = c(paste0(y, "_l1"), "dp_pt", controles)
  )
  if (fe) rhs <- c(rhs, "factor(ciclo)")
  lm(as.formula(paste(y, "~", paste(rhs, collapse = " + "))), data = d)
}

grade <- tidyr::expand_grid(amostra = names(amostras), y = respostas_disp,
                            espec = c("E", "E1", "D"))

modelos <- purrr::pmap(grade, function(amostra, y, espec) estimar(amostras[[amostra]], y, espec))
names(modelos) <- paste(grade$amostra, grade$y, grade$espec, sep = "__")

# ------------------------------------------------------------
# 2. Coeficientes (MQO e Newey-West)
# ------------------------------------------------------------

coeficientes <- purrr::imap_dfr(modelos, function(m, nm) {
  p <- strsplit(nm, "__")[[1]]
  dplyr::left_join(
    broom::tidy(m) |> dplyr::select(term, estimate, se_ols = std.error, p_ols = p.value),
    tidy_nw(m) |> dplyr::select(term, se_nw = std.error, p_nw = p.value, conf.low, conf.high),
    by = "term"
  ) |>
    dplyr::mutate(amostra = p[1], y = p[2], espec = p[3], .before = 1)
}) |>
  dplyr::filter(!grepl("factor\\(ciclo\\)", term))

export_table(coeficientes |> format_table(4),
             file.path(saida_dir, "static_dynamic_coefficients.csv"))

# ------------------------------------------------------------
# 3. Ajuste
# ------------------------------------------------------------

ajuste <- purrr::imap_dfr(modelos, function(m, nm) {
  p <- strsplit(nm, "__")[[1]]
  broom::glance(m) |>
    dplyr::transmute(amostra = p[1], y = p[2], espec = p[3], r2 = r.squared,
                     adj_r2 = adj.r.squared, sigma, AIC, BIC, nobs)
})

export_table(ajuste |> format_table(), file.path(saida_dir, "static_dynamic_fit.csv"))

# ------------------------------------------------------------
# 3b. Testes globais
# ------------------------------------------------------------
# H0: todos os coeficientes de inclinação são zero (intercepto e
# efeitos fixos de ciclo fora da hipótese). F clássico do MQO
# (descritivo) e Wald com Newey-West (ver teste_global no
# 00_functions.R). Não é o teste do coeficiente de ΔP(PT), que
# está em static_dynamic_coefficients.csv.

testes_globais <- purrr::imap_dfr(modelos, function(m, nm) {
  p <- strsplit(nm, "__")[[1]]
  teste_global(m) |> dplyr::mutate(amostra = p[1], y = p[2], espec = p[3], .before = 1)
})

export_table(testes_globais |> format_table(4),
             file.path(saida_dir, "static_dynamic_global_tests.csv"))

# ------------------------------------------------------------
# 3c. Modelo E completo
# ------------------------------------------------------------
# Todos os coeficientes do modelo E empilhado (ΔP(PT), controles,
# intercepto e efeitos fixos de ciclo), com erros-padrão do MQO e
# de Newey-West, e o summary() de cada ativo em texto.

modelos_e <- modelos[grepl("^empilhado__.*__E$", names(modelos))]

modelo_e_completo <- purrr::imap_dfr(modelos_e, function(m, nm) {
  dplyr::left_join(
    broom::tidy(m) |> dplyr::select(term, estimate, se_ols = std.error, t_ols = statistic, p_ols = p.value),
    tidy_nw(m) |> dplyr::select(term, se_nw = std.error, t_nw = statistic, p_nw = p.value, conf.low, conf.high),
    by = "term"
  ) |>
    dplyr::mutate(y = strsplit(nm, "__")[[1]][2], .before = 1)
})

export_table(modelo_e_completo |> format_table(4),
             file.path(saida_dir, "modelo_E_completo.csv"))

summary_e <- unlist(purrr::imap(modelos_e, function(m, nm) {
  V <- vcov_nw(m)
  m$call <- call("lm", formula = stats::formula(m))
  c(paste0("==================== Modelo E empilhado: ", strsplit(nm, "__")[[1]][2], " ===================="),
    capture.output(summary(m)),
    paste0("Coeficientes com erros-padrão Newey-West (", nw_lag_usado(V),
           " defasagens, calculado dentro de cada ciclo):"),
    capture.output(lmtest::coeftest(m, vcov. = V)),
    "")
}))

writeLines(summary_e, file.path(saida_dir, "modelo_E_summary.txt"))
cat("", summary_e, sep = "\n")

# ------------------------------------------------------------
# 4. Tabela-resumo do coeficiente de interesse
# ------------------------------------------------------------
# Magnitude econômica: resposta a +10 p.p. em P(PT).

# Modelo D: efeito acumulado de uma mudança isolada em ΔP(PT), b / (1 - r)
acumulado_d <- coeficientes |>
  dplyr::filter(espec == "D") |>
  dplyr::group_by(amostra, y) |>
  dplyr::summarise(
    efeito_acumulado = estimate[term == "dp_pt"] / (1 - estimate[term == paste0(y[1], "_l1")]),
    .groups = "drop"
  ) |>
  dplyr::mutate(espec = "D", term = "dp_pt")

resumo_dp <- coeficientes |>
  dplyr::filter(term %in% c("dp_pt", "dp_pt_l1") | grepl("_l1$", term) & espec == "D") |>
  dplyr::mutate(efeito_10pp = dplyr::if_else(grepl("^dp_pt", term), 10 * estimate, NA_real_)) |>
  dplyr::left_join(acumulado_d, by = c("amostra", "y", "espec", "term")) |>
  dplyr::left_join(ajuste |> dplyr::select(amostra, y, espec, adj_r2, nobs),
                   by = c("amostra", "y", "espec")) |>
  dplyr::mutate(sig = dplyr::case_when(p_nw < .01 ~ "***", p_nw < .05 ~ "**",
                                       p_nw < .10 ~ "*", TRUE ~ ""))

export_table(resumo_dp |> format_table(4),
             file.path(saida_dir, "static_dynamic_summary.csv"))

save_object(modelos, file.path(saida_dir, "static_dynamic_models.rds"))

cat("\n========== ΔP(PT): EMPILHADO ==========\n")
print(resumo_dp |> dplyr::filter(amostra == "empilhado") |>
        dplyr::select(y, espec, term, estimate, se_nw, p_nw, sig, efeito_10pp, efeito_acumulado, adj_r2, nobs),
      n = Inf)
cat("\n========== TESTES GLOBAIS (inclinações = 0): EMPILHADO ==========\n")
print(testes_globais |> dplyr::filter(amostra == "empilhado") |> format_table(3), n = Inf, width = Inf)
message("06_models.R concluído com sucesso.")