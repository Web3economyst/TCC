# ============================================================
# ESTIMADOR GERAL LOCAL LINEAR - ELEIÇÕES 2018 / 2022 / 2026
# ============================================================
# Escolha 2018, 2022 ou 2026 em ANO_ANALISE.
# Execute este arquivo para a análise principal comum às três eleições.
# As análises exploratórias específicas ficam nos arquivos auxiliares.
#
# Arquitetura:
#   1. Cada eleição é preparada a partir de sua própria base.
#   2. A preparação transforma as bases para uma estrutura comum.
#   3. A partir daí, o estimador local linear é idêntico.
#
# Estrutura padronizada usada pelo estimador:
#   serie_1T / serie_2T:
#     data_referencia
#     cand_a_total
#     cand_b_total
#     cand_a_validos
#     cand_b_validos
#     margem_total
#     margem_validos
#     x
#
# Para 2018, 2022 e 2026, cada eleição é carregada de sua
# própria base e transformada para a mesma estrutura padronizada.
# ============================================================

library(tidyverse)
library(lubridate)
library(stringr)

# Rode com a pasta preparacao_dados como diretório de trabalho
# (Session > Set Working Directory > To Source File Location).

# ------------------------------------------------------------
# 0. ESCOLHA DA ELEIÇÃO
# ------------------------------------------------------------

ANO_ANALISE <- 2026  # 2018, 2022 ou 2026

config <- list(
  `2018` = list(
    data_1T = as.Date("2018-10-07"),
    data_2T = as.Date("2018-10-28"),
    cand_a = "haddad",
    cand_b = "bolsonaro",
    nome_a = "Haddad",
    nome_b = "Bolsonaro"
  ),
  `2022` = list(
    data_1T = as.Date("2022-10-02"),
    data_2T = as.Date("2022-10-30"),
    cand_a = "lula",
    cand_b = "bolsonaro",
    nome_a = "Lula",
    nome_b = "Bolsonaro"
  ),
  `2026` = list(
    data_1T = as.Date("2026-10-04"),
    data_2T = as.Date("2026-10-25"),
    cand_a = "lula",
    cand_b = "flavio",
    nome_a = "Lula",
    nome_b = "Flávio"
  )
)

cfg <- config[[as.character(ANO_ANALISE)]]

if (is.null(cfg)) {
  stop("ANO_ANALISE deve ser 2018, 2022 ou 2026.")
}

# ------------------------------------------------------------
# DATAS FIXAS DE INÍCIO DA VALIDAÇÃO
# Definidas por ano e turno com base nas análises exploratórias.
#
# 2018:
#   1T: 01/09/2018
#   2T: 01/07/2018
#   Datas escolhidas entre as janelas testadas no arquivo
#   05_analises_exploratorias_2018.R.
#
# 2022:
#   1T e 2T: 01/05/2022
#   Data utilizada nos testes do arquivo
#   05_analises_exploratorias_2022.R.
#
# 2026:
#   1T e 2T: 01/05/2022
#   Data utilizada nos testes do arquivo
#   05_analises_exploratorias_2022.R.
# ------------------------------------------------------------

datas_validacao <- list(
  `2018` = list(
    inicio_teste_1T = as.Date("2018-09-01"),
    inicio_teste_2T = as.Date("2018-07-01")
  ),
  `2022` = list(
    inicio_teste_1T = as.Date("2022-05-01"),
    inicio_teste_2T = as.Date("2022-05-01")
  ),
  `2026` = list(
    inicio_teste_1T = as.Date("2026-05-01"),
    inicio_teste_2T = as.Date("2026-05-01")
  )
)



datas_ano <- datas_validacao[[as.character(ANO_ANALISE)]]

if (is.null(datas_ano)) {
  stop(
    "Datas fixas de validação ainda não definidas para ",
    ANO_ANALISE, "."
  )
}

inicio_teste_1T <- datas_ano$inicio_teste_1T
inicio_teste_2T <- datas_ano$inicio_teste_2T

cand_a <- cfg$cand_a
cand_b <- cfg$cand_b
nome_a <- cfg$nome_a
nome_b <- cfg$nome_b

# ------------------------------------------------------------
# 1. PADRONIZAÇÃO DO INSTITUTO
# ------------------------------------------------------------

padronizar_instituto <- function(x) {
  case_when(
    str_detect(x, regex("Paraná", ignore_case = TRUE)) ~ "Paraná",
    str_detect(x, regex("Atlas", ignore_case = TRUE)) ~ "AtlasIntel",
    str_detect(x, regex("Quaest", ignore_case = TRUE)) ~ "Quaest",
    str_detect(x, regex("Futura", ignore_case = TRUE)) ~ "Futura",
    str_detect(x, regex("Ideia", ignore_case = TRUE)) ~ "Ideia",
    str_detect(x, regex("Real ?Time|RealTime", ignore_case = TRUE)) ~ "Real Time Big Data",
    str_detect(x, regex("Datafolha", ignore_case = TRUE)) ~ "Datafolha",
    str_detect(x, regex("Gerp", ignore_case = TRUE)) ~ "GERP",
    str_detect(x, regex("Verit", ignore_case = TRUE)) ~ "Veritá",
    str_detect(x, regex("FSB|Nexus", ignore_case = TRUE)) ~ "BTG/FSB",
    TRUE ~ x
  )
}

# ------------------------------------------------------------
# 2. FUNÇÕES AUXILIARES DE PREPARAÇÃO
# ------------------------------------------------------------

# Converte percentuais da base bruta (0--100) para proporções (0--1).
# Mantemos os nomes das variáveis explícitos para evitar conversões
# acidentais em objetos que já estejam em proporção.

preparar_datas <- function(dados, data_eleicao) {
  dados %>%
    mutate(
      data_inicio = as.Date(data_inicio),
      data_fim = as.Date(data_fim),
      data_referencia = data_fim,
      dias_campo = as.integer(data_fim - data_inicio) + 1L,
      dias_ate_eleicao = as.integer(data_eleicao - data_referencia),
      instituto = padronizar_instituto(instituto)
    ) %>%
    filter(data_referencia < data_eleicao)
}

# Média temporal dos pontos de pesquisa.
# A agregação é feita primeiro no nível diário e depois o estimador
# usa a série resultante.

construir_serie <- function(dados) {
  dados %>%
    group_by(data_referencia) %>%
    summarise(
      cand_a_total = mean(cand_a_total, na.rm = TRUE),
      cand_b_total = mean(cand_b_total, na.rm = TRUE),
      cand_a_validos = mean(cand_a_validos, na.rm = TRUE),
      cand_b_validos = mean(cand_b_validos, na.rm = TRUE),
      margem_total = mean(margem_total, na.rm = TRUE),
      margem_validos = mean(margem_validos, na.rm = TRUE),
      n_pesquisas = n(),
      .groups = "drop"
    ) %>%
    mutate(
      x = as.numeric(data_referencia)
    )
}

# ------------------------------------------------------------
# 3. CARREGAMENTO DAS BASES
# ------------------------------------------------------------

if (ANO_ANALISE == 2018) {
  
  source("01_base_2018.R")
  
  if (!exists("base_1T_raw") || !exists("base_2T_raw")) {
    stop(
      "Para 2018, 01_base_2018.R deve produzir " ,
      "base_1T_raw e base_2T_raw."
    )
  }
  
} else if (ANO_ANALISE == 2022) {
  
  source("02_base_2022.R")
  
  if (!exists("base_1T_raw") || !exists("base_2T_raw")) {
    stop(
      "Para 2022, 02_base_2022.R deve produzir " ,
      "base_1T_raw e base_2T_raw."
    )
  }
  
} else if (ANO_ANALISE == 2026) {
  
  # A base 2026 é construída em 03_base_2026.R.
  # Ela fornece:
  #   base_1T_raw = 1º turno em formato largo;
  #   base_2T_raw = 2º turno em formato longo, com duas linhas por pesquisa.
  source("03_base_2026.R")
  
  if (!exists("base_1T_raw") || !exists("base_2T_raw")) {
    stop(
      "Para 2026, 03_base_2026.R deve produzir ",
      "base_1T_raw e base_2T_raw."
    )
  }
}

# ------------------------------------------------------------
# 4. PREPARAÇÃO ESPECÍFICA DE 2018
# ------------------------------------------------------------

if (ANO_ANALISE == 2018) {
  
  # ----------------------------------------------------------
  # 4.1 Primeiro turno
  # ----------------------------------------------------------
  
  base_1T <- preparar_datas(
    base_1T_raw,
    cfg$data_1T
  ) %>%
    mutate(
      # Percentuais da base original estão em pontos percentuais.
      # Convertendo para proporções antes de qualquer estimação.
      across(
        all_of(c(
          "haddad", "gomes", "silva", "meirelles",
          "dias", "alckmin", "amoedo", "bolsonaro", "outros"
        )),
        ~ .x / 100
      )
    )
  
  # Para votos válidos, usamos os candidatos individualizados e "outros".
  # Abstencao_nao_decidiu permanece fora do denominador.
  candidatos_1T <- c(
    "haddad", "gomes", "silva", "meirelles",
    "dias", "alckmin", "amoedo", "bolsonaro", "outros"
  )
  
  base_1T <- base_1T %>%
    mutate(
      total_candidatos = rowSums(
        across(all_of(candidatos_1T)),
        na.rm = TRUE
      ),
      cand_a_total = .data[[cand_a]],
      cand_b_total = .data[[cand_b]],
      cand_a_validos = if_else(
        total_candidatos > 0,
        .data[[cand_a]] / total_candidatos,
        NA_real_
      ),
      cand_b_validos = if_else(
        total_candidatos > 0,
        .data[[cand_b]] / total_candidatos,
        NA_real_
      ),
      margem_total = cand_a_total - cand_b_total,
      margem_validos = cand_a_validos - cand_b_validos
    )
  
  serie_1T <- construir_serie(base_1T)
  
  # ----------------------------------------------------------
  # 4.2 Segundo turno
  # ----------------------------------------------------------
  
  base_2T <- preparar_datas(
    base_2T_raw,
    cfg$data_2T
  ) %>%
    mutate(
      nome_candidato = str_to_lower(str_trim(nome_candidato)),
      nome_candidato = case_when(
        nome_candidato == "bolsonaro" ~ "bolsonaro",
        nome_candidato == "haddad" ~ "haddad",
        TRUE ~ nome_candidato
      ),
      percentual = percentual / 100
    )
  
  base_2T_wide <- base_2T %>%
    filter(nome_candidato %in% c(cand_a, cand_b)) %>%
    select(
      instituto,
      data_inicio,
      data_fim,
      data_referencia,
      amostra,
      margem_erro,
      registro_tse,
      nome_candidato,
      percentual
    ) %>%
    pivot_wider(
      id_cols = c(
        instituto,
        data_inicio,
        data_fim,
        data_referencia,
        amostra,
        margem_erro,
        registro_tse
      ),
      names_from = nome_candidato,
      values_from = percentual
    ) %>%
    mutate(
      total_2T = .data[[cand_a]] + .data[[cand_b]],
      cand_a_total = .data[[cand_a]],
      cand_b_total = .data[[cand_b]],
      cand_a_validos = if_else(
        total_2T > 0,
        .data[[cand_a]] / total_2T,
        NA_real_
      ),
      cand_b_validos = if_else(
        total_2T > 0,
        .data[[cand_b]] / total_2T,
        NA_real_
      ),
      margem_total = cand_a_total - cand_b_total,
      margem_validos = cand_a_validos - cand_b_validos,
      x = as.numeric(data_referencia)
    ) %>%
    filter(
      is.finite(cand_a_total),
      is.finite(cand_b_total)
    )
  
  serie_2T <- construir_serie(base_2T_wide)
}

# ------------------------------------------------------------
# 5. PREPARAÇÃO ESPECÍFICA DE 2022
# ------------------------------------------------------------

if (ANO_ANALISE == 2022) {
  
  # A base 2022 tem uma estrutura diferente da base 2018:
  # o 1T é originalmente largo, com uma coluna para cada candidato,
  # enquanto o objeto final da base também contém a versão longa.
  # Aqui usamos diretamente base_1T_raw e base_2T_raw para manter
  # a preparação do estimador independente das etapas metodológicas
  # adicionais existentes em 02_base_2022.R.
  
  # ----------------------------------------------------------
  # 5.1 Primeiro turno
  # ----------------------------------------------------------
  
  base_1T <- preparar_datas(
    base_1T_raw,
    cfg$data_1T
  ) %>%
    mutate(
      across(
        all_of(c(
          "lula", "bolsonaro", "ciro", "tebet", "soraya",
          "felipe_davila", "kelmon", "pericles", "sofia_manzano",
          "vera_lucia", "eymael", "outros_branco_nulo",
          "indecisos_nao_sabe"
        )),
        ~ .x / 100
      )
    )
  
  # Somente candidatos entram no denominador de votos válidos.
  # "outros_branco_nulo" e "indecisos_nao_sabe" ficam fora.
  candidatos_1T <- c(
    "lula", "bolsonaro", "ciro", "tebet", "soraya",
    "felipe_davila", "kelmon", "pericles", "sofia_manzano",
    "vera_lucia", "eymael"
  )
  
  base_1T <- base_1T %>%
    mutate(
      total_candidatos = rowSums(
        across(all_of(candidatos_1T)),
        na.rm = TRUE
      ),
      cand_a_total = .data[[cand_a]],
      cand_b_total = .data[[cand_b]],
      cand_a_validos = if_else(
        total_candidatos > 0,
        .data[[cand_a]] / total_candidatos,
        NA_real_
      ),
      cand_b_validos = if_else(
        total_candidatos > 0,
        .data[[cand_b]] / total_candidatos,
        NA_real_
      ),
      margem_total = cand_a_total - cand_b_total,
      margem_validos = cand_a_validos - cand_b_validos
    )
  
  serie_1T <- construir_serie(base_1T)
  
  # ----------------------------------------------------------
  # 5.2 Segundo turno
  # ----------------------------------------------------------
  
  base_2T <- preparar_datas(
    base_2T_raw,
    cfg$data_2T
  ) %>%
    mutate(
      nome_candidato = str_to_lower(str_trim(nome_candidato)),
      nome_candidato = case_when(
        nome_candidato == "bolsonaro" ~ "bolsonaro",
        nome_candidato == "lula" ~ "lula",
        TRUE ~ nome_candidato
      ),
      percentual = percentual / 100
    )
  
  base_2T_wide <- base_2T %>%
    filter(nome_candidato %in% c(cand_a, cand_b)) %>%
    select(
      instituto,
      data_inicio,
      data_fim,
      data_referencia,
      amostra,
      margem_erro,
      registro_tse,
      amostra_tse,
      contratante,
      id_painel,
      nome_candidato,
      percentual
    ) %>%
    pivot_wider(
      id_cols = c(
        instituto,
        data_inicio,
        data_fim,
        data_referencia,
        amostra,
        margem_erro,
        registro_tse,
        amostra_tse,
        contratante,
        id_painel
      ),
      names_from = nome_candidato,
      values_from = percentual
    ) %>%
    mutate(
      total_2T = .data[[cand_a]] + .data[[cand_b]],
      cand_a_total = .data[[cand_a]],
      cand_b_total = .data[[cand_b]],
      cand_a_validos = if_else(
        total_2T > 0,
        .data[[cand_a]] / total_2T,
        NA_real_
      ),
      cand_b_validos = if_else(
        total_2T > 0,
        .data[[cand_b]] / total_2T,
        NA_real_
      ),
      margem_total = cand_a_total - cand_b_total,
      margem_validos = cand_a_validos - cand_b_validos,
      x = as.numeric(data_referencia)
    ) %>%
    filter(
      is.finite(cand_a_total),
      is.finite(cand_b_total)
    )
  
  serie_2T <- construir_serie(base_2T_wide)
}

# ------------------------------------------------------------
# 6. PREPARAÇÃO ESPECÍFICA DE 2026
# ------------------------------------------------------------

if (ANO_ANALISE == 2026) {

  # Confere se a base 03_base_2026.R entregou os campos esperados.
  # A base bruta continua sendo a fonte dos percentuais do estimador.
  colunas_1T_necessarias <- c(
    "instituto", "data_inicio", "data_fim", "amostra", "margem_erro",
    "lula", "flavio", "caiado", "zema", "renan", "cury",
    "outros_branco_nulo", "indecisos_nao_sabe", "registro_tse"
  )
  colunas_2T_necessarias <- c(
    "instituto", "data_inicio", "data_fim", "amostra", "margem_erro",
    "nome_candidato", "percentual", "registro_tse"
  )

  faltam_1T <- setdiff(colunas_1T_necessarias, names(base_1T_raw))
  faltam_2T <- setdiff(colunas_2T_necessarias, names(base_2T_raw))

  if (length(faltam_1T) > 0) {
    stop(
      "base_1T_raw, produzida por 03_base_2026.R, não contém: ",
      paste(faltam_1T, collapse = ", ")
    )
  }
  if (length(faltam_2T) > 0) {
    stop(
      "base_2T_raw, produzida por 03_base_2026.R, não contém: ",
      paste(faltam_2T, collapse = ", ")
    )
  }

  # ----------------------------------------------------------
  # 6.1 Primeiro turno
  # ----------------------------------------------------------
  #
  # A base 2026 está em formato largo, com uma coluna para cada
  # candidato. Percentuais permanecem em pontos percentuais na
  # base bruta e são convertidos para proporções aqui.
  #
  # "outros_branco_nulo" e "indecisos_nao_sabe" ficam fora do
  # denominador operacional de válidos.
  # ATENÇÃO: como a base 03 agrupa "outros" com branco/nulo, não é
  # possível recuperar separadamente eventuais votos em candidatos
  # não listados. Portanto, "votos_validos" aqui significa a participação
  # normalizada entre os seis candidatos individualizados na base.
  
  candidatos_1T_2026 <- c(
    "lula", "flavio", "caiado", "zema", "renan", "cury"
  )
  
  base_1T <- preparar_datas(
    base_1T_raw,
    cfg$data_1T
  ) %>%
    mutate(
      across(
        all_of(c(
          candidatos_1T_2026,
          "outros_branco_nulo",
          "indecisos_nao_sabe"
        )),
        ~ .x / 100
      )
    ) %>%
    mutate(
      total_candidatos = rowSums(
        across(all_of(candidatos_1T_2026)),
        na.rm = TRUE
      ),
      cand_a_total = .data[[cand_a]],
      cand_b_total = .data[[cand_b]],
      cand_a_validos = if_else(
        total_candidatos > 0,
        .data[[cand_a]] / total_candidatos,
        NA_real_
      ),
      cand_b_validos = if_else(
        total_candidatos > 0,
        .data[[cand_b]] / total_candidatos,
        NA_real_
      ),
      margem_total = cand_a_total - cand_b_total,
      margem_validos = cand_a_validos - cand_b_validos
    )
  
  serie_1T <- construir_serie(base_1T)
  
  # ----------------------------------------------------------
  # 6.2 Segundo turno
  # ----------------------------------------------------------
  #
  # Cada pesquisa possui duas linhas: Lula e Flávio.
  # "cand_*_total" preserva os percentuais publicados na pesquisa.
  # "cand_*_validos" normaliza Lula e Flávio pela soma dos dois,
  # de modo que os percentuais válidos somem 100% por pesquisa.
  
  base_2T <- preparar_datas(
    base_2T_raw,
    cfg$data_2T
  ) %>%
    mutate(
      nome_candidato = str_to_lower(str_trim(nome_candidato)),
      nome_candidato = stringi::stri_trans_general(
        nome_candidato,
        "Latin-ASCII"
      ),
      nome_candidato = case_when(
        nome_candidato == "lula" ~ "lula",
        nome_candidato == "flavio" ~ "flavio",
        TRUE ~ nome_candidato
      ),
      percentual = percentual / 100
    )
  
  base_2T_wide <- base_2T %>%
    filter(nome_candidato %in% c(cand_a, cand_b)) %>%
    select(
      instituto,
      data_inicio,
      data_fim,
      data_referencia,
      amostra,
      margem_erro,
      registro_tse,
      nome_candidato,
      percentual
    ) %>%
    pivot_wider(
      id_cols = c(
        instituto,
        data_inicio,
        data_fim,
        data_referencia,
        amostra,
        margem_erro,
        registro_tse
      ),
      names_from = nome_candidato,
      values_from = percentual
    ) %>%
    mutate(
      total_2T = .data[[cand_a]] + .data[[cand_b]],
      cand_a_total = .data[[cand_a]],
      cand_b_total = .data[[cand_b]],
      cand_a_validos = if_else(
        total_2T > 0,
        .data[[cand_a]] / total_2T,
        NA_real_
      ),
      cand_b_validos = if_else(
        total_2T > 0,
        .data[[cand_b]] / total_2T,
        NA_real_
      ),
      margem_total = cand_a_total - cand_b_total,
      margem_validos = cand_a_validos - cand_b_validos,
      x = as.numeric(data_referencia)
    ) %>%
    filter(
      is.finite(cand_a_total),
      is.finite(cand_b_total)
    )
  
  serie_2T <- construir_serie(base_2T_wide)
}

# ------------------------------------------------------------
# 6. VALIDAÇÃO DA ESTRUTURA PADRONIZADA
# ------------------------------------------------------------

variaveis_padrao <- c(
  "data_referencia",
  "cand_a_total",
  "cand_b_total",
  "cand_a_validos",
  "cand_b_validos",
  "margem_total",
  "margem_validos",
  "x"
)

validar_estrutura <- function(dados, nome_objeto) {
  faltantes <- setdiff(variaveis_padrao, names(dados))
  
  if (length(faltantes) > 0) {
    stop(
      "O objeto ", nome_objeto,
      " não possui as variáveis padronizadas: ",
      paste(faltantes, collapse = ", ")
    )
  }
}

validar_estrutura(serie_1T, "serie_1T")
validar_estrutura(serie_2T, "serie_2T")

# ------------------------------------------------------------
# 7. REGRESSÃO LOCAL LINEAR
# ------------------------------------------------------------

regressao_local_linear <- function(x, y, x0, bandwidth) {
  
  dados <- tibble(x = x, y = y) %>%
    filter(is.finite(x), is.finite(y)) %>%
    mutate(
      u = (x - x0) / bandwidth,
      peso = 0.75 * pmax(1 - u^2, 0), 
      dx = x - x0
    ) %>%
    filter(peso > 0)
  
  # Alternativa: kernel de Epanechnikov
  # peso <- 0.75 * pmax(1 - u^2, 0)
  
  # Kernel triangular
  # pmax(1 - abs(u), 0)
  
  
  if (nrow(dados) < 4) {
    return(
      tibble(
        fit = NA_real_,
        se = NA_real_,
        n = nrow(dados)
      )
    )
  }
  
  X <- cbind(1, dados$dx)
  W <- diag(dados$peso)
  XtWX <- t(X) %*% W %*% X
  
  if (!all(is.finite(XtWX)) || abs(det(XtWX)) < 1e-12) {
    return(
      tibble(
        fit = NA_real_,
        se = NA_real_,
        n = nrow(dados)
      )
    )
  }
  
  beta <- solve(XtWX, t(X) %*% W %*% dados$y)
  fit <- as.numeric(beta[1])
  
  residuos <- dados$y - as.numeric(X %*% beta)
  gl <- max(sum(dados$peso) - 2, 1)
  sigma2 <- sum(dados$peso * residuos^2) / gl
  matriz_cov <- sigma2 * solve(XtWX)
  se <- sqrt(max(matriz_cov[1, 1], 0))
  
  tibble(
    fit = fit,
    se = se,
    n = nrow(dados)
  )
}

# ------------------------------------------------------------
# 8. BANDWIDTHS E VALIDAÇÃO TEMPORAL
# ------------------------------------------------------------

bandwidths <- sort(unique(c(
  3, 5, 7, 10, 14, 21, 28, 35, 40, 50,
  seq(60, 600, by = 10),
  seq(60, 140, by = 5),
  seq(250, 440, by = 5)
)))

avaliar_rolling <- function(
    dados, y, bandwidth,
    inicio_teste,
    inicio_amostra = as.Date("1900-01-01")
) {
  
  corte <- as.numeric(inicio_amostra)
  teste_inicio <- as.numeric(inicio_teste)
  
  dados <- dados %>%
    mutate(
      x = as.numeric(data_referencia)
    ) %>%
    filter(
      is.finite(x),
      is.finite({{ y }})
    ) %>%
    arrange(x)
  
  datas <- sort(unique(
    dados$x[dados$x >= teste_inicio]
  ))
  
  resultados <- list()
  
  for (x0 in datas) {
    
    treino <- dados %>%
      filter(
        x >= corte,
        x < x0
      )
    
    teste <- dados %>%
      filter(x == x0)
    
    if (nrow(treino) < 4 || nrow(teste) == 0) {
      next
    }
    
    pred <- regressao_local_linear(
      x = treino$x,
      y = dplyr::pull(treino, {{ y }}),
      x0 = x0,
      bandwidth = bandwidth
    )
    
    if (!is.finite(pred$fit[1])) {
      next
    }
    
    # Cada pesquisa é uma observação de teste.
    # Não calcular a média das pesquisas da data.
    y_real <- dplyr::pull(teste, {{ y }})
    
    resultados[[length(resultados) + 1]] <- tibble(
      x = rep(x0, length(y_real)),
      real = y_real,
      previsto = rep(pred$fit[1], length(y_real)),
      erro = y_real - pred$fit[1]
    )
  }
  
  bind_rows(resultados)
}

avaliar_bandwidths <- function(
    dados, y, bandwidths,
    inicio_teste,
    inicio_amostra = as.Date("1900-01-01")
) {
  
  purrr::map_dfr(bandwidths, function(h) {
    
    cv <- avaliar_rolling(
      dados = dados,
      y = {{ y }},
      bandwidth = h,
      inicio_amostra = inicio_amostra,
      inicio_teste = inicio_teste
    )
    
    if (nrow(cv) == 0) {
      return(tibble(
        bandwidth = h,
        RMSE = NA_real_,
        MAE = NA_real_,
        n = 0L,
        n_datas = 0L
      ))
    }
    
    tibble(
      bandwidth = h,
      RMSE = sqrt(mean(cv$erro^2, na.rm = TRUE)),
      MAE = mean(abs(cv$erro), na.rm = TRUE),
      n = sum(is.finite(cv$erro)),
      n_datas = n_distinct(cv$x[is.finite(cv$erro)])
    )
  })
}

# ------------------------------------------------------------
# VALIDAÇÃO COM PESO IGUAL POR DIA
# ------------------------------------------------------------

avaliar_bandwidths_por_dia <- function(
    dados, y, bandwidths,
    inicio_teste,
    inicio_amostra = as.Date("1900-01-01")
) {
  
  purrr::map_dfr(bandwidths, function(h) {
    
    cv <- avaliar_rolling(
      dados = dados,
      y = {{ y }},
      bandwidth = h,
      inicio_amostra = inicio_amostra,
      inicio_teste = inicio_teste
    )
    
    if (nrow(cv) == 0) {
      return(tibble(
        bandwidth = h,
        RMSE = NA_real_,
        MAE = NA_real_,
        n_pesquisas = 0L,
        n_datas = 0L
      ))
    }
    
    # Uma observação por data: erro médio das pesquisas do dia
    erros_dia <- cv %>%
      group_by(x) %>%
      summarise(
        erro_dia = mean(erro, na.rm = TRUE),
        n_pesquisas = sum(is.finite(erro)),
        .groups = "drop"
      )
    
    tibble(
      bandwidth = h,
      RMSE = sqrt(mean(erros_dia$erro_dia^2, na.rm = TRUE)),
      MAE = mean(abs(erros_dia$erro_dia), na.rm = TRUE),
      n_pesquisas = sum(erros_dia$n_pesquisas),
      n_datas = sum(is.finite(erros_dia$erro_dia))
    )
  })
}

# CV auxiliar da margem total, por pesquisa individual, usada na calibração
# das probabilidades. A escolha de h é feita pela margem de votos válidos,
# com peso igual por dia.
cv_1T_total <- avaliar_bandwidths(
  dados = base_1T,
  y = margem_total,
  bandwidths = bandwidths,
  inicio_amostra = as.Date("1900-01-01"),
  inicio_teste = inicio_teste_1T
)

cv_2T_total <- avaliar_bandwidths(
  dados = base_2T_wide,
  y = margem_total,
  bandwidths = bandwidths,
  inicio_amostra = as.Date("1900-01-01"),
  inicio_teste = inicio_teste_2T
)


# ------------------------------------------------------------
# 8.1 VALIDAÇÃO PRINCIPAL: PESO IGUAL POR DIA
# ------------------------------------------------------------

cv_1T_validos <- avaliar_bandwidths_por_dia(
  dados = base_1T,
  y = margem_validos,
  bandwidths = bandwidths,
  inicio_amostra = as.Date("1900-01-01"),
  inicio_teste = inicio_teste_1T
)

cv_2T_validos <- avaliar_bandwidths_por_dia(
  dados = base_2T_wide,
  y = margem_validos,
  bandwidths = bandwidths,
  inicio_amostra = as.Date("1900-01-01"),
  inicio_teste = inicio_teste_2T
)

# A grade refinada de 5 dias já está integrada à validação principal.

# ------------------------------------------------------------
# 8.4 SELEÇÃO DO BANDWIDTH COM TOLERÂNCIA DE 0,5%
# ------------------------------------------------------------
# Escolhidos por validação temporal e estabilização

selecionar_bandwidth_tolerancia <- function(
    cv,
    tolerancia = 0.005
) {
  
  cv_valid <- cv %>%
    filter(is.finite(RMSE)) %>%
    arrange(bandwidth)
  
  if (nrow(cv_valid) == 0) {
    stop("Não há resultados válidos de validação.")
  }
  
  rmse_min <- min(cv_valid$RMSE)
  
  elegiveis <- cv_valid %>%
    filter(RMSE <= rmse_min * (1 + tolerancia))
  
  if (nrow(elegiveis) == 0) {
    stop("Nenhum bandwidth satisfaz a tolerância.")
  }
  
  # Menor bandwidth dentro da tolerância
  escolhido <- elegiveis %>%
    slice_min(bandwidth, n = 1, with_ties = FALSE)
  
  escolhido
}

# Seleção para cada turno
selecao_1T <- selecionar_bandwidth_tolerancia(
  cv_1T_validos,
  tolerancia = 0.005
)

selecao_2T <- selecionar_bandwidth_tolerancia(
  cv_2T_validos,
  tolerancia = 0.005
)

bandwidth_final_1T <- selecao_1T$bandwidth
bandwidth_final_2T <- selecao_2T$bandwidth

# Registrar os resultados da seleção
cat("\n--- JANELAS DE VALIDAÇÃO ---\n")
cat("1º turno: início =", as.character(inicio_teste_1T),
    "| eleição =", as.character(cfg$data_1T), "\n")
cat("2º turno: início =", as.character(inicio_teste_2T),
    "| eleição =", as.character(cfg$data_2T), "\n")

cat("\n--- SELEÇÃO DO BANDWIDTH ---\n")

cat(
  "1º turno: h =", bandwidth_final_1T,
  "| RMSE =", round(selecao_1T$RMSE, 5), "\n"
)

cat(
  "2º turno: h =", bandwidth_final_2T,
  "| RMSE =", round(selecao_2T$RMSE, 5), "\n"
)


# ------------------------------------------------------------
# 9. ESTIMATIVA DOS CANDIDATOS
# ------------------------------------------------------------

estimar_candidato <- function(dados, variavel, x0, bandwidth) {
  regressao_local_linear(
    x = dados$x,
    y = dplyr::pull(dados, {{ variavel }}),
    x0 = x0,
    bandwidth = bandwidth
  )
}

x_atual_1T <- max(serie_1T$x, na.rm = TRUE)
x_atual_2T <- max(serie_2T$x, na.rm = TRUE)

# ------------------------------------------------------------
# 10. ESTIMATIVAS MAIS RECENTES - 1T
# ------------------------------------------------------------

cand_a_total_1T <- estimar_candidato(
  serie_1T,
  cand_a_total,
  x_atual_1T,
  bandwidth_final_1T
)

cand_b_total_1T <- estimar_candidato(
  serie_1T,
  cand_b_total,
  x_atual_1T,
  bandwidth_final_1T
)

cand_a_validos_1T <- estimar_candidato(
  serie_1T,
  cand_a_validos,
  x_atual_1T,
  bandwidth_final_1T
)

cand_b_validos_1T <- estimar_candidato(
  serie_1T,
  cand_b_validos,
  x_atual_1T,
  bandwidth_final_1T
)

# ------------------------------------------------------------
# 11. ESTIMATIVAS MAIS RECENTES - 2T
# ------------------------------------------------------------

cand_a_total_2T <- estimar_candidato(
  serie_2T,
  cand_a_total,
  x_atual_2T,
  bandwidth_final_2T
)

cand_b_total_2T <- estimar_candidato(
  serie_2T,
  cand_b_total,
  x_atual_2T,
  bandwidth_final_2T
)

cand_a_validos_2T <- estimar_candidato(
  serie_2T,
  cand_a_validos,
  x_atual_2T,
  bandwidth_final_2T
)

cand_b_validos_2T <- estimar_candidato(
  serie_2T,
  cand_b_validos,
  x_atual_2T,
  bandwidth_final_2T
)

# ------------------------------------------------------------
# 12. MARGENS ESTIMADAS
# ------------------------------------------------------------

margem_1T_total <- cand_a_total_1T$fit - cand_b_total_1T$fit
margem_1T_validos <- cand_a_validos_1T$fit - cand_b_validos_1T$fit

margem_2T_total <- cand_a_total_2T$fit - cand_b_total_2T$fit
margem_2T_validos <- cand_a_validos_2T$fit - cand_b_validos_2T$fit

# ------------------------------------------------------------
# 13. TABELAS FINAIS
# ------------------------------------------------------------

resultado_1T <- tibble(
  candidato = c(nome_a, nome_b),
  votos_totais = 100 * c(
    cand_a_total_1T$fit,
    cand_b_total_1T$fit
  ),
  votos_validos = 100 * c(
    cand_a_validos_1T$fit,
    cand_b_validos_1T$fit
  )
)

resultado_2T <- tibble(
  candidato = c(nome_a, nome_b),
  votos_totais = 100 * c(
    cand_a_total_2T$fit,
    cand_b_total_2T$fit
  ),
  votos_validos = 100 * c(
    cand_a_validos_2T$fit,
    cand_b_validos_2T$fit
  )
)

cat("\n============================================================\n")
cat("ELEIÇÃO:", ANO_ANALISE, "\n")
cat("============================================================\n")

cat("\nCandidatos analisados:", nome_a, "x", nome_b, "\n")
cat("Bandwidth 1T:", bandwidth_final_1T, "dias\n")
cat("Bandwidth 2T:", bandwidth_final_2T, "dias\n")

cat("\n--- 1º TURNO ---\n")
print(
  resultado_1T %>%
    mutate(across(where(is.numeric), ~ round(.x, 2)))
)

cat("\nMargem total 1T:", round(100 * margem_1T_total, 2), "p.p.\n")
cat("Margem de válidos 1T:", round(100 * margem_1T_validos, 2), "p.p.\n")

cat("\n--- 2º TURNO ---\n")
print(
  resultado_2T %>%
    mutate(across(where(is.numeric), ~ round(.x, 2)))
)

cat("\nMargem total 2T:", round(100 * margem_2T_total, 2), "p.p.\n")
cat("Margem de válidos 2T:", round(100 * margem_2T_validos, 2), "p.p.\n")

# ------------------------------------------------------------
# 14. PONTOS DAS PESQUISAS INDIVIDUAIS
# ------------------------------------------------------------

pontos_margem_1T <- base_1T %>%
  select(
    instituto,
    data_referencia,
    margem_total,
    margem_validos
  ) %>%
  filter(is.finite(margem_total))

pontos_margem_2T <- base_2T_wide %>%
  select(
    instituto,
    data_referencia,
    margem_total,
    margem_validos
  ) %>%
  filter(is.finite(margem_total))

# ------------------------------------------------------------
# 15. CURVA LOCAL LINEAR DA MARGEM
# ------------------------------------------------------------

gerar_curva_local <- function(dados, variavel, bandwidth) {
  
  grade <- seq(
    min(dados$x, na.rm = TRUE),
    max(dados$x, na.rm = TRUE),
    length.out = 250
  )
  
  map_dfr(
    grade,
    function(x0) {
      
      resultado <- regressao_local_linear(
        x = dados$x,
        y = dplyr::pull(dados, {{ variavel }}),
        x0 = x0,
        bandwidth = bandwidth
      )
      
      tibble(
        x = x0,
        fit = resultado$fit,
        se = resultado$se,
        n = resultado$n
      )
    }
  ) %>%
    mutate(
      data_referencia = as.Date(
        x,
        origin = "1970-01-01"
      ),
      ic_inf = fit - 1.96 * se,
      ic_sup = fit + 1.96 * se
    )
}

curva_margem_1T <- gerar_curva_local(
  serie_1T,
  margem_validos,
  bandwidth_final_1T
)

curva_margem_2T <- gerar_curva_local(
  serie_2T,
  margem_validos,
  bandwidth_final_2T
)

# ------------------------------------------------------------
# 16. GRÁFICO DA MARGEM - 1º TURNO
# ------------------------------------------------------------

grafico_margem_1T <- ggplot() +
  
  geom_ribbon(
    data = curva_margem_1T,
    aes(
      x = data_referencia,
      ymin = 100 * ic_inf,
      ymax = 100 * ic_sup
    ),
    fill = "grey70",
    alpha = 0.35
  ) +
  
  geom_point(
    data = pontos_margem_1T,
    aes(
      x = data_referencia,
      y = 100 * margem_validos
    ),
    size = 2.5,
    alpha = 0.65
  ) +
  
  geom_line(
    data = curva_margem_1T,
    aes(
      x = data_referencia,
      y = 100 * fit
    ),
    linewidth = 1.3
  ) +
  
  geom_hline(
    yintercept = 0,
    linetype = "dashed"
  ) +
  
  labs(
    title = paste0(
      "Margem ", nome_a, " − ", nome_b, " - 1º turno"
    ),
    subtitle = paste0(
      "Regressão local linear | bandwidth = ",
      bandwidth_final_1T,
      " dias"
    ),
    x = "Data da pesquisa",
    y = "Margem (p.p.)"
  ) +
  
  theme_minimal()

print(grafico_margem_1T)

# ------------------------------------------------------------
# 17. GRÁFICO DA MARGEM - 2º TURNO
# ------------------------------------------------------------

grafico_margem_2T <- ggplot() +
  
  geom_ribbon(
    data = curva_margem_2T,
    aes(
      x = data_referencia,
      ymin = 100 * ic_inf,
      ymax = 100 * ic_sup
    ),
    fill = "grey70",
    alpha = 0.35
  ) +
  
  geom_point(
    data = pontos_margem_2T,
    aes(
      x = data_referencia,
      y = 100 * margem_validos
    ),
    size = 2.5,
    alpha = 0.65
  ) +
  
  geom_line(
    data = curva_margem_2T,
    aes(
      x = data_referencia,
      y = 100 * fit
    ),
    linewidth = 1.3
  ) +
  
  geom_hline(
    yintercept = 0,
    linetype = "dashed"
  ) +
  
  labs(
    title = paste0(
      "Margem ", nome_a, " − ", nome_b, " - 2º turno"
    ),
    subtitle = paste0(
      "Regressão local linear | bandwidth = ",
      bandwidth_final_2T,
      " dias"
    ),
    x = "Data da pesquisa",
    y = "Margem (p.p.)"
  ) +
  
  theme_minimal()

print(grafico_margem_2T)

# ------------------------------------------------------------
# 18. PROBABILIDADES A PARTIR DA MARGEM
# ------------------------------------------------------------

# Usar o RMSE da margem total no mesmo bandwidth empregado
# para construir a curva da margem total.
rmse_pred_1T <- cv_1T_total %>%
  filter(bandwidth == bandwidth_final_1T) %>%
  pull(RMSE)

rmse_pred_2T <- cv_2T_total %>%
  filter(bandwidth == bandwidth_final_2T) %>%
  pull(RMSE)

if (length(rmse_pred_1T) != 1 || !is.finite(rmse_pred_1T)) {
  stop("RMSE da margem total indisponível para o bandwidth escolhido no 1º turno.")
}

if (length(rmse_pred_2T) != 1 || !is.finite(rmse_pred_2T)) {
  stop("RMSE da margem total indisponível para o bandwidth escolhido no 2º turno.")
}

probabilidade_1T <- curva_margem_1T %>%
  mutate(
    se_total = sqrt(
      se^2 + rmse_pred_1T^2
    ),
    prob_a = pnorm(
      0,
      mean = fit,
      sd = se_total,
      lower.tail = FALSE
    ),
    prob_a_pct = 100 * prob_a
  )

probabilidade_2T <- curva_margem_2T %>%
  mutate(
    se_total = sqrt(
      se^2 + rmse_pred_2T^2
    ),
    prob_a = pnorm(
      0,
      mean = fit,
      sd = se_total,
      lower.tail = FALSE
    ),
    prob_a_pct = 100 * prob_a
  )

# ------------------------------------------------------------
# 19. GRÁFICO DA PROBABILIDADE - 1º TURNO
# ------------------------------------------------------------

grafico_prob_1T <- ggplot(
  probabilidade_1T,
  aes(
    x = data_referencia,
    y = prob_a_pct
  )
) +
  
  geom_line(
    linewidth = 1.3
  ) +
  
  geom_hline(
    yintercept = 50,
    linetype = "dashed"
  ) +
  
  labs(
    title = paste0(
      "Probabilidade modelada de ",
      nome_a,
      " estar à frente de ",
      nome_b,
      " - 1º turno"
    ),
    subtitle = paste0(
      "Margem ",
      nome_a,
      " − ",
      nome_b,
      " | bandwidth = ",
      bandwidth_final_1T,
      " dias"
    ),
    x = "Data",
    y = "Probabilidade (%)"
  ) +
  
  theme_minimal()

print(grafico_prob_1T)

# ------------------------------------------------------------
# 20. GRÁFICO DA PROBABILIDADE - 2º TURNO
# ------------------------------------------------------------

grafico_prob_2T <- ggplot(
  probabilidade_2T,
  aes(
    x = data_referencia,
    y = prob_a_pct
  )
) +
  
  geom_line(
    linewidth = 1.3
  ) +
  
  geom_hline(
    yintercept = 50,
    linetype = "dashed"
  ) +
  
  labs(
    title = paste0(
      "Probabilidade modelada de ",
      nome_a,
      " estar à frente de ",
      nome_b,
      " - 2º turno"
    ),
    subtitle = paste0(
      "Margem ",
      nome_a,
      " − ",
      nome_b,
      " | bandwidth = ",
      bandwidth_final_2T,
      " dias"
    ),
    x = "Data",
    y = "Probabilidade (%)"
  ) +
  
  theme_minimal()

print(grafico_prob_2T)

# ------------------------------------------------------------
# CV-RMSE: PRIMEIRO E SEGUNDO TURNOS
# ------------------------------------------------------------

library(dplyr)
library(ggplot2)

cv_comparacao <- bind_rows(
  cv_1T_validos %>% mutate(turno = "1º turno"),
  cv_2T_validos %>% mutate(turno = "2º turno")
) %>%
  filter(is.finite(bandwidth), is.finite(RMSE)) %>%
  mutate(turno = factor(turno, levels = c("1º turno", "2º turno")))

# Marcar no gráfico o bandwidth efetivamente selecionado pela regra
# do menor h dentro de 0,5% do RMSE mínimo.
melhores <- bind_rows(
  selecao_1T %>% mutate(turno = "1º turno"),
  selecao_2T %>% mutate(turno = "2º turno")
) %>%
  mutate(turno = factor(turno, levels = c("1º turno", "2º turno")))

grafico_cv <- ggplot(
  cv_comparacao,
  aes(x = bandwidth, y = RMSE, color = turno)
) +
  geom_line(linewidth = 0.9) +
  geom_point(size = 1.8) +
  geom_point(
    data = melhores,
    aes(x = bandwidth, y = RMSE),
    size = 3.5,
    shape = 21,
    fill = "white",
    stroke = 1.2
  ) +
  geom_vline(
    data = melhores,
    aes(xintercept = bandwidth, color = turno),
    linetype = "dashed",
    alpha = 0.65
  ) +
  scale_x_continuous(
    breaks = seq(0, 600, by = 50)
  ) +
  coord_cartesian(xlim = c(0, 600)) +
  labs(
    title = "Validação temporal do bandwidth",
    subtitle = "Regressão local linear - kernel epanechnikov",
    x = "Bandwidth h (dias)",
    y = "CV-RMSE",
    color = "Turno"
  ) +
  theme_minimal(base_size = 12) +
  theme(legend.position = "bottom")

print(grafico_cv)

# Bandwidth e RMSE mínimos observados
melhores %>%
  select(turno, bandwidth, RMSE, MAE, n_pesquisas, n_datas)

# ------------------------------------------------------------
# 20. OBJETOS PRINCIPAIS
# ------------------------------------------------------------
#
# Preparação:
#   base_1T
#   base_2T_wide
#
# Séries:
#   serie_1T
#   serie_2T
#
# Validação:
#   cv_1T_total
#   cv_1T_validos
#   cv_2T_total
#   cv_2T_validos
#
# Bandwidth:
#   bandwidth_final_1T
#   bandwidth_final_2T
#
# Resultados:
#   resultado_1T
#   resultado_2T
#
# Margens:
#   margem_1T_total
#   margem_1T_validos
#   margem_2T_total
#   margem_2T_validos
#
# Gráficos:
#   grafico_margem_1T
#   grafico_margem_2T
#   grafico_prob_1T
#   grafico_prob_2T
#
# ============================================================
# FIM
# ============================================================
