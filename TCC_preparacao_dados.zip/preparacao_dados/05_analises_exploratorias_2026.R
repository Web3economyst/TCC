# ============================================================
# ANÁLISES EXPLORATÓRIAS E SENSIBILIDADE - ELEIÇÃO 2026
# ============================================================
# COMO USAR:
# 1. Abra 04_estimador_linear_2018_2022_2026_geral.R.
# 2. Defina ANO_ANALISE <- 2026 e execute o arquivo inteiro.
# 3. Execute este arquivo no mesmo ambiente do R.
#
# Este arquivo pressupõe que o estimador geral já criou:
# base_1T, base_2T_wide, serie_1T, serie_2T, bandwidths,
# avaliar_bandwidths_por_dia, gerar_curva_local e margem_validos.
#
# Os testes são diagnósticos: não alteram nem substituem a seleção
# oficial do bandwidth no estimador geral.
# ============================================================

if (!exists("ANO_ANALISE") || ANO_ANALISE != 2026) {
  stop("Execute primeiro o estimador geral com ANO_ANALISE <- 2026.")
}

library(tidyverse)
library(lubridate)

cat(
  "\nATENÇÃO: os cortes de validação de 2026 são exploratórios. ",
  "Os bandwidths calculados pelo script 04 usam cortes provisórios; ",
  "a decisão final só deve ocorrer após comparar as tabelas deste arquivo.\n"
)

# ------------------------------------------------------------
# 0. AUDITORIA DA COBERTURA TEMPORAL
# ------------------------------------------------------------
# Antes de interpretar o CV, verifique a cobertura real da base ativa.
# A base de 2026 inclui pesquisas históricas de 2025 e pesquisas de 2026.
# No 2T, a validação é necessariamente provisória até a eleição de
# 25/10/2026; aqui o CV mede previsibilidade de pesquisas posteriores,
# não erro em relação ao resultado eleitoral final.

resumo_cobertura_2026 <- bind_rows(
  base_1T %>% mutate(turno = "1º turno"),
  base_2T_wide %>% mutate(turno = "2º turno")
) %>%
  group_by(turno) %>%
  summarise(
    primeira_data = min(data_referencia, na.rm = TRUE),
    ultima_data = max(data_referencia, na.rm = TRUE),
    n_pesquisas = n(),
    n_datas = n_distinct(data_referencia),
    .groups = "drop"
  )

cat("\n--- Cobertura temporal da base ativa 2026 ---\n")
print(resumo_cobertura_2026)

cat("\n--- Pesquisas e datas por mês ---\n")
cobertura_mensal_2026 <- bind_rows(
  base_1T %>% mutate(turno = "1º turno"),
  base_2T_wide %>% mutate(turno = "2º turno")
) %>%
  mutate(mes = floor_date(data_referencia, "month")) %>%
  count(turno, mes, name = "n_pesquisas") %>%
  arrange(turno, mes)

print(cobertura_mensal_2026)

# ------------------------------------------------------------
# 1. ANÁLISE EXPLORATÓRIA DA DATA DE INÍCIO DA VALIDAÇÃO
# ------------------------------------------------------------
# As datas são candidatas para comparação, não escolhas prévias.
# A escolha final deve considerar simultaneamente:
#   (a) RMSE/MAE;
#   (b) número de pesquisas e datas efetivamente validadas;
#   (c) estabilidade do bandwidth entre datas de início.
#

# Candidatos definidos para análise de sensibilidade:
# 1T: maio a setembro, considerando a evolução da cobertura.
# 2T: maio a outubro, incluindo cortes próximos ao início
# da campanha e à reta final.
# A escolha deve considerar sparsity, RMSE/MAE, quantidade
# de pesquisas e datas distintas e estabilidade do bandwidth.
# Nenhuma data é assumida como ótima antes de comparar RMSE, MAE e n.
#
# Não usar dados posteriores à data de cada observação para treinar:
# avaliar_bandwidths_por_dia faz validação temporal rolling.


inicio_validacao_1T_2026 <- as.Date(c(
  "2026-05-01", "2026-06-01", "2026-07-01",
  "2026-08-01", "2026-09-01"
))

inicio_validacao_2T_2026 <- as.Date(c(
  "2026-05-01", "2026-06-01", "2026-07-01",
  "2026-08-01", "2026-09-01", "2026-10-01",
  "2026-10-05", "2026-10-08", "2026-10-10"
))


avaliar_datas_validacao_2026 <- function(dados, y, datas_inicio, turno) {
  purrr::map_dfr(datas_inicio, function(data_inicio) {
    cv <- avaliar_bandwidths_por_dia(
      dados = dados,
      y = {{ y }},
      bandwidths = bandwidths,
      inicio_amostra = as.Date("1900-01-01"),
      inicio_teste = data_inicio
    )

    cv %>%
      mutate(inicio_validacao = data_inicio, turno = turno)
  })
}

cv_datas_1T_2026 <- avaliar_datas_validacao_2026(
  dados = base_1T,
  y = margem_validos,
  datas_inicio = inicio_validacao_1T_2026,
  turno = "1º turno"
)

cv_datas_2T_2026 <- avaliar_datas_validacao_2026(
  dados = base_2T_wide,
  y = margem_validos,
  datas_inicio = inicio_validacao_2T_2026,
  turno = "2º turno"
)

cv_datas_2026 <- bind_rows(cv_datas_1T_2026, cv_datas_2T_2026)

# Compara mínimo puro com tolerâncias de 0,5%, 1% e 2%.
# A tolerância é aplicada relativamente ao menor RMSE de cada
# combinação turno/data de validação; escolhe-se o menor h elegível.
selecionar_h_tolerancia_2026 <- function(
    cv,
    tolerancias = c(0, 0.005, 0.01, 0.02)
) {
  cv_valid <- cv %>% filter(is.finite(RMSE))

  if (nrow(cv_valid) == 0) {
    warning("Nenhum RMSE finito foi encontrado na validação por data.")
    return(tibble())
  }

  cv_valid %>%
    group_by(turno, inicio_validacao) %>%
    group_modify(~ purrr::map_dfr(tolerancias, function(tol) {
      rmse_min <- min(.x$RMSE, na.rm = TRUE)

      escolhido <- .x %>%
        filter(RMSE <= rmse_min * (1 + tol)) %>%
        slice_min(bandwidth, n = 1, with_ties = FALSE)

      escolhido %>%
        mutate(tolerancia = tol, RMSE_minimo = rmse_min)
    })) %>%
    ungroup() %>%
    select(
      turno, inicio_validacao, tolerancia, bandwidth,
      RMSE, MAE, n_pesquisas, n_datas, RMSE_minimo
    ) %>%
    arrange(turno, inicio_validacao, tolerancia)
}

selecao_datas_2026 <- selecionar_h_tolerancia_2026(cv_datas_2026)

cat("\n--- Datas candidatas e tamanho efetivo da validação ---\n")
tamanho_validacao_2026 <- cv_datas_2026 %>%
  distinct(turno, inicio_validacao, bandwidth, n_pesquisas, n_datas) %>%
  group_by(turno, inicio_validacao) %>%
  summarise(
    pesquisas = max(n_pesquisas, na.rm = TRUE),
    dias = max(n_datas, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(turno, inicio_validacao)

print(tamanho_validacao_2026)

cat("\n--- Bandwidth por data de validação e tolerância ---\n")
print(selecao_datas_2026)

grafico_cv_datas_2026 <- ggplot(
  cv_datas_2026,
  aes(
    x = bandwidth, y = RMSE,
    color = factor(inicio_validacao),
    group = inicio_validacao
  )
) +
  geom_line(linewidth = 0.8) +
  geom_point(size = 1.1) +
  facet_wrap(~ turno, scales = "free_y") +
  labs(
    title = "2026 — Sensibilidade da validação temporal",
    subtitle = "RMSE por bandwidth e data de início da validação",
    x = "Bandwidth h (dias)",
    y = "RMSE de validação",
    color = "Início da validação"
  ) +
  theme_minimal()

print(grafico_cv_datas_2026)

# ------------------------------------------------------------
# 2. SENSIBILIDADE À JANELA DE TREINAMENTO
# ------------------------------------------------------------
# Mantém fixa uma data de validação por turno e altera apenas o início
# da amostra de treinamento. Isso ajuda a avaliar se o histórico de 2025
# e os primeiros meses de 2026 influenciam a escolha de h.
# IMPORTANTE: janelas recentes podem ter poucas observações antes do
# teste. Interprete RMSE/MAE junto com n_pesquisas e n_datas; não compare
# métricas sem considerar o tamanho e a cobertura de cada amostra.
#
# Para ambos os turnos, usamos 01/09/2026 como referência na análise
# da janela de treinamento. Assim, comparamos o efeito do histórico
# mantendo fixo o período de validação.
# A escolha é exploratória: verifique abaixo quantas pesquisas e datas
# efetivamente entram em cada combinação de turno e janela.


janelas_treinamento_2026 <- list(
  Todo_historico = as.Date("1900-01-01"),
  Ano_2025 = as.Date("2025-01-01"),
  Marco_2026 = as.Date("2026-03-01"),
  Maio_2026 = as.Date("2026-05-01"),
  Julho_2026 = as.Date("2026-07-01")
)

avaliar_janelas_treinamento_2026 <- function(
    dados, y, inicio_teste, turno
) {
  purrr::imap_dfr(
    janelas_treinamento_2026,
    function(corte, nome) {
      avaliar_bandwidths_por_dia(
        dados = dados,
        y = {{ y }},
        bandwidths = bandwidths,
        inicio_amostra = corte,
        inicio_teste = inicio_teste
      ) %>%
        mutate(janela_treinamento = nome, turno = turno)
    }
  )
}

cv_1T_janelas_2026 <- avaliar_janelas_treinamento_2026(
  dados = base_1T,
  y = margem_validos,
  inicio_teste = as.Date("2026-09-01"),
  turno = "1º turno"
)

cv_2T_janelas_2026 <- avaliar_janelas_treinamento_2026(
  dados = base_2T_wide,
  y = margem_validos,
  inicio_teste = as.Date("2026-09-01"),
  turno = "2º turno"
)

cv_janelas_treinamento_2026 <- bind_rows(
  cv_1T_janelas_2026, cv_2T_janelas_2026
)

selecionar_h_janela_treinamento_2026 <- function(cv, tolerancia = 0.005) {
  cv_valid <- cv %>% filter(is.finite(RMSE))

  if (nrow(cv_valid) == 0) {
    warning("Nenhum RMSE finito foi encontrado na análise das janelas de treinamento.")
    return(tibble())
  }

  cv_valid %>%
    group_by(turno, janela_treinamento) %>%
    group_modify(~ {
      rmse_min <- min(.x$RMSE, na.rm = TRUE)
      .x %>%
        filter(RMSE <= rmse_min * (1 + tolerancia)) %>%
        slice_min(bandwidth, n = 1, with_ties = FALSE)
    }) %>%
    ungroup() %>%
    arrange(turno, janela_treinamento)
}

melhores_janelas_treinamento_2026 <- selecionar_h_janela_treinamento_2026(
  cv_janelas_treinamento_2026
)

cat("\n--- Sensibilidade ao início da amostra de treinamento (tolerância 0,5%) ---\n")
print(melhores_janelas_treinamento_2026)

# ------------------------------------------------------------
# 3. COMPARAÇÃO VISUAL DE CURVAS COM BANDWIDTHS ALTERNATIVOS
# ------------------------------------------------------------
# Usa o bandwidth final do estimador geral como centro e compara
# alternativas próximas. Os gráficos são diagnósticos e não redefinem h.
#
# A grade oficial pode não conter exatamente h +/- 20 ou h +/- 40;
# por isso, selecionamos apenas os valores existentes na grade.

hs_1T_2026 <- sort(unique(bandwidths[
  bandwidths %in% c(
    bandwidth_final_1T - 40, bandwidth_final_1T - 20,
    bandwidth_final_1T, bandwidth_final_1T + 20,
    bandwidth_final_1T + 40
  )
]))

hs_2T_2026 <- sort(unique(bandwidths[
  bandwidths %in% c(
    bandwidth_final_2T - 40, bandwidth_final_2T - 20,
    bandwidth_final_2T, bandwidth_final_2T + 20,
    bandwidth_final_2T + 40
  )
]))

# Garante que o h final apareça mesmo se a grade tiver sido modificada.
hs_1T_2026 <- sort(unique(c(hs_1T_2026, bandwidth_final_1T)))
hs_2T_2026 <- sort(unique(c(hs_2T_2026, bandwidth_final_2T)))

curvas_1T_comparacao_2026 <- purrr::map_dfr(
  hs_1T_2026,
  function(h) {
    gerar_curva_local(serie_1T, margem_validos, h) %>%
      mutate(bandwidth = factor(h))
  }
)

curvas_2T_comparacao_2026 <- purrr::map_dfr(
  hs_2T_2026,
  function(h) {
    gerar_curva_local(serie_2T, margem_validos, h) %>%
      mutate(bandwidth = factor(h))
  }
)

grafico_comparacao_1T_2026 <- ggplot(
  curvas_1T_comparacao_2026,
  aes(
    x = data_referencia, y = 100 * fit,
    color = bandwidth, group = bandwidth
  )
) +
  geom_line(linewidth = 1.1) +
  geom_hline(yintercept = 0, linetype = "dashed") +
  labs(
    title = "2026 — Margem de votos válidos, primeiro turno",
    subtitle = "Comparação exploratória de bandwidths próximos ao h final",
    x = "Data da pesquisa",
    y = "Margem estimada (p.p.)",
    color = "Bandwidth (dias)"
  ) +
  theme_minimal()

grafico_comparacao_2T_2026 <- ggplot(
  curvas_2T_comparacao_2026,
  aes(
    x = data_referencia, y = 100 * fit,
    color = bandwidth, group = bandwidth
  )
) +
  geom_line(linewidth = 1.1) +
  geom_hline(yintercept = 0, linetype = "dashed") +
  labs(
    title = "2026 — Margem de votos válidos, segundo turno",
    subtitle = "Comparação exploratória de bandwidths",
    x = "Data da pesquisa",
    y = "Margem estimada (p.p.)",
    color = "Bandwidth (dias)"
  ) +
  theme_minimal()

print(grafico_comparacao_1T_2026)
print(grafico_comparacao_2T_2026)

# ------------------------------------------------------------
# 4. EXPORTAÇÃO OPCIONAL DOS RESULTADOS
# ------------------------------------------------------------
# Arquivos CSV para inspeção posterior. A exportação pode ser desligada
# definindo salvar_resultados_2026 <- FALSE antes de executar esta seção.

salvar_resultados_2026 <- TRUE

if (salvar_resultados_2026) {
  write_csv(cv_datas_2026, "cv_datas_2026.csv")
  write_csv(selecao_datas_2026, "selecao_datas_2026.csv")
  write_csv(tamanho_validacao_2026, "tamanho_validacao_2026.csv")
  write_csv(cv_janelas_treinamento_2026, "cv_janelas_treinamento_2026.csv")
  write_csv(
    melhores_janelas_treinamento_2026,
    "melhores_janelas_treinamento_2026.csv"
  )
}

# Antes de interpretar os resultados, confira se cada combinação de
# turno/data/janela produziu observações de validação suficientes.
# Se uma combinação não gerar RMSE finito, ela não será selecionada.
#
# Objetos principais para inspeção:
# resumo_cobertura_2026, cobertura_mensal_2026
# cv_datas_2026, selecao_datas_2026, tamanho_validacao_2026
# grafico_cv_datas_2026
# cv_janelas_treinamento_2026, melhores_janelas_treinamento_2026
# grafico_comparacao_1T_2026, grafico_comparacao_2T_2026
#
# Nota metodológica:
# O RMSE/MAE desta validação mede a capacidade de prever pesquisas
# posteriores com pesquisas anteriores. Não é erro em relação ao voto
# real. No 2º turno, a validação final contra o resultado eleitoral só
# poderá ser feita depois da apuração de 25/10/2026.

# ============================================================
# COMPARAÇÃO GLOBAL DOS BANDWIDTHS — 2026
# ============================================================

comparacao_global_2026 <- cv_datas_2026 %>%
  filter(
    inicio_validacao <= as.Date("2026-09-01"),
    is.finite(RMSE),
    is.finite(MAE)
  ) %>%
  group_by(turno, bandwidth) %>%
  summarise(
    RMSE_mediano = median(RMSE),
    RMSE_minimo = min(RMSE),
    RMSE_maximo = max(RMSE),
    MAE_mediano = median(MAE),
    n_cortes = n_distinct(inicio_validacao),
    .groups = "drop"
  ) %>%
  group_by(turno) %>%
  mutate(
    ranking_RMSE = rank(RMSE_mediano, ties.method = "min"),
    ranking_MAE = rank(MAE_mediano, ties.method = "min")
  ) %>%
  ungroup() %>%
  arrange(turno, ranking_RMSE, ranking_MAE)

print(comparacao_global_2026, n = Inf)
