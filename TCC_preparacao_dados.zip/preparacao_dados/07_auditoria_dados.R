# ============================================================
# 07 - AUDITORIA DAS BASES DE PESQUISAS (SEÇÃO 3.1 E APÊNDICE B)
#      Dados: fontes, pareamento e imputação (2018 / 2022 / 2026)
# ============================================================
#
# Roda as três bases (01, 02 e 03) sem alterar os arquivos e produz:
#   1. pesquisas por ano e turno (base final);
#   2. conciliação com as pesquisas que entram no agregador (04);
#   3. pareamento com o registro do TSE;
#   4. imputações: origem do modo de coleta, características
#      preenchidas por etapa e verificações de consistência;
#   5. cobertura do mercado de previsão;
#   6. tabela pronta em LaTeX para a seção 3.2.
#
# Coloque este arquivo na mesma pasta dos scripts 01, 02 e 03.
# As bases continuam lendo os arquivos do TSE e da Betfair das pastas
# configuradas nelas. Nada é regravado: salvar_arquivos vira FALSE só
# durante esta execução.
#
# Unidades de contagem:
#   - "pesquisa-turno": uma pesquisa medida em um turno. Uma pesquisa de
#     2018 que mediu o 1º turno e o cenário de 2º turno conta 1 vez em
#     cada turno.
#   - "pesquisa distinta": um id_pesquisa (protocolo do TSE ou
#     SEM-REGISTRO_<instituto>_<data>), contado uma vez no ano.
# ============================================================

library(tidyverse)

ARQUIVOS_BASE <- c(`2018` = "01_base_2018.R",
                   `2022` = "02_base_2022.R",
                   `2026` = "03_base_2026.R")
OBJETO_FINAL <- c(`2018` = "base_2018", `2022` = "base_2022_v7", `2026` = "base_2026_v7")

# Mesmos candidatos e datas do 04 (definem o que entra no agregador)
CONFIG_AGREGADOR <- list(
  `2018` = list(e1 = as.Date("2018-10-07"), e2 = as.Date("2018-10-28"), a = "haddad", b = "bolsonaro"),
  `2022` = list(e1 = as.Date("2022-10-02"), e2 = as.Date("2022-10-30"), a = "lula", b = "bolsonaro"),
  `2026` = list(e1 = as.Date("2026-10-04"), e2 = as.Date("2026-10-25"), a = "lula", b = "flavio")
)

PASTA_SAIDA_AUD <- "saida_auditoria"
dir.create(PASTA_SAIDA_AUD, showWarnings = FALSE)

CARACTERISTICAS <- c(
  "modelo_coleta_final", "local_entrevista_final", "usa_quotas_final", "ppt_final",
  "amostragem_multietapas_final", "tem_estratificacao_final", "tse_tablet",
  "tse_checagem_pct", "empresa_pesquisa", "contratante_tse", "tipo_contratante",
  "pesquisa_autofinanciada"
)

# ------------------------------------------------------------
# 0. EXECUÇÃO DAS BASES COM "FOTOGRAFIAS" ANTES DA IMPUTAÇÃO
# ------------------------------------------------------------
# Em 2022 e 2026 a imputação manual (seção 12) começa na linha
# "modo_era_na <- ..." e a regra da checagem na linha
# "checagem_padrao <- 20". Guardamos uma cópia da base logo antes de
# cada uma, para saber o que veio do TSE, o que veio da imputação manual
# e o que veio da regra da checagem. O arquivo original não é alterado.

rodar_base <- function(ano) {
  arquivo <- ARQUIVOS_BASE[[ano]]
  message("Executando ", arquivo, " ...")
  linhas <- readLines(arquivo, encoding = "UTF-8", warn = FALSE)

  i_manual <- grep("modo_era_na <- is.na(base_v7$modelo_coleta_final)", linhas, fixed = TRUE)
  i_checagem <- grep("checagem_padrao <- 20", linhas, fixed = TRUE)
  if (length(i_manual) == 1) linhas[i_manual] <- paste(".foto_antes_manual <- base_v7;", linhas[i_manual])
  if (length(i_checagem) == 1) linhas[i_checagem] <- paste(".foto_antes_checagem <- base_v7;", linhas[i_checagem])

  linhas <- sub("^salvar_arquivos <- TRUE", "salvar_arquivos <- FALSE", linhas)

  env <- new.env(parent = globalenv())
  capture.output(eval(parse(text = linhas, encoding = "UTF-8"), envir = env))
  env
}

ambientes <- map(names(ARQUIVOS_BASE), rodar_base)
names(ambientes) <- names(ARQUIVOS_BASE)

base_final <- function(ano) get(OBJETO_FINAL[[ano]], envir = ambientes[[ano]])

# ------------------------------------------------------------
# 1. PESQUISAS POR ANO E TURNO (BASE FINAL)
# ------------------------------------------------------------

pesquisas_turno <- map_dfr(names(ambientes), function(ano) {
  cfg <- CONFIG_AGREGADOR[[ano]]
  base_final(ano) %>%
    distinct(id_pesquisa, turno, .keep_all = TRUE) %>%
    mutate(ano = as.integer(ano))
})

tab_pesquisas <- pesquisas_turno %>%
  group_by(ano, turno) %>%
  summarise(
    pesquisas = n(),
    institutos = n_distinct(instituto_metodologia),
    primeira = min(data_fim),
    ultima = max(data_fim),
    ano_anterior = sum(pre_ano_eleitoral == 1, na.rm = TRUE),
    boca_de_urna = sum(boca_de_urna == 1, na.rm = TRUE),
    com_registro_tse = sum(tse_metodologia_fonte == "registro_tse", na.rm = TRUE),
    sem_registro_tse = sum(str_starts(id_pesquisa, "SEM-REGISTRO")),
    amostra_mediana = median(amostra, na.rm = TRUE),
    .groups = "drop"
  )

# 2º turno medido antes do 1º turno (cenários hipotéticos)
tab_2T_antes <- pesquisas_turno %>%
  filter(turno == 2) %>%
  mutate(e1 = map_chr(as.character(ano), ~ as.character(CONFIG_AGREGADOR[[.x]]$e1)) %>% as.Date()) %>%
  group_by(ano) %>%
  summarise(turno = 2L, cenario_2T_antes_do_1T = sum(data_fim < e1), .groups = "drop")

tab_pesquisas <- tab_pesquisas %>%
  left_join(tab_2T_antes, by = c("ano", "turno")) %>%
  mutate(cenario_2T_antes_do_1T = if_else(turno == 1, NA_integer_, cenario_2T_antes_do_1T))

# Pesquisas distintas no ano (uma pesquisa com os dois turnos conta 1 vez)
tab_distintas <- pesquisas_turno %>%
  group_by(ano, id_pesquisa) %>%
  summarise(turnos = paste(sort(unique(turno)), collapse = " e "), .groups = "drop") %>%
  count(ano, turnos, name = "pesquisas") %>%
  group_by(ano) %>%
  mutate(total_distintas = sum(pesquisas)) %>%
  ungroup()

cat("\n=== 1. PESQUISAS POR ANO E TURNO (base final) ===\n")
print(tab_pesquisas, width = Inf)
cat("\n--- Pesquisas distintas: quais turnos cada uma mediu ---\n")
print(tab_distintas)

# ------------------------------------------------------------
# 2. CONCILIAÇÃO COM O AGREGADOR (04)
# ------------------------------------------------------------
# O 04 usa base_1T_raw e base_2T_raw, só com data de fim anterior à
# eleição do turno e com os dois candidatos principais preenchidos.

contar_agregador <- function(ano) {
  env <- ambientes[[ano]]; cfg <- CONFIG_AGREGADOR[[ano]]
  r1 <- env$base_1T_raw %>%
    mutate(data_fim = as.Date(data_fim)) %>%
    filter(data_fim < cfg$e1, is.finite(.data[[cfg$a]]), is.finite(.data[[cfg$b]]))
  id_cols <- intersect(c("instituto", "data_inicio", "data_fim", "amostra", "margem_erro",
                         "registro_tse", "amostra_tse", "contratante", "id_painel"),
                       names(env$base_2T_raw))
  r2 <- env$base_2T_raw %>%
    mutate(data_fim = as.Date(data_fim),
           nome = stringi::stri_trans_general(str_to_lower(str_trim(nome_candidato)), "Latin-ASCII")) %>%
    filter(data_fim < cfg$e2, nome %in% c(cfg$a, cfg$b), is.finite(percentual)) %>%
    group_by(across(all_of(id_cols))) %>%
    filter(n_distinct(nome) == 2) %>%
    ungroup() %>%
    distinct(across(all_of(id_cols)))
  tibble(ano = as.integer(ano), turno = c(1L, 2L), usadas_agregador = c(nrow(r1), nrow(r2)))
}

tab_agregador <- map_dfr(names(ambientes), contar_agregador)

# 2º turno: pesquisas que não têm exatamente os dois candidatos com a mesma
# identificação (ex.: registro digitado diferente nas duas linhas). O 04
# descarta essas pesquisas sem avisar.
incompletas_2T <- map_dfr(names(ambientes), function(ano) {
  env <- ambientes[[ano]]; cfg <- CONFIG_AGREGADOR[[ano]]
  id_cols <- intersect(c("instituto", "data_inicio", "data_fim", "amostra", "margem_erro",
                         "registro_tse", "amostra_tse", "contratante", "id_painel"),
                       names(env$base_2T_raw))
  env$base_2T_raw %>%
    mutate(nome = stringi::stri_trans_general(str_to_lower(str_trim(nome_candidato)), "Latin-ASCII")) %>%
    filter(nome %in% c(cfg$a, cfg$b), as.Date(data_fim) < cfg$e2) %>%
    group_by(across(all_of(id_cols))) %>%
    summarise(candidatos = paste(sort(unique(nome)), collapse = " e "), linhas = n(), .groups = "drop") %>%
    filter(linhas != 2 | !str_detect(candidatos, " e ")) %>%
    mutate(ano = as.integer(ano), .before = 1) %>%
    mutate(across(everything(), as.character))
})

# Pesquisas da base final que o 04 descarta por data (no dia da eleição ou depois)
descartadas_data <- pesquisas_turno %>%
  mutate(eleicao = if_else(turno == 1,
                           map_chr(as.character(ano), ~ as.character(CONFIG_AGREGADOR[[.x]]$e1)),
                           map_chr(as.character(ano), ~ as.character(CONFIG_AGREGADOR[[.x]]$e2))) %>% as.Date()) %>%
  filter(data_fim >= eleicao) %>%
  select(ano, turno, id_pesquisa, instituto, data_inicio, data_fim, boca_de_urna)

conciliacao <- tab_pesquisas %>%
  select(ano, turno, pesquisas_base = pesquisas) %>%
  left_join(tab_agregador, by = c("ano", "turno")) %>%
  left_join(descartadas_data %>% count(ano, turno, name = "descartadas_por_data"), by = c("ano", "turno")) %>%
  mutate(descartadas_por_data = coalesce(descartadas_por_data, 0L),
         diferenca_nao_explicada = pesquisas_base - descartadas_por_data - usadas_agregador)

cat("\n=== 2. BASE FINAL x PESQUISAS USADAS NO AGREGADOR ===\n")
print(conciliacao)
if (nrow(descartadas_data) > 0) { cat("\nDescartadas por data:\n"); print(descartadas_data) }
if (nrow(incompletas_2T) > 0) {
  cat("\nATENÇÃO: pesquisas de 2º turno sem os dois candidatos na mesma identificação\n",
      "(o 04 descarta essas pesquisas; confira registro, datas e amostra digitados):\n")
  print(incompletas_2T, width = Inf)
}

# ------------------------------------------------------------
# 3. PAREAMENTO COM O REGISTRO DO TSE
# ------------------------------------------------------------

# 3.1 Situação de cada pesquisa
pareamento <- pesquisas_turno %>%
  distinct(ano, id_pesquisa, .keep_all = TRUE) %>%
  mutate(situacao_tse = case_when(
    str_starts(id_pesquisa, "SEM-REGISTRO") ~ "sem registro (ano anterior ou não registrada)",
    tse_metodologia_fonte == "registro_tse" ~ "registro encontrado no TSE",
    TRUE ~ "registro digitado, não encontrado no TSE"
  )) %>%
  count(ano, situacao_tse, name = "pesquisas")

cat("\n=== 3. PAREAMENTO COM O TSE (pesquisas distintas) ===\n")
print(pareamento)

# 3.2 2018: auditoria do próprio 01 (status por pesquisa)
if (exists("auditoria_tse", envir = ambientes[["2018"]])) {
  status_2018 <- ambientes[["2018"]]$auditoria_tse %>% count(status_tse, name = "pesquisas")
  cat("\n--- 2018: status do pareamento (auditoria_tse do 01) ---\n")
  print(status_2018)
  write_csv(status_2018, file.path(PASTA_SAIDA_AUD, "pareamento_status_2018.csv"))
}

# 3.3 2022 e 2026: datas ou amostra diferentes do registro
# (mais de 2 dias no início/fim ou mais de 5% na amostra; nada é alterado)
divergencias_tse <- map_dfr(c("2022", "2026"), function(ano) {
  b <- get(paste0("base_", ano), envir = ambientes[[ano]])
  if (!all(c("dt_inicio_tse", "dt_fim_tse", "qt_entrevistado_tse") %in% names(b))) return(NULL)
  b %>%
    filter(!is.na(registro_tse), !is.na(dt_fim_tse)) %>%
    distinct(registro_tse, turno, instituto, data_inicio, data_fim, amostra,
             dt_inicio_tse, dt_fim_tse, qt_entrevistado_tse) %>%
    mutate(dif_inicio = as.numeric(as.Date(data_inicio) - dt_inicio_tse),
           dif_fim = as.numeric(as.Date(data_fim) - dt_fim_tse),
           dif_amostra_pct = 100 * (as.numeric(amostra) / qt_entrevistado_tse - 1)) %>%
    filter(abs(dif_inicio) > 2 | abs(dif_fim) > 2 | abs(dif_amostra_pct) > 5) %>%
    mutate(ano = as.integer(ano))
})
cat("\n--- 2022 e 2026: pesquisas com datas/amostra bem diferentes do TSE:",
    nrow(distinct(divergencias_tse, ano, registro_tse)), "---\n")
print(divergencias_tse %>% count(ano, name = "pesquisas"))

# 3.4 2018: correções adotadas pelo registro do TSE
corrigidas_2018 <- base_final("2018") %>% distinct(id_pesquisa, corrigido_tse) %>%
  summarise(corrigidas_pelo_tse = sum(corrigido_tse == 1))
cat("\n2018: pesquisas com datas/amostra corrigidas pelo TSE:", corrigidas_2018$corrigidas_pelo_tse, "\n")

# ------------------------------------------------------------
# 4. IMPUTAÇÕES
# ------------------------------------------------------------

# 4.1 Origem do modo de coleta (pesquisas distintas)
origem_modo <- pesquisas_turno %>%
  distinct(ano, id_pesquisa, .keep_all = TRUE) %>%
  mutate(fonte_modelo_coleta = coalesce(fonte_modelo_coleta, "sem informação")) %>%
  count(ano, fonte_modelo_coleta, name = "pesquisas") %>%
  group_by(ano) %>%
  mutate(pct = round(100 * pesquisas / sum(pesquisas), 1)) %>%
  ungroup()

cat("\n=== 4. IMPUTAÇÕES ===\n--- 4.1 Origem do modo de coleta (pesquisas distintas) ---\n")
print(origem_modo, n = Inf)

origem_metodologia <- pesquisas_turno %>%
  distinct(ano, id_pesquisa, .keep_all = TRUE) %>%
  count(ano, tse_metodologia_fonte, name = "pesquisas")
cat("\n--- Origem da metodologia (tse_metodologia_fonte) ---\n")
print(origem_metodologia)

# 4.2 Características preenchidas em cada etapa (2022 e 2026)
preencher_por_etapa <- map_dfr(c("2022", "2026"), function(ano) {
  env <- ambientes[[ano]]
  if (!exists(".foto_antes_manual", envir = env) || !exists(".foto_antes_checagem", envir = env)) {
    warning("Fotografias da imputação não encontradas em ", ano, ": a seção 12 mudou?")
    return(NULL)
  }
  por_pesquisa <- function(d) d %>% distinct(id_pesquisa, .keep_all = TRUE) %>%
    select(id_pesquisa, any_of(CARACTERISTICAS))
  f0 <- por_pesquisa(env$.foto_antes_manual)
  f1 <- por_pesquisa(env$.foto_antes_checagem)
  ff <- por_pesquisa(base_final(ano))
  map_dfr(intersect(CARACTERISTICAS, names(ff)), function(v) {
    a0 <- !is.na(f0[[v]][match(ff$id_pesquisa, f0$id_pesquisa)])
    a1 <- !is.na(f1[[v]][match(ff$id_pesquisa, f1$id_pesquisa)])
    af <- !is.na(ff[[v]])
    tibble(ano = as.integer(ano), caracteristica = v, pesquisas = nrow(ff),
           do_tse = sum(a0),
           imputacao_manual = sum(!a0 & a1),
           regra_checagem = sum(!a1 & af),
           faltam = sum(!af))
  })
})
cat("\n--- 4.2 Características: TSE x imputação manual x regra da checagem (2022 e 2026) ---\n")
cat("(em 2026, 'imputacao_manual' inclui a tabela de modo por instituto da seção 4.1)\n")
print(preencher_por_etapa, n = Inf)

# 4.3 Verificações de consistência
verificacoes <- map_dfr(names(ambientes), function(ano) {
  env <- ambientes[[ano]]
  ff <- base_final(ano) %>% distinct(id_pesquisa, .keep_all = TRUE)
  out <- list()

  if (exists("imputacao_manual", envir = env)) {
    im <- env$imputacao_manual
    out$ids_inexistentes <- sum(!im$id_pesquisa %in% ff$id_pesquisa)
    if (out$ids_inexistentes > 0) {
      cat("\n", ano, ": ids da tabela imputacao_manual que não existem na base",
          "(essas pesquisas NÃO recebem a imputação):\n")
      print(setdiff(im$id_pesquisa, ff$id_pesquisa))
    }
    out$ids_repetidos_tabela <- sum(duplicated(im$id_pesquisa))
  }
  if (exists(".foto_antes_manual", envir = env)) {
    f0 <- env$.foto_antes_manual %>% distinct(id_pesquisa, .keep_all = TRUE)
    m <- match(ff$id_pesquisa, f0$id_pesquisa)
    out$valor_do_tse_sobrescrito <- sum(map_int(intersect(CARACTERISTICAS, names(f0)), function(v) {
      antes <- f0[[v]][m]; depois <- ff[[v]]
      sum(!is.na(antes) & (is.na(depois) | as.character(antes) != as.character(depois)))
    }))
  }
  modos_ok <- c("presencial", "telefonica_entrevistador", "telefonica_IVR", "misto", "online")
  locais_ok <- c("domiciliar", "ponto_fluxo", "domiciliar_ou_fluxo", "telefone", "online")
  tipos_ok <- c("proprio_instituto", "partido", "mercado_financeiro", "midia",
                "entidade_empresarial", "sindical_ou_movimento", "outro")
  dummies <- c("usa_quotas_final", "ppt_final", "amostragem_multietapas_final",
               "tem_estratificacao_final", "tse_tablet", "pesquisa_autofinanciada")
  out$modo_categoria_invalida <- sum(!is.na(ff$modelo_coleta_final) & !ff$modelo_coleta_final %in% modos_ok)
  out$local_categoria_invalida <- sum(!is.na(ff$local_entrevista_final) & !ff$local_entrevista_final %in% locais_ok)
  out$tipo_contratante_invalido <- sum(!is.na(ff$tipo_contratante) & !ff$tipo_contratante %in% tipos_ok)
  out$dummy_fora_de_0_1 <- sum(map_int(intersect(dummies, names(ff)), ~ sum(!is.na(ff[[.x]]) & !ff[[.x]] %in% c(0, 1))))
  out$checagem_fora_0_100 <- sum(!is.na(ff$tse_checagem_pct) & (ff$tse_checagem_pct <= 0 | ff$tse_checagem_pct > 100))
  out$id_turno_candidato_repetido <- base_final(ano) %>% count(id_pesquisa, turno, nome_clean) %>% filter(n > 1) %>% nrow()

  tibble(ano = as.integer(ano), verificacao = names(out), problemas = unlist(out))
})
cat("\n--- 4.3 Verificações (o esperado é 0 em todas) ---\n")
print(verificacoes, n = Inf)

# 4.4 Pesquisas que continuam com alguma característica vazia
pendencias <- map_dfr(names(ambientes), function(ano) {
  ff <- base_final(ano) %>% distinct(id_pesquisa, .keep_all = TRUE)
  vars <- intersect(CARACTERISTICAS, names(ff))
  ff %>%
    mutate(falta = pmap_chr(across(all_of(vars)), function(...) {
      x <- c(...); paste(names(x)[is.na(x)], collapse = ", ")
    })) %>%
    filter(falta != "") %>%
    transmute(ano = as.integer(ano), id_pesquisa, instituto, data_fim, falta)
})
cat("\n--- 4.4 Pesquisas com alguma característica ainda vazia ---\n")
print(pendencias %>% count(ano, name = "pesquisas"))

# 4.5 Outras intervenções documentadas nas bases
outras <- tibble(
  ano = c(2018L, 2018L, 2026L),
  intervencao = c("modo de coleta imputado manualmente (RealTime, presencial)",
                  "pesquisas de 2017 com metodologia pelo perfil do instituto",
                  "2º turno divulgado só em votos válidos (abstenção = NA)"),
  pesquisas = c(
    pesquisas_turno %>% filter(ano == 2018) %>% distinct(id_pesquisa, .keep_all = TRUE) %>%
      summarise(n = sum(fonte_modelo_coleta %in% "imputado_manual")) %>% pull(n),
    pesquisas_turno %>% filter(ano == 2018) %>% distinct(id_pesquisa, .keep_all = TRUE) %>%
      summarise(n = sum(tse_metodologia_fonte %in% "imputada_perfil_instituto")) %>% pull(n),
    if (exists("divulgadas_so_em_validos", envir = ambientes[["2026"]]))
      nrow(ambientes[["2026"]]$divulgadas_so_em_validos) else NA_integer_
  )
)
cat("\n--- 4.5 Outras intervenções ---\n")
print(outras)

# ------------------------------------------------------------
# 5. COBERTURA DO MERCADO DE PREVISÃO
# ------------------------------------------------------------
# Linhas candidato x pesquisa com probabilidade de mercado na véspera
# do início do campo.

cobertura_mercado <- map_dfr(names(ambientes), function(ano) {
  base_final(ano) %>%
    group_by(turno) %>%
    summarise(linhas = n(), com_mercado = sum(!is.na(probabilidade_mercado)),
              pct = round(100 * com_mercado / linhas, 1), .groups = "drop") %>%
    mutate(ano = as.integer(ano), .before = 1)
})
cat("\n=== 5. COBERTURA DO MERCADO (linhas candidato x pesquisa) ===\n")
print(cobertura_mercado)

# ------------------------------------------------------------
# 6. EXPORTAÇÃO E TABELA EM LaTeX PARA A 3.2
# ------------------------------------------------------------

write_csv(tab_pesquisas, file.path(PASTA_SAIDA_AUD, "pesquisas_ano_turno.csv"))
write_csv(tab_distintas, file.path(PASTA_SAIDA_AUD, "pesquisas_distintas.csv"))
write_csv(conciliacao, file.path(PASTA_SAIDA_AUD, "conciliacao_agregador.csv"))
write_csv(descartadas_data, file.path(PASTA_SAIDA_AUD, "descartadas_por_data.csv"))
write_csv(incompletas_2T, file.path(PASTA_SAIDA_AUD, "segundo_turno_incompletas.csv"))
write_csv(pareamento, file.path(PASTA_SAIDA_AUD, "pareamento_tse.csv"))
write_csv(divergencias_tse, file.path(PASTA_SAIDA_AUD, "divergencias_tse_2022_2026.csv"))
write_csv(origem_modo, file.path(PASTA_SAIDA_AUD, "origem_modo_coleta.csv"))
write_csv(preencher_por_etapa, file.path(PASTA_SAIDA_AUD, "caracteristicas_por_etapa.csv"))
write_csv(verificacoes, file.path(PASTA_SAIDA_AUD, "verificacoes.csv"))
write_csv(pendencias, file.path(PASTA_SAIDA_AUD, "pendencias.csv"))
write_csv(cobertura_mercado, file.path(PASTA_SAIDA_AUD, "cobertura_mercado.csv"))

num_br <- function(x) format(x, big.mark = ".", decimal.mark = ",", trim = TRUE)
data_br <- function(x) format(x, "%d/%m/%Y")

imputado_turno <- pesquisas_turno %>%
  group_by(ano, turno) %>%
  summarise(modo_imputado = sum(str_detect(coalesce(fonte_modelo_coleta, ""), "imputado")), .groups = "drop")

linhas_tex <- tab_pesquisas %>%
  left_join(tab_agregador, by = c("ano", "turno")) %>%
  left_join(imputado_turno, by = c("ano", "turno")) %>%
  arrange(ano, turno) %>%
  mutate(linha = paste0(
    ano, " & ", turno, "º & ", num_br(pesquisas), " & ", num_br(institutos), " & ",
    data_br(primeira), " a ", data_br(ultima), " & ", num_br(com_registro_tse), " & ",
    num_br(modo_imputado), " & ", num_br(usadas_agregador), " \\\\"
  )) %>%
  pull(linha)

tex <- c(
  "\\begin{table}[htbp]",
  "\\centering",
  "\\caption{Pesquisas eleitorais por eleição e turno}",
  "\\label{tab:dados_pesquisas}",
  "\\footnotesize",
  "\\begin{tabular}{llrrlrrr}",
  "\\toprule",
  "Ano & Turno & Pesquisas & Institutos & Período de campo & Registro TSE & Modo imputado & No agregador \\\\",
  "\\midrule",
  linhas_tex,
  "\\bottomrule",
  "\\end{tabular}",
  "\\vspace{0.4\\baselineskip}\\raggedright",
  "\\fonte{Elaboração própria com base nas pesquisas divulgadas e nos registros do TSE.}",
  "\\end{table}"
)
writeLines(tex, file.path(PASTA_SAIDA_AUD, "tabela_dados_3_2.tex"), useBytes = TRUE)

cat("\nTabela LaTeX salva em", file.path(PASTA_SAIDA_AUD, "tabela_dados_3_2.tex"), "\n")
cat("Arquivos salvos em", normalizePath(PASTA_SAIDA_AUD), "\n")
