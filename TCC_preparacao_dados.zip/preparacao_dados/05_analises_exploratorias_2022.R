# ============================================================
# ANÁLISES EXPLORATÓRIAS ADICIONAIS - ELEIÇÃO 2022
# ============================================================
# COMO USAR:
# 1. Abra 04_estimador_linear_2018_2022_2026_geral.R.
# 2. Defina ANO_ANALISE <- 2022 e execute o arquivo inteiro.
# 3. Execute este arquivo no mesmo ambiente do R.
#
# Este arquivo pressupõe que o estimador geral já criou:
# base_1T, base_2T_wide, serie_1T, serie_2T, bandwidths,
# avaliar_bandwidths_por_dia, gerar_curva_local,
# margem_validos, bandwidth_final_1T e bandwidth_final_2T.
# Não escolhe o bandwidth oficial: os testes abaixo são diagnósticos.
# ============================================================

if (!exists("ANO_ANALISE") || ANO_ANALISE != 2022) {
  stop("Execute primeiro o estimador geral com ANO_ANALISE <- 2022.")
}

library(tidyverse)

# ------------------------------------------------------------
# 1. SENSIBILIDADE À JANELA DE TREINAMENTO
# ------------------------------------------------------------
# Mantém o início da validação em 01/05/2022, como na análise original.
# Cada janela altera apenas o início da amostra de treinamento.

janelas_2022 <- list(
  Todas = as.Date("1900-01-01"),
  Marco = as.Date("2022-03-01"),
  Abril = as.Date("2022-04-01"),
  Maio  = as.Date("2022-05-01")
)

cv_1T_sensibilidade_2022 <- purrr::imap_dfr(
  janelas_2022,
  function(corte, nome) {
    avaliar_bandwidths_por_dia(
      dados = base_1T,
      y = margem_validos,
      bandwidths = bandwidths,
      inicio_amostra = corte,
      inicio_teste = as.Date("2022-05-01")
    ) %>%
      mutate(janela = nome, turno = "1º turno")
  }
)

cv_2T_sensibilidade_2022 <- purrr::imap_dfr(
  janelas_2022,
  function(corte, nome) {
    avaliar_bandwidths_por_dia(
      dados = base_2T_wide,
      y = margem_validos,
      bandwidths = bandwidths,
      inicio_amostra = corte,
      inicio_teste = as.Date("2022-05-01")
    ) %>%
      mutate(janela = nome, turno = "2º turno")
  }
)

selecionar_h_por_janela_2022 <- function(cv, tolerancia = 0.005) {
  cv %>%
    filter(is.finite(RMSE)) %>%
    group_by(janela) %>%
    group_modify(~ {
      rmse_min <- min(.x$RMSE)
      .x %>%
        filter(RMSE <= rmse_min * (1 + tolerancia)) %>%
        slice_min(bandwidth, n = 1, with_ties = FALSE)
    }) %>%
    ungroup()
}

melhores_1T_sensibilidade_2022 <- selecionar_h_por_janela_2022(
  cv_1T_sensibilidade_2022
)

melhores_2T_sensibilidade_2022 <- selecionar_h_por_janela_2022(
  cv_2T_sensibilidade_2022
)

cat("\n--- Sensibilidade 2022: primeiro turno ---\n")
print(melhores_1T_sensibilidade_2022)
cat("\n--- Sensibilidade 2022: segundo turno ---\n")
print(melhores_2T_sensibilidade_2022)

# ------------------------------------------------------------
# 2. COMPARAÇÃO EXPLORATÓRIA DE CURVAS COM BANDWIDTHS FIXOS
# ------------------------------------------------------------
# Mantém os valores explorados na análise original de 2022.
# Estes gráficos não definem o bandwidth oficial.

curvas_1T_comparacao_2022 <- purrr::map_dfr(
  c(100, 200, 410),
  function(h) {
    gerar_curva_local(serie_1T, margem_validos, h) %>%
      mutate(bandwidth = factor(h))
  }
)

curvas_2T_comparacao_2022 <- purrr::map_dfr(
  c(70, 90, 110),
  function(h) {
    gerar_curva_local(serie_2T, margem_validos, h) %>%
      mutate(bandwidth = factor(h))
  }
)

grafico_comparacao_1T_2022 <- ggplot(
  curvas_1T_comparacao_2022,
  aes(x = data_referencia, y = 100 * fit,
      color = bandwidth, group = bandwidth)
) +
  geom_line(linewidth = 1.1) +
  geom_hline(yintercept = 0, linetype = "dashed") +
  labs(
    title = "2022 — Margem de votos válidos, primeiro turno",
    subtitle = "Comparação exploratória de bandwidths",
    x = "Data da pesquisa", y = "Margem estimada (p.p.)",
    color = "Bandwidth (dias)"
  ) +
  theme_minimal()

grafico_comparacao_2T_2022 <- ggplot(
  curvas_2T_comparacao_2022,
  aes(x = data_referencia, y = 100 * fit,
      color = bandwidth, group = bandwidth)
) +
  geom_line(linewidth = 1.1) +
  geom_hline(yintercept = 0, linetype = "dashed") +
  labs(
    title = "2022 — Margem de votos válidos, segundo turno",
    subtitle = "Comparação exploratória de bandwidths",
    x = "Data da pesquisa", y = "Margem estimada (p.p.)",
    color = "Bandwidth (dias)"
  ) +
  theme_minimal()

print(grafico_comparacao_1T_2022)
print(grafico_comparacao_2T_2022)

# Objetos principais:
# cv_1T_sensibilidade_2022, cv_2T_sensibilidade_2022
# melhores_1T_sensibilidade_2022, melhores_2T_sensibilidade_2022
# grafico_comparacao_1T_2022, grafico_comparacao_2T_2022
