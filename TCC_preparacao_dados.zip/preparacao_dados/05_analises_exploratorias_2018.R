# ============================================================
# ANÁLISES EXPLORATÓRIAS E SENSIBILIDADE - ELEIÇÃO 2018
# ============================================================
# COMO USAR:
# 1. No estimador geral, defina ANO_ANALISE <- 2018 e execute tudo.
# 2. Execute este arquivo no mesmo ambiente do R.
#
# Este arquivo pressupõe que o estimador geral já criou:
# base_1T, base_2T_wide, bandwidths, avaliar_bandwidths_por_dia,
# gerar_curva_local, serie_1T, serie_2T e as margens necessárias.
# A seleção oficial continua sendo a do estimador geral: validação
# temporal, peso igual por dia e tolerância de 0,5%.
# ============================================================

if (!exists("ANO_ANALISE") || ANO_ANALISE != 2018) {
  stop("Execute primeiro o estimador geral com ANO_ANALISE <- 2018.")
}

library(tidyverse)

# ------------------------------------------------------------
# 1. ANÁLISE EXPLORATÓRIA DA DATA DE INÍCIO DA VALIDAÇÃO
# ------------------------------------------------------------
# Em 2018, a cobertura de pesquisas é desigual ao longo do tempo.
# Por isso, comparamos datas plausíveis de início da validação em vez
# de assumir automaticamente o mesmo horizonte usado em 2022.
# A escolha não usa o resultado oficial da eleição.
#
# 1T: pesquisas ficam mais frequentes perto de agosto/setembro.
# 2T: a cobertura começa a melhorar por volta de maio/junho.
# Ajuste os candidatos após inspecionar a distribuição temporal da base.

inicio_validacao_1T_2018 <- as.Date(c(
  "2018-08-01", "2018-08-15", "2018-09-01"
))

inicio_validacao_2T_2018 <- as.Date(c(
  "2018-05-01", "2018-06-01", "2018-07-01"
))

avaliar_datas_validacao_2018 <- function(dados, y, datas_inicio, turno) {
  purrr::map_dfr(datas_inicio, function(data_inicio) {
    cv <- avaliar_bandwidths_por_dia(
      dados = dados,
      y = {{ y }},
      bandwidths = bandwidths,
      inicio_amostra = as.Date("1900-01-01"),
      inicio_teste = data_inicio
    )
    cv %>% mutate(inicio_validacao = data_inicio, turno = turno)
  })
}

cv_datas_1T_2018 <- avaliar_datas_validacao_2018(
  dados = base_1T,
  y = margem_validos,
  datas_inicio = inicio_validacao_1T_2018,
  turno = "1º turno"
)

cv_datas_2T_2018 <- avaliar_datas_validacao_2018(
  dados = base_2T_wide,
  y = margem_validos,
  datas_inicio = inicio_validacao_2T_2018,
  turno = "2º turno"
)

cv_datas_2018 <- bind_rows(cv_datas_1T_2018, cv_datas_2T_2018)

# Compara o mínimo puro com diferentes tolerâncias. O critério de 0,5%
# não é imposto nesta etapa: a tabela permite ver se muda a escolha de h.
selecionar_h_tolerancia <- function(cv, tolerancias = c(0, 0.005, 0.01, 0.02)) {
  cv %>%
    filter(is.finite(RMSE)) %>%
    group_by(turno, inicio_validacao) %>%
    group_modify(~ purrr::map_dfr(tolerancias, function(tol) {
      rmse_min <- min(.x$RMSE, na.rm = TRUE)
      escolhido <- .x %>%
        filter(RMSE <= rmse_min * (1 + tol)) %>%
        slice_min(bandwidth, n = 1, with_ties = FALSE)
      escolhido %>% mutate(tolerancia = tol, RMSE_minimo = rmse_min)
    })) %>%
    ungroup() %>%
    select(turno, inicio_validacao, tolerancia, bandwidth, RMSE, MAE,
           n_pesquisas, n_datas, RMSE_minimo)
}

selecao_datas_2018 <- selecionar_h_tolerancia(cv_datas_2018)

cat("\n--- Datas candidatas e tamanhos efetivos da validação ---\n")
print(
  cv_datas_2018 %>%
    distinct(turno, inicio_validacao, bandwidth, n_pesquisas, n_datas) %>%
    group_by(turno, inicio_validacao) %>%
    summarise(
      pesquisas = max(n_pesquisas, na.rm = TRUE),
      dias = max(n_datas, na.rm = TRUE),
      .groups = "drop"
    )
)

cat("\n--- Bandwidth escolhido por data e tolerância ---\n")
print(selecao_datas_2018)

# Gráfico do RMSE por bandwidth, uma faceta por data de início.
grafico_cv_datas_2018 <- ggplot(
  cv_datas_2018,
  aes(x = bandwidth, y = RMSE, color = factor(inicio_validacao), group = inicio_validacao)
) +
  geom_line(linewidth = 0.8) +
  geom_point(size = 1.2) +
  facet_wrap(~ turno, scales = "free_y") +
  labs(
    title = "2018 — Sensibilidade da validação temporal",
    subtitle = "RMSE por bandwidth conforme a data de início da validação",
    x = "Bandwidth h (dias)", y = "RMSE de validação",
    color = "Início da validação"
  ) +
  theme_minimal()

print(grafico_cv_datas_2018)

# Objetos para inspeção:
# cv_datas_2018: métricas completas para cada data de início e bandwidth
# selecao_datas_2018: comparação entre mínimo puro e tolerâncias
# grafico_cv_datas_2018: estabilidade da curva de validação

# ------------------------------------------------------------
# 2. COMPARAÇÃO VISUAL DE CURVAS
# ------------------------------------------------------------
# Em vez de importar os valores fixos de 2022, comparamos o h escolhido
# com alternativas próximas, limitadas à grade disponível.

hs_1T_2018 <- sort(unique(pmax(3, c(
  bandwidth_final_1T - 40,
  bandwidth_final_1T - 20,
  bandwidth_final_1T,
  bandwidth_final_1T + 20,
  bandwidth_final_1T + 40
))))

hs_2T_2018 <- sort(unique(pmax(3, c(
  bandwidth_final_2T - 40,
  bandwidth_final_2T - 20,
  bandwidth_final_2T,
  bandwidth_final_2T + 20,
  bandwidth_final_2T + 40
))))

curvas_1T_comparacao_2018 <- purrr::map_dfr(
  hs_1T_2018,
  function(h) {
    gerar_curva_local(serie_1T, margem_validos, h) %>%
      mutate(bandwidth = factor(h))
  }
)

curvas_2T_comparacao_2018 <- purrr::map_dfr(
  hs_2T_2018,
  function(h) {
    gerar_curva_local(serie_2T, margem_validos, h) %>%
      mutate(bandwidth = factor(h))
  }
)

grafico_comparacao_1T_2018 <- ggplot(
  curvas_1T_comparacao_2018,
  aes(x = data_referencia, y = 100 * fit,
      color = bandwidth, group = bandwidth)
) +
  geom_line(linewidth = 1.1) +
  geom_hline(yintercept = 0, linetype = "dashed") +
  labs(
    title = "2018 — Margem de votos válidos, primeiro turno",
    subtitle = "Comparação de bandwidths próximos para inspeção visual",
    x = "Data da pesquisa", y = "Margem estimada (p.p.)",
    color = "Bandwidth (dias)"
  ) +
  theme_minimal()

grafico_comparacao_2T_2018 <- ggplot(
  curvas_2T_comparacao_2018,
  aes(x = data_referencia, y = 100 * fit,
      color = bandwidth, group = bandwidth)
) +
  geom_line(linewidth = 1.1) +
  geom_hline(yintercept = 0, linetype = "dashed") +
  labs(
    title = "2018 — Margem de votos válidos, segundo turno",
    subtitle = "Comparação de bandwidths próximos para inspeção visual",
    x = "Data da pesquisa", y = "Margem estimada (p.p.)",
    color = "Bandwidth (dias)"
  ) +
  theme_minimal()

print(grafico_comparacao_1T_2018)
print(grafico_comparacao_2T_2018)

# Objetos principais:
# cv_1T_sensibilidade_2018, cv_2T_sensibilidade_2018
# melhores_1T_sensibilidade_2018, melhores_2T_sensibilidade_2018
# grafico_comparacao_1T_2018, grafico_comparacao_2T_2018


# ------------------------------------------------------------
# 3. COMPARAÇÃO DIRETA: h = 280, 290 e 300 NO 1º TURNO
# ------------------------------------------------------------

h_candidatos_1T <- c(280, 290, 300)

cv_1T_h_candidatos <- purrr::map_dfr(
  inicio_validacao_1T_2018,
  function(data_inicio) {
    avaliar_bandwidths_por_dia(
      dados = base_1T,
      y = margem_validos,
      bandwidths = h_candidatos_1T,
      inicio_amostra = as.Date("1900-01-01"),
      inicio_teste = data_inicio
    ) %>%
      mutate(inicio_validacao = data_inicio)
  }
)

comparacao_h_1T_2018 <- cv_1T_h_candidatos %>%
  select(
    inicio_validacao, bandwidth,
    RMSE, MAE, n_pesquisas, n_datas
  ) %>%
  arrange(inicio_validacao, bandwidth)

cat("\n--- Comparação direta de h no 1º turno de 2018 ---\n")
print(comparacao_h_1T_2018, n = Inf)

grafico_h_1T_2018 <- ggplot(
  cv_1T_h_candidatos,
  aes(
    x = bandwidth, y = RMSE,
    color = factor(inicio_validacao),
    group = inicio_validacao
  )
) +
  geom_line(linewidth = 0.9) +
  geom_point(size = 2) +
  scale_x_continuous(breaks = h_candidatos_1T) +
  labs(
    title = "2018 — Comparação de bandwidths no 1º turno",
    subtitle = "h = 280, 290 e 300 dias",
    x = "Bandwidth (dias)",
    y = "RMSE de validação",
    color = "Início da validação"
  ) +
  theme_minimal()

print(grafico_h_1T_2018)

