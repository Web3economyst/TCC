# ============================================================
# POLYMARKET 2026 - PROBABILIDADE DIÁRIA DE VITÓRIA (BRASIL)
# ============================================================
#
# Arquivos de entrada (baixados da Polymarket, na pasta_dados):
#   polymarket_mercados.csv        um mercado SIM/NÃO por candidato
#                                  ("<candidato> vence a eleição
#                                  presidencial de 2026"), com volume total
#   polymarket_serie_horaria.csv   preço do contrato SIM de hora em hora
#                                  (candidato, ts em segundos UTC, preco,
#                                  datahora_brt)
#
# O que o mercado precifica: a probabilidade de o candidato VENCER a
# eleição (1º e 2º turnos), como na Betfair em 2018 e 2022. O preço do
# contrato SIM (de 0 a 1 dólar) é lido diretamente como probabilidade.
#
# Diferença em relação à Betfair: a série da Polymarket traz um único preço
# por hora, sem o livro de ofertas (sem preço de compra e de venda
# separados) e sem volume diário. Por isso:
#   - não há spread: liquidez_mercado fica NA na base;
#   - não há volume diário: volume_mercado fica NA na base;
#   - o passo "ponto médio entre comprar e vender" da Betfair não se
#     aplica; o preço já é a probabilidade.
# Os demais passos são os mesmos da Betfair:
#   1. preço do dia = último preço do dia no horário de Brasília; dia sem
#      atualização mantém o preço do dia anterior;
#   2. margem: os preços de todos os candidatos listados no dia são
#      divididos pela soma do dia, de modo que o total seja 1.
#
# Saída (mesmas colunas lidas pelo 03_base_2026_v7.R, seção 14):
#   mercado_2026_diario.csv  nome_clean, data_brt, prob_norm, spread_prob,
#                            volume_dia (+ preço bruto e soma do dia)
# ============================================================

library(tidyverse)
library(lubridate)

pasta_dados <- file.path(getwd(), "pasta_dados")

arquivo_mercados <- file.path(pasta_dados, "polymarket_mercados.csv")
arquivo_horario <- file.path(pasta_dados, "polymarket_serie_horaria.csv")
arquivo_saida <- file.path(pasta_dados, "mercado_2026_diario.csv")

fuso_br <- "America/Sao_Paulo"

# ---- 1. candidatos no padrão da base de pesquisas -------------
# nome_clean igual ao das tabelas de 2026 (lula, flavio, caiado, zema,
# renan, cury). Os demais ficam com nome próprio.
mapa_candidatos <- tribble(
  ~candidato,                    ~nome_clean,
  "Luiz Inácio Lula da Silva",   "lula",
  "Flávio Bolsonaro",            "flavio",
  "Ronaldo Caiado",              "caiado",
  "Romeu Zema",                  "zema",
  "Renan Santos",                "renan",
  "Augusto Cury",                "cury",
  "Tarcisio de Freitas",         "tarcisio",
  "Ratinho Júnior",              "ratinho",
  "Eduardo Bolsonaro",           "eduardo_bolsonaro",
  "Michelle Bolsonaro",          "michelle",
  "Jair Bolsonaro",              "bolsonaro",
  "Geraldo Alckmin",             "alckmin",
  "Eduardo Leite",               "leite",
  "Fernando Haddad",             "haddad",
  "Camilo Santana",              "camilo",
  "Aldo Rebelo",                 "aldo",
  "Tereza Cristina",             "tereza",
  "Pablo Marçal",                "marcal",
  "Helder Barbalho",             "helder"
)

mercados <- read_csv(arquivo_mercados, show_col_types = FALSE) %>%
  mutate(fechado_em = ymd_hms(fechado_em, tz = "UTC", quiet = TRUE))

horario <- read_csv(arquivo_horario, show_col_types = FALSE) %>%
  mutate(
    data_hora_brt = with_tz(as_datetime(ts, tz = "UTC"), fuso_br),
    data_brt = as_date(data_hora_brt)
  ) %>%
  left_join(mapa_candidatos, by = "candidato")

sem_mapa <- setdiff(unique(horario$candidato), mapa_candidatos$candidato)
if (length(sem_mapa) > 0) stop("Candidatos sem nome_clean: ", paste(sem_mapa, collapse = ", "))

# ---- 2. preço de fechamento do dia (horário de Brasília) ------
fechamento <- horario %>%
  arrange(nome_clean, ts) %>%
  group_by(nome_clean, data_brt) %>%
  summarise(preco_fech = last(preco), n_atualizacoes = n(), .groups = "drop")

# grade completa: do primeiro preço do candidato até o fechamento do seu
# mercado (ou até o último dia da série, se o mercado segue aberto)
ultimo_dia_serie <- max(horario$data_brt)
periodo_candidato <- horario %>%
  group_by(candidato, nome_clean) %>%
  summarise(inicio = min(data_brt), .groups = "drop") %>%
  left_join(mercados %>% select(candidato, fechado_em), by = "candidato") %>%
  mutate(fim = coalesce(as_date(with_tz(fechado_em, fuso_br)), ultimo_dia_serie))

mercado_diario <- periodo_candidato %>%
  mutate(data_brt = map2(inicio, fim, ~ seq(.x, .y, by = "day"))) %>%
  unnest(data_brt) %>%
  select(nome_clean, data_brt) %>%
  left_join(fechamento, by = c("nome_clean", "data_brt")) %>%
  arrange(nome_clean, data_brt) %>%
  group_by(nome_clean) %>%
  fill(preco_fech, .direction = "down") %>%        # dia sem atualização: preço anterior
  ungroup() %>%
  mutate(n_atualizacoes = coalesce(n_atualizacoes, 0L)) %>%
  # ---- 3. retirada da margem: divide pela soma do dia ----------
  group_by(data_brt) %>%
  mutate(
    soma_precos = sum(preco_fech, na.rm = TRUE),
    prob_norm = preco_fech / soma_precos
  ) %>%
  ungroup() %>%
  mutate(
    spread_prob = NA_real_,   # a série não traz compra e venda separados
    volume_dia = NA_real_     # a série não traz volume diário
  ) %>%
  select(nome_clean, data_brt, prob_norm, spread_prob, volume_dia,
         preco_fech, soma_precos, n_atualizacoes) %>%
  arrange(data_brt, desc(prob_norm))

write_csv(mercado_diario, arquivo_saida)
message("Mercado diário salvo em: ", normalizePath(arquivo_saida, mustWork = FALSE))

# ---- conferências ---------------------------------------------
cat("\nPeríodo:", format(min(mercado_diario$data_brt)), "a", format(max(mercado_diario$data_brt)), "\n")
cat("Soma dos preços antes da normalização (mediana diária):",
    round(median(distinct(mercado_diario, data_brt, soma_precos)$soma_precos), 3), "\n")

mercado_diario %>%
  filter(nome_clean %in% c("lula", "flavio"),
         data_brt %in% as.Date(c("2026-01-15", "2026-05-01", "2026-08-15", "2026-09-15",
                                 "2026-10-01", "2026-10-03", "2026-10-04", "2026-10-05"))) %>%
  select(data_brt, nome_clean, prob_norm) %>%
  pivot_wider(names_from = nome_clean, values_from = prob_norm) %>%
  print()

# ============================================================
# FIM
# ============================================================
