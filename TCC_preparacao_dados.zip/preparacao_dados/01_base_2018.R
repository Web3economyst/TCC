# ============================================================
# CÓDIGO 2018 - BASE DE PESQUISAS + CARACTERÍSTICAS
# ============================================================
#
# Monta, do início ao fim, a base de pesquisas presidenciais de 2018
# (1º e 2º turnos), com uma linha por candidato x pesquisa x turno.
#
# Diferença em relação à V6: a lógica e os valores são os mesmos, mas a
# base final tem UMA coluna por conceito (73 colunas, contra 169):
#   - não cria as colunas reservadas que ficavam vazias;
#   - não cria colunas constantes nem cópias de outras colunas;
#   - a metodologia sai só na versão consolidada (Wikipédia + TSE);
#   - detalhes de auditoria ficam no objeto `auditoria_tse`, não na base.
# O dicionário das colunas está na seção 14 e é exportado junto.
#
# Entradas (no diretório de trabalho):
#   - pesquisa_eleitoral_2018_BR.csv  (registros do TSE)
#   - betfair_2018_diario.csv         (gerado por betfair_2018_extracao.R)
#
# Saídas:
#   - objeto `base_2018` (758 linhas x 73 colunas)
#   - objetos auxiliares: `auditoria_tse`, `perfil_metodologia_instituto`,
#     `dicionario_base_2018`
#   - arquivos (se salvar_arquivos = TRUE): base_2018.rds,
#     base_2018.csv (Excel em português: ";" e decimal ","),
#     base_2018_dicionario.csv e, se o pacote writexl estiver
#     instalado, base_2018.xlsx (abas base e dicionario)
#
# Seções
#   0. Parâmetros              8. Pesquisas sem registro (2017)
#   1. Pesquisas - 1º turno    9. Imputação manual (RealTime)
#   2. Pesquisas - 2º turno   10. Metodologia consolidada
#   3. Formato longo          11. Financiamento e contratante
#   4. Metodologia (Wikipédia)12. Auditoria do pareamento com o TSE
#   5. Registro no TSE        13. Variáveis derivadas
#   6. Correções pelo TSE     14. Mercado de previsão
#   7. Metodologia do TSE     15. Base final e exportação
# ============================================================

library(tidyverse)
library(lubridate)

# ============================================================
# 0. PARÂMETROS
# ============================================================
# pasta com pesquisa_eleitoral_2018_BRASIL.csv (e o arquivo de mercado, se houver)
pasta_dados <- file.path(getwd(), "pasta_dados")
pasta_saida <- pasta_dados

arquivo_tse <- file.path(pasta_dados, "pesquisa_eleitoral_2018_BR.csv")
arquivo_betfair_diario <- file.path(pasta_dados, "betfair_2018_diario.csv")

salvar_arquivos <- TRUE
prefixo_saida <- file.path(pasta_saida, "base_2018")

data_eleicao_1t <- as.Date("2018-10-07")
data_eleicao_2t <- as.Date("2018-10-28")

# ============================================================
# 1. PESQUISAS - 1º TURNO
# ============================================================
# Fonte: Wikipédia (pesquisas de 2018). Cenários com Haddad (quando havia
# "Haddad" e "Haddad apoiado por Lula", usa-se o segundo); sem Doria ou
# Joaquim Barbosa. Percentuais em pontos percentuais sobre votos totais.

  base_1T_raw <- tribble(
    ~instituto, ~data_inicio, ~data_fim, ~amostra, ~margem_erro,
    ~haddad, ~gomes, ~silva, ~meirelles, ~dias, ~alckmin, ~amoedo, ~bolsonaro,
    ~outros, ~abstencao_nao_decidiu, ~registro_tse,

    # ==========================================================
    # OUTUBRO — mais recentes
    # ==========================================================
    
    # "IBOPE", "2018-10-07", "2018-10-07", 30000, 2,
    # 28, 14, 2, 1, 1, 4, 3, 45, 2, 7, "BR-07052/2018",
    
    "Globo e O Estado de S. Paulo/IBOPE", "2018-10-05", "2018-10-06", 3010, 2,
    22, 11, 3, 2, 1, 7, 2, 36, 3, 12, "BR-01537/2018",
    
    "Globo e Folha/Datafolha", "2018-10-05", "2018-10-06", 19552, 2,
    22, 13, 3, 2, 2, 7, 3, 36, 2, 10, "BR-01584/2018",
    
    "CNT/MDA", "2018-10-04", "2018-10-05", 2002, 2.2,
    24.0, 9.9, 2.2, 1.6, 1.7, 5.8, 2.3, 36.7, 1.9, 13.8, "BR-04819/2018",
    
    "Veritá", "2018-10-02", "2018-10-05", 5208, 2,
    18.8, 8.4, 1.4, 0.8, 1.0, 4.2, 2.9, 41.5, 2.0, 19.0, "BR-03229/2018",
    
    "XP/Ipespe", "2018-10-03", "2018-10-04", 2000, 2.2,
    22, 11, 4, 2, 2, 7, 3, 36, 1, 12, "BR-06509/2018",
    
    "RecordTV/RealTime Big Data", "2018-10-03", "2018-10-04", 10000, 2,
    24, 12, 4, 1, 1, 6, 2, 34, 1, 15, "BR-05770/2018",
    
    "DataPoder360", "2018-10-03", "2018-10-04", 4000, 2,
    25, 15, 2, 3, 4, 7, 2, 30, 5, 7, "BR-07142/2018",
    
    "Globo e Folha/Datafolha", "2018-10-03", "2018-10-04", 10930, 2,
    22, 11, 4, 2, 2, 8, 3, 35, 1, 11, "BR-02581/2018",
    
    "Empiricus/Paraná Pesquisas", "2018-10-02", "2018-10-04", 2080, 2,
    21.8, 9.4, 3.5, 1.7, 1.4, 7.4, 3.1, 34.9, 2.1, 14.7, "BR-08437/2018",
    
    "Movimento Parlamentarista Brasileiro/Amostra", "2018-09-28", "2018-10-03", 2500, 2,
    22, 10, 6, 2, 1, 6, 2, 30, 0, 18, "BR-09143/2018",
    
    "Folha/Datafolha", "2018-10-02", "2018-10-02", 3240, 2,
    21, 11, 4, 2, 2, 9, 3, 32, 2, 13, "BR-03147/2018",
    
    "Globo e O Estado de S. Paulo/IBOPE", "2018-10-01", "2018-10-02", 3010, 2,
    23, 10, 4, 2, 1, 7, 2, 32, 1, 17, "BR-08245/2018",
    
    # ==========================================================
    # SETEMBRO
    # ==========================================================
    
    "BTG Pactual/FSB Pesquisa", "2018-09-29", "2018-09-30", 2000, 2,
    24, 9, 4, 2, 2, 11, 5, 31, 1, 12, "BR-05879/2018",
    
    "Globo e O Estado de S. Paulo/IBOPE", "2018-09-29", "2018-09-30", 3010, 2,
    21, 11, 4, 2, 2, 8, 3, 31, 1, 17, "BR-08650/2018",
    
    # Protocolo corrigido: na fonte estava BR-06298/2018 (dígitos trocados);
    # o registro no TSE é BR-06928/2018 (mesmas datas e amostra).
    "RecordTV/RealTime Big Data", "2018-09-28", "2018-09-29", 3200, 2,
    24, 11, 5, 3, 2, 7, 3, 29, 1, 15, "BR-06928/2018",
    
    "CNT/MDA", "2018-09-27", "2018-09-28", 2000, 2.2,
    25.2, 9.4, 2.6, 2.0, 1.7, 7.3, 2.0, 28.2, 1.6, 20.0, "BR-03303/2018",
    
    "Globo e Folha/Datafolha", "2018-09-26", "2018-09-28", 9000, 2,
    22, 11, 5, 2, 2, 10, 3, 28, 3, 15, "BR-08687/2018",
    
    "Genial Investimentos/Brasilis", "2018-09-25", "2018-09-26", 1000, 3.5,
    22, 8, 5, 2, 3, 10, 3, 27, 4, 18, "BR-00592/2018",
    
    "XP/Ipespe", "2018-09-24", "2018-09-26", 2000, 2.2,
    21, 11, 5, 2, 2, 8, 3, 28, 1, 17, "BR-00526/2018",
    
    "Empiricus/Paraná Pesquisas", "2018-09-23", "2018-09-25", 2020, 2.0,
    20.2, 10.1, 4.3, 1.3, 1.9, 7.6, 3.8, 31.2, 1.2, 18.2, "BR-03512/2018",
    
    "CNI/IBOPE", "2018-09-22", "2018-09-24", 2000, 2,
    21, 12, 6, 2, 2, 8, 3, 27, 1, 18, "BR-04669/2018",
    
    "IstoÉ/Sensus", "2018-09-21", "2018-09-24", 2000, 2.2,
    24.5, 7.7, 2.7, 1.6, 1.7, 5.6, 1.9, 30.6, 1.3, 22.4, "BR-02407/2018",
    
    "Globo e O Estado de S. Paulo/IBOPE", "2018-09-22", "2018-09-23", 2506, 2,
    # Versão 6: Marina Silva = 5 (antes NA), conferido na divulgação do IBOPE
    22, 11, 5, 2, 2, 8, 3, 28, 1, 18, "BR-06630/2018",
    
    "BTG Pactual/FSB Pesquisa", "2018-09-22", "2018-09-23", 2000, 2,
    23, 10, 5, 3, 2, 8, 3, 33, 1, 13, "BR-03861/2018",
    
    "DataPoder360", "2018-09-19", "2018-09-20", 4000, 2,
    22, 14, 4, 3, 3, 6, 1, 26, 5, 15, "BR-02039/2018",
    
    "Globo e Folha/Datafolha", "2018-09-18", "2018-09-19", 8601, 2,
    16, 13, 7, 2, 3, 9, 3, 28, 2, 17, "BR-06919/2018",
    
    "Genial Investimentos/Brasilis", "2018-09-17", "2018-09-19", 1000, 3.5,
    17, 7, 6, 3, 4, 7, 5, 30, 4, 18, "BR-01687/2018",
    
    # XP: havia Haddad e Haddad apoiado por Lula.
    # Conforme definido: usar Haddad apoiado por Lula.
    "XP/Ipespe", "2018-09-17", "2018-09-19", 2000, 2.2,
    17, 10, 4, 2, 3, 7, 3, 27, 1, 26, "BR-02995/2018",
    
    "Globo e O Estado de S. Paulo/IBOPE", "2018-09-16", "2018-09-18", 2506, 2,
    19, 11, 6, 2, 3, 7, 2, 28, 1, 21, "BR-09678/2018",
    
    "BTG Pactual/FSB Pesquisa", "2018-09-15", "2018-09-16", 2000, 2,
    16, 14, 5, 2, 2, 6, 4, 33, 2, 16, "BR-06478/2018",
    
    "CNT/MDA", "2018-09-12", "2018-09-15", 2002, 2.2,
    17.6, 10.8, 4.1, 1.7, 1.9, 6.1, 2.8, 28.2, 1.1, 25.7, "BR-04362/2018",
    
    "Globo e Folha/Datafolha", "2018-09-13", "2018-09-14", 2820, 2,
    13, 13, 8, 3, 3, 9, 3, 26, 3, 19, "BR-05596/2018",
    
    # XP: usar Haddad apoiado por Lula = 16%.
    "XP/Ipespe", "2018-09-10", "2018-09-12", 2000, 2.2,
    16, 11, 6, 2, 4, 9, 4, 23, 1, 23, "BR-07277/2018",
    
    # CUT/Vox Populi: usar Haddad apoiado por Lula = 22%.
    "CUT/Vox Populi", "2018-09-07", "2018-09-11", 2000, 2.2,
    22, 10, 5, 2, 1, 4, 1, 18, 1, 37, "BR-01669/2018",
    
    "Empiricus/Paraná Pesquisas", "2018-09-07", "2018-09-11", 2010, 2.0,
    8.3, 11.9, 10.6, 2.4, 3.7, 8.7, 3.3, 26.6, 2.7, 21.8, "BR-02410/2018",
    
    "Globo e Folha/Datafolha", "2018-09-10", "2018-09-10", 2804, 2,
    9, 13, 11, 3, 3, 10, 3, 24, 3, 22, "BR-02376/2018",
    
      "IBOPE", "2018-09-08", "2018-09-10", 2002, 2,
      8, 11, 9, 3, 3, 9, 3, 26, 2, 26, "BR-05221/2018",
      
      "BTG Pactual/FSB Pesquisa", "2018-09-08", "2018-09-09", 2000, 2,
      8, 12, 8, 3, 3, 8, 3, 30, 2, 24, "BR-01522/2018",
      
      "RecordTV/RealTime Big Data", "2018-09-07", "2018-09-09", 3200, 2,
      7, 11, 11, 2, 4, 9, 3, 25, 2, 26, "BR-05291/2018",
      
      "XP/Ipespe", "2018-09-03", "2018-09-05", 2000, 2.2,
      14, 10, 8, 2, 4, 8, 4, 20, 1, 28, "BR-00339/2018",
      
      "Globo e O Estado de S. Paulo/IBOPE", "2018-09-01", "2018-09-03", 2002, 2,
      6, 12, 12, 2, 3, 9, 3, 22, 3, 28, "BR-05003/2018",
      
      "BTG Pactual/FSB Pesquisa", "2018-09-01", "2018-09-02", 2000, 2,
      6, 12, 11, 1, 3, 8, 4, 26, 2, 28, "BR-01057/2018",
      
      # ==========================================================
      # AGOSTO
      # ==========================================================
      
      "XP/Ipespe", "2018-08-27", "2018-08-29", 1000, 3.2,
      13, 10, 10, 1, 4, 8, 4, 21, 6, 28, "BR-07252/2018",
      
      "BTG Pactual/FSB Pesquisa", "2018-08-25", "2018-08-26", 2000, 2,
      5, 8, 15, 1, 3, 9, 4, 24, 4, 28, "BR-06062/2018",
      
      "XP/Ipespe", "2018-08-20", "2018-08-22", 1000, 3.2,
      13, 8, 9, 1, 5, 8, 2, 20, 2, 31, "BR-07829/2018",
      
      "Globo e Folha/Datafolha", "2018-08-20", "2018-08-21", 8433, 2,
      4, 10, 16, 2, 4, 9, 2, 22, 4, 28, "BR-04023/2018",
      
      "Globo e O Estado de S. Paulo/IBOPE", "2018-08-17", "2018-08-19", 2002, 2,
      4, 9, 12, 1, 3, 7, 1, 20, 7, 38, "BR-01665/2018",
      
      "XP/Ipespe", "2018-08-13", "2018-08-15", 1000, 3.2,
      15, 7, 9, 2, 6, 9, 1, 21, 3, 28, "BR-02075/2018",
      
      "Paraná Pesquisas", "2018-08-09", "2018-08-13", 2002, 2,
      3.8, 10.2, 13.2, 0.9, 4.9, 8.5, 1.1, 23.9, 3.8, 29.9, "BR-02891/2018",
      
      "RealTime Big Data", "2018-08-10", "2018-08-12", 3200, 2,
      6, 8, 11, 1, 6, 9, 1, 21, 1, 36, "BR-09102/2018",
      
      "XP/Ipespe", "2018-08-06", "2018-08-08", 1000, 3.2,
      13, 7, 10, 2, 5, 9, NA, 21, 3, 30, "BR-08988/2018",
      
      "XP/Ipespe", "2018-07-30", "2018-08-01", 1000, 3.2,
      13, 8, 9, 2, 4, 9, NA, 20, 3, 31, "BR-06820/2018",
      
      # ==========================================================
      # JULHO
      # ==========================================================
      
      "Paraná Pesquisas", "2018-07-25", "2018-07-30", 2240, 2,
      2.8, 10.7, 14.4, 1.1, 5, 7.8, 1, 23.6, 4.3, 29.4, "BR-00884/2018",
      
      "DataPoder360", "2018-07-25", "2018-07-28", 3000, 2.2,
      # Versão 6: cenário reduzido com 6 candidatos (sem outros nomes).
      # Os 43% são branco/nulo + não sabe/não respondeu ("não voto",
      # segundo o Poder360): outros = 0 e abstencao_nao_decidiu = 43
      # (antes: outros = 43 e abstencao_nao_decidiu = NA).
      5, 13, 6, NA, 4, 9, NA, 20, 0, 43, "BR-09828/2018",
      
      "XP/Ipespe", "2018-07-23", "2018-07-25", 1000, 3.2,
      12, 9, 10, 1, 5, 9, NA, 22, 3, 29, "BR-07756/2018",
      
      "Veja/Ideia Big Data", "2018-07-20", "2018-07-23", 2036, 2.67,
      9, 7, 11, 2, 4, 6, 1, 19, 4, 37, "BR-04178/2018",
      
      "XP/Ipespe", "2018-07-16", "2018-07-18", 1000, 3.2,
      13, 8, 10, 2, 5, 7, NA, 21, 3, 31, "BR-02843/2018",
      
      "XP/Ipespe", "2018-07-09", "2018-07-11", 1000, 3.2,
      12, 8, 11, 2, 4, 7, NA, 21, 4, 31, "BR-09898/2018",
      
      "XP/Ipespe", "2018-07-02", "2018-07-04", 1000, 3.2,
      11, 8, 11, 2, 5, 7, NA, 21, 4, 29, "BR-04338/2018",
      
      # ==========================================================
      # JUNHO
      # ==========================================================
      
      "DataPoder360", "2018-06-25", "2018-06-29", 5500, 2,
      5, 12, 7, 1, 4, 7, 0, 18, 5, 42, "BR-05297/2018",
      
      "XP/Ipespe", "2018-06-25", "2018-06-27", 1000, 3.2,
      11, 8, 10, 2, 5, 7, NA, 20, 4, 33, "BR-03362/2018",
      
      "CNI/IBOPE", "2018-06-21", "2018-06-24", 2000, 2,
      2, 8, 13, 1, 3, 6, 1, 17, 9, 41, "BR-02265/2018",
      
      "XP/Ipespe", "2018-06-18", "2018-06-20", 1000, 3.2,
      12, 8, 11, 2, 5, 8, NA, 19, 4, 31, "BR-06647/2018",
      
      "XP/Ipespe", "2018-06-11", "2018-06-13", 1000, 3.2,
      11, 9, 10, 2, 6, 8, NA, 20, 2, 31, "BR-07273/2018",
      
      "Datafolha", "2018-06-06", "2018-06-07", 2824, 2,
      1, 10, 15, 1, 4, 7, 1, 19, 9, 33, "BR-05110/2018",
      
      "XP/Ipespe", "2018-06-04", "2018-06-06", 1000, 3.2,
      11, 9, 11, 2, 6, 8, NA, 21, 4, 27, "BR-05997/2018",
      
      # ==========================================================
      # MAIO
      # ==========================================================
      
      "DataPoder360", "2018-05-25", "2018-05-31", 10500, 1.8,
      6, 11, 7, 1, 5, 6, NA, 21, 5.8, 39, "BR-09186/2018",
      
      "XP/Ipespe", "2018-05-15", "2018-05-23", 2000, 2.2,
      3, 10, 14, 2, 4, 9, NA, 24, 2, 32, "BR-09600/2018",
      
      "CNT/MDA", "2018-05-09", "2018-05-12", 2002, 2.2,
      2.3, 9, 11.2, 0.5, 3, 5.3, 0.6, 18.3, 3.8, 45.7, "BR-09430/2018",
    
      
      
      # ==========================================================
      # MARÇO — mais antiga
      # ==========================================================
      
      "CNT/MDA", "2018-02-28", "2018-03-03", 2002, 2.2,
      2.4, 8.1, 13.4, NA, 4.1, 8.7, NA, 20.2, 4.6, 38.5, "BR-06600/2018",
    
    # ==========================================================
    # DEZEMBRO DE 2017
    # ==========================================================
    
    "DataPoder360", "2017-12-08", "2017-12-11", 2210, 2.6,
    5, 10, 10, NA, NA, 7, NA, 23, NA, 46,
    NA,
    
    # ==========================================================
    # NOVEMBRO DE 2017
    # ==========================================================
    
    "Datafolha", "2017-11-29", "2017-11-30", 2765, 2,
    3, 12, 16, NA, 5, 9, 1, 21, 4, 28,
    NA,
    
    "DataPoder360", "2017-11-16", "2017-11-18", 2171, 2.9,
    4, 12, 12, NA, NA, 9, NA, 22, NA, NA,
    NA,
    
    # ==========================================================
    # OUTUBRO DE 2017
    # ==========================================================
    
    "DataPoder360", "2017-10-26", "2017-10-29", 2016, 2.9,
    4, 14, 9, NA, NA, 10, NA, 23, NA, 40,
    NA,
    
    # Outubro de 2017
    "IBOPE", "2017-10-18", "2017-10-22", 2002, 2,
    2, 9, 18, 1, 4, 8, 1, 18, 3, 36, NA,
    
    # Setembro de 2017
    "Datafolha", "2017-09-27", "2017-09-28", 2772, 2,
    3, 9, 22, 2, 5, 9, 1, 19, 2, 28, NA,
    
    # Setembro de 2017
    "DataPoder360", "2017-09-15", "2017-09-17", 2280, 2.8,
    4, 11, 12, NA, NA, 7, NA, 26, NA, 41, NA,
    
    # Agosto de 2017
    "DataPoder360", "2017-08-12", "2017-08-14", 2088, 3.0,
    3, 8, 8, NA, NA, 9, NA, 27, NA, 45, NA,
    )

# ============================================================
# 2. PESQUISAS - 2º TURNO (Haddad x Bolsonaro)
# ============================================================
# Inclui os cenários hipotéticos medidos antes do 1º turno.

  base_2T_raw <- tribble(
    ~instituto, ~data_inicio, ~data_fim, ~amostra, ~margem_erro,
    ~nome_candidato, ~percentual, ~abstencao_nao_decidiu, ~registro_tse,
    
    # 28 de outubro — BOCA DE URNA
    "IBOPE", "2018-10-28", "2018-10-28", 30000, 2,
    "Bolsonaro", 56, NA, "BR-07268/2018",
    "IBOPE", "2018-10-28", "2018-10-28", 30000, 2,
    "Haddad", 44, NA, "BR-07268/2018",
    
    # 26–27 de outubro
    "Globo e O Estado de S. Paulo/IBOPE", "2018-10-26", "2018-10-27", 3010, 2,
    "Bolsonaro", 47, 12, "BR-02934/2018",
    "Globo e O Estado de S. Paulo/IBOPE", "2018-10-26", "2018-10-27", 3010, 2,
    "Haddad", 41, 12, "BR-02934/2018",
    
    "CNT/MDA", "2018-10-26", "2018-10-27", 2002, 2.2,
    "Bolsonaro", 48.5, 14.5, "BR-06933/2018",
    "CNT/MDA", "2018-10-26", "2018-10-27", 2002, 2.2,
    "Haddad", 37, 14.5, "BR-06933/2018",
    
    "Globo e Folha/Datafolha", "2018-10-26", "2018-10-27", 1837, 2,
    "Bolsonaro", 47, 13, "BR-02460/2018",
    "Globo e Folha/Datafolha", "2018-10-26", "2018-10-27", 1837, 2,
    "Haddad", 39, 13, "BR-02460/2018",
    
    # 26 de outubro
    "RecordTV/RealTime Big Data", "2018-10-26", "2018-10-26", 5000, 2,
    "Bolsonaro", 47, 14, "BR-04450/2018",
    "RecordTV/RealTime Big Data", "2018-10-26", "2018-10-26", 5000, 2,
    "Haddad", 39, 14, "BR-04450/2018",
    
    # 24–25 de outubro
    "Globo e Folha/Datafolha", "2018-10-24", "2018-10-25", 9173, 2,
    "Bolsonaro", 48, 14, "BR-05743/2018",
    "Globo e Folha/Datafolha", "2018-10-24", "2018-10-25", 9173, 2,
    "Haddad", 38, 14, "BR-05743/2018",
    
    # 23–25 de outubro
    "Empiricus/Paraná Pesquisas", "2018-10-23", "2018-10-25", 2120, 2,
    "Bolsonaro", 53, 12.5, "BR-06785/2018",
    "Empiricus/Paraná Pesquisas", "2018-10-23", "2018-10-25", 2120, 2,
    "Haddad", 34.4, 12.5, "BR-06785/2018",
    
    # 23–24 de outubro
    "XP/Ipespe", "2018-10-23", "2018-10-24", 2000, 2.2,
    "Bolsonaro", 51, 12, "BR-08283/2018",
    "XP/Ipespe", "2018-10-23", "2018-10-24", 2000, 2.2,
    "Haddad", 37, 12, "BR-08283/2018",
    
    # 24 de outubro
    "RecordTV/RealTime Big Data", "2018-10-24", "2018-10-24", 5000, 2,
    "Bolsonaro", 49, 13, "BR-08980/2018",
    "RecordTV/RealTime Big Data", "2018-10-24", "2018-10-24", 5000, 2,
    "Haddad", 38, 13, "BR-08980/2018",
    
    # 21–23 de outubro
    "Globo e O Estado de S. Paulo/IBOPE", "2018-10-21", "2018-10-23", 3010, 2,
    "Bolsonaro", 50, 13, "BR-07272/2018",
    "Globo e O Estado de S. Paulo/IBOPE", "2018-10-21", "2018-10-23", 3010, 2,
    "Haddad", 37, 13, "BR-07272/2018",
    
    # 22–23 de outubro
    "CUT/Vox Populi", "2018-10-22", "2018-10-23", 2000, 2.2,
    "Bolsonaro", 44, 17, "BR-00709/2018",
    "CUT/Vox Populi", "2018-10-22", "2018-10-23", 2000, 2.2,
    "Haddad", 39, 17, "BR-00709/2018",
    
    # 20–21 de outubro
    "CNT/MDA", "2018-10-20", "2018-10-21", 2002, 2.2,
    "Bolsonaro", 48.8, 14.5, "BR-00346/2018",
    "CNT/MDA", "2018-10-20", "2018-10-21", 2002, 2.2,
    "Haddad", 36.7, 14.5, "BR-00346/2018",
    
    "BTG Pactual/FSB Pesquisa", "2018-10-20", "2018-10-21", 2000, 2,
    "Bolsonaro", 52, 13, "BR-03689/2018",
    "BTG Pactual/FSB Pesquisa", "2018-10-20", "2018-10-21", 2000, 2,
    "Haddad", 35, 13, "BR-03689/2018",
    
    # 19–20 de outubro
    "RecordTV/RealTime Big Data", "2018-10-19", "2018-10-20", 5000, 2,
    "Bolsonaro", 52, 11, "BR-09760/2018",
    "RecordTV/RealTime Big Data", "2018-10-19", "2018-10-20", 5000, 2,
    "Haddad", 37, 11, "BR-09760/2018",
    
    # 17–18 de outubro
    "DataPoder360", "2018-10-17", "2018-10-18", 4000, 2,
    "Bolsonaro", 57, 12, "BR-08852/2018",
    "DataPoder360", "2018-10-17", "2018-10-18", 4000, 2,
    "Haddad", 31, 12, "BR-08852/2018",
    
    "Globo e Folha/Datafolha", "2018-10-17", "2018-10-18", 9137, 2,
    "Bolsonaro", 50, 15, "BR-07528/2018",
    "Globo e Folha/Datafolha", "2018-10-17", "2018-10-18", 9137, 2,
    "Haddad", 35, 15, "BR-07528/2018",
    
    # 16–17 de outubro
    "CUT/Vox Populi", "2018-10-16", "2018-10-17", 2000, 2.2,
    "Bolsonaro", 44, 17, "BR-08732/2018",
    "CUT/Vox Populi", "2018-10-16", "2018-10-17", 2000, 2.2,
    "Haddad", 39, 17, "BR-08732/2018",
    
    "RecordTV/RealTime Big Data", "2018-10-16", "2018-10-17", 5000, 2,
    "Bolsonaro", 52, 13, "BR-03883/2018",
    "RecordTV/RealTime Big Data", "2018-10-16", "2018-10-17", 5000, 2,
    "Haddad", 35, 13, "BR-03883/2018",
    
    "XP/Ipespe", "2018-10-15", "2018-10-17", 2000, 2.2,
    "Bolsonaro", 51, 13, "BR-05349/2018",
    "XP/Ipespe", "2018-10-15", "2018-10-17", 2000, 2.2,
    "Haddad", 37, 13, "BR-05349/2018",
    
    # 14–17 de outubro
    "Empiricus/Paraná Pesquisas", "2018-10-14", "2018-10-17", 2080, 2,
    "Bolsonaro", 52.9, 13.2, "BR-04446/2018",
    "Empiricus/Paraná Pesquisas", "2018-10-14", "2018-10-17", 2080, 2,
    "Haddad", 33.9, 13.2, "BR-04446/2018",
    
    # 13–14 de outubro
    "BTG Pactual/FSB Pesquisa", "2018-10-13", "2018-10-14", 2000, 2,
    "Bolsonaro", 51, 14, "BR-07950/2018",
    "BTG Pactual/FSB Pesquisa", "2018-10-13", "2018-10-14", 2000, 2,
    "Haddad", 35, 14, "BR-07950/2018",
    
    "Globo e O Estado de S. Paulo/IBOPE", "2018-10-13", "2018-10-14", 2506, 2,
    "Bolsonaro", 52, 11, "BR-01112/2018",
    "Globo e O Estado de S. Paulo/IBOPE", "2018-10-13", "2018-10-14", 2506, 2,
    "Haddad", 37, 11, "BR-01112/2018",
    
    # 12–13 de outubro
    "RecordTV/RealTime Big Data", "2018-10-12", "2018-10-13", 5000, 2,
    "Bolsonaro", 48, 19, "BR-00723/2018",
    "RecordTV/RealTime Big Data", "2018-10-12", "2018-10-13", 5000, 2,
    "Haddad", 33, 19, "BR-00723/2018",
    
    # 10 de outubro
    "Globo e Folha/Datafolha", "2018-10-10", "2018-10-10", 3235, 2,
    "Bolsonaro", 49, 14, "BR-00214/2018",
    "Globo e Folha/Datafolha", "2018-10-10", "2018-10-10", 3235, 2,
    "Haddad", 36, 14, "BR-00214/2018",
    
    # 8–10 de outubro
    "Ideia Big Data/Veja", "2018-10-08", "2018-10-10", 2036, 2.67,
    "Bolsonaro", 48, 11, "BR-09687/2018",
    "Ideia Big Data/Veja", "2018-10-08", "2018-10-10", 2036, 2.67,
    "Haddad", 41, 11, "BR-09687/2018",
    
    # 8–9 de outubro
    "XP/Ipespe", "2018-10-08", "2018-10-09", 2000, 2.2,
    "Bolsonaro", 51, 14, "BR-02361/2018",
    "XP/Ipespe", "2018-10-08", "2018-10-09", 2000, 2.2,
    "Haddad", 36, 14, "BR-02361/2018",
    
    # 5–6 de outubro
    "Globo e O Estado de S. Paulo/IBOPE", "2018-10-05", "2018-10-06", 3010, 2,
    "Bolsonaro", 45, 15, "BR-01537/2018",
    "Globo e O Estado de S. Paulo/IBOPE", "2018-10-05", "2018-10-06", 3010, 2,
    "Haddad", 41, 15, "BR-01537/2018",
    
    # 5–6 de outubro
    "Globo e Folha/Datafolha", "2018-10-05", "2018-10-06", 19552, 2,
    "Bolsonaro", 45, 12, "BR-01584/2018",
    "Globo e Folha/Datafolha", "2018-10-05", "2018-10-06", 19552, 2,
    "Haddad", 43, 12, "BR-01584/2018",
    
    # 4–5 de outubro
    "CNT/MDA", "2018-10-04", "2018-10-05", 2002, 2.2,
    "Bolsonaro", 45.2, 16.1, "BR-04819/2018",
    "CNT/MDA", "2018-10-04", "2018-10-05", 2002, 2.2,
    "Haddad", 38.7, 16.1, "BR-04819/2018",
    
    # 3–4 de outubro
    "XP/Ipespe", "2018-10-03", "2018-10-04", 2000, 2.2,
    "Bolsonaro", 43, 15, "BR-06509/2018",
    "XP/Ipespe", "2018-10-03", "2018-10-04", 2000, 2.2,
    "Haddad", 42, 15, "BR-06509/2018",
    
    # 3–4 de outubro
    "RecordTV/RealTime Big Data", "2018-10-03", "2018-10-04", 10000, 2,
    "Bolsonaro", 43, 17, "BR-05770/2018",
    "RecordTV/RealTime Big Data", "2018-10-03", "2018-10-04", 10000, 2,
    "Haddad", 40, 17, "BR-05770/2018",
    
    # 3–4 de outubro
    "DataPoder360", "2018-10-03", "2018-10-04", 4000, 2,
    "Bolsonaro", 45, 13, "BR-07142/2018",
    "DataPoder360", "2018-10-03", "2018-10-04", 4000, 2,
    "Haddad", 42, 13, "BR-07142/2018",
    
    # 3–4 de outubro
    "Globo e Folha/Datafolha", "2018-10-03", "2018-10-04", 10930, 2,
    "Bolsonaro", 44, 12, "BR-02581/2018",
    "Globo e Folha/Datafolha", "2018-10-03", "2018-10-04", 10930, 2,
    "Haddad", 43, 12, "BR-02581/2018",
    
    # 2–4 de outubro
    "Empiricus/Paraná Pesquisas", "2018-10-02", "2018-10-04", 2080, 2,
    "Bolsonaro", 47.1, 14.8, "BR-08437/2018",
    "Empiricus/Paraná Pesquisas", "2018-10-02", "2018-10-04", 2080, 2,
    "Haddad", 38.1, 14.8, "BR-08437/2018",
    
    # 28 de setembro–3 de outubro
    "Movimento Parlamentarista Brasileiro/Amostra", "2018-09-28", "2018-10-03", 2500, 2,
    "Bolsonaro", 37, 22, "BR-09143/2018",
    "Movimento Parlamentarista Brasileiro/Amostra", "2018-09-28", "2018-10-03", 2500, 2,
    "Haddad", 41, 22, "BR-09143/2018",
    
    # 2 de outubro
    "Folha/Datafolha", "2018-10-02", "2018-10-02", 3240, 2,
    "Bolsonaro", 44, 14, "BR-03147/2018",
    "Folha/Datafolha", "2018-10-02", "2018-10-02", 3240, 2,
    "Haddad", 42, 14, "BR-03147/2018",
    
    # 1–2 de outubro
    "Globo e O Estado de S. Paulo/IBOPE", "2018-10-01", "2018-10-02", 3010, 2,
    "Bolsonaro", 41, 15, "BR-08245/2018",
    "Globo e O Estado de S. Paulo/IBOPE", "2018-10-01", "2018-10-02", 3010, 2,
    "Haddad", 43, 15, "BR-08245/2018",
    
    # 29–30 de setembro
    "BTG Pactual/FSB Pesquisa", "2018-09-29", "2018-09-30", 2000, 2,
    "Bolsonaro", 43, 15, "BR-05879/2018",
    "BTG Pactual/FSB Pesquisa", "2018-09-29", "2018-09-30", 2000, 2,
    "Haddad", 42, 15, "BR-05879/2018",
    
    # 29–30 de setembro
    "Globo e O Estado de S. Paulo/IBOPE", "2018-09-29", "2018-09-30", 3010, 2,
    "Bolsonaro", 42, 17, "BR-08650/2018",
    "Globo e O Estado de S. Paulo/IBOPE", "2018-09-29", "2018-09-30", 3010, 2,
    "Haddad", 42, 17, "BR-08650/2018",
    
    # 28–29 de setembro (protocolo corrigido; na fonte: BR-06298/2018)
    "RecordTV/RealTime Big Data", "2018-09-28", "2018-09-29", 3200, 2,
    "Bolsonaro", 41, 14, "BR-06928/2018",
    "RecordTV/RealTime Big Data", "2018-09-28", "2018-09-29", 3200, 2,
    "Haddad", 45, 14, "BR-06928/2018",
    
    # 27–28 de setembro
    "CNT/MDA", "2018-09-27", "2018-09-28", 2000, 2.2,
    "Bolsonaro", 37.3, 20.0, "BR-03303/2018",
    "CNT/MDA", "2018-09-27", "2018-09-28", 2000, 2.2,
    "Haddad", 42.7, 20.0, "BR-03303/2018",
    
    # 26–28 de setembro
    "Globo e Folha/Datafolha", "2018-09-26", "2018-09-28", 9000, 2,
    "Bolsonaro", 39, 15, "BR-08687/2018",
    "Globo e Folha/Datafolha", "2018-09-26", "2018-09-28", 9000, 2,
    "Haddad", 45, 15, "BR-08687/2018",
    
    # 25–26 de setembro
    "Genial Investimentos/Brasilis", "2018-09-25", "2018-09-26", 1000, 3.5,
    "Bolsonaro", 36, 19, "BR-00592/2018",
    "Genial Investimentos/Brasilis", "2018-09-25", "2018-09-26", 1000, 3.5,
    "Haddad", 44, 19, "BR-00592/2018",
    
    # 24–26 de setembro
    "XP/Ipespe", "2018-09-24", "2018-09-26", 2000, 2.2,
    "Bolsonaro", 39, 18, "BR-00526/2018",
    "XP/Ipespe", "2018-09-24", "2018-09-26", 2000, 2.2,
    "Haddad", 43, 18, "BR-00526/2018",
    
    # 23–25 de setembro
    "Empiricus/Paraná Pesquisas", "2018-09-23", "2018-09-25", 2020, 2.0,
    "Bolsonaro", 44.3, 16.4, "BR-03512/2018",
    "Empiricus/Paraná Pesquisas", "2018-09-23", "2018-09-25", 2020, 2.0,
    "Haddad", 39.4, 16.4, "BR-03512/2018",
    
    # 22–24 de setembro
    "CNI/IBOPE", "2018-09-22", "2018-09-24", 2000, 2,
    "Bolsonaro", 38, 20, "BR-04669/2018",
    "CNI/IBOPE", "2018-09-22", "2018-09-24", 2000, 2,
    "Haddad", 42, 20, "BR-04669/2018",
    
    # 21–24 de setembro
    "IstoÉ/Sensus", "2018-09-21", "2018-09-24", 2000, 2.2,
    "Bolsonaro", 37.2, 26.6, "BR-02407/2018",
    "IstoÉ/Sensus", "2018-09-21", "2018-09-24", 2000, 2.2,
    "Haddad", 36.3, 26.6, "BR-02407/2018",
    
    # 22–23 de setembro
    "Globo e O Estado de S. Paulo/IBOPE", "2018-09-22", "2018-09-23", 2506, 2,
    "Bolsonaro", 37, 19, "BR-06630/2018",
    "Globo e O Estado de S. Paulo/IBOPE", "2018-09-22", "2018-09-23", 2506, 2,
    "Haddad", 43, 19, "BR-06630/2018",
    
    # 22–23 de setembro
    "BTG Pactual/FSB Pesquisa", "2018-09-22", "2018-09-23", 2000, 2,
    "Bolsonaro", 44, 15, "BR-03861/2018",
    "BTG Pactual/FSB Pesquisa", "2018-09-22", "2018-09-23", 2000, 2,
    "Haddad", 40, 15, "BR-03861/2018",
    
    # 19–20 de setembro
    "DataPoder360", "2018-09-19", "2018-09-20", 4000, 2,
    "Bolsonaro", 40, 17, "BR-02039/2018",
    "DataPoder360", "2018-09-19", "2018-09-20", 4000, 2,
    "Haddad", 43, 17, "BR-02039/2018",
    
    # 18–19 de setembro
    "Globo e Folha/Datafolha", "2018-09-18", "2018-09-19", 8601, 2,
    "Bolsonaro", 41, 17, "BR-06919/2018",
    "Globo e Folha/Datafolha", "2018-09-18", "2018-09-19", 8601, 2,
    "Haddad", 41, 17, "BR-06919/2018",
    
    # 17–19 de setembro
    "Genial Investimentos/Brasilis", "2018-09-17", "2018-09-19", 1000, 3.5,
    "Bolsonaro", 42, 18, "BR-01687/2018",
    "Genial Investimentos/Brasilis", "2018-09-17", "2018-09-19", 1000, 3.5,
    "Haddad", 40, 18, "BR-01687/2018",
    
    # 17–19 de setembro
    "XP/Ipespe", "2018-09-17", "2018-09-19", 2000, 2.2,
    "Bolsonaro", 41, 21, "BR-02995/2018",
    "XP/Ipespe", "2018-09-17", "2018-09-19", 2000, 2.2,
    "Haddad", 41, 21, "BR-02995/2018",
    
    # 16–18 de setembro
    "Globo e O Estado de S. Paulo/IBOPE", "2018-09-16", "2018-09-18", 2506, 2,
    "Bolsonaro", 40, 20, "BR-09678/2018",
    "Globo e O Estado de S. Paulo/IBOPE", "2018-09-16", "2018-09-18", 2506, 2,
    "Haddad", 40, 20, "BR-09678/2018",
    
    # 15–16 de setembro
    "BTG Pactual/FSB Pesquisa", "2018-09-15", "2018-09-16", 2000, 2,
    "Bolsonaro", 46, 16, "BR-06478/2018",
    "BTG Pactual/FSB Pesquisa", "2018-09-15", "2018-09-16", 2000, 2,
    "Haddad", 38, 16, "BR-06478/2018",
    
    # 12–15 de setembro
    "CNT/MDA", "2018-09-12", "2018-09-15", 2002, 2.2,
    "Bolsonaro", 39.0, 25.3, "BR-04362/2018",
    "CNT/MDA", "2018-09-12", "2018-09-15", 2002, 2.2,
    "Haddad", 35.7, 25.3, "BR-04362/2018",
    
    # 13–14 de setembro
    "Globo e Folha/Datafolha", "2018-09-13", "2018-09-14", 2820, 2,
    "Bolsonaro", 41, 19, "BR-05596/2018",
    "Globo e Folha/Datafolha", "2018-09-13", "2018-09-14", 2820, 2,
    "Haddad", 40, 19, "BR-05596/2018",
    
    # 10–12 de setembro
    "XP/Ipespe", "2018-09-10", "2018-09-12", 2000, 2.2,
    "Bolsonaro", 40, 22, "BR-07277/2018",
    "XP/Ipespe", "2018-09-10", "2018-09-12", 2000, 2.2,
    "Haddad", 38, 22, "BR-07277/2018",
    
    # 7–11 de setembro
    "CUT/Vox Populi", "2018-09-07", "2018-09-11", 2000, 2.2,
    "Bolsonaro", 24, 40, "BR-01669/2018",
    "CUT/Vox Populi", "2018-09-07", "2018-09-11", 2000, 2.2,
    "Haddad", 36, 40, "BR-01669/2018",
    
    # 10 de setembro
    "Globo e Folha/Datafolha", "2018-09-10", "2018-09-10", 2804, 2,
    "Bolsonaro", 38, 23, "BR-02376/2018",
    "Globo e Folha/Datafolha", "2018-09-10", "2018-09-10", 2804, 2,
    "Haddad", 39, 23, "BR-02376/2018",
    
    # 8–10 de setembro
    "IBOPE", "2018-09-08", "2018-09-10", 2002, 2,
    "Bolsonaro", 40, 24, "BR-05221/2018",
    "IBOPE", "2018-09-08", "2018-09-10", 2002, 2,
    "Haddad", 36, 24, "BR-05221/2018",
    
    # 7–9 de setembro
    "RecordTV/RealTime Big Data", "2018-09-07", "2018-09-09", 3200, 2,
    "Bolsonaro", 36, 31, "BR-05291/2018",
    "RecordTV/RealTime Big Data", "2018-09-07", "2018-09-09", 3200, 2,
    "Haddad", 33, 31, "BR-05291/2018",
    
    # 3–5 de setembro
    "XP/Ipespe", "2018-09-03", "2018-09-05", 2000, 2.2,
    "Bolsonaro", 39, 26, "BR-00339/2018",
    "XP/Ipespe", "2018-09-03", "2018-09-05", 2000, 2.2,
    "Haddad", 36, 26, "BR-00339/2018",
    
    # 1–3 de setembro
    "Globo e O Estado de S. Paulo/IBOPE", "2018-09-01", "2018-09-03", 2002, 2,
    "Bolsonaro", 37, 27, "BR-05003/2018",
    "Globo e O Estado de S. Paulo/IBOPE", "2018-09-01", "2018-09-03", 2002, 2,
    "Haddad", 36, 27, "BR-05003/2018",
    
    # 27–29 de agosto
    "XP/Ipespe", "2018-08-27", "2018-08-29", 1000, 3.2,
    "Bolsonaro", 37, 29, "BR-07252/2018",
    "XP/Ipespe", "2018-08-27", "2018-08-29", 1000, 3.2,
    "Haddad", 34, 29, "BR-07252/2018",
    
    # 20–22 de agosto
    "XP/Ipespe", "2018-08-20", "2018-08-22", 1000, 3.2,
    "Bolsonaro", 38, 30, "BR-07829/2018",
    "XP/Ipespe", "2018-08-20", "2018-08-22", 1000, 3.2,
    "Haddad", 32, 30, "BR-07829/2018",
    
    # 20–21 de agosto
    "Globo e Folha/Datafolha", "2018-08-20", "2018-08-21", 8433, 2,
    "Bolsonaro", 38, 33, "BR-04023/2018",
    "Globo e Folha/Datafolha", "2018-08-20", "2018-08-21", 8433, 2,
    "Haddad", 29, 33, "BR-04023/2018",
    
    # 13–15 de agosto
    "XP/Ipespe", "2018-08-13", "2018-08-15", 1000, 3.2,
    "Bolsonaro", 37, 31, "BR-02075/2018",
    "XP/Ipespe", "2018-08-13", "2018-08-15", 1000, 3.2,
    "Haddad", 32, 31, "BR-02075/2018",
    
    # 10–12 de agosto
    "RealTime Big Data", "2018-08-10", "2018-08-12", 3200, 2,
    "Bolsonaro", 39, 36, "BR-09102/2018",
    "RealTime Big Data", "2018-08-10", "2018-08-12", 3200, 2,
    "Haddad", 25, 36, "BR-09102/2018",
    
    # 6–8 de agosto
    "XP/Ipespe", "2018-08-06", "2018-08-08", 1000, 3.2,
    "Bolsonaro", 37, 34, "BR-08988/2018",
    "XP/Ipespe", "2018-08-06", "2018-08-08", 1000, 3.2,
    "Haddad", 29, 34, "BR-08988/2018",
    
    # 30 de julho–1 de agosto
    "XP/Ipespe", "2018-07-30", "2018-08-01", 1000, 3.2,
    "Bolsonaro", 37, 35, "BR-06820/2018",
    "XP/Ipespe", "2018-07-30", "2018-08-01", 1000, 3.2,
    "Haddad", 28, 35, "BR-06820/2018",
    
    # 23–25 de julho
    "XP/Ipespe", "2018-07-23", "2018-07-25", 1000, 3.2,
    "Bolsonaro", 38, 36, "BR-07756/2018",
    "XP/Ipespe", "2018-07-23", "2018-07-25", 1000, 3.2,
    "Haddad", 27, 36, "BR-07756/2018",
    
    # 20–23 de julho
    "Veja/Ideia Big Data", "2018-07-20", "2018-07-23", 2036, 2.67,
    "Bolsonaro", 31, 54, "BR-04178/2018",
    "Veja/Ideia Big Data", "2018-07-20", "2018-07-23", 2036, 2.67,
    "Haddad", 15, 54, "BR-04178/2018",
    
    # 16–18 de julho
    "XP/Ipespe", "2018-07-16", "2018-07-18", 1000, 3.2,
    "Bolsonaro", 38, 35, "BR-02843/2018",
    "XP/Ipespe", "2018-07-16", "2018-07-18", 1000, 3.2,
    "Haddad", 28, 35, "BR-02843/2018",
    
    # 25–29 de junho
    "DataPoder360", "2018-06-25", "2018-06-29", 5500, 2,
    "Bolsonaro", 36, 41, "BR-05297/2018",
    "DataPoder360", "2018-06-25", "2018-06-29", 5500, 2,
    "Haddad", 23, 41, "BR-05297/2018",
    
    # 6–7 de junho
    "Datafolha", "2018-06-06", "2018-06-07", 2824, 2,
    "Bolsonaro", 36, 37, "BR-05110/2018",
    "Datafolha", "2018-06-06", "2018-06-07", 2824, 2,
    "Haddad", 27, 37, "BR-05110/2018",
    
    # 25–31 de maio
    "DataPoder360", "2018-05-25", "2018-05-31", 10500, 1.8,
    "Bolsonaro", 35, 45, "BR-09186/2018",
    "DataPoder360", "2018-05-25", "2018-05-31", 10500, 1.8,
    "Haddad", 20, 45, "BR-09186/2018",
    
    # 9–12 de maio
    "CNT/MDA", "2018-05-09", "2018-05-12", 2002, 2.2,
    "Bolsonaro", 31.5, 54.5, "BR-09430/2018",
    "CNT/MDA", "2018-05-09", "2018-05-12", 2002, 2.2,
    "Haddad", 14, 54.5, "BR-09430/2018",
    
    # 11–13 de abril
    "Datafolha", "2018-04-11", "2018-04-13", 4260, 2,
    "Bolsonaro", 37, 37, "BR-08510/2018",
    "Datafolha", "2018-04-11", "2018-04-13", 4260, 2,
    "Haddad", 26, 37, "BR-08510/2018",
  )

# ============================================================
# 3. FORMATO LONGO (UMA LINHA POR CANDIDATO x PESQUISA x TURNO)
# ============================================================
# Percentuais convertidos para proporção (0-1).

padronizar_instituto <- function(instituto) {
  case_when(
    str_detect(instituto, "Datafolha") ~ "Datafolha",
    str_detect(instituto, "DataPoder360") ~ "DataPoder360",
    str_detect(instituto, "XP/Ipespe") ~ "XP/Ipespe",
    str_detect(instituto, "FSB Pesquisa") ~ "BTG Pactual/FSB Pesquisa",
    str_detect(instituto, "IBOPE") ~ "IBOPE",
    str_detect(instituto, "CNT/MDA") ~ "CNT/MDA",
    str_detect(instituto, "Paraná Pesquisas") ~ "Paraná Pesquisas",
    str_detect(instituto, "RealTime Big Data") ~ "RecordTV/RealTime Big Data",
    str_detect(instituto, "Ideia Big Data") ~ "Ideia Big Data/Veja",
    str_detect(instituto, "Brasilis") ~ "Genial Investimentos/Brasilis",
    str_detect(instituto, "Vox Populi") ~ "CUT/Vox Populi",
    str_detect(instituto, "Amostra") ~ "Amostra Instituto de Pesquisa",
    TRUE ~ instituto
  )
}

base_1T <- base_1T_raw %>%
  pivot_longer(
    cols = c(haddad, gomes, silva, meirelles, dias, alckmin, amoedo, bolsonaro),
    names_to = "nome_clean",
    values_to = "percentual"
  ) %>%
  filter(!is.na(percentual)) %>%
  mutate(turno = 1L)

base_2T <- base_2T_raw %>%
  mutate(
    turno = 2L,
    outros = NA_real_,
    nome_clean = case_when(
      nome_candidato == "Bolsonaro" ~ "bolsonaro",
      nome_candidato == "Haddad" ~ "haddad",
      TRUE ~ nome_candidato
    )
  ) %>%
  select(-nome_candidato)

base_2018 <- bind_rows(base_1T, base_2T) %>%
  mutate(
    data_inicio = as.Date(data_inicio),
    data_fim = as.Date(data_fim),
    percentual = percentual / 100,
    outros = outros / 100,
    abstencao_nao_decidiu = abstencao_nao_decidiu / 100,
    instituto_metodologia = padronizar_instituto(instituto)
  )

# ============================================================
# 4. METODOLOGIA DOCUMENTADA NA WIKIPÉDIA (POR INSTITUTO)
# ============================================================
# Usada só como uma das fontes da metodologia consolidada (seção 10).
# Na Wikipédia as características só registram presença: 1 ou NA.

caracteristicas_instituto <- tribble(
  ~instituto_metodologia, ~modelo_coleta, ~tipo_coleta, ~selecao_amostra,
  ~estratificacao, ~cotas, ~ponderacao, ~local_entrevista, ~checagem_pct,
  ~telefone_fixo_movel, ~ordem_candidatos_aleatoria, ~universo, ~fonte_metodologia,
  "Amostra Instituto de Pesquisa", "presencial", "entrevista presencial", "probabilística aleatória; três estágios", "região geográfica; natureza do município", "sexo; faixa etária", NA, "bairros e pontos de abordagem", 20, NA, NA, "eleitores", "Wikipédia — metodologias de 2018",
  "Genial Investimentos/Brasilis", "telefonica_entrevistador", "telefone com entrevistador", "aleatória a partir de banco de números fixos e móveis; estratificada por DDD", "DDD; região; tipo de telefonia; nota?; idade", NA, NA, "telefone", NA, "fixo e móvel", NA, "eleitores com acesso à telefonia fixa ou móvel", "Wikipédia — metodologias de 2018",
  "Datafolha", "presencial", "entrevista presencial", "amostragem estratificada; sorteio aleatório dos entrevistados", "sexo; idade", NA, NA, "pontos de fluxo", NA, NA, NA, "eleitores com 16 anos ou mais", "Wikipédia — metodologias de 2018",
  "DataPoder360", "telefonica_IVR", "telefone por IVR", "números discados de maneira aleatória e automática pelo discador", NA, NA, "sexo; idade; grau de instrução; região", "telefone", NA, "fixo e móvel", NA, NA, "Wikipédia — metodologias de 2018",
  "BTG Pactual/FSB Pesquisa", "telefonica_entrevistador", "telefone com entrevistador", NA, NA, "sexo; idade; região; tipo de telefonia", "fator de ponderação para corrigir distorções em relação ao plano amostral", "telefone", NA, "fixo e móvel", NA, NA, "Wikipédia — metodologias de 2018",
  "IBOPE", "presencial", "entrevista pessoal", "conglomerados em três estágios; PPT nos dois primeiros estágios", "sexo; idade; instrução; atividade", "sexo; grupo de idade; instrução; atividade", NA, "domicílio", 20, NA, NA, "eleitorado; conforme pesquisa/contratante", "Wikipédia — metodologias de 2018",
  "XP/Ipespe", "telefonica_entrevistador", "telefone com entrevistador", "amostra representativa dos eleitores com acesso à rede telefônica fixa e celular", "sexo; idade; escolaridade; renda familiar", NA, NA, "telefone", 20, "fixo e móvel", 1, "eleitores brasileiros com acesso à rede telefônica fixa e celular", "Wikipédia — metodologias de 2018",
  "CNT/MDA", NA, NA, "sorteio aleatório de municípios com PPT; amostragem por cotas", "região; unidades da federação; porte do município; zona urbana/rural", "região; município; porte do município; zona urbana/rural; sexo; idade; renda familiar", NA, NA, 20, NA, NA, NA, "Wikipédia — metodologias de 2018",
  "Paraná Pesquisas", NA, NA, "três etapas; PPT para municípios e setores censitários; seleção final por quotas", NA, "sexo; faixa etária; escolaridade; nível econômico", NA, "setores censitários", 20, NA, NA, "eleitores com 16 anos ou mais", "Wikipédia — metodologias de 2018",
  "CUT/Vox Populi", "presencial", "entrevista pessoal e domiciliar com tablet", NA, NA, "sexo; idade; escolaridade; renda", NA, "domicílio", NA, NA, NA, "população brasileira com 16 anos ou mais; urbana e rural", "Wikipédia — metodologias de 2018",
  "Ideia Big Data/Veja", NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA,
  "RecordTV/RealTime Big Data", NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA
)

base_2018 <- base_2018 %>%
  left_join(
    caracteristicas_instituto %>%
      select(instituto_metodologia, modelo_coleta, selecao_amostra,
             estratificacao, cotas, local_entrevista),
    by = "instituto_metodologia"
  ) %>%
  mutate(
    .wiki_modelo = modelo_coleta,
    .wiki_domiciliar = str_detect(coalesce(local_entrevista, ""), regex("domic", ignore_case = TRUE)),
    .wiki_fluxo = str_detect(coalesce(local_entrevista, ""),
                             regex("ponto[s]? de fluxo|pontos de abordagem", ignore_case = TRUE)),
    .wiki_local = case_when(
      .wiki_domiciliar & .wiki_fluxo ~ "domiciliar_ou_fluxo",
      .wiki_domiciliar ~ "domiciliar",
      .wiki_fluxo ~ "ponto_fluxo",
      modelo_coleta %in% c("telefonica_entrevistador", "telefonica_IVR") ~ "telefone",
      TRUE ~ NA_character_
    ),
    .wiki_cotas = if_else(!is.na(cotas), 1, NA_real_),
    .wiki_estratificacao = if_else(!is.na(estratificacao), 1, NA_real_),
    .wiki_ppt = if_else(
      str_detect(coalesce(selecao_amostra, ""),
                 regex("PPT|probabilidade proporcional", ignore_case = TRUE)), 1, NA_real_),
    .wiki_multiestagio = if_else(
      str_detect(coalesce(selecao_amostra, ""),
                 regex("três etapas|tres etapas|três estágios|tres estagios|estágios", ignore_case = TRUE)),
      1, NA_real_)
  ) %>%
  select(-modelo_coleta, -selecao_amostra, -estratificacao, -cotas, -local_entrevista,
         -.wiki_domiciliar, -.wiki_fluxo)

# ============================================================
# 5. REGISTRO NO TSE
# ============================================================
# Pareamento pelo protocolo:
#   - o TSE grava o protocolo sem separadores ("BR070522018"); a chave
#     do join é o protocolo sem "-" e "/";
#   - protocolos reaproveitados pelo TSE (o mesmo número para duas
#     pesquisas): fica o registro com data de término mais próxima;
#   - co-contratantes (Globo + Folha, Globo + Estadão): unidos numa linha.

tse_2018 <- read_delim(
  arquivo_tse,
  delim = ";",
  locale = locale(encoding = "Latin1"),
  na = c("#NULO#", ""),
  show_col_types = FALSE,
  trim_ws = TRUE
) %>%
  filter(SG_UF == "BR", SG_UE == "BR") %>%
  transmute(
    reg_join = NR_PROTOCOLO_REGISTRO,
    dt_registro = dmy(DT_REGISTRO),
    dt_inicio_tse = dmy(DT_INICIO_PESQUISA),
    dt_fim_tse = dmy(DT_FIM_PESQUISA),
    amostra_tse = as.numeric(QT_ENTREVISTADOS),
    empresa_pesquisa = NM_EMPRESA,
    empresa_fantasia = NM_EMPRESA_FANTASIA,
    contratante_tse = NM_CONTRATANTE,
    valor_pesquisa = parse_number(
      as.character(VR_PESQUISA),
      locale = locale(decimal_mark = ",", grouping_mark = ".")
    ),
    metodologia_pesquisa = DS_METODOLOGIA_PESQUISA,
    plano_amostral = DS_PLANO_AMOSTRAL,
    sistema_controle = DS_SISTEMA_CONTROLE,
    dado_municipio = DS_DADO_MUNICIPIO,
    # versão 6: financiamento e responsável técnico
    .cnpj_empresa = NR_CNPJ_EMPRESA,
    .cnpj_contratante = NR_CPF_CNPJ_CONTRATANTE,
    origem_recurso_tse = DS_ORIGEM_RECURSO,
    pagante_tse = NM_PAGANTE_PESQUISA,
    estatistico_resp_tse = NM_ESTATISTICO_RESP
  ) %>%
  # (d) co-contratantes numa linha só
  group_by(reg_join, dt_fim_tse) %>%
  mutate(
    # autofinanciada: a própria empresa de pesquisa é a contratante
    pesquisa_autofinanciada = as.numeric(any(.cnpj_empresa == .cnpj_contratante, na.rm = TRUE)),
    contratante_tse = paste(unique(contratante_tse), collapse = " | "),
    origem_recurso_tse = paste(unique(na.omit(origem_recurso_tse)), collapse = " | "),
    pagante_tse = paste(unique(na.omit(pagante_tse)), collapse = " | ")
  ) %>%
  slice(1) %>%
  ungroup() %>%
  mutate(across(c(origem_recurso_tse, pagante_tse), ~ na_if(.x, ""))) %>%
  select(-.cnpj_empresa, -.cnpj_contratante)

base_2018 <- base_2018 %>%
  mutate(
    reg_join = str_remove_all(registro_tse, "[-/]"),
    .linha = row_number()
  ) %>%
  left_join(tse_2018, by = "reg_join", relationship = "many-to-many") %>%
  group_by(.linha) %>%
  slice_min(abs(as.numeric(dt_fim_tse - data_fim)), n = 1, with_ties = FALSE) %>%
  ungroup() %>%
  mutate(
    # identificador: protocolo do TSE; sem registro (2017):
    # SEM-REGISTRO_<instituto>_<data de término>
    id_pesquisa = coalesce(
      registro_tse,
      paste0("SEM-REGISTRO_", str_remove_all(instituto_metodologia, "[^A-Za-z0-9]"),
             "_", format(data_fim, "%Y%m%d"))
    )
  ) %>%
  select(-reg_join, -.linha)

# ============================================================
# 6. CORREÇÕES PELO REGISTRO DO TSE
# ============================================================
# Seis pesquisas com datas e/ou amostra divergentes do TSE sem explicação
# metodológica: adota-se o TSE. Nas demais divergências mantém-se a base
# (janela de registro do IBOPE, amostra planejada x realizada, diferenças
# de 1-2 dias). Os valores originais ficam em *_wiki (usados só na
# auditoria, seção 12).

ids_corrigir_tse <- c(
  "BR-02460/2018",  # Datafolha 26-27/10 (2T): amostra 1.837 x 18.060
  "BR-09600/2018",  # XP/Ipespe 15-23/05: TSE 15-18/05, amostra 1.000
  "BR-07142/2018",  # DataPoder360 03-04/10: amostra 4.000 x 3.000
  "BR-01669/2018",  # CUT/Vox Populi 07-11/09: amostra 2.000 x 2.750
  "BR-09102/2018",  # RealTime Big Data 10-12/08: TSE 09-11/08
  "BR-03303/2018"   # CNT/MDA 27-28/09: TSE 27-29/09, amostra 2.002
)

base_2018 <- base_2018 %>%
  mutate(
    data_inicio_wiki = data_inicio,
    data_fim_wiki = data_fim,
    amostra_wiki = amostra,
    corrigido_tse = if_else(id_pesquisa %in% ids_corrigir_tse & !is.na(dt_fim_tse), 1, 0),
    data_inicio = if_else(corrigido_tse == 1, dt_inicio_tse, data_inicio),
    data_fim = if_else(corrigido_tse == 1, dt_fim_tse, data_fim),
    amostra = if_else(corrigido_tse == 1, amostra_tse, amostra),
    dias_campo = as.integer(data_fim - data_inicio) + 1L,
    dias_ate_eleicao = as.integer(
      if_else(turno == 1L, data_eleicao_1t, data_eleicao_2t) - data_fim
    )
  )

# ============================================================
# 7. METODOLOGIA REGISTRADA NO TSE (CODIFICADA)
# ============================================================
# Converte os textos do registro (metodologia, plano amostral e sistema de
# controle) em variáveis padronizadas, pesquisa a pesquisa.
#   tse_modo_coleta: telefonica_IVR / telefonica_entrevistador /
#                    presencial / misto
#   tse_modo_fonte:  "explicito" (declarado na metodologia) ou
#                    "implicito" (deduzido do sorteio de setores
#                    censitários, que só se aplica a coleta presencial)

# percentuais de checagem escritos por extenso (ex.: CNT/MDA:
# "um mínimo de vinte por cento de checagem")
extenso_pct <- c(
  "vinte e cinco" = 25, "cinco" = 5, "dez" = 10, "quinze" = 15,
  "vinte" = 20, "trinta" = 30, "quarenta" = 40, "cinquenta" = 50
)

norm_txt <- function(x) {
  x %>%
    coalesce("") %>%
    str_to_lower() %>%
    stringi::stri_trans_general("Latin-ASCII") %>%
    str_squish()
}

base_2018 <- base_2018 %>%
  mutate(
    .met = norm_txt(metodologia_pesquisa),
    .pla = norm_txt(plano_amostral),
    .ctl = norm_txt(sistema_controle),
    .tudo = paste(.met, .pla),
    # versão 6: o local da entrevista também é procurado no sistema de
    # controle (ex.: Sensus descreve "entrevistas individuais domiciliares"
    # nesse campo)
    .tudo_ctl = paste(.met, .pla, .ctl),

    .ivr  = str_detect(.met, "automatizad|\\bura\\b|\\bivr\\b|unidade de resposta"),
    .pres = str_detect(.met, "pessoa(l|is)\\b|face.a.face|pontos? de fluxo|domicil|abordagem pessoal"),
    .tel  = str_detect(.met, "telef"),

    tse_modo_coleta = case_when(
      is.na(empresa_pesquisa) ~ NA_character_,
      .ivr ~ "telefonica_IVR",
      .pres & .tel ~ "misto",
      .pres ~ "presencial",
      .tel ~ "telefonica_entrevistador",
      str_detect(.tudo, "setor(es)? censitario") ~ "presencial",
      str_detect(.pla, "telef") ~ "telefonica_entrevistador",
      TRUE ~ NA_character_
    ),
    tse_modo_fonte = case_when(
      is.na(tse_modo_coleta) ~ NA_character_,
      .ivr | .pres | .tel ~ "explicito",
      TRUE ~ "implicito"
    ),
    tse_local_entrevista = case_when(
      is.na(empresa_pesquisa) ~ NA_character_,
      tse_modo_coleta %in% c("telefonica_IVR", "telefonica_entrevistador") ~ "telefone",
      str_detect(.tudo_ctl, "domicil") & str_detect(.tudo_ctl, "fluxo") ~ "domiciliar_ou_fluxo",
      str_detect(.tudo_ctl, "domicil") ~ "domiciliar",
      str_detect(.tudo_ctl, "fluxo|pontos de abordagem") ~ "ponto_fluxo",
      TRUE ~ NA_character_
    ),
    tse_cotas         = if_else(is.na(empresa_pesquisa), NA_real_, as.numeric(str_detect(.tudo, "cota|quota"))),
    tse_ppt           = if_else(is.na(empresa_pesquisa), NA_real_, as.numeric(str_detect(.tudo, "\\bppt\\b|probabilidade proporcional"))),
    tse_multiestagio  = if_else(is.na(empresa_pesquisa), NA_real_, as.numeric(str_detect(.tudo, "estagio|etapa"))),
    tse_estratificacao = if_else(is.na(empresa_pesquisa), NA_real_, as.numeric(str_detect(.tudo, "estratific"))),
    tse_ponderacao    = if_else(is.na(empresa_pesquisa), NA_real_, as.numeric(str_detect(.tudo, "ponder|normaliz"))),
    tse_tablet        = if_else(is.na(empresa_pesquisa), NA_real_, as.numeric(str_detect(paste(.met, .ctl), "tablet|questionario eletronico"))),
    tse_checagem_pct  = suppressWarnings(as.numeric(str_extract(.ctl, "\\d{1,3}(?=\\s*%)"))),
    # versão 6: se não houver número com "%", procura o percentual por extenso
    .chk_extenso = str_match(.ctl, paste0("(", paste(names(extenso_pct), collapse = "|"), ") por cento"))[, 2],
    tse_checagem_pct  = coalesce(tse_checagem_pct, unname(extenso_pct[.chk_extenso])),
    tse_checagem_pct  = if_else(tse_checagem_pct > 0 & tse_checagem_pct <= 100, tse_checagem_pct, NA_real_)
  ) %>%
  select(-.met, -.pla, -.ctl, -.tudo, -.tudo_ctl, -.chk_extenso, -.ivr, -.pres, -.tel)

# ============================================================
# 8. METODOLOGIA DAS PESQUISAS SEM REGISTRO NO TSE (2017)
# ============================================================
# As pesquisas de 2017 não têm registro no TSE: a obrigação vale a partir
# de 1º de janeiro do ano da eleição (Resolução TSE nº 23.549/2017,
# art. 2º). A metodologia delas vem de duas fontes, nesta ordem:
#   1. FICHA TÉCNICA (preenchimento manual, tabela `metodologia_manual_2017`);
#   2. PERFIL DO INSTITUTO (reserva): moda dos registros do instituto no
#      TSE em 2018 (média para a checagem), usado quando a pesquisa está
#      marcada como "perfil_instituto" ou quando a ficha não informa um
#      campo (as células que caem no perfil são listadas no console).
# Só recebem esses valores as pesquisas SEM protocolo. Pesquisa com
# protocolo que não casou com o TSE fica como "registro_nao_pareado".

# ---- 8.a Perfil do instituto (reserva) ----------------------

moda <- function(x) {
  x <- x[!is.na(x)]
  if (length(x) == 0) return(x[NA_integer_])
  ux <- unique(x)
  ux[which.max(tabulate(match(x, ux)))]
}

share_moda <- function(x) {
  x <- x[!is.na(x)]
  if (length(x) == 0) return(NA_real_)
  mean(x == moda(x))
}

vars_perfil_cat <- c("tse_modo_coleta", "tse_local_entrevista", "tse_cotas", "tse_ppt",
                     "tse_multiestagio", "tse_estratificacao", "tse_ponderacao", "tse_tablet")
vars_metodologia <- c(vars_perfil_cat, "tse_checagem_pct")

perfil_metodologia_instituto <- base_2018 %>%
  filter(!is.na(empresa_pesquisa)) %>%
  distinct(instituto_metodologia, registro_tse, .keep_all = TRUE) %>%
  group_by(instituto_metodologia) %>%
  summarise(
    n_registros_tse = n(),
    across(all_of(vars_perfil_cat), moda, .names = "{.col}"),
    across(all_of(vars_perfil_cat), share_moda, .names = "share_{.col}"),
    tse_checagem_pct = mean(tse_checagem_pct, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  mutate(tse_checagem_pct = if_else(is.nan(tse_checagem_pct), NA_real_, tse_checagem_pct))

# ---- 8.b Tabela manual a partir das fichas técnicas ---------
#
# COMO PREENCHER
#   - Os valores já preenchidos são os do perfil do instituto (o que o
#     código imputava antes). Ao conferir a ficha técnica de uma pesquisa:
#       1. substitua os valores pelos da ficha;
#       2. troque `fonte` de "perfil_instituto" para "ficha_tecnica";
#       3. use `observacao` para anotar o documento (ex.: "PDF Poder360,
#          p. 2") ou algo relevante.
#   - Campo que a ficha não informa: deixe NA (o código usa o perfil do
#     instituto nessa célula e avisa).
#   - Enquanto `fonte` = "perfil_instituto", os valores da linha são
#     IGNORADOS e o perfil é usado.
#
# CÓDIGOS ACEITOS
#   tse_modo_coleta:      "presencial", "telefonica_entrevistador",
#                         "telefonica_IVR", "misto", "online"
#   tse_local_entrevista: "domiciliar", "ponto_fluxo",
#                         "domiciliar_ou_fluxo", "telefone"
#   tse_cotas, tse_ppt, tse_multiestagio, tse_estratificacao,
#   tse_ponderacao, tse_tablet:  1 = a ficha menciona; 0 = não menciona
#   tse_checagem_pct:     percentual de questionários checados (0 a 100)

metodologia_manual_2017 <- tribble(
  ~id_pesquisa,                         ~fonte,
  ~tse_modo_coleta,   ~tse_local_entrevista,
  ~tse_cotas, ~tse_ppt, ~tse_multiestagio, ~tse_estratificacao, ~tse_ponderacao, ~tse_tablet,
  ~tse_checagem_pct,  ~observacao,

  # DataPoder360 - campo 12-14/08/2017 - amostra 2.088
  "SEM-REGISTRO_DataPoder360_20170814", "perfil_instituto",
  "telefonica_IVR",   "telefone",
  0, 0, 0, 1, 1, 0,
  20,                 NA_character_,

  # DataPoder360 - campo 15-17/09/2017 - amostra 2.280
  "SEM-REGISTRO_DataPoder360_20170917", "perfil_instituto",
  "telefonica_IVR",   "telefone",
  0, 0, 0, 1, 1, 0,
  20,                 NA_character_,

  # Datafolha - campo 27-28/09/2017 - amostra 2.772
  "SEM-REGISTRO_Datafolha_20170928",    "perfil_instituto",
  "presencial",       "ponto_fluxo",
  1, 0, 1, 1, 1, 1,
  30,                 NA_character_,

  # IBOPE - campo 18-22/10/2017 - amostra 2.002
  "SEM-REGISTRO_IBOPE_20171022",        "perfil_instituto",
  "presencial",       NA_character_,
  1, 1, 1, 0, 1, 0,
  20,                 NA_character_,

  # DataPoder360 - campo 26-29/10/2017 - amostra 2.016
  "SEM-REGISTRO_DataPoder360_20171029", "perfil_instituto",
  "telefonica_IVR",   "telefone",
  0, 0, 0, 1, 1, 0,
  20,                 NA_character_,

  # DataPoder360 - campo 16-18/11/2017 - amostra 2.171
  "SEM-REGISTRO_DataPoder360_20171118", "perfil_instituto",
  "telefonica_IVR",   "telefone",
  0, 0, 0, 1, 1, 0,
  20,                 NA_character_,

  # Datafolha - campo 29-30/11/2017 - amostra 2.765
  "SEM-REGISTRO_Datafolha_20171130",    "perfil_instituto",
  "presencial",       "ponto_fluxo",
  1, 0, 1, 1, 1, 1,
  30,                 NA_character_,

  # DataPoder360 - campo 08-11/12/2017 - amostra 2.210
  "SEM-REGISTRO_DataPoder360_20171211", "perfil_instituto",
  "telefonica_IVR",   "telefone",
  0, 0, 0, 1, 1, 0,
  20,                 NA_character_
)

# ---- 8.c Conferência da tabela manual -----------------------

ids_sem_registro <- base_2018 %>%
  filter(is.na(registro_tse)) %>%
  distinct(id_pesquisa) %>%
  pull(id_pesquisa)

ids_desconhecidos <- setdiff(metodologia_manual_2017$id_pesquisa, ids_sem_registro)
if (length(ids_desconhecidos) > 0) {
  stop("IDs da tabela manual que não são pesquisas sem registro na base: ",
       paste(ids_desconhecidos, collapse = ", "))
}
ids_fora_da_tabela <- setdiff(ids_sem_registro, metodologia_manual_2017$id_pesquisa)
if (length(ids_fora_da_tabela) > 0) {
  warning("Pesquisas sem registro fora da tabela manual (recebem o perfil do instituto): ",
          paste(ids_fora_da_tabela, collapse = ", "))
}
stopifnot(
  all(metodologia_manual_2017$fonte %in% c("ficha_tecnica", "perfil_instituto")),
  all(metodologia_manual_2017$tse_modo_coleta %in%
        c("presencial", "telefonica_entrevistador", "telefonica_IVR", "misto", "online", NA)),
  all(metodologia_manual_2017$tse_local_entrevista %in%
        c("domiciliar", "ponto_fluxo", "domiciliar_ou_fluxo", "telefone", NA)),
  all(unlist(metodologia_manual_2017[c("tse_cotas", "tse_ppt", "tse_multiestagio",
                                       "tse_estratificacao", "tse_ponderacao", "tse_tablet")])
      %in% c(0, 1, NA)),
  all(is.na(metodologia_manual_2017$tse_checagem_pct) |
        between(metodologia_manual_2017$tse_checagem_pct, 0, 100))
)

# ---- 8.d Aplicação -------------------------------------------

base_2018 <- base_2018 %>%
  left_join(
    metodologia_manual_2017 %>%
      select(id_pesquisa, fonte, all_of(vars_metodologia)) %>%
      rename(fonte_ficha = fonte) %>%
      rename_with(~ paste0(.x, "_manual"), all_of(vars_metodologia)),
    by = "id_pesquisa"
  ) %>%
  left_join(
    perfil_metodologia_instituto %>%
      select(instituto_metodologia, all_of(vars_metodologia)) %>%
      rename_with(~ paste0(.x, "_perfil"), all_of(vars_metodologia)),
    by = "instituto_metodologia"
  ) %>%
  mutate(
    .sem_registro = is.na(registro_tse),
    .usa_ficha = .sem_registro & fonte_ficha %in% "ficha_tecnica",
    tse_metodologia_fonte = case_when(
      !is.na(empresa_pesquisa) ~ "registro_tse",
      .usa_ficha ~ "ficha_tecnica_manual",
      .sem_registro & !is.na(tse_modo_coleta_perfil) ~ "imputada_perfil_instituto",
      !.sem_registro ~ "registro_nao_pareado",
      TRUE ~ NA_character_
    )
  )

# células da ficha que ficaram NA e caem no perfil do instituto
celulas_perfil <- map_dfr(vars_metodologia, function(v) {
  base_2018 %>%
    filter(.usa_ficha, is.na(.data[[paste0(v, "_manual")]])) %>%
    distinct(id_pesquisa) %>%
    mutate(variavel = v)
})
if (nrow(celulas_perfil) > 0) {
  message("Campos sem informação na ficha técnica (usado o perfil do instituto):")
  print(celulas_perfil)
}

for (v in vars_metodologia) {
  manual <- base_2018[[paste0(v, "_manual")]]
  perfil <- base_2018[[paste0(v, "_perfil")]]
  base_2018[[v]] <- case_when(
    base_2018$.usa_ficha ~ coalesce(manual, perfil),
    base_2018$tse_metodologia_fonte %in% "imputada_perfil_instituto" ~ perfil,
    TRUE ~ base_2018[[v]]
  )
}

base_2018 <- base_2018 %>%
  mutate(
    tse_modo_fonte = case_when(
      .usa_ficha & !is.na(tse_modo_coleta_manual) ~ "ficha_tecnica",
      .usa_ficha ~ "imputado",
      tse_metodologia_fonte %in% "imputada_perfil_instituto" ~ "imputado",
      TRUE ~ tse_modo_fonte
    )
  ) %>%
  select(-ends_with("_manual"), -ends_with("_perfil"), -fonte_ficha,
         -.sem_registro, -.usa_ficha)

# Quadro para conferência
base_2018 %>%
  filter(is.na(registro_tse)) %>%
  distinct(id_pesquisa, tse_metodologia_fonte, tse_modo_fonte,
           across(all_of(vars_metodologia))) %>%
  print(n = Inf, width = Inf)

# ============================================================
# 9. IMPUTAÇÃO MANUAL DO MODO DE COLETA (REALTIME BIG DATA)
# ============================================================
# Três pesquisas da RealTime têm registro no TSE, mas o texto não declara
# o modo de coleta. Diferem das telefônicas do instituto (RecordTV,
# outubro, 5.000/10.000 entrevistas): amostra de 3.200, plano com
# "Divisão Censitária", cotas e equipe de campo com coordenação regional,
# supervisores e entrevistadores. Por decisão metodológica, presenciais
# (tse_modo_fonte = "imputado_manual"). O local da entrevista segue NA.

ids_realtime_presencial <- c("BR-09102/2018", "BR-05291/2018", "BR-06928/2018")

base_2018 <- base_2018 %>%
  mutate(
    .imputar_manual = id_pesquisa %in% ids_realtime_presencial & is.na(tse_modo_coleta),
    tse_modo_coleta = if_else(.imputar_manual, "presencial", tse_modo_coleta),
    tse_modo_fonte = if_else(.imputar_manual, "imputado_manual", tse_modo_fonte)
  ) %>%
  select(-.imputar_manual)

# ============================================================
# 10. METODOLOGIA CONSOLIDADA (WIKIPÉDIA + TSE)
# ============================================================
# modelo_coleta_final, em ordem de prioridade:
#   1) TSE explícito/implícito (registro da própria pesquisa) ou ficha
#      técnica (2017, seção 8);
#   2) Wikipédia;
#   3) TSE imputado (perfil do instituto ou imputação manual).
# Demais *_final: Wikipédia quando documentada; senão, TSE (no TSE,
# 0 = "não mencionado no registro").

base_2018 <- base_2018 %>%
  mutate(
    modelo_coleta_final = case_when(
      tse_modo_fonte %in% c("explicito", "implicito", "ficha_tecnica") ~ tse_modo_coleta,
      !is.na(.wiki_modelo) ~ .wiki_modelo,
      !is.na(tse_modo_coleta) ~ tse_modo_coleta,
      TRUE ~ NA_character_
    ),
    fonte_modelo_coleta = case_when(
      tse_modo_fonte == "explicito" ~ "tse_explicito",
      tse_modo_fonte == "implicito" ~ "tse_implicito",
      tse_modo_fonte == "ficha_tecnica" ~ "ficha_tecnica",
      !is.na(.wiki_modelo) ~ "wikipedia",
      tse_modo_fonte == "imputado" ~ "imputado_perfil_instituto",
      tse_modo_fonte == "imputado_manual" ~ "imputado_manual",
      TRUE ~ NA_character_
    ),
    coleta_presencial_final = case_when(
      is.na(modelo_coleta_final) ~ NA_real_,
      modelo_coleta_final %in% c("presencial", "misto") ~ 1,
      TRUE ~ 0
    ),
    coleta_telefone_final = case_when(
      is.na(modelo_coleta_final) ~ NA_real_,
      modelo_coleta_final %in% c("telefonica_IVR", "telefonica_entrevistador", "misto") ~ 1,
      TRUE ~ 0
    ),
    coleta_ivr_final = case_when(
      is.na(modelo_coleta_final) ~ NA_real_,
      modelo_coleta_final == "telefonica_IVR" ~ 1,
      TRUE ~ 0
    ),
    local_entrevista_final = coalesce(tse_local_entrevista, .wiki_local),
    usa_quotas_final = coalesce(.wiki_cotas, tse_cotas),
    ppt_final = coalesce(.wiki_ppt, tse_ppt),
    amostragem_multietapas_final = coalesce(.wiki_multiestagio, tse_multiestagio),
    tem_estratificacao_final = coalesce(.wiki_estratificacao, tse_estratificacao)
  ) %>%
  select(-starts_with(".wiki_"))

# ============================================================
# 11. FINANCIAMENTO E TIPO DE CONTRATANTE
# ============================================================
# pesquisa_autofinanciada: 1 = a empresa é a própria contratante no
# registro do TSE. tipo_contratante: classificação do contratante
# registrado. Pesquisas sem registro (2017) ficam NA.

base_2018 <- base_2018 %>%
  mutate(
    .contr = norm_txt(contratante_tse),
    tipo_contratante = case_when(
      is.na(empresa_pesquisa) ~ NA_character_,
      pesquisa_autofinanciada == 1 ~ "proprio_instituto",
      str_detect(.contr, "partido|fundo partidario") ~ "partido",
      str_detect(.contr, "banco|corretora|investimentos|empiricus") ~ "mercado_financeiro",
      str_detect(.contr, "folha|globo|estado de s|abril|record|editora|comunicac|jornal") ~ "midia",
      str_detect(.contr, "confederacao|federacao") ~ "entidade_empresarial",
      str_detect(.contr, "central unica|sindicato|movimento") ~ "sindical_ou_movimento",
      TRUE ~ "outro"
    )
  ) %>%
  select(-.contr)

# ============================================================
# 12. AUDITORIA DO PAREAMENTO COM O TSE (OBJETO À PARTE)
# ============================================================
# Uma linha por pesquisa. Não entra na base final.
# status_tse: ok / corrigido_tse / divergente_mantido_base /
#             sem_registro_ficha_tecnica / sem_registro_imputado /
#             registro_sem_tse

auditoria_tse <- base_2018 %>%
  group_by(id_pesquisa, registro_tse, instituto, instituto_metodologia,
           data_inicio_wiki, data_fim_wiki, amostra_wiki,
           data_inicio, data_fim, amostra,
           dt_inicio_tse, dt_fim_tse, amostra_tse,
           corrigido_tse, tse_metodologia_fonte, tse_modo_coleta) %>%
  summarise(turnos = paste(sort(unique(turno)), collapse = " e "), .groups = "drop") %>%
  mutate(
    diverge_inicio = !is.na(dt_inicio_tse) & data_inicio != dt_inicio_tse,
    diverge_fim = !is.na(dt_fim_tse) & data_fim != dt_fim_tse,
    diverge_amostra = !is.na(amostra_tse) & amostra != amostra_tse,
    status_tse = case_when(
      is.na(registro_tse) & tse_metodologia_fonte %in% "ficha_tecnica_manual" ~ "sem_registro_ficha_tecnica",
      is.na(registro_tse) & tse_metodologia_fonte %in% "imputada_perfil_instituto" ~ "sem_registro_imputado",
      is.na(registro_tse) ~ "sem_registro",
      is.na(dt_fim_tse) ~ "registro_sem_tse",
      corrigido_tse == 1 ~ "corrigido_tse",
      diverge_inicio | diverge_fim | diverge_amostra ~ "divergente_mantido_base",
      TRUE ~ "ok"
    )
  ) %>%
  arrange(status_tse, data_fim)

auditoria_tse %>% count(status_tse)

auditoria_tse %>%
  filter(status_tse != "ok") %>%
  select(status_tse, id_pesquisa, instituto, turnos,
         data_inicio_wiki, data_fim_wiki, amostra_wiki,
         data_inicio, data_fim, amostra, tse_modo_coleta) %>%
  print(n = Inf)

# ============================================================
# 13. VARIÁVEIS DERIVADAS
# ============================================================

feriados_nacionais_2018 <- as.Date(c(
  "2018-01-01", "2018-02-13", "2018-03-30", "2018-04-21", "2018-05-01",
  "2018-09-07", "2018-10-12", "2018-11-02", "2018-11-15", "2018-12-25"
))

dias_do_campo <- function(inicio, fim) map2(inicio, fim, ~ seq(.x, .y, by = "day"))

# ---- 13.1 Escopo, votos válidos e cenário --------------------
# percentual_validos = percentual / (soma dos candidatos + outros);
# exclui brancos, nulos e indecisos, como o resultado oficial.

base_2018 <- base_2018 %>%
  group_by(id_pesquisa, turno) %>%
  mutate(
    percentual_validos = percentual / (sum(percentual, na.rm = TRUE) + coalesce(first(outros), 0)),
    # candidatos principais no cenário (os 8 acompanhados)
    n_candidatos_cenario = n_distinct(nome_clean)
  ) %>%
  ungroup() %>%
  mutate(
    boca_de_urna = if_else(
      data_inicio == data_fim & data_fim %in% c(data_eleicao_1t, data_eleicao_2t), 1, 0),
    pre_ano_eleitoral = if_else(year(data_fim) < 2018, 1, 0)
  )

# ---- 13.2 Tamanho, precisão e calendário ---------------------

base_2018 <- base_2018 %>%
  mutate(
    log_amostra = if_else(!is.na(amostra) & amostra > 0, log(amostra), NA_real_),
    # erro-padrão teórico sob amostragem aleatória simples
    se_p = if_else(!is.na(amostra) & amostra > 0,
                   sqrt(percentual * (1 - percentual) / amostra), NA_real_),
    margem_teorica_95 = 1.96 * se_p * 100,
    diferenca_margem_teorica = margem_erro - margem_teorica_95,
    amostra_grande = if_else(amostra >= 5000, 1, 0),
    .dias = dias_do_campo(data_inicio, data_fim),
    dias_uteis_campo = map_dbl(.dias, ~ sum(wday(.x) %in% 2:6)),
    coleta_sabado = map_dbl(.dias, ~ as.numeric(any(wday(.x) == 7))),
    coleta_domingo = map_dbl(.dias, ~ as.numeric(any(wday(.x) == 1))),
    coleta_feriado_nacional = map_dbl(.dias, ~ as.numeric(any(.x %in% feriados_nacionais_2018))),
    inicio_campo_dia_semana = as.character(wday(data_inicio, label = TRUE, abbr = FALSE)),
    fim_campo_dia_semana = as.character(wday(data_fim, label = TRUE, abbr = FALSE))
  ) %>%
  select(-.dias)

# ---- 13.3 Frequência e recência do instituto -----------------
# Calculadas no nível da PESQUISA:
#   - dias_desde_ultima_pesquisa_instituto: fim do campo menos o fim da
#     pesquisa anterior do mesmo instituto (independente do turno);
#   - n_pesquisas_instituto_turno: ordem da pesquisa no instituto e turno,
#     contando só as anteriores (1 = primeira).

recencia_instituto <- base_2018 %>%
  distinct(instituto_metodologia, id_pesquisa, data_inicio, data_fim) %>%
  arrange(instituto_metodologia, data_fim, data_inicio, id_pesquisa) %>%
  group_by(instituto_metodologia) %>%
  mutate(dias_desde_ultima_pesquisa_instituto = as.numeric(data_fim - lag(data_fim))) %>%
  ungroup() %>%
  select(instituto_metodologia, id_pesquisa, dias_desde_ultima_pesquisa_instituto)

ordem_instituto_turno <- base_2018 %>%
  distinct(instituto_metodologia, turno, id_pesquisa, data_inicio, data_fim) %>%
  arrange(instituto_metodologia, turno, data_fim, data_inicio, id_pesquisa) %>%
  group_by(instituto_metodologia, turno) %>%
  mutate(n_pesquisas_instituto_turno = row_number()) %>%
  ungroup() %>%
  select(instituto_metodologia, turno, id_pesquisa, n_pesquisas_instituto_turno)

base_2018 <- base_2018 %>%
  left_join(recencia_instituto, by = c("instituto_metodologia", "id_pesquisa")) %>%
  left_join(ordem_instituto_turno, by = c("instituto_metodologia", "turno", "id_pesquisa"))

# ---- 13.4 Consenso anterior ----------------------------------
# Média e desvio-padrão das pesquisas encerradas ANTES desta (mesmo
# candidato e turno). Limitação conhecida: usa todas as pesquisas
# anteriores desde 2017, com o mesmo peso (ver README).

base_2018 <- base_2018 %>%
  mutate(
    consenso_previo = map_dbl(seq_len(n()), function(i) {
      ok <- turno == turno[i] & nome_clean == nome_clean[i] & data_fim < data_fim[i]
      if (!any(ok)) NA_real_ else mean(percentual[ok], na.rm = TRUE)
    }),
    desvio_padrao_consenso = map_dbl(seq_len(n()), function(i) {
      ok <- turno == turno[i] & nome_clean == nome_clean[i] & data_fim < data_fim[i]
      if (sum(ok) < 2) NA_real_ else sd(percentual[ok], na.rm = TRUE)
    }),
    distancia_consenso = percentual - consenso_previo,
    z_consenso = distancia_consenso / desvio_padrao_consenso,
    outlier = case_when(is.na(z_consenso) ~ NA_real_, abs(z_consenso) >= 2 ~ 1, TRUE ~ 0),
    direcao_vs_consenso = sign(distancia_consenso)
  )

# ---- 13.5 Movimento em relação à pesquisa anterior do mesmo instituto

base_2018 <- base_2018 %>%
  arrange(instituto_metodologia, turno, nome_clean, data_fim, data_inicio, id_pesquisa) %>%
  group_by(instituto_metodologia, turno, nome_clean) %>%
  mutate(
    percentual_pesquisa_anterior = lag(percentual),
    movimento_candidato = percentual - percentual_pesquisa_anterior,
    dias_desde_pesquisa_anterior_candidato = as.numeric(data_fim - lag(data_fim))
  ) %>%
  ungroup()

# ============================================================
# 14. MERCADO DE PREVISÃO (BETFAIR)
# ============================================================
# Painel diário candidato x dia (horário de Brasília), mercado "Next
# President" (01/05 a 28/10/2018). O mercado precifica a probabilidade de
# VENCER a eleição, não o percentual de votos.
#   - "véspera" = dia anterior ao início do campo; valores de fechamento;
#   - variações em pontos de probabilidade (escala 0-1);
#   - janelas que passam por dia de votação são calculadas e marcadas nas
#     flags *_inclui_votacao;
#   - fora da cobertura do mercado (antes de 01/05/2018 ou candidato ainda
#     não listado; Haddad só a partir de 10/09/2018): NA, sem imputação.
#   - prob_vitoria_pesquisa (2º turno): erro total = 2x o erro amostral
#     (Shirani-Mehr, Rothschild, Goel & Gelman, 2018, JASA).

# fator aplicado ao erro-padrão amostral para aproximar o erro total
# da pesquisa (amostral + não amostral). Referência: o erro total das
# pesquisas eleitorais costuma ser da ordem de 2x o erro amostral
# declarado (Shirani-Mehr, Rothschild, Goel & Gelman, 2018, JASA).
fator_erro_total <- 2

datas_eleicao <- c(data_eleicao_1t, data_eleicao_2t)
inicio_campanha_2t <- as.Date("2018-10-08")

betfair_diario <- read_csv(arquivo_betfair_diario, show_col_types = FALSE) %>%
  mutate(data_brt = as.Date(data_brt)) %>%
  arrange(nome_clean, data_brt) %>%
  group_by(nome_clean) %>%
  mutate(volume_cum = cumsum(volume_dia)) %>%
  ungroup() %>%
  select(nome_clean, data_brt, prob_norm, spread_prob, volume_cum)

chave_mercado <- paste(betfair_diario$nome_clean, betfair_diario$data_brt)

busca_mercado <- function(nome, data, coluna) {
  betfair_diario[[coluna]][match(paste(nome, data), chave_mercado)]
}

# TRUE se algum dia de votação cai em (a, b]: a variação do fechamento
# de a até o fechamento de b incorporaria o resultado da urna
janela_com_eleicao <- function(a, b) {
  (datas_eleicao[1] > a & datas_eleicao[1] <= b) |
    (datas_eleicao[2] > a & datas_eleicao[2] <= b)
}

base_2018 <- base_2018 %>%
  mutate(
    .vespera = data_inicio - 1,

    # --- nível na véspera -------------------------------------------
    probabilidade_mercado = busca_mercado(nome_clean, .vespera, "prob_norm"),

    liquidez_mercado = busca_mercado(nome_clean, .vespera, "spread_prob"),

    .vol_cum_vespera = busca_mercado(nome_clean, .vespera, "volume_cum"),
    .vol_cum_8d = busca_mercado(nome_clean, .vespera - 7, "volume_cum"),
    volume_mercado = if_else(
      is.na(.vol_cum_vespera),
      NA_real_,
      .vol_cum_vespera - coalesce(.vol_cum_8d, 0)
    ),

    # --- dinâmica antes, durante e depois da pesquisa ----------------
    # Os valores são calculados mesmo quando a janela passa por um dia
    # de votação; as flags *_inclui_votacao identificam esses casos.
    antecipacao_mercado = probabilidade_mercado -
      busca_mercado(nome_clean, data_inicio - 4, "prob_norm"),

    variacao_mercado = busca_mercado(nome_clean, data_fim, "prob_norm") -
      probabilidade_mercado,

    reacao_mercado_pos = busca_mercado(nome_clean, data_fim + 2, "prob_norm") -
      busca_mercado(nome_clean, data_fim, "prob_norm"),

    antecipacao_inclui_votacao = if_else(
      is.na(antecipacao_mercado), NA_real_,
      as.numeric(janela_com_eleicao(data_inicio - 4, .vespera))
    ),
    variacao_inclui_votacao = if_else(
      is.na(variacao_mercado), NA_real_,
      as.numeric(janela_com_eleicao(.vespera, data_fim))
    ),
    reacao_inclui_votacao = if_else(
      is.na(reacao_mercado_pos), NA_real_,
      as.numeric(janela_com_eleicao(data_fim, data_fim + 2))
    )
  ) %>%
  # --- 2º turno: probabilidade de vitória implícita na pesquisa -------
  group_by(id_pesquisa, turno, data_fim) %>%
  mutate(
    .p_bolsonaro = if (any(nome_clean == "bolsonaro")) percentual[nome_clean == "bolsonaro"][1] else NA_real_,
    .p_haddad = if (any(nome_clean == "haddad")) percentual[nome_clean == "haddad"][1] else NA_real_
  ) %>%
  ungroup() %>%
  mutate(
    # participação de Bolsonaro nos votos válidos (só Bolsonaro + Haddad)
    .validos = .p_bolsonaro + .p_haddad,
    .v_bolsonaro = .p_bolsonaro / .validos,
    # amostra efetiva: só quem declarou voto em um dos dois
    .n_efetivo = amostra * .validos,
    .ep_total = sqrt(.v_bolsonaro * (1 - .v_bolsonaro) / .n_efetivo) * fator_erro_total,
    .pv_bolsonaro = pnorm((.v_bolsonaro - 0.5) / .ep_total),

    prob_vitoria_pesquisa = case_when(
      turno != 2L ~ NA_real_,
      nome_clean == "bolsonaro" ~ .pv_bolsonaro,
      nome_clean == "haddad" ~ 1 - .pv_bolsonaro,
      TRUE ~ NA_real_
    ),

    # Calculado para todas as pesquisas de 2º turno. Antes do 1º turno
    # (gap_pre_1turno = 1) a comparação é entre uma probabilidade
    # CONDICIONAL (pesquisa: "se o 2º turno for Haddad x Bolsonaro") e
    # uma INCONDICIONAL (mercado: "quem será presidente", o que inclui o
    # risco de o candidato nem chegar ao 2º turno). Nesses casos o gap
    # não deve ser lido como otimismo/pessimismo da pesquisa.
    gap_pesquisa_mercado = if_else(
      turno == 2L,
      prob_vitoria_pesquisa - probabilidade_mercado,
      NA_real_
    ),
    gap_pre_1turno = if_else(
      is.na(gap_pesquisa_mercado), NA_real_,
      as.numeric(data_inicio < inicio_campanha_2t)
    )
  ) %>%
  select(-starts_with("."))

# ============================================================
# 15. BASE FINAL E EXPORTAÇÃO
# ============================================================

dicionario_base_2018 <- tribble(
  ~coluna, ~grupo, ~descricao,
  # identificação e escopo
  "id_pesquisa", "identificacao", "Protocolo TSE; sem registro: SEM-REGISTRO_<instituto>_<data>",
  "instituto", "identificacao", "Instituto/contratante como divulgado",
  "instituto_metodologia", "identificacao", "Instituto padronizado",
  "turno", "identificacao", "1 ou 2",
  "nome_clean", "identificacao", "Candidato (código)",
  "data_inicio", "identificacao", "Início do campo",
  "data_fim", "identificacao", "Fim do campo",
  "dias_campo", "identificacao", "Duração do campo em dias",
  "dias_ate_eleicao", "identificacao", "Dias entre o fim do campo e a eleição do turno",
  "boca_de_urna", "identificacao", "1 = boca de urna",
  "pre_ano_eleitoral", "identificacao", "1 = pesquisa de 2017",
  "corrigido_tse", "identificacao", "1 = datas/amostra corrigidas pelo registro do TSE",
  # resultado da pesquisa
  "amostra", "resultado", "Número de entrevistas",
  "margem_erro", "resultado", "Margem de erro declarada (p.p.)",
  "percentual", "resultado", "Intenção de voto sobre votos totais (0-1)",
  "percentual_validos", "resultado", "Intenção de voto sobre votos válidos (0-1)",
  "outros", "resultado", "Outros candidatos (0-1); NA no 2º turno",
  "abstencao_nao_decidiu", "resultado", "Branco, nulo e indecisos (0-1)",
  # tamanho, precisão e calendário
  "log_amostra", "precisao_calendario", "Logaritmo da amostra",
  "se_p", "precisao_calendario", "Erro-padrão teórico (AAS) do percentual",
  "margem_teorica_95", "precisao_calendario", "Margem teórica a 95% (p.p.)",
  "diferenca_margem_teorica", "precisao_calendario", "Margem declarada - margem teórica",
  "amostra_grande", "precisao_calendario", "1 = amostra >= 2.000",
  "dias_uteis_campo", "precisao_calendario", "Dias úteis no período de campo",
  "coleta_sabado", "precisao_calendario", "1 = campo inclui sábado",
  "coleta_domingo", "precisao_calendario", "1 = campo inclui domingo",
  "coleta_feriado_nacional", "precisao_calendario", "1 = campo inclui feriado nacional",
  "inicio_campo_dia_semana", "precisao_calendario", "Dia da semana do início do campo",
  "fim_campo_dia_semana", "precisao_calendario", "Dia da semana do fim do campo",
  # cenário, recência e consenso
  "n_candidatos_cenario", "cenario_recencia", "Candidatos principais no cenário",
  "n_pesquisas_instituto_turno", "cenario_recencia", "Ordem da pesquisa no instituto e turno",
  "dias_desde_ultima_pesquisa_instituto", "cenario_recencia", "Dias desde a pesquisa anterior do instituto",
  "percentual_pesquisa_anterior", "cenario_recencia", "Percentual na pesquisa anterior do mesmo instituto",
  "movimento_candidato", "cenario_recencia", "Variação contra a pesquisa anterior do mesmo instituto",
  "dias_desde_pesquisa_anterior_candidato", "cenario_recencia", "Dias desde essa pesquisa anterior",
  "consenso_previo", "cenario_recencia", "Média das pesquisas anteriores (ver limitação no README)",
  "distancia_consenso", "cenario_recencia", "Percentual - consenso",
  "desvio_padrao_consenso", "cenario_recencia", "Desvio-padrão das pesquisas anteriores",
  "z_consenso", "cenario_recencia", "Distância padronizada ao consenso",
  "outlier", "cenario_recencia", "1 = |z| >= 2",
  "direcao_vs_consenso", "cenario_recencia", "1 acima, -1 abaixo, 0 igual ao consenso",
  # metodologia consolidada
  "modelo_coleta_final", "metodologia", "Modo de coleta (Wikipédia + TSE)",
  "fonte_modelo_coleta", "metodologia", "Origem do modo de coleta",
  "coleta_presencial_final", "metodologia", "1 = presencial",
  "coleta_telefone_final", "metodologia", "1 = telefone (com entrevistador ou IVR)",
  "coleta_ivr_final", "metodologia", "1 = telefone automatizado (IVR)",
  "local_entrevista_final", "metodologia", "Domiciliar / ponto de fluxo / telefone",
  "usa_quotas_final", "metodologia", "1 = cotas",
  "ppt_final", "metodologia", "1 = probabilidade proporcional ao tamanho",
  "amostragem_multietapas_final", "metodologia", "1 = amostragem em múltiplos estágios",
  "tem_estratificacao_final", "metodologia", "1 = estratificação",
  "tse_tablet", "metodologia", "1 = coleta em tablet/questionário eletrônico",
  "tse_checagem_pct", "metodologia", "Percentual de questionários checados",
  "tse_metodologia_fonte", "metodologia", "registro_tse / ficha_tecnica_manual / imputada_perfil_instituto",
  # registro no TSE
  "empresa_pesquisa", "registro_tse", "Empresa registrada no TSE",
  "contratante_tse", "registro_tse", "Contratante(s) registrado(s)",
  "tipo_contratante", "registro_tse", "Mercado financeiro / mídia / próprio instituto / etc.",
  "pesquisa_autofinanciada", "registro_tse", "1 = empresa é a própria contratante",
  "valor_pesquisa", "registro_tse", "Valor declarado (R$)",
  "estatistico_resp_tse", "registro_tse", "Estatístico responsável",
  "dt_registro", "registro_tse", "Data do registro no TSE",
  # mercado de previsão
  "probabilidade_mercado", "mercado", "Prob. de vitória na véspera do campo",
  "volume_mercado", "mercado", "Volume negociado em 7 dias até a véspera (GBP)",
  "liquidez_mercado", "mercado", "Spread na véspera (menor = mais líquido); NA = livro de um lado",
  "antecipacao_mercado", "mercado", "Variação da prob. nos 3 dias antes do campo",
  "variacao_mercado", "mercado", "Variação da prob. durante o campo",
  "reacao_mercado_pos", "mercado", "Variação da prob. do fim do campo até 2 dias depois",
  "antecipacao_inclui_votacao", "mercado", "1 = janela inclui dia de votação",
  "variacao_inclui_votacao", "mercado", "1 = janela inclui dia de votação",
  "reacao_inclui_votacao", "mercado", "1 = janela inclui dia de votação",
  "prob_vitoria_pesquisa", "mercado", "2º turno: prob. de estar à frente segundo a pesquisa",
  "gap_pesquisa_mercado", "mercado", "2º turno: prob_vitoria_pesquisa - probabilidade_mercado",
  "gap_pre_1turno", "mercado", "1 = pesquisa de 2º turno feita antes do 1º turno"
)

faltando <- setdiff(dicionario_base_2018$coluna, names(base_2018))
if (length(faltando) > 0) stop("Colunas não criadas: ", paste(faltando, collapse = ", "))

base_2018 <- base_2018 %>%
  select(all_of(dicionario_base_2018$coluna)) %>%
  arrange(data_fim, turno, instituto, nome_clean)

dicionario_base_2018 <- dicionario_base_2018 %>%
  mutate(pct_na = map_dbl(coluna, ~ round(100 * mean(is.na(base_2018[[.x]])), 1)))

if (salvar_arquivos) {
  saveRDS(base_2018, paste0(prefixo_saida, ".rds"))

  # CSV para Excel em português: ";" como separador, "," decimal e
  # UTF-8 com BOM (acentos corretos no Excel)
  salvar_csv_excel <- function(df, arquivo) {
    tmp <- tempfile(fileext = ".csv")
    write.table(df, tmp, sep = ";", dec = ",", row.names = FALSE,
                na = "", qmethod = "double", fileEncoding = "UTF-8")
    conteudo <- readBin(tmp, "raw", file.info(tmp)$size)
    writeBin(c(as.raw(c(0xEF, 0xBB, 0xBF)), conteudo), arquivo)
    unlink(tmp)
  }
  salvar_csv_excel(base_2018, paste0(prefixo_saida, ".csv"))
  salvar_csv_excel(dicionario_base_2018, paste0(prefixo_saida, "_dicionario.csv"))

  if (requireNamespace("writexl", quietly = TRUE)) {
    writexl::write_xlsx(list(base = base_2018, dicionario = dicionario_base_2018),
                        paste0(prefixo_saida, ".xlsx"))
  } else {
    message("Pacote writexl não instalado: .xlsx não gerado.")
  }
}

# ---- Conferências ---------------------------------------------

cat("\nBase final:", nrow(base_2018), "linhas x", ncol(base_2018), "colunas\n")
count(base_2018, turno)
auditoria_tse %>% count(status_tse)
base_2018 %>% distinct(id_pesquisa, .keep_all = TRUE) %>% count(fonte_modelo_coleta, modelo_coleta_final)
dicionario_base_2018 %>% filter(pct_na > 0) %>% arrange(desc(pct_na)) %>% print(n = Inf)

# ============================================================
# FIM
# ============================================================
