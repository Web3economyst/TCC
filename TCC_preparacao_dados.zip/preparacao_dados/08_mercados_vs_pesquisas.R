# ============================================================
# 08 - MERCADOS DE PREVISÃO x AGREGADOR DE PESQUISAS
#      Eleições 2018 / 2022 / 2026 - disputa do 2º turno (A x B)
# ============================================================
#
# Pergunta: os mercados reagiram a informações que as pesquisas não
# capturaram?
#
# O que este arquivo faz, em 6 passos:
#   1. Carrega as pesquisas de cada ano com a preparação do 04 do
#      professor (sem alterar nada nas bases).
#   2. Escolhe o h do 2º turno com as funções do próprio 04
#      (validação temporal, peso igual por dia, tolerância de 0,5%).
#   3. Constrói, para cada dia, a probabilidade de A vencer segundo as
#      pesquisas: margem do local linear + erro da validação -> pnorm
#      (mesma ideia da seção 18 do 04).
#   4. Lê a probabilidade de vitória dos mercados (Betfair 2018 e 2022,
#      Polymarket 2026) e normaliza entre os dois finalistas.
#   5. Compara as duas séries: distância, volatilidade, acerto do
#      vencedor, Brier, correlação defasada e precedência temporal.
#   6. Estudo de evento: como o mercado se moveu antes, logo depois e
#      alguns dias depois de cada pesquisa, conforme a "surpresa" da
#      pesquisa em relação ao agregador.
#
# Coloque na mesma pasta do 04 e das bases 01, 02 e 03.
# Saídas: pasta "saida_mercados" (CSVs e PNGs).
# ============================================================

library(tidyverse)

# ------------------------------------------------------------
# 0. CONFIGURAÇÃO
# ------------------------------------------------------------

ANOS <- c(2018, 2022, 2026)
PASTA_SAIDA <- "saida_mercados"
dir.create(PASTA_SAIDA, showWarnings = FALSE)

# Arquivos diários de mercado (saídas dos scripts de extração).
# Colunas usadas: data_brt, nome_clean, prob_norm.
ARQUIVO_MERCADO <- c(
  `2018` = file.path("pasta_dados", "betfair_2018_diario.csv"),
  `2022` = file.path("pasta_dados", "betfair_2022_diario.csv"),
  `2026` = file.path("pasta_dados", "mercado_2026_diario.csv")
)

# Quem venceu o 2º turno: 1 = candidato A (Haddad/Lula), 0 = candidato B
A_VENCEU <- c(`2018` = 0, `2022` = 1, `2026` = 1)

# TRUE: escolhe o h com a validação do 04 (alguns minutos por ano).
# FALSE: usa os valores abaixo (preencha 2026 com o que o 04 imprimir).
RECALCULAR_H <- TRUE
H_FIXO <- c(`2018` = 14, `2022` = 90, `2026` = 65)

# ------------------------------------------------------------
# 1. CARREGAR PESQUISAS E FUNÇÕES DO 04
# ------------------------------------------------------------
# Executa o 04 até a linha anterior ao CV dele ("CV auxiliar da margem
# total"). Assim ficam disponíveis base_2T_wide, serie_2T,
# regressao_local_linear(), avaliar_bandwidths_por_dia(),
# selecionar_bandwidth_tolerancia() e bandwidths, sem rodar o CV inteiro.

carregar_ano <- function(ano) {
  ANO_ANALISE <<- ano
  linhas <- readLines("04_estimador_linear_2018_2022_2026_geral.R", encoding = "UTF-8")
  fim <- grep("CV auxiliar da margem total", linhas, fixed = TRUE, useBytes = TRUE)[1] - 1
  linhas[grepl("^ANO_ANALISE <-", linhas)] <- ""   # vale o ano do loop
  eval(parse(text = linhas[1:fim], encoding = "UTF-8"), envir = globalenv())

  list(
    ano = ano, cfg = cfg,
    pesquisas = base_2T_wide,      # pesquisas individuais do 2º turno
    serie = serie_2T,              # médias diárias (usadas pelo 04 na curva)
    inicio_teste = inicio_teste_2T
  )
}

# ------------------------------------------------------------
# 2. h DO 2º TURNO (regra do professor)
# ------------------------------------------------------------

# Regra de seleção do 04 (seção 8.4), copiada sem alteração: o 04 a
# define depois do trecho que executamos acima.
selecionar_bandwidth_tolerancia <- function(cv, tolerancia = 0.005) {
  cv_valid <- cv %>% filter(is.finite(RMSE)) %>% arrange(bandwidth)
  if (nrow(cv_valid) == 0) stop("Não há resultados válidos de validação.")
  rmse_min <- min(cv_valid$RMSE)
  cv_valid %>%
    filter(RMSE <= rmse_min * (1 + tolerancia)) %>%
    slice_min(bandwidth, n = 1, with_ties = FALSE)   # menor h dentro da tolerância
}

escolher_h <- function(d) {
  cv <- avaliar_bandwidths_por_dia(
    dados = d$pesquisas, y = margem_validos, bandwidths = bandwidths,
    inicio_teste = d$inicio_teste
  )
  sel <- selecionar_bandwidth_tolerancia(cv, tolerancia = 0.005)
  list(h = sel$bandwidth, rmse = sel$RMSE)
}

# Erro de validação para um h já conhecido (usado quando RECALCULAR_H = FALSE)
rmse_para_h <- function(d, h) {
  avaliar_bandwidths_por_dia(
    dados = d$pesquisas, y = margem_validos, bandwidths = h,
    inicio_teste = d$inicio_teste
  )$RMSE
}

# ------------------------------------------------------------
# 3. PROBABILIDADE DAS PESQUISAS, DIA A DIA
# ------------------------------------------------------------
# Em cada dia d, usa só as pesquisas com fim de campo até d e estima a
# margem na data da pesquisa mais recente (como o x_atual do 04).
# Probabilidade de A vencer = P(margem > 0), com desvio
# sqrt(se^2 + RMSE^2), como na seção 18 do 04. Aqui o RMSE é o da
# margem de votos válidos, na mesma unidade da curva.

prob_pesquisas_diaria <- function(serie, dias, h, rmse) {
  map_dfr(dias, function(d0) {
    passado <- serie %>% filter(data_referencia <= d0)
    if (nrow(passado) < 4) return(NULL)
    x0 <- max(passado$x)
    est <- regressao_local_linear(passado$x, passado$margem_validos, x0, h)
    if (!is.finite(est$fit)) return(NULL)
    dp <- sqrt(est$se^2 + rmse^2)
    tibble(data = d0, margem_pesq = est$fit,
           p_pesq = pnorm(0, mean = est$fit, sd = dp, lower.tail = FALSE))
  })
}

# ------------------------------------------------------------
# 4. PROBABILIDADE DOS MERCADOS
# ------------------------------------------------------------
# q = pA / (pA + pB): probabilidade de A vencer, normalizada entre os
# dois finalistas (retira o peso dos demais candidatos).

ler_mercado <- function(ano, a, b) {
  read_csv(ARQUIVO_MERCADO[[as.character(ano)]], show_col_types = FALSE) %>%
    mutate(data = as.Date(data_brt)) %>%
    filter(nome_clean %in% c(a, b)) %>%
    select(data, nome_clean, prob_norm) %>%
    pivot_wider(names_from = nome_clean, values_from = prob_norm, values_fn = last) %>%
    transmute(data, q_merc = .data[[a]] / (.data[[a]] + .data[[b]])) %>%
    filter(is.finite(q_merc))
}

# ------------------------------------------------------------
# 5. PAINEL DIÁRIO DE CADA ANO
# ------------------------------------------------------------

paineis <- list(); hs <- list(); pesquisas_ano <- list()

for (ano in ANOS) {
  message("=== ", ano, " ===")
  d <- carregar_ano(ano)
  a <- d$cfg$cand_a; b <- d$cfg$cand_b
  e1 <- d$cfg$data_1T; e2 <- d$cfg$data_2T

  if (RECALCULAR_H) {
    sel <- escolher_h(d)
  } else {
    h <- H_FIXO[[as.character(ano)]]
    sel <- list(h = h, rmse = rmse_para_h(d, h))
  }
  hs[[as.character(ano)]] <- tibble(ano = ano, h = sel$h, rmse_pp = 100 * sel$rmse)
  message("h = ", sel$h, " | RMSE = ", round(100 * sel$rmse, 2), " p.p.")

  merc <- ler_mercado(ano, a, b) %>% filter(data < e2)   # até a véspera do 2º turno
  pesq <- prob_pesquisas_diaria(d$serie, merc$data, sel$h, sel$rmse)

  paineis[[as.character(ano)]] <- merc %>%
    inner_join(pesq, by = "data") %>%
    arrange(data) %>%
    mutate(
      ano = !!ano, a_venceu = !!A_VENCEU[[as.character(ano)]],
      periodo = if_else(data < e1, "antes do 1º turno", "entre turnos"),
      distancia = q_merc - p_pesq,            # > 0: mercado mais favorável a A
      dq = q_merc - lag(q_merc),               # variação diária do mercado
      dp = p_pesq - lag(p_pesq)                # variação diária das pesquisas
    )

  pesquisas_ano[[as.character(ano)]] <- d$pesquisas %>%
    transmute(ano = !!ano, instituto, data_inicio = as.Date(data_inicio),
              data_fim = as.Date(data_fim), margem = margem_validos)
}

painel <- bind_rows(paineis)
write_csv(painel, file.path(PASTA_SAIDA, "painel_diario.csv"))
write_csv(bind_rows(hs), file.path(PASTA_SAIDA, "h_escolhido.csv"))

# ------------------------------------------------------------
# 6. RESUMO POR ANO E PERÍODO
# ------------------------------------------------------------
# Brier = média de (probabilidade - resultado)^2: 0 é perfeito, 0,25 é
# o de quem diz sempre 50%. Compara cada dia com o resultado final, por
# isso dias muito distantes da eleição pesam igual aos da véspera.

resumir <- function(df) {
  summarise(df,
    dias = n(),
    q_media = mean(q_merc), p_media = mean(p_pesq),
    distancia_media = mean(distancia),
    distancia_abs_media = mean(abs(distancia)),
    cor_niveis = cor(q_merc, p_pesq),
    cor_variacoes = cor(dq, dp, use = "complete.obs"),
    vol_merc_pp = 100 * sd(dq, na.rm = TRUE),     # volatilidade diária
    vol_pesq_pp = 100 * sd(dp, na.rm = TRUE),
    acerto_merc = mean((q_merc > 0.5) == (first(a_venceu) == 1)),
    acerto_pesq = mean((p_pesq > 0.5) == (first(a_venceu) == 1)),
    brier_merc = mean((q_merc - first(a_venceu))^2),
    brier_pesq = mean((p_pesq - first(a_venceu))^2),
    .groups = "drop"
  )
}

resumo <- bind_rows(
  painel %>% group_by(ano, periodo) %>% resumir(),
  painel %>% group_by(ano) %>% resumir() %>% mutate(periodo = "ciclo inteiro")
) %>% arrange(ano, periodo)
print(resumo, width = Inf)
write_csv(resumo, file.path(PASTA_SAIDA, "resumo_periodos.csv"))

# Véspera de cada turno: o que cada fonte dizia no último dia
vesperas <- painel %>%
  group_by(ano) %>%
  mutate(e1 = max(data[periodo == "antes do 1º turno"])) %>%
  filter(data == e1 | data == max(data)) %>%
  ungroup() %>%
  mutate(momento = if_else(data == e1, "véspera do 1º turno", "véspera do 2º turno")) %>%
  select(ano, momento, data, q_merc, p_pesq, margem_pesq, a_venceu)
print(vesperas)
write_csv(vesperas, file.path(PASTA_SAIDA, "vesperas.csv"))

# ------------------------------------------------------------
# 7. QUEM SE MOVE PRIMEIRO? (correlação defasada e precedência)
# ------------------------------------------------------------
# Correlação entre a variação do mercado no dia t e a das pesquisas no
# dia t + k. Pico em k > 0: o mercado se move antes das pesquisas.
# Pico em k < 0: o mercado vai atrás das pesquisas.
#
# ATENÇÃO: a série das pesquisas é uma curva suavizada que só muda
# quando sai pesquisa nova; os testes abaixo são exploratórios.

defasagens <- -7:7
ccf_tab <- painel %>%
  filter(is.finite(dq), is.finite(dp)) %>%
  group_by(ano) %>%
  group_modify(~ {
    cc <- ccf(.x$dq, .x$dp, lag.max = max(defasagens), plot = FALSE)
    # ccf(x, y)[k] = cor(x[t + k], y[t]); trocamos o sinal para ler
    # "mercado em t, pesquisas em t + k"
    tibble(k = -as.numeric(cc$lag), correlacao = as.numeric(cc$acf))
  }) %>%
  ungroup() %>%
  arrange(ano, k)
write_csv(ccf_tab, file.path(PASTA_SAIDA, "correlacao_defasada.csv"))

# Precedência de Granger com L defasagens (MQO, teste F):
#   "mercado -> pesquisas": defasagens do mercado ajudam a prever as pesquisas?
#   "pesquisas -> mercado": defasagens das pesquisas ajudam a prever o mercado?
L <- 3
granger <- function(y, x, L) {
  df <- tibble(y = y, x = x)
  for (l in 1:L) { df[[paste0("y", l)]] <- lag(y, l); df[[paste0("x", l)]] <- lag(x, l) }
  df <- na.omit(df)
  restrito <- lm(reformulate(paste0("y", 1:L), "y"), data = df)
  completo <- lm(reformulate(c(paste0("y", 1:L), paste0("x", 1:L)), "y"), data = df)
  av <- anova(restrito, completo)
  tibble(F = av$F[2], p_valor = av$`Pr(>F)`[2], n = nrow(df))
}

precedencia <- painel %>%
  filter(is.finite(dq), is.finite(dp)) %>%
  group_by(ano) %>%
  group_modify(~ bind_rows(
    granger(.x$dp, .x$dq, L) %>% mutate(direcao = "mercado -> pesquisas"),
    granger(.x$dq, .x$dp, L) %>% mutate(direcao = "pesquisas -> mercado")
  )) %>%
  ungroup()
print(precedencia)
write_csv(precedencia, file.path(PASTA_SAIDA, "precedencia_granger.csv"))

# ------------------------------------------------------------
# 8. ESTUDO DE EVENTO: O MERCADO DIANTE DE CADA PESQUISA
# ------------------------------------------------------------
# Surpresa da pesquisa = margem da pesquisa - margem que o agregador
# estimava com as pesquisas anteriores a ela (em p.p.).
# Variações do mercado (em pontos de probabilidade) em três janelas:
#   antecipação: de 4 dias a 1 dia antes do início do campo
#   reação:      do fim do campo até 2 dias depois
#   reversão:    de 2 até 7 dias depois do fim do campo
# Regressão de cada variação na surpresa:
#   beta > 0 na reação     -> o mercado segue as pesquisas;
#   beta > 0 na antecipação -> o mercado já se movia antes da pesquisa;
#   beta < 0 na reversão   -> parte da reação é desfeita depois.
# Janelas que atravessam o dia do 1º turno são excluídas.

q_em <- function(merc, dias) merc$q_merc[match(dias, merc$data)]

eventos <- map_dfr(ANOS, function(ano) {
  p <- painel %>% filter(ano == !!ano)
  pesq <- pesquisas_ano[[as.character(ano)]] %>% filter(data_fim >= min(p$data), data_fim <= max(p$data) - 7)
  e1 <- max(p$data[p$periodo == "antes do 1º turno"]) + 1
  pesq %>%
    mutate(
      # margem do agregador no dia anterior ao fim do campo
      margem_antes = p$margem_pesq[match(data_fim - 1, p$data)],
      surpresa_pp = 100 * (margem - margem_antes),
      antecipacao = 100 * (q_em(p, data_inicio - 1) - q_em(p, data_inicio - 4)),
      reacao      = 100 * (q_em(p, data_fim + 2)    - q_em(p, data_fim)),
      reversao    = 100 * (q_em(p, data_fim + 7)    - q_em(p, data_fim + 2)),
      cruza_1T = (data_inicio - 4 < e1) & (data_fim + 7 >= e1)
    ) %>%
    filter(!cruza_1T, is.finite(surpresa_pp))
})
write_csv(eventos, file.path(PASTA_SAIDA, "eventos_pesquisas.csv"))

evento_reg <- eventos %>%
  pivot_longer(c(antecipacao, reacao, reversao), names_to = "janela", values_to = "variacao_pp") %>%
  filter(is.finite(variacao_pp)) %>%
  group_by(ano, janela) %>%
  group_modify(~ {
    m <- summary(lm(variacao_pp ~ surpresa_pp, data = .x))$coefficients
    tibble(beta = m["surpresa_pp", 1], ep = m["surpresa_pp", 2],
           p_valor = m["surpresa_pp", 4], n = nrow(.x))
  }) %>%
  ungroup() %>%
  mutate(janela = factor(janela, c("antecipacao", "reacao", "reversao"))) %>%
  arrange(ano, janela)
print(evento_reg)
write_csv(evento_reg, file.path(PASTA_SAIDA, "eventos_regressao.csv"))

# ------------------------------------------------------------
# 9. GRÁFICOS
# ------------------------------------------------------------

nomes_a <- c(`2018` = "Haddad", `2022` = "Lula", `2026` = "Lula")
painel_graf <- painel %>% mutate(painel = paste0(ano, " - probabilidade de ", nomes_a[as.character(ano)], " vencer"))
inicio_2T <- painel_graf %>% group_by(painel) %>%
  summarise(e1 = min(data[periodo == "entre turnos"]), .groups = "drop")

g_prob <- painel_graf %>%
  select(painel, data, Mercado = q_merc, Pesquisas = p_pesq) %>%
  pivot_longer(c(Mercado, Pesquisas), names_to = "fonte", values_to = "prob") %>%
  ggplot(aes(data, 100 * prob, colour = fonte)) +
  geom_hline(yintercept = 50, linetype = "dashed") +
  geom_vline(data = inicio_2T, aes(xintercept = e1), linetype = "dotted") +
  geom_line(linewidth = 0.8) +
  facet_wrap(~ painel, ncol = 1, scales = "free_x") +
  labs(title = "Mercado de previsão x agregador de pesquisas",
       subtitle = "Pontilhado: dia seguinte ao 1º turno",
       x = NULL, y = "Probabilidade (%)", colour = NULL) +
  theme_minimal(base_size = 11) + theme(legend.position = "bottom")
ggsave(file.path(PASTA_SAIDA, "probabilidades.png"), g_prob, width = 9, height = 10, dpi = 150)

g_dist <- ggplot(painel_graf, aes(data, 100 * distancia)) +
  geom_hline(yintercept = 0) +
  geom_vline(data = inicio_2T, aes(xintercept = e1), linetype = "dotted") +
  geom_line(linewidth = 0.7) +
  facet_wrap(~ painel, ncol = 1, scales = "free_x") +
  labs(title = "Distância entre mercado e pesquisas",
       subtitle = "Acima de zero: mercado mais favorável ao candidato A que as pesquisas",
       x = NULL, y = "Mercado - pesquisas (p.p. de probabilidade)") +
  theme_minimal(base_size = 11)
ggsave(file.path(PASTA_SAIDA, "distancia.png"), g_dist, width = 9, height = 10, dpi = 150)

cat("\nArquivos salvos em", normalizePath(PASTA_SAIDA), "\n")
