# ============================================================
# BETFAIR 2022 - EXTRAÇÃO DO MERCADO "PRESIDENT AFTER 2022 ELECTION"
# ============================================================
#
# Mesmo código de betfair_2018_extracao.R. Só mudam: o arquivo de
# entrada, o mapa de candidatos, as datas dos turnos e os nomes das
# saídas (marcados com  # 2022). Também salva uma planilha Excel.
#
# Arquivo de entrada: dado histórico da Betfair Exchange (nível PRO),
# em formato de stream (um JSON por linha, mensagens "mcm").
#   - mercado: 1.180434883 - "President after 2022 Election"
#     (evento "Brazil - General Election 2022")
#   - período: 11/03/2021 a 31/10/2022 (liquidação: Lula vencedor)
#   - o que o mercado precifica: probabilidade de o candidato VENCER a
#     eleição (1º e 2º turnos), e não o percentual de votos.
#   - o arquivo 1.198355665 ("Finish in the Final 2") é outro mercado
#     (quem vai ao 2º turno) e não é usado aqui.
#
# Como o arquivo é organizado (e como é tratado aqui):
#   - marketDefinition: estado do mercado (OPEN / SUSPENDED / CLOSED,
#     in-play) e lista de candidatos (runners). Novos candidatos entram
#     ao longo do tempo (ex.: Tebet, Soraya e demais candidatos registrados).
#   - img = true: imagem completa do mercado -> o livro de ofertas é
#     zerado e reconstruído a partir da mensagem.
#   - img = false: deltas. Em cada runner:
#       atb = ofertas disponíveis para apostar a favor (back) [preço, valor]
#       atl = ofertas disponíveis para apostar contra (lay) [preço, valor]
#             valor 0 = nível removido
#       trd = volume negociado ACUMULADO em cada preço [preço, volume]
#       ltp = último preço negociado
#   - O campo "tv" do runner nas mensagens delta NÃO é o total acumulado
#     do runner (é o volume dos preços presentes na mensagem). Por isso o
#     volume acumulado é recalculado como a soma da escada "trd".
#   - Atualizações feitas com o mercado SUSPENDED ou CLOSED são
#     descartadas (incluem o reset de liquidação de 28/10, 22:57 UTC).
#
# Horário: pt vem em milissegundos UTC; os dias são definidos no horário
# de Brasília (America/Sao_Paulo). Desde 2019 não há horário de verão,
# então todo o período de 2022 está em UTC-3.
#
# Mercado "in-play": a Betfair deixou o mercado aberto durante a
# apuração (02/10 a 04/10 e 30/10 a 31/10). Esses preços entram, como
# em 2018, e ficam marcados em `in_play` na tabela de eventos.
#
# Saídas:
#   betfair_runners         - um registro por candidato
#   betfair_status_mercado  - transições de status do mercado
#   betfair_eventos         - uma linha por atualização de candidato
#   betfair_diario          - painel candidato x dia (horário de Brasília)
#   betfair_mercado_diario  - indicadores do mercado como um todo, por dia
#   betfair_2022.xlsx       - planilha com as quatro tabelas acima      # 2022
#
# Preços são odds decimais. Probabilidade implícita = 1 / preço.
# Volumes em libras (GBP), como fornecidos pela Betfair.
# ============================================================

library(tidyverse)
library(lubridate)
library(jsonlite)
library(writexl) 

# pasta com pesquisa_eleitoral_2026_BRASIL.csv (e o arquivo de mercado, se houver)
pasta_dados <- file.path(getwd(), "pasta_dados")
pasta_saida <- pasta_dados

arquivo_betfair <- file.path("pasta_dados/1.180434883")
                                       # 2022
fuso_br <- "America/Sao_Paulo"
salvar_arquivos <- TRUE

# pasta onde os arquivos de saída são salvos: a mesma do arquivo da
# Betfair (é de lá que o tribble_2022_corrigido_v3.R lê o
# betfair_2022_diario.csv). Sem isso, o R salvaria na pasta de trabalho
# (getwd()), que costuma ser "Documentos".
pasta_saida <- dirname(arquivo_betfair)

# ============================================================
# 1. MAPEAMENTO DOS CANDIDATOS PARA O PADRÃO DA BASE DE PESQUISAS
# ============================================================
# nome_clean segue a base de pesquisas 2022 (base_2022_v7).          # 2022
# Candidatos que não estão na base de pesquisas ficam com nome próprio.
# O casamento é feito pelo id do candidato na Betfair (runner_id), e não
# pelo nome, para não depender de acentos (Lula, Péricles, Vera Lúcia...).

mapa_candidatos <- tribble(
  ~runner_id, ~nome_clean,        # nome na Betfair
  38782747L,  "lula",             # Luiz Inácio Lula da Silva
  18522097L,  "bolsonaro",        # Jair Bolsonaro
  18522099L,  "ciro",             # Ciro Gomes
  47939993L,  "tebet",            # Simone Tebet
  47939994L,  "soraya",           # Soraya Thronicke
  47939987L,  "felipe_davila",    # Luiz Felipe d'Avila
  47939988L,  "eymael",           # José Maria Eymael
  47939991L,  "pericles",         # Leonardo Péricles
  47940008L,  "sofia_manzano",    # Sofia Manzano
  47939992L,  "vera_lucia",       # Vera Lúcia Salgado
  47939989L,  "jefferson",        # Roberto Jefferson (substituído por Kelmon)
  47939990L,  "marcal",           # Pablo Marçal
  20578421L,  "haddad",           # Fernando Haddad
  38782766L,  "dino",             # Flávio Dino
  20296970L,  "boulos",           # Guilherme Boulos
  38782775L,  "doria",            # João Doria
  38782779L,  "amoedo",           # João Amoêdo
  8881034L,   "marina",           # Marina Silva
  38782782L,  "moro",             # Sergio Moro
  38782783L,  "huck",             # Luciano Huck
  41320624L,  "leite"             # Eduardo Leite
)

# ============================================================
# 2. LEITURA E RECONSTRUÇÃO DO LIVRO DE OFERTAS
# ============================================================

linhas <- read_lines(arquivo_betfair)

# --- funções auxiliares do livro de ofertas ------------------

# aplica deltas [preço, valor] a uma escada (vetor nomeado por preço)
aplicar_deltas <- function(escada, deltas) {
  for (d in deltas) {
    chave <- as.character(d[[1]])
    valor <- d[[2]]
    if (valor == 0) {
      escada <- escada[names(escada) != chave]
    } else {
      escada[chave] <- valor
    }
  }
  escada
}

# janelas móveis simples (sem dependência de pacotes extras)
slider_sd <- function(x, k) {
  map_dbl(seq_along(x), function(j) {
    if (j < k) return(NA_real_)
    janela <- x[(j - k + 1):j]
    if (sum(!is.na(janela)) < 2) NA_real_ else sd(janela, na.rm = TRUE)
  })
}

slider_soma <- function(x, k) {
  map_dbl(seq_along(x), function(j) if (j < k) NA_real_ else sum(x[(j - k + 1):j], na.rm = TRUE))
}

novo_runner <- function() {
  list(atb = numeric(0), atl = numeric(0), trd = numeric(0), ltp = NA_real_)
}

# melhores preços e profundidade (soma dos k melhores níveis)
resumo_lado <- function(escada, lado, k = 3) {
  if (length(escada) == 0) {
    return(c(preco = NA_real_, valor = NA_real_, prof_k = NA_real_, total = NA_real_))
  }
  precos <- as.numeric(names(escada))
  ordem <- if (lado == "back") order(precos, decreasing = TRUE) else order(precos)
  c(
    preco = precos[ordem[1]],
    valor = unname(escada[ordem[1]]),
    prof_k = sum(escada[ordem[seq_len(min(k, length(ordem)))]]),
    total = sum(escada)
  )
}

# --- estruturas de saída ------------------------------------

n_cap <- 250000L
ev <- list(
  pt = numeric(n_cap), runner_id = integer(n_cap), img = logical(n_cap),
  status = character(n_cap), in_play = logical(n_cap),
  ltp = numeric(n_cap),
  back = numeric(n_cap), back_valor = numeric(n_cap), back_prof3 = numeric(n_cap), back_total = numeric(n_cap),
  lay = numeric(n_cap), lay_valor = numeric(n_cap), lay_prof3 = numeric(n_cap), lay_total = numeric(n_cap),
  volume_acum = numeric(n_cap), volume_incr = numeric(n_cap), preco_x_volume_incr = numeric(n_cap),
  mercado_volume_acum = numeric(n_cap)
)

md_linhas <- list()
livro <- list()
status_atual <- NA_character_
in_play_atual <- NA
mercado_tv <- NA_real_
i <- 0L

for (linha in linhas) {
  msg <- parse_json(linha)
  pt <- msg$pt
  
  for (mc in msg$mc) {
    
    # ---- definição do mercado ----
    if (!is.null(mc$marketDefinition)) {
      md <- mc$marketDefinition
      status_atual <- md$status
      in_play_atual <- md$inPlay
      md_linhas[[length(md_linhas) + 1]] <- tibble(
        pt = pt,
        status = md$status,
        in_play = md$inPlay,
        n_runners_ativos = md$numberOfActiveRunners,
        runner_id = map_int(md$runners, ~ as.integer(.x$id)),
        nome_betfair = map_chr(md$runners, ~ .x$name),
        runner_status = map_chr(md$runners, ~ .x$status)
      )
    }
    
    if (!is.null(mc$tv)) mercado_tv <- mc$tv
    
    # ---- imagem completa: zera o livro ----
    eh_img <- isTRUE(mc$img)
    if (eh_img) livro <- list()
    
    # ---- atualizações por candidato ----
    for (rc in mc$rc) {
      id <- as.character(rc$id)
      r <- if (is.null(livro[[id]])) novo_runner() else livro[[id]]
      
      vol_antes <- sum(r$trd)
      pxv <- 0
      
      if (!is.null(rc$atb)) r$atb <- aplicar_deltas(r$atb, rc$atb)
      if (!is.null(rc$atl)) r$atl <- aplicar_deltas(r$atl, rc$atl)
      if (!is.null(rc$trd)) {
        if (!eh_img) {
          # volume novo em cada preço (para o preço médio ponderado)
          for (d in rc$trd) {
            chave <- as.character(d[[1]])
            antes <- if (chave %in% names(r$trd)) r$trd[[chave]] else 0
            delta <- d[[2]] - antes
            if (delta > 0) pxv <- pxv + d[[1]] * delta
          }
        }
        r$trd <- aplicar_deltas(r$trd, rc$trd)
      }
      if (!is.null(rc$ltp)) r$ltp <- rc$ltp
      
      livro[[id]] <- r
      
      # ---- registra o estado após a atualização ----
      i <- i + 1L
      if (i > n_cap) {
        n_cap <- n_cap * 2L
        ev <- map(ev, ~ { length(.x) <- n_cap; .x })
      }
      sb <- resumo_lado(r$atb, "back")
      sl <- resumo_lado(r$atl, "lay")
      vol_depois <- sum(r$trd)
      
      ev$pt[i] <- pt
      ev$runner_id[i] <- rc$id
      ev$img[i] <- eh_img
      ev$status[i] <- status_atual
      ev$in_play[i] <- in_play_atual
      ev$ltp[i] <- r$ltp
      ev$back[i] <- sb[["preco"]]; ev$back_valor[i] <- sb[["valor"]]
      ev$back_prof3[i] <- sb[["prof_k"]]; ev$back_total[i] <- sb[["total"]]
      ev$lay[i] <- sl[["preco"]]; ev$lay_valor[i] <- sl[["valor"]]
      ev$lay_prof3[i] <- sl[["prof_k"]]; ev$lay_total[i] <- sl[["total"]]
      ev$volume_acum[i] <- vol_depois
      ev$volume_incr[i] <- if (eh_img) 0 else max(vol_depois - vol_antes, 0)
      ev$preco_x_volume_incr[i] <- pxv
      ev$mercado_volume_acum[i] <- mercado_tv
    }
  }
}

ev <- map(ev, ~ .x[seq_len(i)])

# ============================================================
# 3. TABELAS DE REFERÊNCIA: CANDIDATOS E STATUS DO MERCADO
# ============================================================

md_todas <- bind_rows(md_linhas) %>%
  mutate(data_hora_utc = as_datetime(pt / 1000, tz = "UTC"))

betfair_runners <- md_todas %>%
  group_by(runner_id, nome_betfair) %>%
  summarise(
    entrada_utc = min(data_hora_utc),
    status_final = last(runner_status),
    .groups = "drop"
  ) %>%
  mutate(entrada_brt = with_tz(entrada_utc, fuso_br)) %>%
  left_join(mapa_candidatos, by = "runner_id") %>%                      # 2022
  arrange(entrada_utc, runner_id)

betfair_status_mercado <- md_todas %>%
  distinct(pt, data_hora_utc, status, in_play, n_runners_ativos) %>%
  arrange(pt) %>%
  filter(
    status != lag(status, default = "") |
      in_play != lag(in_play, default = NA) |
      n_runners_ativos != lag(n_runners_ativos, default = -1L)
  ) %>%
  mutate(data_hora_brt = with_tz(data_hora_utc, fuso_br))

# ============================================================
# 4. TABELA DE EVENTOS (UMA LINHA POR ATUALIZAÇÃO DE CANDIDATO)
# ============================================================

betfair_eventos <- as_tibble(ev) %>%
  mutate(
    data_hora_utc = as_datetime(pt / 1000, tz = "UTC"),
    data_hora_brt = with_tz(data_hora_utc, fuso_br),
    data_brt = as_date(data_hora_brt)
  ) %>%
  # descarta atualizações com o mercado suspenso ou fechado
  filter(status == "OPEN") %>%
  left_join(betfair_runners %>% select(runner_id, nome_betfair, nome_clean), by = "runner_id") %>%
  mutate(
    prob_ltp = 1 / ltp,
    # back = melhor preço para apostar a favor (maior preço em atb)
    # lay  = melhor preço para apostar contra  (menor preço em atl)
    prob_back = 1 / back,
    prob_lay = 1 / lay,
    prob_mid = (prob_back + prob_lay) / 2,
    spread_prob = prob_back - prob_lay
  ) %>%
  select(data_hora_utc, data_hora_brt, data_brt, runner_id, nome_betfair, nome_clean,
         in_play, img, ltp, back, back_valor, back_prof3, back_total,
         lay, lay_valor, lay_prof3, lay_total,
         prob_ltp, prob_back, prob_lay, prob_mid, spread_prob,
         volume_acum, volume_incr, preco_x_volume_incr, mercado_volume_acum)

# ============================================================
# 5. PAINEL DIÁRIO: CANDIDATO x DIA (HORÁRIO DE BRASÍLIA)
# ============================================================
# Estado de fechamento = última atualização do dia. Dias sem
# atualização herdam o estado anterior (o livro não mudou) e têm
# volume zero.

fechamento <- betfair_eventos %>%
  group_by(runner_id, data_brt) %>%
  summarise(
    ltp_fech = last(ltp),
    back_fech = last(back),
    lay_fech = last(lay),
    back_prof3_fech = last(back_prof3),
    lay_prof3_fech = last(lay_prof3),
    volume_acum_fech = last(volume_acum),
    volume_dia = sum(volume_incr),
    pxv_dia = sum(preco_x_volume_incr),
    n_negociacoes = sum(volume_incr > 0),
    n_atualizacoes = n(),
    .groups = "drop"
  )

data_fim_mercado <- as_date(with_tz(max(betfair_eventos$data_hora_utc), fuso_br))

grade <- betfair_runners %>%
  transmute(runner_id, inicio = as_date(entrada_brt)) %>%
  mutate(data_brt = map(inicio, ~ seq(.x, data_fim_mercado, by = "day"))) %>%
  unnest(data_brt) %>%
  select(-inicio)

cols_estado <- c("ltp_fech", "back_fech", "lay_fech", "back_prof3_fech",
                 "lay_prof3_fech", "volume_acum_fech")

betfair_diario <- grade %>%
  left_join(fechamento, by = c("runner_id", "data_brt")) %>%
  mutate(
    teve_atualizacao = !is.na(n_atualizacoes),
    # um lado do livro vazio no fechamento é informação (NA real);
    # marca com -Inf para não ser sobrescrito pelo fill
    across(all_of(cols_estado), ~ if_else(teve_atualizacao & is.na(.x), -Inf, .x))
  ) %>%
  arrange(runner_id, data_brt) %>%
  group_by(runner_id) %>%
  fill(all_of(cols_estado), .direction = "down") %>%
  mutate(across(all_of(cols_estado), ~ if_else(is.infinite(.x), NA_real_, .x))) %>%
  mutate(
    volume_dia = coalesce(volume_dia, 0),
    pxv_dia = coalesce(pxv_dia, 0),
    n_negociacoes = coalesce(n_negociacoes, 0L),
    n_atualizacoes = coalesce(n_atualizacoes, 0L),
    
    # preço médio ponderado por volume do dia (só em dias com negociação)
    vwap_dia = if_else(volume_dia > 0, pxv_dia / volume_dia, NA_real_),
    
    # probabilidades implícitas no fechamento
    prob_ltp = 1 / ltp_fech,
    prob_back = 1 / back_fech,
    prob_lay = 1 / lay_fech,
    prob_mid = (prob_back + prob_lay) / 2,
    prob_vwap = 1 / vwap_dia,
    spread_prob = prob_back - prob_lay,
    
    # probabilidade de referência.
    # A probabilidade "justa" fica entre 1/lay (limite inferior) e
    # 1/back (limite superior). Regra:
    #   - livro com os dois lados -> meio do spread;
    #   - só um lado -> o limite disponível (ex.: candidato eliminado
    #     com oferta só a 1000 -> prob <= 0,001);
    #   - livro vazio -> último preço negociado.
    # Não se usa o último preço como primeira opção porque, em
    # candidatos sem negociação recente, ele pode ser muito antigo.
    prob_ref = coalesce(prob_mid, prob_back, prob_lay, prob_ltp),
    prob_ref_fonte = case_when(
      !is.na(prob_mid) ~ "mid",
      !is.na(prob_back) ~ "limite_back",
      !is.na(prob_lay) ~ "limite_lay",
      !is.na(prob_ltp) ~ "ultimo_negocio",
      TRUE ~ NA_character_
    ),
    
    liquidez_prof3 = back_prof3_fech + lay_prof3_fech
  ) %>%
  ungroup() %>%
  # normalização entre candidatos: remove a margem (overround) do livro
  group_by(data_brt) %>%
  mutate(
    soma_prob_ref = sum(prob_ref, na.rm = TRUE),
    prob_norm = prob_ref / soma_prob_ref
  ) %>%
  ungroup() %>%
  # dinâmica no tempo
  arrange(runner_id, data_brt) %>%
  group_by(runner_id) %>%
  mutate(
    var_prob_1d = prob_norm - lag(prob_norm, 1),
    var_prob_7d = prob_norm - lag(prob_norm, 7),
    volatilidade_7d = slider_sd(var_prob_1d, 7),
    volume_7d = slider_soma(volume_dia, 7)
  ) %>%
  ungroup() %>%
  left_join(betfair_runners %>% select(runner_id, nome_betfair, nome_clean), by = "runner_id") %>%
  select(data_brt, runner_id, nome_betfair, nome_clean, teve_atualizacao,
         ltp_fech, back_fech, lay_fech, vwap_dia,
         prob_ltp, prob_back, prob_lay, prob_mid, prob_vwap, prob_ref, prob_ref_fonte, prob_norm,
         spread_prob, back_prof3_fech, lay_prof3_fech, liquidez_prof3,
         volume_dia, volume_7d, volume_acum_fech, n_negociacoes, n_atualizacoes,
         var_prob_1d, var_prob_7d, volatilidade_7d, soma_prob_ref) %>%
  arrange(data_brt, desc(prob_norm))

# ============================================================
# 6. INDICADORES DIÁRIOS DO MERCADO COMO UM TODO
# ============================================================

betfair_mercado_diario <- betfair_diario %>%
  group_by(data_brt) %>%
  summarise(
    n_candidatos_listados = n(),
    volume_mercado_dia = sum(volume_dia),
    n_negociacoes_mercado = sum(n_negociacoes),
    # soma das probabilidades implícitas antes da normalização
    # (> 1 indica margem/overround do livro)
    overround = first(soma_prob_ref),
    # concentração das probabilidades (Herfindahl): 1 = certeza
    hhi_prob = sum(prob_norm^2, na.rm = TRUE),
    # entropia: incerteza do mercado sobre o vencedor
    entropia_prob = -sum(if_else(prob_norm > 0, prob_norm * log(prob_norm), 0), na.rm = TRUE),
    favorito = nome_clean[which.max(prob_norm)],
    prob_favorito = max(prob_norm, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(data_brt) %>%
  mutate(
    volume_mercado_acum = cumsum(volume_mercado_dia),
    periodo = case_when(                                                 # 2022
      data_brt < as.Date("2022-10-02") ~ "pre_1turno",
      data_brt == as.Date("2022-10-02") ~ "dia_1turno",
      data_brt < as.Date("2022-10-30") ~ "entre_turnos",
      TRUE ~ "dia_2turno"
    )
  )

# ============================================================
# 7. SALVAR
# ============================================================

if (salvar_arquivos) {
  write_csv(betfair_runners, file.path(pasta_saida, "betfair_2022_runners.csv"))                 # 2022
  write_csv(betfair_status_mercado, file.path(pasta_saida, "betfair_2022_status_mercado.csv"))
  write_csv(betfair_diario, file.path(pasta_saida, "betfair_2022_diario.csv"))
  write_csv(betfair_mercado_diario, file.path(pasta_saida, "betfair_2022_mercado_diario.csv"))
  saveRDS(betfair_eventos, file.path(pasta_saida, "betfair_2022_eventos.rds"))
  
  # planilha: uma aba por tabela (datas e horários como texto legível)
  write_xlsx(
    list(
      diario = betfair_diario,
      mercado_diario = betfair_mercado_diario,
      candidatos = betfair_runners %>% mutate(across(where(is.POSIXct), ~ format(.x, "%Y-%m-%d %H:%M:%S"))),
      status_mercado = betfair_status_mercado %>% mutate(across(where(is.POSIXct), ~ format(.x, "%Y-%m-%d %H:%M:%S")))
    ),
    file.path(pasta_saida, "betfair_2022.xlsx")
  )
  
  message("Arquivos da Betfair salvos em: ", normalizePath(pasta_saida))
}

# ============================================================
# 8. CONFERÊNCIAS
# ============================================================

betfair_runners

betfair_status_mercado

# volume total por candidato (GBP)
betfair_diario %>%
  group_by(nome_clean) %>%
  summarise(volume_total = sum(volume_dia), .groups = "drop") %>%
  arrange(desc(volume_total))

# probabilidade normalizada em datas-chave
betfair_diario %>%
  filter(
    data_brt %in% as.Date(c("2022-01-03", "2022-05-02", "2022-08-16",   # 2022
                            "2022-10-01", "2022-10-03", "2022-10-29")),
    nome_clean %in% c("lula", "bolsonaro", "ciro", "tebet", "moro")
  ) %>%
  select(data_brt, nome_clean, prob_norm) %>%
  pivot_wider(names_from = nome_clean, values_from = prob_norm)

glimpse(betfair_diario)

# ============================================================
# FIM
# ============================================================