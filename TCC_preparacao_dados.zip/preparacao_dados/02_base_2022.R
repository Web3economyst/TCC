# ============================================================
# CÓDIGO 2022 - BASE DE PESQUISAS (V2: SAÍDA NO FORMATO DA BASE DE 2018)
# ============================================================
#
# Este código monta a base de 2022 do zero e já entrega no MESMO formato
# da base de 2018 (base_2018): mesmas 73 colunas, mesma ordem, mesmas
# regras de cálculo e mesmas abas no Excel (base e dicionario).
#
# De onde vem cada parte
#   - Pesquisas (percentuais, datas, amostra, margem, registro):
#     digitadas neste código, nas tabelas (tribble) das seções 1 e 2.
#     1º turno: uma linha por pesquisa, uma coluna por candidato, mais
#     branco/nulo e indecisos. 2º turno: uma linha por candidato,
#     Bolsonaro primeiro e Lula depois; abstencao_nao_decidiu =
#     outros_branco_nulo + indecisos_nao_sabe.
#   - Características do registro (metodologia, plano amostral, empresa,
#     valor, estatístico...): arquivo do TSE pesquisa_eleitoral_2022_BR.csv,
#     ligado pelo número de registro (seções 6 e 7).
#   - Mercado de previsão (opcional): betfair_2022_diario.csv, gerado por
#     betfair_2022_extracao.R. Se não existir, as colunas de mercado ficam NA.
#
# O que difere de 2018 (só o que os dados de 2022 exigem)
#   - Datas das eleições: 02/10/2022 e 30/10/2022; 2º turno começa em
#     03/10/2022; pre_ano_eleitoral = pesquisa anterior a 2022.
#   - Feriados nacionais de 2019 a 2022 (há pesquisas desde 2019).
#   - Modo de coleta: as mesmas regras de 2018, mais a categoria "online"
#     (questionário web, usado pela AtlasIntel).
#   - A metodologia vem só do registro do TSE. Sem registro (pesquisas até
#     2021): NA, sem imputação.
#   - outros: NA. No 1º turno de 2022 os candidatos que não concorreram
#     estão somados a branco/nulo e não podem ser separados;
#     percentual_validos usa a soma dos candidatos listados.
#   - corrigido_tse: 0 (datas e amostra não são substituídas pelo TSE).
#   - prob_vitoria_pesquisa: 2º turno Lula x Bolsonaro.
#
# Saídas (na pasta_saida, se salvar_arquivos = TRUE):
#   base_2022.rds, base_2022.csv (Excel em português),
#   base_2022_dicionario.csv e base_2022.xlsx (abas base e dicionario)
# ============================================================


library(tidyverse)
library(lubridate)

# ============================================================
# 0. PARÂMETROS
# ============================================================

# pasta com pesquisa_eleitoral_2022_BR.csv e betfair_2022_diario.csv
pasta_dados <- file.path(getwd(), "pasta_dados")
pasta_saida <- pasta_dados

arquivo_tse_2022 <- file.path(pasta_dados, "pesquisa_eleitoral_2022_BR.csv")
arquivo_betfair_diario_2022 <- file.path(pasta_dados, "betfair_2022_diario.csv")

salvar_arquivos <- TRUE
prefixo_saida <- file.path(pasta_saida, "base_2022_v7")

ano_eleicao <- 2022
data_eleicao_1t <- as.Date("2022-10-02")
data_eleicao_2t <- as.Date("2022-10-30")
inicio_campanha_2t <- as.Date("2022-10-03")


# ============================================================
# 1. PESQUISAS - 1º TURNO
# ============================================================

base_1T_raw <- tribble(
  ~instituto, ~data_inicio, ~data_fim, ~amostra, ~margem_erro,
  ~lula, ~bolsonaro, ~ciro, ~tebet, ~soraya, ~felipe_davila, ~kelmon,
  ~pericles, ~sofia_manzano, ~vera_lucia, ~eymael,
  ~outros_branco_nulo, ~indecisos_nao_sabe,
  ~registro_tse, ~amostra_tse, ~contratante, ~id_painel,
  
  "Datafolha", "2022-09-30", "2022-10-01", 12800, 2,
  48, 34, 5, 6, 1, 1, 0, 0, 0, 0, 0, 3, 2, "BR-00245/2022", 12800, "Folha de S.Paulo e Grupo Globo", "2022_10941",
  
  "Ipec", "2022-09-25", "2022-10-01", 3008, 2,
  47, 34, 5, 5, 1, 1, 0, 0, 0, 0, 0, 4, 3, "BR-00999/2022", 3008, "Rede Globo", "2022_10939",
  
  "Ipespe", "2022-09-30", "2022-09-30", 1100, 3,
  46, 33, 7, 6, 1, 0, 1, 0, 0, 0, 0, 3, 1, "BR-05007/2022", 1100, "Abrapel", "2022_10908",
  
  "MDA", "2022-09-28", "2022-09-30", 2002, 2.2,
  44.2, 36.3, 4.5, 4.3, 1.2, 0.4, 0.3, 0, 0.2, 0.1, 0, 4.2, 4.3, "BR-02944/2022", 2002, "CNT", "2022_10909",
  
  "AtlasIntel", "2022-09-28", "2022-09-30", 4500, 1,
  49.8, 40.7, 3.9, 2.6, 0.7, 0.8, 0.3, 0, 0, 0, NA, NA, NA,
  "BR-07338/2022", 4500, "CNN Brasil", NA,
  
  # ATENÇÃO:
  # AtlasIntel BR-07338/2022 publica "Branco/Nulo/Não sabem = 1%"
  # como categoria agregada. Como não foi possível decompor esse 1%
  # entre outros_branco_nulo e indecisos_nao_sabe, considerar +1 p.p.
  # no total não-válido ao calcular os percentuais de votos válidos.
  
  "Datafolha", "2022-09-27", "2022-09-29", 6800, 2,
  48, 34, 6, 5, 1, 0, 0, 0, 0, 0, 0, 3, 2, "BR-09479/2022", 6800, "Folha de S. Paulo e Grupo Globo", "2022_10835",
  
  "Parana Pesquisas", "2022-09-27", "2022-09-29", 2020, 2.2,
  43.9, 37.3, 4.9, 5.8, 0.5, 0.4, 0.1, 0, 0, 0.1, 0.1, 3.8, 3.1, "BR-07917/2022", 2020, "Parana Pesquisas", "2022_10873",
  
  # 24–29 de setembro
  "Verita", "2022-09-24", "2022-09-29", 51169, 2,
  41.6, 44.6, 4.1, 4.2, 0.9, 1.4, 0.3, 0, 0.1, 0, NA,
  0.4, 2.4,
  "BR-05980/2022", 51169, NA, NA,
  
  "Brasmarket", "2022-09-26", "2022-09-28", 1600, 2.45,
  30.9, 45.4, 6.2, 5.2, 0.8, 0.3, 0.3, 0.1, 0, 0, 0, 2.6, 8.3, "BR-08847/2022", 1600, "Brasmarket", "2022_10869",
  
  "Futura", "2022-09-26", "2022-09-28", 2000, 2.2,
  40.7, 37.8, 5.6, 7.2, 0.9, 0.4, 0.1, 0.3, 0.1, 0.3, 0, 3.4, 3.3, "BR-06743/2022", 2000, "Banco Modal", "2022_10872",
  
  "AtlasIntel", "2022-09-24", "2022-09-28", 4500, 1,
  49.3, 39.9, 3.5, 2.5, 0.8, 0.7, 0.1, 0, 0, 0.2, 0.1, 2.7, NA, "BR-01318/2022", 4500, "Arko Advice", "2022_10875",
  
  "Ideia", "2022-09-23", "2022-09-28", 1500, 3,
  47, 37, 6, 5, 0.2, 0.4, 0.1, 0.1, 0.1, 0.2, 0.1, 1, 3, "BR-09782/2022", 1500, "Exame", "2022_10810",
  
  "PoderData", "2022-09-25", "2022-09-27", 4500, 1.5,
  45, 36, 6, 4, 1, 1, 0, 0, 0, 0, 0, 4, 1, "BR-01426/2022", 4500, "PoderData", "2022_10782",
  
  "Quaest", "2022-09-24", "2022-09-27", 2000, 2,
  46, 33, 6, 5, 1, 0, 0, 0, 0, 0, 0, 4, 5, "BR-04371/2022", 2000, "Genial Investimentos", "2022_10783",
  
  "AtlasIntel", "2022-09-22", "2022-09-26", 4500, 1,
  48.3, 41, 3.5, 2.1, 1, 1.3, 0.1, 0, 0, 0.2, 0.1, 2.3, NA, "BR-02714/2022", 4500, "AtlasIntel", "2022_10751",
  
  "Parana Pesquisas", "2022-09-22", "2022-09-26", 2020, 2.2,
  42.7, 36.4, 5.6, 5, 0.8, 0.1, 0.1, 0.1, 0, 0.1, 0, 4.6, 4.6, "BR-03928/2022", 2020, "BGC Liquidez", "2022_10758",
  
  "Ipec", "2022-09-25", "2022-09-26", 3008, 2,
  48, 31, 6, 5, 1, 1, 0, 0, 0, 0, 0, 4, 4, "BR-01640/2022", 3008, "Grupo Globo", "2022_10745",
  
  "FSB", "2022-09-23", "2022-09-25", 2000, 2,
  45, 35, 7, 4, 1, 1, 0, 0, 0, 0, 0, 4, 2, "BR-08123/2022", 2000, "BTG Pactual", "2022_10718",
  
  "Verita", "2022-09-19", "2022-09-23", 11000, 2,
  42.1, 43.2, 4.7, 4, 1.1, 1, 0.1, 0.1, 0.1, 0.1, 0.3, 1.2, 2.1, "BR-06580/2022", 11000, "Verita", "2022_10719",
  
  "Datafolha", "2022-09-20", "2022-09-22", 6754, 2,
  47, 33, 7, 5, 1, 0, 0, 0, 0, 0, 0, 4, 2, "BR-04180/2022", 6754, "Folha de S. Paulo e Grupo Globo", "2022_10664",
  
  "Equilíbrio Brasil", "2022-09-20", "2022-09-22", 11500, 3,
  39, 44, 5, 4, 2, 1, NA, NA, NA, NA, NA, 1, 4, "BR-02018/2022", 11500, "Multi Mercado", "2022_10811",
  
  "Futura", "2022-09-19", "2022-09-21", 2000, 2.2,
  39.1, 39.2, 6.6, 6.1, 0.8, 0.3, 0.1, NA, 0.2, 0.4, 0.2, 3.8, 3.3, "BR-02650/2022", 2000, "Banco Modal", "2022_10696",
  
  "Ipespe", "2022-09-19", "2022-09-21", 2000, 2.2,
  46, 35, 7, 4, 1, 0, 0, NA, 0, 0, 0, 5, 2, "BR-08425/2022", 2000, "XP Investimentos", "2022_10667",
  
  "Brasmarket", "2022-09-18", "2022-09-20", 2400, 2,
  31, 44.9, 6.5, 4.5, 0.7, 0.4, 0.1, 0, 0.1, 0, 0.1, 6.2, 5.7, "BR-00580/2022", 2400, "Brasmarket", "2022_10665",
  
  "PoderData", "2022-09-18", "2022-09-20", 3500, 2,
  44, 37, 7, 4, 1, 1, 0, 0, 0, 0, 0, 3, 2, "BR-00407/2022", 3500, "PoderData", "2022_10652",
  
  "Quaest", "2022-09-17", "2022-09-20", 2000, 2,
  44, 34, 6, 5, 1, 0, 0, 0, 0, 0, 0, 5, 5, "BR-04459/2022", 2000, "Genial Investimentos", "2022_10653",
  
  "AtlasIntel", "2022-09-16", "2022-09-20", 7514, 1,
  48.4, 38.6, 6.3, 4, 0.4, 0.7, 0.1, 0.2, 0.1, 0.1, 0.2, NA, 1, "BR-01204/2022", 7500, "Arko Advice", "2022_10666",
  
  "Parana Pesquisas", "2022-09-15", "2022-09-19", 2020, 2.2,
  40.1, 36.4, 7.2, 4.6, 0.7, 0.2, 0.1, 0, 0.2, 0.2, 0, 5.6, 4.7, "BR-09417/2022", 2020, "Parana Pesquisas", "2022_10637",
  
  "FSB", "2022-09-16", "2022-09-18", 2000, 2,
  44, 35, 7, 5, 1, 0, 0, 0, 0, 0, 0, 4, 5, "BR-07560/2022", 2000, "BTG Pactual", "2022_10605",
  
  "Ipec", "2022-09-13", "2022-09-18", 3008, 2,
  47, 31, 7, 5, 1, 0, 0, 0, 0, 0, 0, 5, 4, "BR-00073/2022", 3008, "Grupo Globo", "2022_10627",
  
  "Ipespe", "2022-09-14", "2022-09-16", 1100, 3,
  45, 35, 7, 5, 1, 1, 0, 0, 0, 0, 0, 3, 2, "BR-08883/2022", 1100, "Abrapel/Ipespe", "2022_10579",
  
  "Datafolha", "2022-09-13", "2022-09-15", 5926, 2,
  45, 33, 8, 5, 2, 0, 0, 0, 0, 0, 0, 4, 2, "BR-04099/2022", 5926, "Folha de S. Paulo e Grupo Globo", "2022_10556",
  
  "Futura", "2022-09-12", "2022-09-14", 2000, 2.2,
  36.9, 41.9, 7, 6.4, 0.5, 0.4, NA, 0, 0.1, 0.2, 0, 3.3, 3.2, "BR-00745/2022", 2000, "Banco Modal", "2022_10572",
  
  "MDA", "2022-09-12", "2022-09-14", 2002, 2.2,
  43.4, 34.8, 5.6, 4.7, 0.7, 0.3, 0.1, 0, 0.1, 0.2, 0, 4.1, 6, "BR-06984/2022", 2002, "Confederação Nacional do Transporte", "2022_10565",
  
  "Brasmarket", "2022-09-10", "2022-09-14", 2400, 2,
  30.5, 43.5, 7.6, 4.6, 0.8, 0.3, 0.2, 0, 0.2, 0, 0.1, 6.8, 5.3, "BR-01527/2022", 2400, "Asserj", "2022_10573",
  
  "PoderData", "2022-09-11", "2022-09-13", 3500, 2,
  43, 37, 8, 5, 0, 1, 0, 0, 0, 0, 0, 3, 2, "BR-02955/2022", 3500, "PoderData", "2022_10533",
  
  "Quaest", "2022-09-10", "2022-09-13", 2000, 2,
  42, 34, 7, 4, 1, 1, 0, 0, 0, 0, 0, 5, 6, "BR-03420/2022", 2000, "Genial Investimentos", "2022_10530",
  
  "Parana Pesquisas", "2022-09-08", "2022-09-12", 2020, 2.2,
  39.6, 36.5, 7.4, 4.7, 0.4, 0.5, 0.1, 0.1, 0.1, 0.1, 0, 6, 4, "BR-05388/2022", 2020, "Parana Pesquisas", "2022_10521",
  
  "FSB", "2022-09-09", "2022-09-11", 2000, 2,
  41, 35, 9, 7, 1, 1, NA, NA, NA, NA, NA, 6, 1, "BR-06321/2022", 2000, "BTG Pactual", "2022_10496",
  
  "Ipec", "2022-09-09", "2022-09-11", 2512, 2,
  46, 31, 7, 4, 1, 1, 0, 0, 0, 0, 0, 6, 4, "BR-01390/2022", 2512, "Grupo Globo", "2022_10520",
  
  "Datafolha", "2022-09-08", "2022-09-09", 2676, 2,
  45, 34, 7, 5, 1, 0, 0, 0, 0, 0, 0, 4, 3, "BR-07422/2022", 2676, "Folha de S. Paulo e Grupo Globo", "2022_10499",
  
  "Ipespe", "2022-09-07", "2022-09-09", 1100, 3,
  44, 36, 8, 5, 1, 1, 0, 0, NA, 0, 0, 3, 2, "BR-07606/2022", 1100, "Abrapel/Ipespe", "2022_10500",
  
  "Futura", "2022-09-05", "2022-09-06", 2000, 2.2,
  35.7, 41.8, 7.7, 5.4, 0.7, 0.2, NA, 0.2, 0.2, 0.2, 0.1, 3.2, 4.1, "BR-02618/2022", 2000, "Banco Modal", "2022_10477",
  
  #Instituto errou o preenchimento relatório TSE
  "PoderData", "2022-09-05", "2022-09-06", 3500, 2,
  43, 37, 8, 5, 0, 0, NA, 0, 0, 0, 0, 3, 2, "BR-03760/2022", 3500, "PoderData", "2022_10448",
  
  "Parana Pesquisas", "2022-08-31", "2022-09-05", 2020, 2.2,
  40.2, 36.4, 7.3, 4.1, 0.6, 0.3, NA, 0.1, 0.1, 0.3, 0, 5.8, 4.2, "BR-09446/2022", 2020, "Parana Pesquisas", "2022_10442",
  
  "FSB", "2022-09-02", "2022-09-04", 2000, 2,
  42, 34, 8, 6, 1, 0, NA, 0, 0, 1, 0, 4, 3, "BR-01786/2022", 2000, "BTG Pactual", "2022_10431",
  
  "Quaest", "2022-09-01", "2022-09-04", 2000, 2,
  44, 34, 7, 4, 1, 1, NA, 0, 0, 0, 0, 4, 5, "BR-00807/2022", 2000, "Genial Investimentos", "2022_10449",
  
  "Ipec", "2022-08-30", "2022-09-05", 2512, 2,
  44, 31, 8, 4, 1, 1, NA, 0, 0, 0, 0, 6, 5, "BR-00922/2022", 2512, "Grupo Globo", "2022_10436",
  
  "Verita", "2022-08-27", "2022-09-02", 21019, 2,
  41.9, 43.6, 5.5, 3.6, 0.3, 0.5, NA, 0.1, 0.1, 0.2, 0.2, 1.3, 2.2, "BR-01060/2022", 21019, "Verita", "2022_10531",
  
  "Datafolha", "2022-08-30", "2022-09-01", 5734, 2,
  45, 32, 9, 5, 1, 1, NA, 0, 0, 0, 0, 4, 2, "BR-00433/2022", 5734, "Folha de S. Paulo e Grupo Globo", "2022_10428",
  
  #tem mesmo código no TSE
  "Ipespe", "2022-08-30", "2022-09-01", 1100, 3,
  44, 35, 9, 5, 1, 1, NA, 0, 0, 0, 0, 3, 2, "BR-09344/2022", 1100, "Abrapel/Ipespe", "2022_10444",
  
  "Gerp", "2022-08-29", "2022-09-01", 2095, 2.18,
  38, 39, 11, 6, 0, 1, NA, 0, 0, 0, 0, 2, 3, "BR-09102/2022", 2095, "Gerp", "2022_10443",
  
  #Instituto errou o preenchimento relatório TSE
  "PoderData", "2022-08-28", "2022-08-30", 3500, 2,
  44, 36, 8, 4, 0, 0, NA, 0, 0, 0, 1, 3, 2, "BR-06922/2022", 3500, "PoderData", "2022_10404",
  
  "Parana Pesquisas", "2022-08-26", "2022-08-30", 2020, 2.2,
  41.3, 37.1, 7.7, 2.4, 0.1, 0.2, NA, 0.1, 0.2, 0.3, 0.1, 5.9, 4, "BR-03492/2022", 2020, "Parana Pesquisas", "2022_10403",
  
  "Ipespe", "2022-08-26", "2022-08-29", 2000, 2.2,
  43, 35, 9, 5, 0, 1, NA, 0, 0, 0, NA, 4, 2, "BR-04347/2022", 2000, "XP Investimentos", "2022_10405",
  
  "Ipec", "2022-08-26", "2022-08-28", 2000, 2,
  44, 32, 7, 3, NA, 1, NA, NA, NA, NA, NA, 7, 6, "BR-01979/2022", 2000, "Grupo Globo", "2022_10385",
  
  "FSB", "2022-08-26", "2022-08-28", 2000, 2,
  43, 36, 9, 4, 0, 0, NA, 0, 0, 1, 0, 0, 7, "BR-08934/2022", 2000, "BTG Pactual", "2022_10376",
  
  "MDA", "2022-08-25", "2022-08-28", 2002, 2.2,
  42.3, 34.1, 7.3, 2.1, 0, 0.3, NA, 0.1, 0, 0.1, 0, 5, 7.8, "BR-00950/2022", 2002, "Confederação Nacional do Transporte", "2022_10389",
  
  "Quaest", "2022-08-25", "2022-08-28", 2000, 2,
  44, 32, 8, 3, 0, 0, NA, 0, 0, 1, 0, 5, 6, "BR-00585/2022", 2000, "Genial Investimentos", "2022_10402",
  
  "Futura", "2022-08-24", "2022-08-25", 2000, 2.2,
  36.9, 40.1, 10.1, 2.2, NA, 0.4, NA, 0.1, 0.1, 0.4, NA, 4.6, 4.6, "BR-07568/2022", 2000, "Banco Modal", "2022_10430",
  
  "AtlasIntel", "2022-08-20", "2022-08-24", 7475, 1,
  46.7, 38.3, 6.4, 3.6, 0.1, 0.7, NA, 0.1, 0.2, 0.4, 0.1, NA, 1.9, "BR-00848/2022", 7500, "Arko Advice", "2022_10340",
  
  "Ideia", "2022-08-19", "2022-08-24", 1500, 3,
  44, 36, 9, 4, 0.1, 1, NA, 0.2, 0.1, 1, 0.1, 2, 3, "BR-02405/2022", 1500, "Exame", "2022_10339",
  
  "Parana Pesquisas", "2022-08-19", "2022-08-23", 2020, 2.2,
  41.7, 37, 7.3, 2.7, 0.1, 0.1, NA, 0.1, 0.1, 0.2, 0.1, 6, 4.1, "BR-03138/2022", 2020, "Parana Pesquisas", "2022_10334",
  
  "Brasmarket", "2022-08-20", "2022-08-22", 2000, 2.2,
  32.9, 41, 4.3, 3.3, 0.1, 0.3, NA, 0.2, 0, 0.4, 0.2, 7.9, 9.4, "BR-07901/2022", 2000, "Asserj", "2022_10335",
  
  "Verita", "2022-08-17", "2022-08-22", 5050, 2,
  42.1, 40.1, 4.2, 2.3, 0.1, 0.6, NA, 0.2, 0.5, 0.2, 0.2, 1.4, 7.2, "BR-03033/2022", 5050, "Verita", "2022_10529",
  
  "FSB", "2022-08-19", "2022-08-21", 2000, 2,
  45, 36, 6, 3, 0, 0, NA, 0, 0, 1, 0, 6, 3, "BR-00244/2022", 2000, "BTG Pactual", "2022_10295",
  
  "Datafolha", "2022-08-16", "2022-08-18", 5744, 2,
  47, 32, 7, 2, 0, 0, NA, 0, 0, 1, 0, 6, 2, "BR-09404/2022", 5744, "Folha de S. Paulo e Grupo Globo", "2022_10271",
  
  "PoderData", "2022-08-14", "2022-08-16", 3500, 1.8,
  44, 37, 6, 4, 0, 0, NA, 0, 1, 0, 0, 4, 3, "BR-02548/2022", 3500, "PoderData", "2022_10252",
  
  "FSB", "2022-08-12", "2022-08-14", 2000, 2,
  45, 34, 8, 2, 0, 0, NA, 0, 0, 0, 0, 6, 2, "BR-00603/2022", 2000, "BTG Pactual", "2022_10215",
  
  "Quaest", "2022-08-11", "2022-08-14", 2000, 2,
  45, 33, 6, 3, 0, 0, NA, 0, 0, 0, 0, 6, 6, "BR-01167/2022", 2000, "Genial Investimentos", "2022_10249",
  
  "Ipec", "2022-08-12", "2022-08-14", 2000, 2,
  44, 32, 6, 2, 0, 0, NA, 0, 0, 1, 0, 8, 7, "BR-03980/2022", 2000, "Grupo Globo", "2022_10219",
  
  # 5–7 de agosto
  "FSB", "2022-08-05", "2022-08-07", 2000, 2,
  41, 34, 7, 3, 0,
  0, NA, 0, 0, 0, 1,
  10, 3,
  "BR-08028/2022", 2000, "BTG Pactual", NA,
  
  # ============================================================
  # PESQUISAS ANTIGAS - JULHO / AGOSTO DE 2022
  # Candidatos que não integram o conjunto final -> outros
  # Bivar, Janones, Jefferson, Santos Cruz
  # Marçal também entra em "outros", pois não existe coluna
  # própria no nosso schema.
  # ============================================================
  
  # 1–5 de agosto
  "Grupo 6Sigma", "2022-08-01", "2022-08-05", 1000, 3.1,
  28.2, 37.5, 8, 3, 0,
  0, NA, 0, 0.1, 0.2, 0.4,
  19.9, NA,
  "BR-04937/2022", NA, NA, NA,
  
  # 1–5 de agosto
  "Gerp", "2022-08-01", "2022-08-05", 2095, 2.18,
  38, 38, 10, 3, 0,
  1, NA, 0, 0, 1, 0,
  9, NA,
  "BR-09327/2022", NA, NA, NA,
  
  # 31 de julho–2 de agosto
  "PoderData", "2022-07-31", "2022-08-02", 3500, 2,
  43, 35, 7, 4, 0,
  1, NA, 0, 0, 0, 1,
  8, NA,
  "BR-08398/2022", NA, NA, NA,
  
  # 30 de julho–2 de agosto
  "Brasmarket", "2022-07-30", "2022-08-02", 2000, 2.2,
  33.1, 39.9, 6.3, 1.7, 0.3,
  0.5, NA, 0.2, 0.2, 0.7, 0,
  17.2, NA,
  "BR-05691/2022", NA, NA, NA,
  
  # 28 de julho–1 de agosto
  "Parana Pesquisas", "2022-07-28", "2022-08-01", 2020, 2.2,
  41.1, 35.6, 7.9, 1.8, 0.1,
  0.1, NA, 0.2, 0.1, 0.5, 0.1,
  12.6, NA,
  "BR-05251/2022", NA, NA, NA,
  
  # 28–31 de julho
  "Quaest", "2022-07-28", "2022-07-31", 2000, 2,
  44, 32, 5, 2, 0,
  0, NA, 0, 0, 0, 0,
  15, NA,
  "BR-02546/2022", NA, NA, NA,
  
  # 27–28 de julho
  "Datafolha", "2022-07-27", "2022-07-28", 2256, 2,
  47, 29, 8, 2, 0,
  0, NA, 0, 0, 1, 0,
  11, NA,
  "BR-01192/2022", NA, NA, NA,
  
  # 21–25 de julho
  "Futura", "2022-07-21", "2022-07-25", 2000, 2.2,
  39.6, 37.5, 7.4, 1.9, 1,
  1, NA, 1, 1, 1, 1,
  14.3, NA,
  "BR-07639/2022", NA, NA, NA,
  
  # 22–24 de julho
  "FSB", "2022-07-22", "2022-07-24", 2000, 2,
  44, 31, 9, 2, 0,
  0, NA, 0, 0, 0, 0,
  13, NA,
  "BR-05938/2022", NA, NA, NA,
  
  # 20–22 de julho
  "Ipespe", "2022-07-20", "2022-07-22", 2000, 2.2,
  44, 35, 9, 4, 0,
  0, NA, 0, 0, 1, 0,
  9, NA,
  "BR-08220/2022", NA, NA, NA,
  
  # 15–20 de julho
  "Ideia", "2022-07-15", "2022-07-20", 1500, 3,
  44, 33, 8, 4, 0.2,
  0.1, NA, 0.5, NA, 1, 0.1,
  10, NA,
  "BR-09608/2022", NA, NA, NA,
  
  # 17–19 de julho
  "PoderData", "2022-07-17", "2022-07-19", 3000, 2,
  43, 37, 6, 3, 0,
  0, NA, 0, 0, 0, 0,
  11, NA,
  "BR-07122/2022", NA, NA, NA,
  
  # 8–10 de julho
  "FSB", "2022-07-08", "2022-07-10", 2000, 2,
  41, 32, 9, 4, 0,
  0, NA, 1, 0, 1, 0,
  12, NA,
  "BR-09292/2022", NA, NA, NA,
  
  # ============================================================
  # JULHO DE 2022 — candidatos que não chegaram à eleição
  # agregados em outros_branco_nulo
  # ============================================================
  
  # 3–5 de julho
  "PoderData", "2022-07-03", "2022-07-05", 3000, 2,
  44, 36, 5, 3, 0,
  0, NA, 0, 0, 0, 0,
  8, 4,
  "BR-06550/2022", NA, NA, NA,
  
  # 30 de junho–5 de julho
  "Parana Pesquisas", "2022-06-30", "2022-07-05", 2020, 2.2,
  41.1, 35.1, 7.4, 2.2, 0.3,
  0.2, NA, 0, 0.6, 0.6, NA,
  8.7, 3.7,
  "BR-09408/2022", NA, "BGC Liquidez", NA,
  
  # 29 de junho–2 de julho
  "Quaest", "2022-06-29", "2022-07-02", 2000, 2,
  45, 31, 6, 2, 0,
  0, NA, 0, 0, 0, 0,
  9, 6,
  "BR-01763/2022", NA, "Genial Investimentos", NA,
  
  # ============================================================
  # JUNHO DE 2022
  # Candidatos que não fazem parte do nosso conjunto final
  # (Janones, Bivar, Marçal, Santos Cruz etc.) -> outros
  # ============================================================
  
  # 24–26 de junho
  "FSB", "2022-06-24", "2022-06-26", 2000, 2,
  43, 33, 8, 3, NA,
  0, NA, 0, 0, 0, 0,
  10, 1,
  "BR-05022/2022", NA, NA, NA,
  
  # 20–24 de junho
  "Futura", "2022-06-20", "2022-06-24", 2000, 2.2,
  38.9, 37.6, 7.3, 2, NA,
  0.2, NA, 0.1, NA, 0.5, 0.1,
  2.2, 11,
  "BR-09994/2022", NA, NA, NA,
  
  # 22–23 de junho
  "Datafolha", "2022-06-22", "2022-06-23", 2556, 2,
  47, 28, 8, 1, NA,
  0, NA, 0, 0, 1, 0,
  13, 1,
  "BR-09088/2022", NA, NA, NA,
  
  # 17–22 de junho
  "Ideia", "2022-06-17", "2022-06-22", 1500, 3,
  45, 36, 7, 3, NA,
  0.5, NA, 0.1, 0.1, 0.3, NA,
  8.1, 0.5,
  "BR-02845/2022", NA, NA, NA,
  
  # 19–21 de junho
  "PoderData", "2022-06-19", "2022-06-21", 3000, 2,
  44, 34, 6, 1, NA,
  0, NA, 0, 0, 0, 1,
  12, 0,
  "BR-07003/2022", NA, NA, NA,
  
  # 10–12 de junho
  "FSB", "2022-06-10", "2022-06-12", 2000, 2,
  44, 32, 9, 2, NA,
  1, NA, 0, 0, 0, 0,
  10, 0,
  "BR-03958/2022", NA, NA, NA,
  
  # ============================================================
  # JUNHO / MAIO / ABRIL DE 2022
  # Mantida a estrutura do base_1T_raw
  #
  # Candidatos que não chegaram à eleição de 2022 são agregados
  # em outros_branco_nulo quando apresentam pontuação:
  # Janones, Bivar, Marçal, Doria, Leite, Temer, Rebelo etc.
  # ============================================================
  
  # 5–7 de junho
  "PoderData", "2022-06-05", "2022-06-07", 3000, 2,
  43, 35, 6, 1, NA, 0, NA, 0, 0, 0, 1,
  3, 10,
  "BR-01975/2022", NA, NA, NA,
  
  # 2–5 de junho
  "Quaest", "2022-06-02", "2022-06-05", 2000, 2,
  46, 30, 7, 1, NA, 0, NA, 0, 0, 0, 0,
  3, 13,
  "BR-03552/2022", NA, NA, NA,
  
  # 30 de maio–3 de junho
  "Gerp", "2022-05-30", "2022-06-03", 2095, 2.18,
  39, 37, 7, 2, NA, 0, NA, 0, 0, 1, 0,
  5, 9,
  "BR-00123/2022", NA, NA, NA,
  
  # 30 de maio–1 de junho
  "Ipespe", "2022-05-30", "2022-06-01", 1000, 3.2,
  45, 34, 9, 0, NA, 0, NA, 0, 0, 1, NA,
  2, 7,
  "BR-02893/2022", NA, NA, NA,
  
  # 26–30 de maio
  "Parana Pesquisas", "2022-05-26", "2022-05-30", 2020, 2.2,
  41.4, 35.3, 7.7, 0, NA, 0.3, NA, 0, 0, 0.6, 0.1,
  3.0, 10.1,
  "BR-04618/2022", NA, NA, NA,
  
  # 27–29 de maio
  "FSB", "2022-05-27", "2022-05-29", 2000, 2,
  46, 32, 9, 0, NA, 0, NA, 0, 0, 0, 0,
  1, 8,
  "BR-03196/2022", NA, NA, NA,
  
  # 25–26 de maio
  "Datafolha", "2022-05-25", "2022-05-26", 2556, 2,
  48, 27, 7, 0, NA, 0, NA, 0, 0, 1, 0,
  3, 11,
  "BR-05166/2022", NA, NA, NA,
  
  # 23–25 de maio
  "Ipespe", "2022-05-23", "2022-05-25", 1000, 3.2,
  45, 34, 8, 3, NA, 0, NA, 0, 0, 0, 0,
  4, 5,
  "BR-07856/2022", NA, NA, NA,
  
  # 23–24 de maio
  "RealTime Big Data", "2022-05-23", "2022-05-24", 3000, 2,
  39, 31, 8, 0, NA, 0, NA, 0, 0, 0, 0,
  7, 14,
  "BR-07451/2022", NA, NA, NA,
  
  # 22–24 de maio
  "PoderData", "2022-05-22", "2022-05-24", 3000, 2,
  43, 35, 5, 0, NA, 0, NA, 0, 0, 0, 1,
  5, 9,
  "BR-05638/2022", NA, NA, NA,
  
  # 16–19 de maio
  # Segundo cenário — Doria continua pontuando e vai para "outros"
  "Futura", "2022-05-16", "2022-05-19", 2000, 2.2,
  38.4, 35.5, 7.6, 0, NA, NA, NA, NA, NA, NA, NA,
  7.5, 9.4,
  "BR-05658/2022", NA, NA, NA,
  
  # 14–19 de maio
  # Cenário 1
  # Janones, Bivar, Doria, Marçal e Rebelo -> "outros"
  # Branco/nulo = 4%; não sabe = 8%
  "Ideia", "2022-05-14", "2022-05-19", 1500, 3,
  41, 32, 9, 0, NA, 1, NA, 0.1, 1, 0.3, 0.4,
  7.4, 8,
  "BR-01734/2022", NA, NA, NA,
  
  # 16–18 de maio
  "Ipespe", "2022-05-16", "2022-05-18", 1000, 3.2,
  44, 32, 8, 0, NA, 0, NA, NA, NA, NA, 0,
  6, 10,
  "BR-08011/2022", NA, NA, NA,
  
  # 10–14 de maio
  "Ranking Brasil", "2022-05-10", "2022-05-14", 3000, 1.8,
  39, 34, 6.4, 0, NA, 0.2, NA, NA, NA, NA, NA,
  4.4, 15,
  "BR-06764/2022", NA, NA, NA,
  
  # 9–11 de maio
  "Ipespe", "2022-05-09", "2022-05-11", 1000, 3.2,
  44, 32, 8, 0, NA, 0, NA, NA, NA, 0, 0,
  5, 10,
  "BR-02603/2022", NA, NA, NA,
  
  # 8–10 de maio
  "PoderData", "2022-05-08", "2022-05-10", 3000, 2,
  42, 35, 5, 0, NA, 0, NA, 0, 0, 0, 0,
  7, 9,
  "BR-08423/2022", NA, NA, NA,
  
  # 5–8 de maio
  "Quaest", "2022-05-05", "2022-05-08", 2000, 2,
  46, 29, 7, 0, NA, 1, NA, NA, NA, NA, NA,
  6, 9,
  "BR-01603/2022", NA, NA, NA,
  
  # 4–7 de maio
  "MDA", "2022-05-04", "2022-05-07", 2002, 2.2,
  40.6, 32, 7.1, 0, NA, 0.3, NA, NA, NA, NA, NA,
  5.6, 12.1,
  "BR-05757/2022", NA, NA, NA,
  
  # 2–4 de maio
  # Janones + Doria + branco/nulo = 2 + 3 + 8 = 13
  "Ipespe", "2022-05-02", "2022-05-04", 1000, 3.2,
  44, 31, 8, 1, NA, 1, NA, NA, NA, 0, 0,
  13, 2,
  "BR-03473/2022", NA, NA, NA,
  
  # 28 de abril–3 de maio
  "Parana Pesquisas", "2022-04-28", "2022-05-03", 2020, 2.2,
  40, 35.2, 7.4, 0, NA, 0.1, NA, NA, NA, NA, NA,
  5.8, 10.7,
  "BR-09280/2022", NA, NA, NA,
  
  # 24–26 de abril
  # Janones 3 + Bivar 1 + Doria 4 + branco/nulo 4 = 12
  "PoderData", "2022-04-24", "2022-04-26", 3000, 2,
  41, 36, 6, 0, NA, 0, NA, 0, 0, 0, 0,
  12, 3,
  "BR-07167/2022", NA, NA, NA,
  
  # 20–25 de abril
  "Futura", "2022-04-20", "2022-04-25", 2000, 2.2,
  41.1, 35.3, 6.8, 0, NA, NA, NA, NA, NA, NA, NA,
  4.6, 11.3,
  "BR-08858/2022", NA, NA, NA,
  
  # 22–24 de abril
  # Cenário escolhido: maior número de candidatos que efetivamente
  # participaram da eleição de 2022.
  # Janones não concorreu -> seus 4% vão para "outros_branco_nulo".
  "FSB", "2022-04-22", "2022-04-24", 2000, 2,
  39, 31, 13, 2, NA, 1, NA,
  NA, NA, NA, NA,
  4, 10,
  "BR-04676/2022", 2000, "BTG Pactual", NA,
  
  # 18–20 de abril
  # Janones 2 + Doria 3 + branco/nulo 7 = 12
  "Ipespe", "2022-04-18", "2022-04-20", 1000, 3.2,
  45, 31, 8, 2, 2, 0, 0, NA, NA, 0, 0,
  12, 2,
  "BR-05747/2022", NA, NA, NA,
  
  # 15–20 de abril
  # Janones 1 + Bivar 0.2 + Doria 3 + Rebelo 0.1
  # + branco/nulo 1 = 5.3
  "Ideia", "2022-04-15", "2022-04-20", 1500, 3,
  42, 33, 10, 0, 1, 0.5, NA, 1, 1, 0.3, 1,
  5.3, 6,
  "BR-02495/2022", NA, NA, NA,
  
  # ============================================================
  # ABRIL DE 2022
  # Mantida a estrutura do base_1T_raw
  #
  # Regra:
  # - escolher, entre os cenários sem Moro, o cenário com maior
  #   número de candidatos que efetivamente concorreram;
  # - candidatos que aparecem no cenário mas não concorreram
  #   -> outros_branco_nulo.
  # ============================================================
  
  # 10–12 de abril
  # Cenário com mais candidatos que efetivamente concorreram:
  # Lula, Bolsonaro, Ciro, Tebet, D'Ávila, Eymael
  # Janones (3%) e Doria (3%) não concorreram -> outros.
  "PoderData", "2022-04-10", "2022-04-12", 3000, 2,
  40, 35, 5, 2, NA, 0, NA,
  0, 0, 0, 1,
  6, 11,
  "BR-00368/2022", NA, NA, NA,
  
  # 8–11 de abril
  # Pesquisa já sem Moro.
  # Janones 2% e Doria 2,6% não concorreram -> outros.
  "Sensus", "2022-04-08", "2022-04-11", 2000, 2.2,
  43.3, 28.8, 6.3, 0.8, NA, 0.1, NA,
  0.1, 0.1, 1.1, 0.1,
  4.6, 14.9,
  "BR-01631/2022", NA, NA, NA,
  
  # 2–5 de abril
  # Sem Moro.
  # Doria 3% e Janones 1% não concorreram -> outros.
  "Ipespe", "2022-04-02", "2022-04-05", 1000, 3.2,
  44, 30, 9, 2, NA, 0, NA,
  0, 0, 0, 0,
  4, 12,
  "BR-03874/2022", 1000, "XP Investimentos", NA,
  
  # 31 de março–5 de abril
  # Cenário sem Moro com maior número de candidatos que
  # efetivamente concorreram.
  # Janones 1,2% + Doria 3,1% -> outros.
  "Parana Pesquisas", "2022-03-31", "2022-04-05", 2020, 2.2,
  41.5, 35.3, 5.8, NA, NA, NA, NA,
  NA, NA, 0, NA,
  4.3, 13.1,
  "BR-08065/2022", 2020, "BGC Liquidez", NA,
  
  
  
  # 30 de março–5 de abril
  # Sem Moro.
  # Janones 2% + Doria 2% -> outros.
  "Gerp", "2022-03-30", "2022-04-05", 2095, 2.18,
  37, 36, 6, NA, NA, NA, NA,
  NA, NA, 0, NA,
  4, 10,
  "BR-02346/2022", 2095, "Gerp", NA,
  
  # 1–3 de abril
  # Cenário V: Lula, Bolsonaro, Ciro e Tebet.
  # Todos concorreram; não há candidato a agregar em outros.
  "Quaest", "2022-04-01", "2022-04-03", 2000, 2,
  46, 32, 7, 2, NA, NA, NA,
  NA, NA, NA, NA,
  0, 13,
  "BR-00372/2022", 2000, "Genial Investimentos", NA,
  
  # 21–25 de março
  # 3º cenário — preservado conforme a tabela.
  # Leite não concorreu -> 3,2% em outros_branco_nulo.
  "Futura", "2022-03-21", "2022-03-25", 2000, 2.2,
  42.4, 38.3, 7.3, NA, NA, NA, NA,
  NA, NA, NA, NA,
  3.2, 8.8,
  "BR-00758/2022", NA, NA, NA,
  
  #Adicionada na auditoria
  "Ideia", "2022-03-18", "2022-03-23", 1500, 3,
  40, 29, 9, 1, NA, 0.4, NA,
  NA, NA, NA, NA,
  17.1, 2,
  "BR-04244/2022", 1500, "Exame", NA,
  
  # ============================================================
  # FEVEREIRO / JANEIRO DE 2022
  # Mantida a ordem do base_1T_raw:
  # lula, bolsonaro, ciro, tebet, soraya, felipe_davila,
  # kelmon, pericles, sofia_manzano, vera_lucia, eymael,
  # outros_branco_nulo, indecisos_nao_sabe
  # ============================================================
  
  # 3–6 de fevereiro
  # QUARTO CENÁRIO
  # Lula 47 | Bolsonaro 26 | Ciro 9 | Alessandro Vieira 3 | Indecisos 14
  # Alessandro Vieira não concorreu -> outros
  "Quaest", "2022-02-03", "2022-02-06", 2000, 2,
  47, 26, 9, NA, NA, NA, NA,
  NA, NA, NA, NA,
  3, 14,
  "BR-08857/2022", NA, NA, NA,
  
  
  # 10–12 de janeiro
  # SEGUNDO CENÁRIO SEM MORO
  # Lula 44 | Bolsonaro 25 | Ciro 9 | Doria 3 | D'Ávila 1 |
  # Tebet 2 | Pacheco 1 | Alessandro Vieira 1 | Indecisos 16
  # Doria, Pacheco e Alessandro não concorreram -> outros = 5
  "Ipespe", "2022-01-10", "2022-01-12", 1000, 3.2,
  44, 25, 9, 2, NA, 1, NA,
  NA, NA, NA, NA,
  5, 16,
  "BR-09080/2022", NA, NA, NA,
  
  
  # 24–25 de janeiro
  # Lula 44 | Bolsonaro 26 | Ciro 9 | Doria 4 | D'Ávila 1 |
  # Tebet 1 | Pacheco 1 | Alessandro Vieira 1 | Indecisos 14
  # Doria, Pacheco e Alessandro não concorreram -> outros = 6
  "Ipespe", "2022-01-24", "2022-01-25", 1000, 3.2,
  44, 26, 9, 1, NA, 1, NA,
  NA, NA, NA, NA,
  6, 14,
  "BR-06408/2022", NA, NA, NA,
  
  # ============================================================
  # FIM DE NOVEMBRO / DEZEMBRO DE 2021 + JANEIRO DE 2022
  #
  # Ordem mantida:
  # lula, bolsonaro, ciro, tebet, soraya, felipe_davila, kelmon,
  # pericles, sofia_manzano, vera_lucia, eymael,
  # outros_branco_nulo, indecisos_nao_sabe
  # ============================================================
  
  # 27–29 de novembro de 2021
  # Atlas Político
  # Dória 5,7 -> outros
  
  "AtlasIntel", "2021-11-27", "2021-11-29", 4401, 1,
  43.8, 34.3, 8.5, NA, NA, 0.1, NA,
  NA, NA, NA, NA,
  5.7, 7.8,
  NA, NA, NA, NA,
  
  
  # 2–5 de dezembro de 2021
  # 3º cenário — sem Moro e sem Doria
  # Bolsonaro 27
  # Lula 48
  # Ciro 8
  # Pacheco 2 -> outros
  # Indecisos 15
  "Quaest", "2021-12-02", "2021-12-05", 2037, 2.2,
  48, 27, 8, NA, NA, NA, NA,
  NA, NA, NA, NA,
  2, 15,
  NA, NA, NA, NA,
  
  
  # ============================================================
  # NOVEMBRO DE 2021
  # Mantida a ordem do base_1T_raw
  # ============================================================
  
  # 16–19 de novembro
  # Parana Pesquisas — último cenário, sem Moro
  # Lula 33,7 | Bolsonaro 39,3 | Outros 17,1 | Indecisos 9,9
  "Parana Pesquisas", "2021-11-16", "2021-11-19", 2020, 2.2,
  33.7, 39.3, NA, NA, NA, NA, NA,
  NA, NA, NA, NA,
  17.1, 9.9,
  NA, NA, NA, NA,
  
  
  # 9–11 de novembro
  # Exame/Ideia — último cenário
  # Lula 40 | Bolsonaro 28 | Ciro 12 | Pacheco 2 | Indecisos 18
  # Pacheco não concorreu -> outros
  "Ideia", "2021-11-09", "2021-11-11", 1200, 3,
  40, 28, 12, NA, NA, NA, NA,
  NA, NA, NA, NA,
  2, 18,
  NA, NA, NA, NA,
  
  # 30 de setembro–3 de outubro de 2021
  # Último cenário com Alessandro Vieira (3%).
  # Vieira não concorreu -> vai para outros_branco_nulo.
  
  "Quaest", "2021-09-30", "2021-10-03", 2048, 2.2,
  46, 27, 12, NA, NA, NA, NA,
  NA, NA, NA, NA,
  2, 14,
  NA, NA, NA, NA,
  
  "Futura", "2021-09-21", "2021-09-24", 2000, 2.2,
  42.6, 32.5, 11.3, NA, NA, NA, NA,
  NA, NA, NA, NA,
  1.5, 12.1,
  NA, NA, NA, NA,
  
  # 13–15 de setembro de 2021
  # Último cenário: Lula 44%, Bolsonaro 26%, Ciro 11%,
  # Doria 6% -> outros, indecisos 12%.
  
  "Datafolha", "2021-09-13", "2021-09-15", 3667, 2,
  44, 26, 11, NA, NA, NA, NA,
  NA, NA, NA, NA,
  6, 12,
  NA, NA, NA, NA,
  
  # 30 de agosto–4 de setembro de 2021
  # Último cenário
  # Leite não concorreu -> somado aos outros.
  "AtlasIntel", "2021-08-30", "2021-09-04", 3146, 2,
  42.5, 35.3, 10.3, NA, NA, NA, NA,
  NA, NA, NA, NA,
  5.8, 6.1,
  NA, NA, NA, NA,
  
  # Genial/Quaest — 26–29 Aug 2021 — terceiro cenário
  # Doria 5% -> outros; Tebet 2%; indecisos 13%
  
  "Quaest", "2021-08-26", "2021-08-29", 2000, 2,
  46, 26, 8, 2, NA, NA, NA,
  NA, NA, NA, NA,
  5, 13,
  NA, NA, NA, NA,
  
  # Modalmais/Futura — 17–20 Ago 2021 — último cenário
  # Ramos 2,1% -> outros; indecisos 12,6%
  
  "Futura", "2021-08-17", "2021-08-20", 2000, 2.2,
  39.4, 35.8, 10.1, NA, NA, NA, NA,
  NA, NA, NA, NA,
  2.1, 12.6,
  NA, NA, NA, NA,
  
  # Genial/Quaest — 29 Jul–1 Ago 2021
  #Virado aqui o valor por inferência
  "Quaest", "2021-07-29", "2021-08-01", 1500, 3,
  46, 29, 12, NA, NA, NA, NA,
  NA, NA, NA, NA,
  NA, 13,
  NA, NA, NA, NA,
  
  # Modalmais/Futura — 23–26 Jul 2021 — último cenário
  # Doria 5,7% -> outros; indecisos 11,5%
  
  "Futura", "2021-07-23", "2021-07-26", 2006, 2.2,
  40.9, 28.7, 13.7, 2.7, NA, NA, NA,
  NA, NA, NA, NA,
  NA, 14,
  NA, NA, NA, NA,
  
  # Exame/Ideia — 5–8 Jul 2021 — último cenário
  # Mandetta 5% -> outros; indecisos 9%
  
  "Ideia", "2021-07-05", "2021-07-08", 1200, 3,
  42, 34, 10, NA, NA, NA, NA,
  NA, NA, NA, NA,
  5, 9,
  NA, NA, NA, NA,
  
  # Genial/Quaest — 1–4 Jul 2021 — último cenário
  # Jereissati 3% -> outros; indecisos 12%
  
  #invertido por inferência
  "Quaest", "2021-07-01", "2021-07-04", 1500, 3,
  45, 28, 11, NA, NA, NA, NA,
  NA, NA, NA, NA,
  3, 14,
  NA, NA, NA, NA,
  
  # Exame/Ideia — 22–24 Jun 2021 — cenário com Leite
  # Leite 6% + Outros 11% = 17% em outros_branco_nulo
  
  "Ideia", "2021-06-22", "2021-06-24", 1200, 3,
  37, 31, 16, NA, NA, NA, NA,
  NA, NA, NA, NA,
  6, 11,
  NA, NA, NA, NA,
  
  # Exame/Ideia — 19–20 Mai 2021
  
  "Ideia", "2021-05-19", "2021-05-20", 1200, 3.1,
  35, 33, 13, NA, NA, NA, NA,
  NA, NA, NA, NA,
  NA, 20,
  NA, NA, NA, NA,
  
)

# ============================================================
# 2. PESQUISAS - 2º TURNO
# ============================================================

base_2T_raw <- tribble(
  ~instituto, ~data_inicio, ~data_fim, ~amostra, ~margem_erro,
  ~nome_candidato, ~percentual, ~abstencao_nao_decidiu,
  ~registro_tse, ~amostra_tse, ~contratante, ~id_painel,
  
  # 29/10/2022 — Verita
  "Verita", "2022-10-28", "2022-10-29", 17552, 2, "Bolsonaro", 47.8, 6.3, "BR-04217/2022", 17552, "Verita", "2022_11233",
  "Verita", "2022-10-28", "2022-10-29", 17552, 2, "Lula", 45.9, 6.3, "BR-04217/2022", 17552, "Verita", "2022_11233",
  
  # 29/10/2022 — Genial/Quaest
  "Quaest", "2022-10-28", "2022-10-29", 2000, 2, "Bolsonaro", 43, 11, "BR-05765/2022", 2000, "Genial Investimentos", "2022_11207",
  "Quaest", "2022-10-28", "2022-10-29", 2000, 2, "Lula", 46, 11, "BR-05765/2022", 2000, "Genial Investimentos", "2022_11207",
  
  # 29/10/2022 — Datafolha
  "Datafolha", "2022-10-28", "2022-10-29", 8308, 2, "Bolsonaro", 45, 6, "BR-08297/2022", 8320, "Folha de S. Paulo e Grupo Globo", "2022_11209",
  "Datafolha", "2022-10-28", "2022-10-29", 8308, 2, "Lula", 49, 6, "BR-08297/2022", 8320, "Folha de S. Paulo e Grupo Globo", "2022_11209",
  
  # 29/10/2022 — Globo/Ipec
  "Ipec", "2022-10-27", "2022-10-29", 4272, 2, "Bolsonaro", 43, 7, "BR-05256/2022", 4272, "Grupo Globo", "2022_11208",
  "Ipec", "2022-10-27", "2022-10-29", 4272, 2, "Lula", 50, 7, "BR-05256/2022", 4272, "Grupo Globo", "2022_11208",
  
  # AtlasIntel — 26–29 Out 2022
  "AtlasIntel", "2022-10-26", "2022-10-29", 7500, 1.0, "Bolsonaro", 45.7, 1.9, "BR-04838/2022", NA, NA, NA,
  "AtlasIntel", "2022-10-26", "2022-10-29", 7500, 1.0, "Lula", 52.4, 1.9, "BR-04838/2022", NA, NA, NA,
  
  # IFP — 24–29 Out 2022
  "IFP", "2022-10-24", "2022-10-29", 2000, 2.5, "Bolsonaro", 45.3, 9.1, "BR-08005/2022", NA, NA, NA,
  "IFP", "2022-10-24", "2022-10-29", 2000, 2.5, "Lula", 45.6, 9.1, "BR-08005/2022", NA, NA, NA,
  
  # 28/10/2022 — CNT/MDA
  "MDA", "2022-10-26", "2022-10-28", 2002, 2.2, "Bolsonaro", 44.9, 8.2, "BR-01820/2022", 2002, "CNT", "2022_11177",
  "MDA", "2022-10-26", "2022-10-28", 2002, 2.2, "Lula", 46.9, 8.2, "BR-01820/2022", 2002, "CNT", "2022_11177",
  
  # 28/10/2022 — Parana Pesquisas
  "Parana Pesquisas", "2022-10-26", "2022-10-28", 2400, 2, "Bolsonaro", 46.3, 6.6, "BR-09573/2022", 2400, "Parana Pesquisas", "2022_11174",
  "Parana Pesquisas", "2022-10-26", "2022-10-28", 2400, 2, "Lula", 47.1, 6.6, "BR-09573/2022", 2400, "Parana Pesquisas", "2022_11174",
  
  # 27/10/2022 — Datafolha
  "Datafolha", "2022-10-25", "2022-10-27", 4580, 2, "Bolsonaro", 44, 7, "BR-04208/2022", 4592, "Folha de S. Paulo e Grupo Globo", "2022_11149",
  "Datafolha", "2022-10-25", "2022-10-27", 4580, 2, "Lula", 49, 7, "BR-04208/2022", 4592, "Folha de S. Paulo e Grupo Globo", "2022_11149",
  
  # 27/10/2022 — Verita
  "Verita", "2022-10-25", "2022-10-27", 30180, 2, "Bolsonaro", 49, 4.9, "BR-04920/2022", 30180, "Verita", "2022_11190",
  "Verita", "2022-10-25", "2022-10-27", 30180, 2, "Lula", 46.1, 4.9, "BR-04920/2022", 30180, "Verita", "2022_11190",
  
  # 27/10/2022 — Brasmarket
  "Brasmarket", "2022-10-23", "2022-10-27", 2400, 2, "Bolsonaro", 48.2, 9.1, "BR-07309/2022", 2400, "Brasmarket", "2022_11189",
  "Brasmarket", "2022-10-23", "2022-10-27", 2400, 2, "Lula", 42.7, 9.1, "BR-07309/2022", 2400, "Brasmarket", "2022_11189",
  
  # 26/10/2022 — Modalmais/Futura
  "Futura", "2022-10-24", "2022-10-26", 2000, 2.2, "Bolsonaro", 47.2, 6.1, "BR-07903/2022", 2000, "Banco Modal", "2022_11167",
  "Futura", "2022-10-24", "2022-10-26", 2000, 2.2, "Lula", 46.6, 6.1, "BR-07903/2022", 2000, "Banco Modal", "2022_11167",
  
  # 26/10/2022 — Gerp
  "Gerp", "2022-10-21", "2022-10-26", 2095, 2.18, "Bolsonaro", 47, 9, "BR-05418/2022", 2095, "Gerp", "2022_11146",
  "Gerp", "2022-10-21", "2022-10-26", 2095, 2.18, "Lula", 43, 9, "BR-05418/2022", 2095, "Gerp", "2022_11146",
  
  # 25/10/2022 — PoderData
  "PoderData", "2022-10-23", "2022-10-25", 5000, 1.5, "Bolsonaro", 44, 7, "BR-01159/2022", 5000, "PoderData", "2022_11133",
  "PoderData", "2022-10-23", "2022-10-25", 5000, 1.5, "Lula", 49, 7, "BR-01159/2022", 5000, "PoderData", "2022_11133",
  
  # 25/10/2022 — Genial/Quaest
  "Quaest", "2022-10-23", "2022-10-25", 2000, 2, "Bolsonaro", 42, 10, "BR-00470/2022", 2000, "Genial Investimentos", "2022_11134",
  "Quaest", "2022-10-23", "2022-10-25", 2000, 2, "Lula", 48, 10, "BR-00470/2022", 2000, "Genial Investimentos", "2022_11134",
  
  # 25/10/2022 — AtlasIntel
  "AtlasIntel", "2022-10-21", "2022-10-25", 7500, 1, "Bolsonaro", 46, 1.6, "BR-01560/2022", 7500, "AtlasIntel", "2022_11164",
  "AtlasIntel", "2022-10-21", "2022-10-25", 7500, 1, "Lula", 52.4, 1.6, "BR-01560/2022", 7500, "AtlasIntel", "2022_11164",
  
  # 25/10/2022 — Brasmarket
  "Brasmarket", "2022-10-21", "2022-10-25", 2400, 2, "Bolsonaro", 48, 10.5, "BR-08584/2022", 2400, "Brasmarket", "2022_11139",
  "Brasmarket", "2022-10-21", "2022-10-25", 2400, 2, "Lula", 41.5, 10.5, "BR-08584/2022", 2400, "Brasmarket", "2022_11139",
  
  # 24/10/2022 — Abrapel/Ipespe
  "Ipespe", "2022-10-22", "2022-10-24", 1100, 3, "Bolsonaro", 44, 6, "BR-08044/2022", 1100, "Abrapel/Ipespe", "2022_11127",
  "Ipespe", "2022-10-22", "2022-10-24", 1100, 3, "Lula", 50, 6, "BR-08044/2022", 1100, "Abrapel/Ipespe", "2022_11127",
  
  # 24/10/2022 — Parana Pesquisas
  "Parana Pesquisas", "2022-10-20", "2022-10-24", 2020, 2.2, "Bolsonaro", 45.9, 7.8, "BR-00525/2022", 2020, "Parana Pesquisas", "2022_11126",
  "Parana Pesquisas", "2022-10-20", "2022-10-24", 2020, 2.2, "Lula", 46.3, 7.8, "BR-00525/2022", 2020, "Parana Pesquisas", "2022_11126",
  
  # 24/10/2022 — Globo/Ipec
  "Ipec", "2022-10-22", "2022-10-24", 3008, 2, "Bolsonaro", 43, 7, "BR-06043/2022", 3008, "Grupo Globo", "2022_11124",
  "Ipec", "2022-10-22", "2022-10-24", 3008, 2, "Lula", 50, 7, "BR-06043/2022", 3008, "Grupo Globo", "2022_11124",
  
  # 23/10/2022 — Brasmarket
  "Brasmarket", "2022-10-19", "2022-10-23", 2400, 2, "Bolsonaro", 47.7, 10.6, "BR-08487/2022", 2400, "Brasmarket", "2022_11120",
  "Brasmarket", "2022-10-19", "2022-10-23", 2400, 2, "Lula", 41.8, 10.6, "BR-08487/2022", 2400, "Brasmarket", "2022_11120",
  
  # 22/10/2022 — AtlasIntel
  "AtlasIntel", "2022-10-18", "2022-10-22", 4500, 1, "Bolsonaro", 46.2, 1.8, "BR-06415/2022", 4500, "AtlasIntel", "2022_11123",
  "AtlasIntel", "2022-10-18", "2022-10-22", 4500, 1, "Lula", 52, 1.8, "BR-06415/2022", 4500, "AtlasIntel", "2022_11123",
  
  "IFP", "2022-10-17", "2022-10-21", 1500, 3, "Bolsonaro", 46.5, 9.9, "BR-01775/2022", 1500, NA, NA,
  "IFP", "2022-10-17", "2022-10-21", 1500, 3, "Lula", 43.6, 9.9, "BR-01775/2022", 1500, NA, NA,
  
  # 20/10/2022 — Verita
  "Verita", "2022-10-17", "2022-10-20", 20220, 2, "Bolsonaro", 49.4, 3.9, "BR-04043/2022", 20220, "Verita", "2022_11125",
  "Verita", "2022-10-17", "2022-10-20", 20220, 2, "Lula", 46.7, 3.9, "BR-04043/2022", 20220, "Verita", "2022_11125",
  
  # 19/10/2022 — Datafolha
  "Datafolha", "2022-10-17", "2022-10-19", 2912, 2, "Bolsonaro", 45, 5, "BR-07340/2022", 2912, "Grupo Globo e Folha de S. Paulo", "2022_11082",
  "Datafolha", "2022-10-17", "2022-10-19", 2912, 2, "Lula", 49, 5, "BR-07340/2022", 2912, "Grupo Globo e Folha de S. Paulo", "2022_11082",
  
  # 19/10/2022 — Modalmais/Futura
  "Futura", "2022-10-17", "2022-10-19", 2000, 2.2, "Bolsonaro", 46.9, 7.1, "BR-08523/2022", 2000, "Banco Modal", "2022_11100",
  "Futura", "2022-10-17", "2022-10-19", 2000, 2.2, "Lula", 45.9, 7.1, "BR-08523/2022", 2000, "Banco Modal", "2022_11100",
  
  # 19/10/2022 — Brasmarket
  "Brasmarket", "2022-10-15", "2022-10-19", 2400, 2, "Bolsonaro", 45.5, 13.7, "BR-05389/2022", 2400, "Brasmarket", "2022_11095",
  "Brasmarket", "2022-10-15", "2022-10-19", 2400, 2, "Lula", 40.8, 13.7, "BR-05389/2022", 2400, "Brasmarket", "2022_11095",
  
  # 19/10/2022 — Parana Pesquisas
  "Parana Pesquisas", "2022-10-15", "2022-10-19", 2020, 2.2, "Bolsonaro", 44.5, 8.6, "BR-02276/2022", 2020, "Parana Pesquisas", "2022_11093",
  "Parana Pesquisas", "2022-10-15", "2022-10-19", 2020, 2.2, "Lula", 46.9, 8.6, "BR-02276/2022", 2020, "Parana Pesquisas", "2022_11093",
  
  # 19/10/2022 — Ideia
  "Ideia", "2022-10-14", "2022-10-19", 1500, 3, "Bolsonaro", 46, 4, "BR-00053/2022", 1500, "Ideia", "2022_11097",
  "Ideia", "2022-10-14", "2022-10-19", 1500, 3, "Lula", 50, 4, "BR-00053/2022", 1500, "Ideia", "2022_11097",
  
  # 18/10/2022 — Abrapel/Ipespe
  "Ipespe", "2022-10-17", "2022-10-18", 1100, 3, "Bolsonaro", 43, 8, "BR-06307/2022", 1100, "Abrapel/Ipespe", "2022_11078",
  "Ipespe", "2022-10-17", "2022-10-18", 1100, 3, "Lula", 49, 8, "BR-06307/2022", 1100, "Abrapel/Ipespe", "2022_11078",
  
  # 18/10/2022 — PoderData
  "PoderData", "2022-10-16", "2022-10-18", 5000, 1.5, "Bolsonaro", 44, 8, "BR-08917/2022", 5000, "PoderData", "2022_11096",
  "PoderData", "2022-10-16", "2022-10-18", 5000, 1.5, "Lula", 48, 8, "BR-08917/2022", 5000, "PoderData", "2022_11096",
  
  # 18/10/2022 — Genial/Quaest
  "Quaest", "2022-10-16", "2022-10-18", 2000, 2, "Bolsonaro", 42, 11, "BR-04387/2022", 2000, "Banco Genial", "2022_11085",
  "Quaest", "2022-10-16", "2022-10-18", 2000, 2, "Lula", 47, 11, "BR-04387/2022", 2000, "Banco Genial", "2022_11085",
  
  # 17/10/2022 — Globo/Ipec
  "Ipec", "2022-10-15", "2022-10-17", 3008, 2, "Bolsonaro", 43, 7, "BR-02707/2022", 3008, "Grupo Globo", "2022_11067",
  "Ipec", "2022-10-15", "2022-10-17", 3008, 2, "Lula", 50, 7, "BR-02707/2022", 3008, "Grupo Globo", "2022_11067",
  
  # 16/10/2022 — CNT/MDA
  "MDA", "2022-10-14", "2022-10-16", 2002, 2.2, "Bolsonaro", 41.8, 10.1, "BR-05514/2022", 2002, "CNT", "2022_11060",
  "MDA", "2022-10-14", "2022-10-16", 2002, 2.2, "Lula", 48.1, 10.1, "BR-05514/2022", 2002, "CNT", "2022_11060",
  
  # 15/10/2022 — Verita
  "Verita", "2022-10-11", "2022-10-15", 5528, 2, "Bolsonaro", 48.7, 4.9, "BR-04850/2022", 5528, "Verita", "2022_11062",
  "Verita", "2022-10-11", "2022-10-15", 5528, 2, "Lula", 46.4, 4.9, "BR-04850/2022", 5528, "Verita", "2022_11062",
  
  # 14/10/2022 — Datafolha
  "Datafolha", "2022-10-13", "2022-10-14", 2898, 2, "Bolsonaro", 44, 6, "BR-01682/2022", 2898, "Folha de S. Paulo e Grupo Globo", "2022_11059",
  "Datafolha", "2022-10-13", "2022-10-14", 2898, 2, "Lula", 49, 6, "BR-01682/2022", 2898, "Folha de S. Paulo e Grupo Globo", "2022_11059",
  
  # 12/10/2022 — Modalmais/Futura
  "Futura", "2022-10-10", "2022-10-12", 2000, 2.2, "Bolsonaro", 46.5, 6.6, "BR-06280/2022", 2000, "Banco Modal", "2022_11056",
  "Futura", "2022-10-10", "2022-10-12", 2000, 2.2, "Lula", 46.9, 6.6, "BR-06280/2022", 2000, "Banco Modal", "2022_11056",
  
  # 12/10/2022 — Abrapel/Ipespe
  "Ipespe", "2022-10-10", "2022-10-12", 2000, 2.2, "Bolsonaro", 43, 8, "BR-07942/2022", 2000, "XP Investimentos", "2022_11055",
  "Ipespe", "2022-10-10", "2022-10-12", 2000, 2.2, "Lula", 49, 8, "BR-07942/2022", 2000, "XP Investimentos", "2022_11055",
  
  # 12/10/2022 — Genial/Quaest
  "Quaest", "2022-10-10", "2022-10-12", 2000, 2, "Bolsonaro", 41, 10, "BR-07106/2022", 2000, "Genial Investimentos", "2022_11048",
  "Quaest", "2022-10-10", "2022-10-12", 2000, 2, "Lula", 49, 10, "BR-07106/2022", 2000, "Genial Investimentos", "2022_11048",
  
  # 12/10/2022 — AtlasIntel
  "AtlasIntel", "2022-10-08", "2022-10-12", 4500, 1, "Bolsonaro", 46.5, NA, "BR-06012/2022", 4500, "AtlasIntel", "2022_11052",
  "AtlasIntel", "2022-10-08", "2022-10-12", 4500, 1, "Lula", 51.1, NA, "BR-06012/2022", 4500, "AtlasIntel", "2022_11052",
  
  # 12/10/2022 — Parana Pesquisas
  "Parana Pesquisas", "2022-10-08", "2022-10-12", 2020, 2.2, "Bolsonaro", 44.1, 8.4, "BR-08438/2022", 2020, "Partido Progressistas", "2022_11045",
  "Parana Pesquisas", "2022-10-08", "2022-10-12", 2020, 2.2, "Lula", 47.6, 8.4, "BR-08438/2022", 2020, "Partido Progressistas", "2022_11045",
  
  # 11/10/2022 — PoderData
  "PoderData", "2022-10-09", "2022-10-11", 5000, 1.5, "Bolsonaro", 44, 8, "BR-09241/2022", 5000, "PoderData", "2022_11044",
  "PoderData", "2022-10-09", "2022-10-11", 5000, 1.5, "Lula", 48, 8, "BR-09241/2022", 5000, "PoderData", "2022_11044",
  
  # 11/10/2022 — Gerp
  "Gerp", "2022-10-06", "2022-10-11", 2095, 2.18, "Bolsonaro", 46, 6, "BR-02322/2022", 2095, "Gerp", "2022_11038",
  "Gerp", "2022-10-06", "2022-10-11", 2095, 2.18, "Lula", 48, 6, "BR-02322/2022", 2095, "Gerp", "2022_11038",
  
  # 10/10/2022 — Abrapel/Ipespe
  "Ipespe", "2022-10-08", "2022-10-10", 1100, 3, "Bolsonaro", 43, 6, "BR-01120/2022", 1100, "Abrapel", "2022_11031",
  "Ipespe", "2022-10-08", "2022-10-10", 1100, 3, "Lula", 50, 6, "BR-01120/2022", 1100, "Abrapel", "2022_11031",
  
  # 10/10/2022 — Globo/Ipec
  "Ipec", "2022-10-04", "2022-10-10", 2000, 2, "Bolsonaro", 42, 7, "BR-02853/2022", 2000, "Grupo Globo", "2022_11020",
  "Ipec", "2022-10-04", "2022-10-10", 2000, 2, "Lula", 51, 7, "BR-02853/2022", 2000, "Grupo Globo", "2022_11020",
  
  # 07/10/2022 — Datafolha
  "Datafolha", "2022-10-05", "2022-10-07", 2884, 2, "Bolsonaro", 44, 8, "BR-02012/2022", 2884, "Grupo Globo e Folha de S. Paulo", "2022_11013",
  "Datafolha", "2022-10-05", "2022-10-07", 2884, 2, "Lula", 49, 8, "BR-02012/2022", 2884, "Grupo Globo e Folha de S. Paulo", "2022_11013",
  
  # 05/10/2022 — Globo/Ipec
  "Ipec", "2022-10-03", "2022-10-05", 2000, 2, "Bolsonaro", 43, 6, "BR-02736/2022", 2000, "Grupo Globo", "2022_11005",
  "Ipec", "2022-10-03", "2022-10-05", 2000, 2, "Lula", 51, 6, "BR-02736/2022", 2000, "Grupo Globo", "2022_11005",
  
  # 05/10/2022 — Genial/Quaest
  "Quaest", "2022-10-03", "2022-10-05", 2000, 2, "Bolsonaro", 41, 11, "BR-07940/2022", 2000, "Banco Genial", "2022_11007",
  "Quaest", "2022-10-03", "2022-10-05", 2000, 2, "Lula", 48, 11, "BR-07940/2022", 2000, "Banco Genial", "2022_11007",
  
  # 04/10/2022 — Modalmais/Futura
  "Futura", "2022-10-03", "2022-10-04", 2000, 2.2, "Bolsonaro", 46, 4.7, "BR-08263/2022", 2000, "Genial Investimentos", "2022_11012",
  "Futura", "2022-10-03", "2022-10-04", 2000, 2.2, "Lula", 49.3, 4.7, "BR-08263/2022", 2000, "Genial Investimentos", "2022_11012",
  
  # 05/10/2022 — PoderData
  "PoderData", "2022-10-03", "2022-10-05", 3500, 2, "Lula", 48, 8, "BR-08253/2022", 3500, NA, NA,
  "PoderData", "2022-10-03", "2022-10-05", 3500, 2, "Bolsonaro", 44, 8, "BR-08253/2022", 3500, NA, NA,
  
  "Ipec", "2022-09-25", "2022-10-01", 3008, 2, "Lula", 53, 11, "BR-00999/2022", 3008, NA, NA,
  "Ipec", "2022-09-25", "2022-10-01", 3008, 2, "Bolsonaro", 37, 11, "BR-00999/2022", 3008, NA, NA,
  
  "Datafolha", "2022-09-30", "2022-10-01", 12800, 2, "Lula", 54, 8, "BR-00245/2022", 12800, NA, NA,
  "Datafolha", "2022-09-30", "2022-10-01", 12800, 2, "Bolsonaro", 38, 8, "BR-00245/2022", 12800, NA, NA,
  
  "Ipespe", "2022-09-30", "2022-09-30", 1100, 3, "Lula", 55, 7, "BR-05007/2022", 1100, NA, NA,
  "Ipespe", "2022-09-30", "2022-09-30", 1100, 3, "Bolsonaro", 38, 7, "BR-05007/2022", 1100, NA, NA,
  
  "AtlasIntel", "2022-09-28", "2022-09-30", 4500, 1, "Lula", 53.1, 4.1, "BR-07338/2022", 4500, NA, NA,
  "AtlasIntel", "2022-09-28", "2022-09-30", 4500, 1, "Bolsonaro", 42.8, 4.1, "BR-07338/2022", 4500, NA, NA,
  
  "MDA", "2022-09-28", "2022-09-30", 2002, 2.2, "Lula", 50.4, 8.4, "BR-02944/2022", 2002, NA, NA,
  "MDA", "2022-09-28", "2022-09-30", 2002, 2.2, "Bolsonaro", 41.2, 8.4, "BR-02944/2022", 2002, NA, NA,
  
  "Datafolha", "2022-09-27", "2022-09-29", 6800, 2, "Lula", 54, 7, "BR-09479/2022", 6800, NA, NA,
  "Datafolha", "2022-09-27", "2022-09-29", 6800, 2, "Bolsonaro", 39, 7, "BR-09479/2022", 6800, NA, NA,
  
  "Futura", "2022-09-26", "2022-09-28", 2000, 2.2, "Lula", 47.7, 9.4, "BR-06743/2022", 2000, NA, NA,
  "Futura", "2022-09-26", "2022-09-28", 2000, 2.2, "Bolsonaro", 42.9, 9.4, "BR-06743/2022", 2000, NA, NA,
  
  "AtlasIntel", "2022-09-24", "2022-09-28", 4500, 1, "Lula", 51.8, 5.8, "BR-01318/2022", 4500, NA, NA,
  "AtlasIntel", "2022-09-24", "2022-09-28", 4500, 1, "Bolsonaro", 42.4, 5.8, "BR-01318/2022", 4500, NA, NA,
  
  "Ideia", "2022-09-23", "2022-09-28", 1500, 3, "Lula", 52, 7, "BR-09782/2022", 1500, NA, NA,
  "Ideia", "2022-09-23", "2022-09-28", 1500, 3, "Bolsonaro", 41, 7, "BR-09782/2022", 1500, NA, NA,
  
  "PoderData", "2022-09-25", "2022-09-27", 4500, 1.5, "Lula", 51, 9, "BR-01426/2022", 4500, NA, NA,
  "PoderData", "2022-09-25", "2022-09-27", 4500, 1.5, "Bolsonaro", 39, 9, "BR-01426/2022", 4500, NA, NA,
  
  "Quaest", "2022-09-24", "2022-09-27", 2000, 2, "Lula", 52, 10, "BR-04371/2022", 2000, NA, NA,
  "Quaest", "2022-09-24", "2022-09-27", 2000, 2, "Bolsonaro", 38, 10, "BR-04371/2022", 2000, NA, NA,
  
  "Ipec", "2022-09-25", "2022-09-26", 3008, 2, "Lula", 54, 11, "BR-01640/2022", 3008, NA, NA,
  "Ipec", "2022-09-25", "2022-09-26", 3008, 2, "Bolsonaro", 35, 11, "BR-01640/2022", 3008, NA, NA,
  
  "Parana Pesquisas", "2022-09-22", "2022-09-26", 2020, 2.2, "Lula", 48, 11.6, "BR-03928/2022", 2020, NA, NA,
  "Parana Pesquisas", "2022-09-22", "2022-09-26", 2020, 2.2, "Bolsonaro", 40.4, 11.6, "BR-03928/2022", 2020, NA, NA,
  
  "AtlasIntel", "2022-09-22", "2022-09-26", 4500, 1, "Lula", 51.3, 5, "BR-02714/2022", 4500, NA, NA,
  "AtlasIntel", "2022-09-22", "2022-09-26", 4500, 1, "Bolsonaro", 43.7, 5, "BR-02714/2022", 4500, NA, NA,
  
  "FSB", "2022-09-23", "2022-09-25", 2000, 2, "Lula", 52, 8, "BR-08123/2022", 2000, NA, NA,
  "FSB", "2022-09-23", "2022-09-25", 2000, 2, "Bolsonaro", 40, 8, "BR-08123/2022", 2000, NA, NA,
  
  "Equilíbrio Brasil", "2022-09-20", "2022-09-22", 11500, 3, "Lula", 43, 10, "BR-02018/2022", 11500, NA, NA,
  "Equilíbrio Brasil", "2022-09-20", "2022-09-22", 11500, 3, "Bolsonaro", 47, 10, "BR-02018/2022", 11500, NA, NA,
  
  "Datafolha", "2022-09-20", "2022-09-22", 6754, 2, "Lula", 54, 9, "BR-04180/2022", 6754, NA, NA,
  "Datafolha", "2022-09-20", "2022-09-22", 6754, 2, "Bolsonaro", 38, 9, "BR-04180/2022", 6754, NA, NA,
  
  "Futura", "2022-09-19", "2022-09-21", 2000, 2.2, "Lula", 47, 8.5, "BR-02650/2022", 2000, NA, NA,
  "Futura", "2022-09-19", "2022-09-21", 2000, 2.2, "Bolsonaro", 44.4, 8.5, "BR-02650/2022", 2000, NA, NA,
  
  "Ipespe", "2022-09-19", "2022-09-21", 2000, 2.2, "Lula", 54, 9, "BR-08425/2022", 2000, NA, NA,
  "Ipespe", "2022-09-19", "2022-09-21", 2000, 2.2, "Bolsonaro", 37, 9, "BR-08425/2022", 2000, NA, NA,
  
  "PoderData", "2022-09-18", "2022-09-20", 3500, 2, "Lula", 50, 8, "BR-00407/2022", 3500, NA, NA,
  "PoderData", "2022-09-18", "2022-09-20", 3500, 2, "Bolsonaro", 42, 8, "BR-00407/2022", 3500, NA, NA,
  
  "Quaest", "2022-09-17", "2022-09-20", 2000, 2, "Lula", 50, 10, "BR-04459/2022", 2000, NA, NA,
  "Quaest", "2022-09-17", "2022-09-20", 2000, 2, "Bolsonaro", 40, 10, "BR-04459/2022", 2000, NA, NA,
  
  "AtlasIntel", "2022-09-16", "2022-09-20", 7514, 1, "Lula", 53.1, 5.5, "BR-01204/2022", 7514, NA, NA,
  "AtlasIntel", "2022-09-16", "2022-09-20", 7514, 1, "Bolsonaro", 41.4, 5.5, "BR-01204/2022", 7514, NA, NA,
  
  "Parana Pesquisas", "2022-09-15", "2022-09-19", 2020, 2.2, "Lula", 47.3, 11.9, "BR-09417/2022", 2020, NA, NA,
  "Parana Pesquisas", "2022-09-15", "2022-09-19", 2020, 2.2, "Bolsonaro", 40.7, 11.9, "BR-09417/2022", 2020, NA, NA,
  
  "Ipec", "2022-09-13", "2022-09-18", 3008, 2, "Lula", 54, 11, "BR-00073/2022", 3008, NA, NA,
  "Ipec", "2022-09-13", "2022-09-18", 3008, 2, "Bolsonaro", 35, 11, "BR-00073/2022", 3008, NA, NA,
  
  "FSB", "2022-09-16", "2022-09-18", 2000, 2, "Lula", 52, 9, "BR-07560/2022", 2000, NA, NA,
  "FSB", "2022-09-16", "2022-09-18", 2000, 2, "Bolsonaro", 39, 9, "BR-07560/2022", 2000, NA, NA,
  
  "Ipespe", "2022-09-14", "2022-09-16", 1100, 3, "Lula", 53, 9, "BR-08883/2022", 1100, NA, NA,
  "Ipespe", "2022-09-14", "2022-09-16", 1100, 3, "Bolsonaro", 38, 9, "BR-08883/2022", 1100, NA, NA,
  
  "Datafolha", "2022-09-13", "2022-09-15", 5926, 2, "Lula", 54, 9, "BR-04099/2022", 5926, NA, NA,
  "Datafolha", "2022-09-13", "2022-09-15", 5926, 2, "Bolsonaro", 38, 9, "BR-04099/2022", 5926, NA, NA,
  
  "Futura", "2022-09-12", "2022-09-14", 2000, 2.2, "Lula", 44.5, 9.1, "BR-00745/2022", 2000, NA, NA,
  "Futura", "2022-09-12", "2022-09-14", 2000, 2.2, "Bolsonaro", 46.4, 9.1, "BR-00745/2022", 2000, NA, NA,
  
  "MDA", "2022-09-12", "2022-09-14", 2002, 2.2, "Lula", 49.4, 11.3, "BR-06984/2022", 2002, NA, NA,
  "MDA", "2022-09-12", "2022-09-14", 2002, 2.2, "Bolsonaro", 39.3, 11.3, "BR-06984/2022", 2002, NA, NA,
  
  "PoderData", "2022-09-11", "2022-09-13", 3500, 2, "Lula", 51, 7, "BR-02955/2022", 3500, NA, NA,
  "PoderData", "2022-09-11", "2022-09-13", 3500, 2, "Bolsonaro", 42, 7, "BR-02955/2022", 3500, NA, NA,
  
  "Quaest", "2022-09-10", "2022-09-13", 2000, 2, "Lula", 48, 12, "BR-03420/2022", 2000, NA, NA,
  "Quaest", "2022-09-10", "2022-09-13", 2000, 2, "Bolsonaro", 40, 12, "BR-03420/2022", 2000, NA, NA,
  
  "Parana Pesquisas", "2022-09-08", "2022-09-12", 2020, 2.2, "Lula", 47.4, 11.5, "BR-05388/2022", 2020, NA, NA,
  "Parana Pesquisas", "2022-09-08", "2022-09-12", 2020, 2.2, "Bolsonaro", 41.2, 11.5, "BR-05388/2022", 2020, NA, NA,
  
  "Ipec", "2022-09-09", "2022-09-11", 2512, 2, "Lula", 53, 11, "BR-01390/2022", 2512, NA, NA,
  "Ipec", "2022-09-09", "2022-09-11", 2512, 2, "Bolsonaro", 36, 11, "BR-01390/2022", 2512, NA, NA,
  
  "FSB", "2022-09-09", "2022-09-11", 2000, 2, "Lula", 51, 11, "BR-06321/2022", 2000, NA, NA,
  "FSB", "2022-09-09", "2022-09-11", 2000, 2, "Bolsonaro", 38, 11, "BR-06321/2022", 2000, NA, NA,
  
  "Datafolha", "2022-09-08", "2022-09-09", 2676, 2, "Lula", 53, 9, "BR-07422/2022", 2676, NA, NA,
  "Datafolha", "2022-09-08", "2022-09-09", 2676, 2, "Bolsonaro", 39, 9, "BR-07422/2022", 2676, NA, NA,
  
  "Ipespe", "2022-09-07", "2022-09-09", 1100, 3, "Lula", 52, 9, "BR-07606/2022", 1100, NA, NA,
  "Ipespe", "2022-09-07", "2022-09-09", 1100, 3, "Bolsonaro", 39, 9, "BR-07606/2022", 1100, NA, NA,
  
  "Futura", "2022-09-05", "2022-09-06", 2000, 2.2, "Lula", 44.7, 9.4, "BR-02618/2022", 2000, NA, NA,
  "Futura", "2022-09-05", "2022-09-06", 2000, 2.2, "Bolsonaro", 45.9, 9.4, "BR-02618/2022", 2000, NA, NA,
  
  "PoderData", "2022-09-05", "2022-09-06", 3500, 2, "Lula", 52, 8, "BR-03760/2022", 3500, NA, NA,
  "PoderData", "2022-09-05", "2022-09-06", 3500, 2, "Bolsonaro", 40, 8, "BR-03760/2022", 3500, NA, NA,
  
  "Parana Pesquisas", "2022-08-31", "2022-09-05", 2020, 2.2, "Lula", 47.8, 12.4, "BR-09446/2022", 2020, NA, NA,
  "Parana Pesquisas", "2022-08-31", "2022-09-05", 2020, 2.2, "Bolsonaro", 40.3, 12.4, "BR-09446/2022", 2020, NA, NA,
  
  "Ipec", "2022-09-02", "2022-09-04", 2512, 2, "Lula", 52, 12, "BR-00922/2022", 2512, NA, NA,
  "Ipec", "2022-09-02", "2022-09-04", 2512, 2, "Bolsonaro", 36, 12, "BR-00922/2022", 2512, NA, NA,
  
  "FSB", "2022-09-02", "2022-09-04", 2000, 2, "Lula", 53, 7, "BR-01786/2022", 2000, NA, NA,
  "FSB", "2022-09-02", "2022-09-04", 2000, 2, "Bolsonaro", 40, 7, "BR-01786/2022", 2000, NA, NA,
  
  "Quaest", "2022-09-01", "2022-09-04", 2000, 2, "Lula", 51, 10, "BR-00807/2022", 2000, NA, NA,
  "Quaest", "2022-09-01", "2022-09-04", 2000, 2, "Bolsonaro", 39, 10, "BR-00807/2022", 2000, NA, NA,
  
  "Ipespe", "2022-08-30", "2022-09-01", 1100, 3, "Lula", 53, 9, "BR-09344/2022", 1100, NA, NA,
  "Ipespe", "2022-08-30", "2022-09-01", 1100, 3, "Bolsonaro", 38, 9, "BR-09344/2022", 1100, NA, NA,
  
  "Datafolha", "2022-08-30", "2022-09-01", 5734, 2, "Lula", 53, 9, "BR-00433/2022", 5734, NA, NA,
  "Datafolha", "2022-08-30", "2022-09-01", 5734, 2, "Bolsonaro", 38, 9, "BR-00433/2022", 5734, NA, NA,
  
  "PoderData", "2022-08-28", "2022-08-30", 3500, 2, "Lula", 50, 9, "BR-06922/2022", 3500, NA, NA,
  "PoderData", "2022-08-28", "2022-08-30", 3500, 2, "Bolsonaro", 41, 9, "BR-06922/2022", 3500, NA, NA,
  
  "Parana Pesquisas", "2022-08-26", "2022-08-30", 2020, 2.2, "Lula", 47.8, 11.4, "BR-03492/2022", 2020, NA, NA,
  "Parana Pesquisas", "2022-08-26", "2022-08-30", 2020, 2.2, "Bolsonaro", 40.8, 11.4, "BR-03492/2022", 2020, NA, NA,
  
  "Ipespe", "2022-08-26", "2022-08-29", 2000, 2.2, "Lula", 53, 9, "BR-04347/2022", 2000, NA, NA,
  "Ipespe", "2022-08-26", "2022-08-29", 2000, 2.2, "Bolsonaro", 38, 9, "BR-04347/2022", 2000, NA, NA,
  
  "FSB", "2022-08-26", "2022-08-28", 2000, 2, "Lula", 52, 9, "BR-08934/2022", 2000, NA, NA,
  "FSB", "2022-08-26", "2022-08-28", 2000, 2, "Bolsonaro", 39, 9, "BR-08934/2022", 2000, NA, NA,
  
  "Ipec", "2022-08-26", "2022-08-28", 2000, 2, "Lula", 50, 13, "BR-01979/2022", 2000, NA, NA,
  "Ipec", "2022-08-26", "2022-08-28", 2000, 2, "Bolsonaro", 37, 13, "BR-01979/2022", 2000, NA, NA,
  
  "Quaest", "2022-08-25", "2022-08-28", 2000, 2, "Lula", 51, 13, "BR-00585/2022", 2000, NA, NA,
  "Quaest", "2022-08-25", "2022-08-28", 2000, 2, "Bolsonaro", 37, 13, "BR-00585/2022", 2000, NA, NA,
  
  "MDA", "2022-08-25", "2022-08-28", 2002, 2.2, "Lula", 50.1, 11.1, "BR-00950/2022", 2002, NA, NA,
  "MDA", "2022-08-25", "2022-08-28", 2002, 2.2, "Bolsonaro", 38.8, 11.1, "BR-00950/2022", 2002, NA, NA,
  
  "Futura", "2022-08-24", "2022-08-25", 2000, 2.2, "Lula", 45.3, 10.9, "BR-07568/2022", 2000, NA, NA,
  "Futura", "2022-08-24", "2022-08-25", 2000, 2.2, "Bolsonaro", 43.8, 10.9, "BR-07568/2022", 2000, NA, NA,
  
  "AtlasIntel", "2022-08-20", "2022-08-24", 7475, 1, "Lula", 51.8, 7.4, "BR-00848/2022", 7475, NA, NA,
  "AtlasIntel", "2022-08-20", "2022-08-24", 7475, 1, "Bolsonaro", 40.8, 7.4, "BR-00848/2022", 7475, NA, NA,
  
  "Ideia", "2022-08-19", "2022-08-24", 1500, 3, "Lula", 49, 13, "BR-02405/2022", 1500, NA, NA,
  "Ideia", "2022-08-19", "2022-08-24", 1500, 3, "Bolsonaro", 40, 13, "BR-02405/2022", 1500, NA, NA,
  
  "Parana Pesquisas", "2022-08-19", "2022-08-23", 2020, 2.2, "Lula", 47.8, 11.8, "BR-03138/2022", 2020, NA, NA,
  "Parana Pesquisas", "2022-08-19", "2022-08-23", 2020, 2.2, "Bolsonaro", 40.4, 11.8, "BR-03138/2022", 2020, NA, NA,
  
  "Verita", "2022-08-17", "2022-08-22", 5050, 2, "Lula", 45.5, 9, "BR-03033/2022", 5050, NA, NA,
  "Verita", "2022-08-17", "2022-08-22", 5050, 2, "Bolsonaro", 45.6, 9, "BR-03033/2022", 5050, NA, NA,
  
  "FSB", "2022-08-19", "2022-08-21", 2000, 2, "Lula", 52, 9, "BR-00244/2022", 2000, NA, NA,
  "FSB", "2022-08-19", "2022-08-21", 2000, 2, "Bolsonaro", 39, 9, "BR-00244/2022", 2000, NA, NA,
  
  "Datafolha", "2022-08-16", "2022-08-18", 5744, 2, "Lula", 54, 9, "BR-09404/2022", 5744, NA, NA,
  "Datafolha", "2022-08-16", "2022-08-18", 5744, 2, "Bolsonaro", 37, 9, "BR-09404/2022", 5744, NA, NA,
  
  "PoderData", "2022-08-14", "2022-08-16", 3500, 1.8, "Lula", 52, 10, "BR-02548/2022", 3500, NA, NA,
  "PoderData", "2022-08-14", "2022-08-16", 3500, 1.8, "Bolsonaro", 38, 10, "BR-02548/2022", 3500, NA, NA,
  
  "FSB", "2022-08-12", "2022-08-14", 2000, 2, "Lula", 53, 10, "BR-00603/2022", 2000, NA, NA,
  "FSB", "2022-08-12", "2022-08-14", 2000, 2, "Bolsonaro", 38, 10, "BR-00603/2022", 2000, NA, NA,
  
  "Ipec", "2022-08-12", "2022-08-14", 2000, 2, "Lula", 51, 14, "BR-03980/2022", 2000, NA, NA,
  "Ipec", "2022-08-12", "2022-08-14", 2000, 2, "Bolsonaro", 35, 14, "BR-03980/2022", 2000, NA, NA,
  
  "Quaest", "2022-08-11", "2022-08-14", 2000, 2, "Lula", 51, 11, "BR-01167/2022", 2000, NA, NA,
  "Quaest", "2022-08-11", "2022-08-14", 2000, 2, "Bolsonaro", 38, 11, "BR-01167/2022", 2000, NA, NA,
  
  "FSB", "2022-08-05", "2022-08-07", 2000, 2, "Lula", 51, 10, "BR-08028/2022", 2000, NA, NA,
  "FSB", "2022-08-05", "2022-08-07", 2000, 2, "Bolsonaro", 39, 10, "BR-08028/2022", 2000, NA, NA,
  
  "Grupo 6Sigma", "2022-08-01", "2022-08-05", 1000, 3.1, "Lula", 37.9, 16.7, "BR-04937/2022", 1000, NA, NA,
  "Grupo 6Sigma", "2022-08-01", "2022-08-05", 1000, 3.1, "Bolsonaro", 45.4, 16.7, "BR-04937/2022", 1000, NA, NA,
  
  "PoderData", "2022-07-31", "2022-08-02", 3500, 2, "Lula", 50, 9, "BR-08398/2022", 3500, NA, NA,
  "PoderData", "2022-07-31", "2022-08-02", 3500, 2, "Bolsonaro", 40, 9, "BR-08398/2022", 3500, NA, NA,
  
  "Parana Pesquisas", "2022-07-28", "2022-08-01", 2020, 2.2, "Lula", 48.6, 12.5, "BR-05251/2022", 2020, NA, NA,
  "Parana Pesquisas", "2022-07-28", "2022-08-01", 2020, 2.2, "Bolsonaro", 38.9, 12.5, "BR-05251/2022", 2020, NA, NA,
  
  "Quaest", "2022-07-28", "2022-07-31", 2000, 2, "Lula", 51, 12, "BR-02546/2022", 2000, NA, NA,
  "Quaest", "2022-07-28", "2022-07-31", 2000, 2, "Bolsonaro", 37, 12, "BR-02546/2022", 2000, NA, NA,
  
  "Datafolha", "2022-07-27", "2022-07-28", 2256, 2, "Lula", 55, 9, "BR-01192/2022", 2256, NA, NA,
  "Datafolha", "2022-07-27", "2022-07-28", 2256, 2, "Bolsonaro", 35, 9, "BR-01192/2022", 2256, NA, NA,
  
  "FSB", "2022-07-22", "2022-07-24", 2000, 2, "Lula", 54, 9, "BR-05938/2022", 2000, NA, NA,
  "FSB", "2022-07-22", "2022-07-24", 2000, 2, "Bolsonaro", 36, 9, "BR-05938/2022", 2000, NA, NA,
  
  "Futura", "2022-07-21", "2022-07-25", 2000, 2.2, "Lula", 46.2, 12.2, "BR-07639/2022", 2000, NA, NA,
  "Futura", "2022-07-21", "2022-07-25", 2000, 2.2, "Bolsonaro", 41.6, 12.2, "BR-07639/2022", 2000, NA, NA,
  
  "Ipespe", "2022-07-20", "2022-07-22", 2000, 2.2, "Lula", 53, 11, "BR-08220/2022", 2000, NA, NA,
  "Ipespe", "2022-07-20", "2022-07-22", 2000, 2.2, "Bolsonaro", 36, 11, "BR-08220/2022", 2000, NA, NA,
  
  "Ideia", "2022-07-15", "2022-07-20", 1500, 3, "Lula", 47, 16, "BR-09608/2022", 1500, NA, NA,
  "Ideia", "2022-07-15", "2022-07-20", 1500, 3, "Bolsonaro", 37, 16, "BR-09608/2022", 1500, NA, NA,
  
  "PoderData", "2022-07-17", "2022-07-19", 3000, 2, "Lula", 51, 12, "BR-07122/2022", 3000, NA, NA,
  "PoderData", "2022-07-17", "2022-07-19", 3000, 2, "Bolsonaro", 38, 12, "BR-07122/2022", 3000, NA, NA,
  
  "FSB", "2022-07-08", "2022-07-10", 2000, 2, "Lula", 53, 10, "BR-09292/2022", 2000, NA, NA,
  "FSB", "2022-07-08", "2022-07-10", 2000, 2, "Bolsonaro", 37, 10, "BR-09292/2022", 2000, NA, NA,
  
  "PoderData", "2022-07-03", "2022-07-05", 3000, 2, "Lula", 50, 12, "BR-06550/2022", 3000, NA, NA,
  "PoderData", "2022-07-03", "2022-07-05", 3000, 2, "Bolsonaro", 38, 12, "BR-06550/2022", 3000, NA, NA,
  
  "Parana Pesquisas", "2022-06-30", "2022-07-05", 2020, 2.2, "Lula", 48, 12.8, "BR-09408/2022", 2020, NA, NA,
  "Parana Pesquisas", "2022-06-30", "2022-07-05", 2020, 2.2, "Bolsonaro", 39.3, 12.8, "BR-09408/2022", 2020, NA, NA,
  
  "Quaest", "2022-06-29", "2022-07-02", 2000, 2, "Lula", 53, 13, "BR-01763/2022", 2000, NA, NA,
  "Quaest", "2022-06-29", "2022-07-02", 2000, 2, "Bolsonaro", 34, 13, "BR-01763/2022", 2000, NA, NA,
  
  "FSB", "2022-06-24", "2022-06-26", 2000, 2, "Lula", 52, 10, "BR-05022/2022", 2000, NA, NA,
  "FSB", "2022-06-24", "2022-06-26", 2000, 2, "Bolsonaro", 37, 10, "BR-05022/2022", 2000, NA, NA,
  
  "Futura", "2022-06-20", "2022-06-24", 2000, 2.2, "Lula", 41.7, 9.3, "BR-09994/2022", 2000, NA, NA,
  "Futura", "2022-06-20", "2022-06-24", 2000, 2.2, "Bolsonaro", 49, 9.3, "BR-09994/2022", 2000, NA, NA,
  
  "Datafolha", "2022-06-22", "2022-06-23", 2556, 2, "Lula", 57, 9, "BR-09088/2022", 2556, NA, NA,
  "Datafolha", "2022-06-22", "2022-06-23", 2556, 2, "Bolsonaro", 34, 9, "BR-09088/2022", 2556, NA, NA,
  
  "Ideia", "2022-06-17", "2022-06-22", 1500, 3, "Lula", 48, 10, "BR-02845/2022", 1500, NA, NA,
  "Ideia", "2022-06-17", "2022-06-22", 1500, 3, "Bolsonaro", 41, 10, "BR-02845/2022", 1500, NA, NA,
  
  "PoderData", "2022-06-19", "2022-06-21", 3000, 2, "Lula", 52, 13, "BR-07003/2022", 3000, NA, NA,
  "PoderData", "2022-06-19", "2022-06-21", 3000, 2, "Bolsonaro", 35, 13, "BR-07003/2022", 3000, NA, NA,
  
  "FSB", "2022-06-10", "2022-06-12", 2000, 2, "Lula", 54, 9, "BR-03958/2022", 2000, NA, NA,
  "FSB", "2022-06-10", "2022-06-12", 2000, 2, "Bolsonaro", 36, 9, "BR-03958/2022", 2000, NA, NA,
  
  "PoderData", "2022-06-05", "2022-06-07", 3000, 2, "Lula", 50, 10, "BR-01975/2022", 3000, NA, NA,
  "PoderData", "2022-06-05", "2022-06-07", 3000, 2, "Bolsonaro", 40, 10, "BR-01975/2022", 3000, NA, NA,
  
  "Quaest", "2022-06-02", "2022-06-05", 2000, 2, "Lula", 54, 12, "BR-03552/2022", 2000, NA, NA,
  "Quaest", "2022-06-02", "2022-06-05", 2000, 2, "Bolsonaro", 32, 12, "BR-03552/2022", 2000, NA, NA,
  
  "Ipespe", "2022-05-30", "2022-06-01", 1000, 3.2, "Lula", 53, 12, "BR-02893/2022", 1000, NA, NA,
  "Ipespe", "2022-05-30", "2022-06-01", 1000, 3.2, "Bolsonaro", 35, 12, "BR-02893/2022", 1000, NA, NA,
  
  "Parana Pesquisas", "2022-05-26", "2022-05-30", 2020, 2.2, "Lula", 47.3, 13.5, "BR-04618/2022", 2020, NA, NA,
  "Parana Pesquisas", "2022-05-26", "2022-05-30", 2020, 2.2, "Bolsonaro", 39.2, 13.5, "BR-04618/2022", 2020, NA, NA,
  
  "FSB", "2022-05-27", "2022-05-29", 2000, 2, "Lula", 54, 11, "BR-03196/2022", 2000, NA, NA,
  "FSB", "2022-05-27", "2022-05-29", 2000, 2, "Bolsonaro", 35, 11, "BR-03196/2022", 2000, NA, NA,
  
  "Datafolha", "2022-05-25", "2022-05-26", 2556, 2, "Lula", 58, 9, "BR-05166/2022", 2556, NA, NA,
  "Datafolha", "2022-05-25", "2022-05-26", 2556, 2, "Bolsonaro", 33, 9, "BR-05166/2022", 2556, NA, NA,
  
  "Ipespe", "2022-05-23", "2022-05-25", 1000, 3.2, "Lula", 53, 12, "BR-07856/2022", 1000, NA, NA,
  "Ipespe", "2022-05-23", "2022-05-25", 1000, 3.2, "Bolsonaro", 35, 12, "BR-07856/2022", 1000, NA, NA,
  
  "PoderData", "2022-05-22", "2022-05-24", 3000, 2, "Lula", 50, 11, "BR-05638/2022", 3000, NA, NA,
  "PoderData", "2022-05-22", "2022-05-24", 3000, 2, "Bolsonaro", 39, 11, "BR-05638/2022", 3000, NA, NA,
  
  "Futura", "2022-05-16", "2022-05-19", 2000, 2.2, "Lula", 49, 10.2, "BR-05658/2022", 2000, NA, NA,
  "Futura", "2022-05-16", "2022-05-19", 2000, 2.2, "Bolsonaro", 40.8, 10.2, "BR-05658/2022", 2000, NA, NA,
  
  "Ideia", "2022-05-14", "2022-05-19", 1500, 3, "Lula", 46, 15, "BR-01734/2022", 1500, NA, NA,
  "Ideia", "2022-05-14", "2022-05-19", 1500, 3, "Bolsonaro", 39, 15, "BR-01734/2022", 1500, NA, NA,
  
  "Ipespe", "2022-05-16", "2022-05-18", 1000, 3.2, "Lula", 53, 13, "BR-08011/2022", 1000, NA, NA,
  "Ipespe", "2022-05-16", "2022-05-18", 1000, 3.2, "Bolsonaro", 34, 13, "BR-08011/2022", 1000, NA, NA,
  
  "Ranking Brasil", "2022-05-10", "2022-05-14", 3000, 1.8, "Lula", 45, 15, "BR-06764/2022", 3000, NA, NA,
  "Ranking Brasil", "2022-05-10", "2022-05-14", 3000, 1.8, "Bolsonaro", 40, 15, "BR-06764/2022", 3000, NA, NA,
  
  "Ipespe", "2022-05-09", "2022-05-11", 1000, 3.2, "Lula", 54, 10, "BR-02603/2022", 1000, NA, NA,
  "Ipespe", "2022-05-09", "2022-05-11", 1000, 3.2, "Bolsonaro", 35, 10, "BR-02603/2022", 1000, NA, NA,
  
  "PoderData", "2022-05-08", "2022-05-10", 3000, 2, "Lula", 49, 13, "BR-08423/2022", 3000, NA, NA,
  "PoderData", "2022-05-08", "2022-05-10", 3000, 2, "Bolsonaro", 38, 13, "BR-08423/2022", 3000, NA, NA,
  
  "Quaest", "2022-05-05", "2022-05-08", 2000, 2, "Lula", 54, 11, "BR-01603/2022", 2000, NA, NA,
  "Quaest", "2022-05-05", "2022-05-08", 2000, 2, "Bolsonaro", 34, 11, "BR-01603/2022", 2000, NA, NA,
  
  "MDA", "2022-05-04", "2022-05-07", 2002, 2.2, "Lula", 50.8, 12.4, "BR-05757/2022", 2002, NA, NA,
  "MDA", "2022-05-04", "2022-05-07", 2002, 2.2, "Bolsonaro", 36.8, 12.4, "BR-05757/2022", 2002, NA, NA,
  
  "Ipespe", "2022-05-02", "2022-05-04", 1000, 3.2, "Lula", 54, 12, "BR-03473/2022", 1000, NA, NA,
  "Ipespe", "2022-05-02", "2022-05-04", 1000, 3.2, "Bolsonaro", 34, 12, "BR-03473/2022", 1000, NA, NA,
  
  "Parana Pesquisas", "2022-04-28", "2022-05-03", 2020, 2.2, "Lula", 46.4, 15, "BR-09280/2022", 2020, NA, NA,
  "Parana Pesquisas", "2022-04-28", "2022-05-03", 2020, 2.2, "Bolsonaro", 38.7, 15, "BR-09280/2022", 2020, NA, NA,
  
  "PoderData", "2022-04-24", "2022-04-26", 3000, 2, "Lula", 48, 13, "BR-07167/2022", 3000, NA, NA,
  "PoderData", "2022-04-24", "2022-04-26", 3000, 2, "Bolsonaro", 39, 13, "BR-07167/2022", 3000, NA, NA,
  
  "Futura", "2022-04-20", "2022-04-25", 2000, 2.2, "Lula", 50.2, 10.1, "BR-08858/2022", 2000, NA, NA,
  "Futura", "2022-04-20", "2022-04-25", 2000, 2.2, "Bolsonaro", 39.7, 10.1, "BR-08858/2022", 2000, NA, NA,
  
  "FSB", "2022-04-22", "2022-04-24", 2000, 2, "Lula", 52, 10, "BR-04676/2022", 2000, NA, NA,
  "FSB", "2022-04-22", "2022-04-24", 2000, 2, "Bolsonaro", 37, 10, "BR-04676/2022", 2000, NA, NA,
  
  "Ipespe", "2022-04-18", "2022-04-20", 1000, 3.2, "Lula", 54, 12, "BR-05747/2022", 1000, NA, NA,
  "Ipespe", "2022-04-18", "2022-04-20", 1000, 3.2, "Bolsonaro", 34, 12, "BR-05747/2022", 1000, NA, NA,
  
  "Ideia", "2022-04-15", "2022-04-20", 1500, 3, "Lula", 48, 13, "BR-02495/2022", 1500, NA, NA,
  "Ideia", "2022-04-15", "2022-04-20", 1500, 3, "Bolsonaro", 39, 13, "BR-02495/2022", 1500, NA, NA,
  
  "PoderData", "2022-04-10", "2022-04-12", 3000, 2, "Lula", 47, 15, "BR-00368/2022", 3000, NA, NA,
  "PoderData", "2022-04-10", "2022-04-12", 3000, 2, "Bolsonaro", 38, 15, "BR-00368/2022", 3000, NA, NA,
  
  "Sensus", "2022-04-08", "2022-04-11", 2000, 2.2, "Lula", 53.1, 12.8, "BR-01631/2022", 2000, NA, NA,
  "Sensus", "2022-04-08", "2022-04-11", 2000, 2.2, "Bolsonaro", 34.1, 12.8, "BR-01631/2022", 2000, NA, NA,
  
  "Ipespe", "2022-04-02", "2022-04-05", 1000, 3.2, "Lula", 53, 14, "BR-03874/2022", 1000, NA, NA,
  "Ipespe", "2022-04-02", "2022-04-05", 1000, 3.2, "Bolsonaro", 33, 14, "BR-03874/2022", 1000, NA, NA,
  
  "Parana Pesquisas", "2022-03-31", "2022-04-05", 2020, 2.2, "Lula", 47.1, 14.4, "BR-08065/2022", 2020, NA, NA,
  "Parana Pesquisas", "2022-03-31", "2022-04-05", 2020, 2.2, "Bolsonaro", 38.5, 14.4, "BR-08065/2022", 2020, NA, NA,
  
  "Quaest", "2022-04-01", "2022-04-03", 2000, 2, "Lula", 55, 11, "BR-00372/2022", 2000, NA, NA,
  "Quaest", "2022-04-01", "2022-04-03", 2000, 2, "Bolsonaro", 34, 11, "BR-00372/2022", 2000, NA, NA,
  
  "PoderData", "2022-03-27", "2022-03-29", 3000, 2, "Lula", 50, 12, "BR-06661/2022", 3000, NA, NA,
  "PoderData", "2022-03-27", "2022-03-29", 3000, 2, "Bolsonaro", 38, 12, "BR-06661/2022", 3000, NA, NA,
  
  "Futura", "2022-03-21", "2022-03-25", 2000, 2.2, "Lula", 48.6, 9.8, "BR-00758/2022", 2000, NA, NA,
  "Futura", "2022-03-21", "2022-03-25", 2000, 2.2, "Bolsonaro", 41.6, 9.8, "BR-00758/2022", 2000, NA, NA,
  
  "Datafolha", "2022-03-22", "2022-03-23", 2556, 2, "Lula", 55, 11, "BR-08967/2022", 2556, NA, NA,
  "Datafolha", "2022-03-22", "2022-03-23", 2556, 2, "Bolsonaro", 34, 11, "BR-08967/2022", 2556, NA, NA,
  
  "Ipespe", "2022-03-21", "2022-03-23", 1000, 3.2, "Lula", 54, 15, "BR-04222/2022", 1000, NA, NA,
  "Ipespe", "2022-03-21", "2022-03-23", 1000, 3.2, "Bolsonaro", 31, 15, "BR-04222/2022", 1000, NA, NA,
  
  "Ideia", "2022-03-18", "2022-03-23", 1500, 3, "Lula", 50, 13, "BR-04244/2022", 1500, NA, NA,
  "Ideia", "2022-03-18", "2022-03-23", 1500, 3, "Bolsonaro", 37, 13, "BR-04244/2022", 1500, NA, NA,
  
  "FSB", "2022-03-18", "2022-03-20", 2000, 2, "Lula", 54, 11, "BR-09630/2022", 2000, NA, NA,
  "FSB", "2022-03-18", "2022-03-20", 2000, 2, "Bolsonaro", 35, 11, "BR-09630/2022", 2000, NA, NA,
  
  "PoderData", "2022-03-13", "2022-03-15", 3000, 2, "Lula", 50, 14, "BR-00835/2022", 3000, NA, NA,
  "PoderData", "2022-03-13", "2022-03-15", 3000, 2, "Bolsonaro", 36, 14, "BR-00835/2022", 3000, NA, NA,
  
  "Quaest", "2022-03-10", "2022-03-13", 2000, 2, "Lula", 54, 13, "BR-06693/2022", 2000, NA, NA,
  "Quaest", "2022-03-10", "2022-03-13", 2000, 2, "Bolsonaro", 32, 13, "BR-06693/2022", 2000, NA, NA,
  
  "Ranking Brasil", "2022-03-07", "2022-03-12", 3000, 1.8, "Lula", 45, 16.7, "BR-04724/2022", 3000, NA, NA,
  "Ranking Brasil", "2022-03-07", "2022-03-12", 3000, 1.8, "Bolsonaro", 38.3, 16.7, "BR-04724/2022", 3000, NA, NA,
  
  "Ipespe", "2022-03-07", "2022-03-09", 1000, 3.2, "Lula", 53, 14, "BR-03573/2022", 1000, NA, NA,
  "Ipespe", "2022-03-07", "2022-03-09", 1000, 3.2, "Bolsonaro", 33, 14, "BR-03573/2022", 1000, NA, NA,
  
  "Parana Pesquisas", "2022-03-03", "2022-03-08", 2020, 2.2, "Lula", 46, 16.7, "BR-06682/2022", 2020, NA, NA,
  "Parana Pesquisas", "2022-03-03", "2022-03-08", 2020, 2.2, "Bolsonaro", 37.3, 16.7, "BR-06682/2022", 2020, NA, NA,
  
  "PoderData", "2022-02-27", "2022-03-01", 3000, 2, "Lula", 51, 11, "BR-01570/2022", 3000, NA, NA,
  "PoderData", "2022-02-27", "2022-03-01", 3000, 2, "Bolsonaro", 37, 11, "BR-01570/2022", 3000, NA, NA,
  
  "Ipespe", "2022-02-21", "2022-02-23", 1000, 3.2, "Lula", 54, 14, "BR-05015/2022", 1000, NA, NA,
  "Ipespe", "2022-02-21", "2022-02-23", 1000, 3.2, "Bolsonaro", 32, 14, "BR-05015/2022", 1000, NA, NA,
  
  "Ideia", "2022-02-18", "2022-02-22", 1500, 3, "Lula", 49, 16, "BR-05955/2022", 1500, NA, NA,
  "Ideia", "2022-02-18", "2022-02-22", 1500, 3, "Bolsonaro", 35, 16, "BR-05955/2022", 1500, NA, NA,
  
  "MDA", "2022-02-16", "2022-02-19", 2002, 2.2, "Lula", 53.2, 11.3, "BR-09751/2022", 2002, NA, NA,
  "MDA", "2022-02-16", "2022-02-19", 2002, 2.2, "Bolsonaro", 35.3, 11.3, "BR-09751/2022", 2002, NA, NA,
  
  "Futura", "2022-02-14", "2022-02-17", 2000, 2.2, "Lula", 48, 11.9, "BR-03014/2022", 2000, NA, NA,
  "Futura", "2022-02-14", "2022-02-17", 2000, 2.2, "Bolsonaro", 40.1, 11.9, "BR-03014/2022", 2000, NA, NA,
  
  "PoderData", "2022-02-13", "2022-02-15", 3000, 2, "Lula", 50, 15, "BR-06942/2022", 3000, NA, NA,
  "PoderData", "2022-02-13", "2022-02-15", 3000, 2, "Bolsonaro", 35, 15, "BR-06942/2022", 3000, NA, NA,
  
  "Ipespe", "2022-02-07", "2022-02-09", 1000, 3.2, "Lula", 54, 15, "BR-03828/2022", 1000, NA, NA,
  "Ipespe", "2022-02-07", "2022-02-09", 1000, 3.2, "Bolsonaro", 31, 15, "BR-03828/2022", 1000, NA, NA,
  
  "Quaest", "2022-02-03", "2022-02-06", 2000, 2, "Lula", 54, 16, "BR-08857/2022", 2000, NA, NA,
  "Quaest", "2022-02-03", "2022-02-06", 2000, 2, "Bolsonaro", 30, 16, "BR-08857/2022", 2000, NA, NA,
  
  "PoderData", "2022-01-31", "2022-02-01", 3000, 2, "Lula", 54, 9, "BR-09445/2022", 3000, NA, NA,
  "PoderData", "2022-01-31", "2022-02-01", 3000, 2, "Bolsonaro", 37, 9, "BR-09445/2022", 3000, NA, NA,
  
  "Parana Pesquisas", "2022-01-27", "2022-02-01", 2020, 2, "Lula", 48.8, 16.9, "BR-09055/2022", 2020, NA, NA,
  "Parana Pesquisas", "2022-01-27", "2022-02-01", 2020, 2, "Bolsonaro", 34.4, 16.9, "BR-09055/2022", 2020, NA, NA,
  
  "Ipespe", "2022-01-24", "2022-01-25", 1000, 3.2, "Lula", 54, 16, "BR-06408/2022", 1000, NA, NA,
  "Ipespe", "2022-01-24", "2022-01-25", 1000, 3.2, "Bolsonaro", 30, 16, "BR-06408/2022", 1000, NA, NA,
  
  "Futura", "2022-01-17", "2022-01-21", 2000, 2.2, "Lula", 50.4, 11.8, "BR-08869/2022", 2000, NA, NA,
  "Futura", "2022-01-17", "2022-01-21", 2000, 2.2, "Bolsonaro", 37.8, 11.8, "BR-08869/2022", 2000, NA, NA,
  
  "PoderData", "2022-01-16", "2022-01-18", 3000, 2, "Lula", 54, 14, "BR-02137/2022", 3000, NA, NA,
  "PoderData", "2022-01-16", "2022-01-18", 3000, 2, "Bolsonaro", 32, 14, "BR-02137/2022", 3000, NA, NA,
  
  "Ideia", "2022-01-09", "2022-01-13", 1500, 3, "Lula", 49, 18, "BR-03460/2022", 1500, NA, NA,
  "Ideia", "2022-01-09", "2022-01-13", 1500, 3, "Bolsonaro", 33, 18, "BR-03460/2022", 1500, NA, NA,
  
  "Ipespe", "2022-01-10", "2022-01-12", 1000, 3.2, "Lula", 56, 13, "BR-09080/2022", 1000, NA, NA,
  "Ipespe", "2022-01-10", "2022-01-12", 1000, 3.2, "Bolsonaro", 31, 13, "BR-09080/2022", 1000, NA, NA,
  
  "Quaest", "2022-01-06", "2022-01-09", 2000, 2, "Lula", 54, 16, "BR-00075/2022", 2000, NA, NA,
  "Quaest", "2022-01-06", "2022-01-09", 2000, 2, "Bolsonaro", 30, 16, "BR-00075/2022", 2000, NA, NA,
  
  "PoderData", "2021-12-19", "2021-12-21", 3000, 2, "Lula", 54, 11, NA, 3000, NA, NA,
  "PoderData", "2021-12-19", "2021-12-21", 3000, 2, "Bolsonaro", 34, 11, NA, 3000, NA, NA,
  
  "Ipespe", "2021-12-14", "2021-12-16", 1000, 3.2, "Lula", 53, 16, NA, 1000, NA, NA,
  "Ipespe", "2021-12-14", "2021-12-16", 1000, 3.2, "Bolsonaro", 31, 16, NA, 1000, NA, NA,
  
  "Datafolha", "2021-12-13", "2021-12-16", 3666, 2, "Lula", 59, 11, NA, 3666, NA, NA,
  "Datafolha", "2021-12-13", "2021-12-16", 3666, 2, "Bolsonaro", 30, 11, NA, 3666, NA, NA,
  
  "MDA", "2021-12-09", "2021-12-11", 2002, 2.2, "Lula", 52.7, 15.9, NA, 2002, NA, NA,
  "MDA", "2021-12-09", "2021-12-11", 2002, 2.2, "Bolsonaro", 31.4, 15.9, NA, 2002, NA, NA,
  
  "Quaest", "2021-12-02", "2021-12-05", 2037, 2.2, "Lula", 55, 14, NA, 2037, NA, NA,
  "Quaest", "2021-12-02", "2021-12-05", 2037, 2.2, "Bolsonaro", 31, 14, NA, 2037, NA, NA,
  
  "AtlasIntel", "2021-11-27", "2021-11-29", 4401, 1, "Lula", 50.5, 13.5, NA, 4401, NA, NA,
  "AtlasIntel", "2021-11-27", "2021-11-29", 4401, 1, "Bolsonaro", 36, 13.5, NA, 4401, NA, NA,
  
  "Sensus", "2021-11-24", "2021-11-28", 2000, 2.2, "Lula", 31.6, 13.3, NA, 2000, NA, NA,
  "Sensus", "2021-11-24", "2021-11-28", 2000, 2.2, "Bolsonaro", 55.1, 13.3, NA, 2000, NA, NA,
  
  #Margem de erro imputada, dado histórico do instituto
  "Ipespe", "2021-11-22", "2021-11-24", 1000, 3.2, "Lula", 52, 16, NA, 1000, NA, NA,
  "Ipespe", "2021-11-22", "2021-11-24", 1000, 3.2, "Bolsonaro", 32, 16, NA, 1000, NA, NA,
  
  "PoderData", "2021-11-22", "2021-11-24", 2500, 2, "Lula", 54, 15, NA, 2500, NA, NA,
  "PoderData", "2021-11-22", "2021-11-24", 2500, 2, "Bolsonaro", 31, 15, NA, 2500, NA, NA,
  
  "Futura", "2021-11-16", "2021-11-20", 2000, 2.2, "Lula", 49.7, 11.9, NA, 2000, NA, NA,
  "Futura", "2021-11-16", "2021-11-20", 2000, 2.2, "Bolsonaro", 38.4, 11.9, NA, 2000, NA, NA,
  
  "Parana Pesquisas", "2021-11-16", "2021-11-19", 2020, 2.2, "Lula", 42.5, 21.9, NA, 2020, NA, NA,
  "Parana Pesquisas", "2021-11-16", "2021-11-19", 2020, 2.2, "Bolsonaro", 35.6, 21.9, NA, 2020, NA, NA,
  
  "Ponteio Política", "2021-11-16", "2021-11-18", 1000, 3, "Lula", 50, 18, NA, 1000, NA, NA,
  "Ponteio Política", "2021-11-16", "2021-11-18", 1000, 3, "Bolsonaro",32, 18, NA, 1000, NA, NA,
  
  "Ideia", "2021-11-09", "2021-11-11", 1200, 3, "Lula", 31, 21, NA, 1200, NA, NA,
  "Ideia", "2021-11-09", "2021-11-11", 1200, 3, "Bolsonaro", 48, 21, NA, 1200, NA, NA,
  
  "Quaest", "2021-11-03", "2021-11-06", 2063, 2.2, "Lula", 57, 16, NA, 2063, NA, NA,
  "Quaest", "2021-11-03", "2021-11-06", 2063, 2.2, "Bolsonaro", 27, 16, NA, 2063, NA, NA,
  
  "Vox Populi", "2021-10-30", "2021-11-04", 2000, 2.2, "Lula", 52, 24, NA, 2000, NA, NA,
  "Vox Populi", "2021-10-30", "2021-11-04", 2000, 2.2, "Bolsonaro", 24, 24, NA, 2000, NA, NA,
  
  "Ipespe", "2021-10-25", "2021-10-28", 1000, 3.2, "Lula", 50, 17, NA, 1000, NA, NA,
  "Ipespe", "2021-10-25", "2021-10-28", 1000, 3.2, "Bolsonaro", 32, 17, NA, 1000, NA, NA,
  
  "PoderData", "2021-10-25", "2021-10-27", 2500, 2, "Lula", 52, 11, NA, 2500, NA, NA,
  "PoderData", "2021-10-25", "2021-10-27", 2500, 2, "Bolsonaro", 37, 11, NA, 2500, NA, NA,
  
  "Futura", "2021-10-19", "2021-10-22", 2000, 2.2, "Lula", 49.2, 13.5, NA, 2000, NA, NA,
  "Futura", "2021-10-19", "2021-10-22", 2000, 2.2, "Bolsonaro", 37.4, 13.5, NA, 2000, NA, NA,
  
  "Quaest", "2021-09-30", "2021-10-03", 2048, 2.2, "Lula", 53, 17, NA, 2048, NA, NA,
  "Quaest", "2021-09-30", "2021-10-03", 2048, 2.2, "Bolsonaro", 29, 17, NA, 2048, NA, NA,
  
  "PoderData", "2021-09-27", "2021-09-29", 2500, 2, "Lula", 56, 11, NA, 2500, NA, NA,
  "PoderData", "2021-09-27", "2021-09-29", 2500, 2, "Bolsonaro", 33, 11, NA, 2500, NA, NA,
  
  "Ipespe", "2021-09-22", "2021-09-24", 1000, 3.2, "Lula", 50, 18, NA, 1000, NA, NA,
  "Ipespe", "2021-09-22", "2021-09-24", 1000, 3.2, "Bolsonaro", 31, 18, NA, 1000, NA, NA,
  
  "Futura", "2021-09-21", "2021-09-24", 2000, 2.2, "Lula", 49.7, 15, NA, 2000, NA, NA,
  "Futura", "2021-09-21", "2021-09-24", 2000, 2.2, "Bolsonaro", 35.3, 15, NA, 2000, NA, NA,
  
  "Datafolha", "2021-09-13", "2021-09-15", 3667, 2, "Lula", 56, 14, NA, 3667, NA, NA,
  "Datafolha", "2021-09-13", "2021-09-15", 3667, 2, "Bolsonaro", 31, 14, NA, 3667, NA, NA,
  
  "DataTempo", "2021-09-09", "2021-09-15", 2025, 2.18, "Lula", 53.1, 16.8, NA, 2025, NA, NA,
  "DataTempo", "2021-09-09", "2021-09-15", 2025, 2.18, "Bolsonaro", 30.1, 16.8, NA, 2025, NA, NA,
  
  "AtlasIntel", "2021-08-30", "2021-09-04", 3146, 2, "Lula", 52.5, 11.6, NA, 3146, NA, NA,
  "AtlasIntel", "2021-08-30", "2021-09-04", 3146, 2, "Bolsonaro", 35.9, 11.6, NA, 3146, NA, NA,
  
  "PoderData", "2021-08-30", "2021-09-01", 2500, 2, "Lula", 55, 15, NA, 2500, NA, NA,
  "PoderData", "2021-08-30", "2021-09-01", 2500, 2, "Bolsonaro", 30, 15, NA, 2500, NA, NA,
  
  "Quaest", "2021-08-26", "2021-08-29", 2000, 2, "Lula", 55, 14, NA, 2000, NA, NA,
  "Quaest", "2021-08-26", "2021-08-29", 2000, 2, "Bolsonaro", 30, 14, NA, 2000, NA, NA,
  
  "Futura", "2021-08-17", "2021-08-20", 2000, 2.2, "Lula", 46.9, 14.3, NA, 2000, NA, NA,
  "Futura", "2021-08-17", "2021-08-20", 2000, 2.2, "Bolsonaro", 38.8, 14.3, NA, 2000, NA, NA,
  
  "Ipespe", "2021-08-11", "2021-08-14", 1000, 3.2, "Lula", 51, 17, NA, 1000, NA, NA,
  "Ipespe", "2021-08-11", "2021-08-14", 1000, 3.2, "Bolsonaro", 32, 17, NA, 1000, NA, NA,
  
  "PoderData", "2021-08-02", "2021-08-04", 2500, 2, "Lula", 52, 16, NA, 2500, NA, NA,
  "PoderData", "2021-08-02", "2021-08-04", 2500, 2, "Bolsonaro", 32, 16, NA, 2500, NA, NA,
  
  "Quaest", "2021-07-29", "2021-08-01", 1500, 3, "Lula", 54, 12, NA, 1500, NA, NA,
  "Quaest", "2021-07-29", "2021-08-01", 1500, 3, "Bolsonaro", 33, 12, NA, 1500, NA, NA,
  
  "AtlasIntel", "2021-07-26", "2021-07-29", 2884, 2, "Lula", 38.1, 12.7, NA, 2884, NA, NA,
  "AtlasIntel", "2021-07-26", "2021-07-29", 2884, 2, "Bolsonaro", 49.2, 12.7, NA, 2884, NA, NA,
  
  "Parana Pesquisas", "2021-07-24", "2021-07-28", 2010, 2, "Lula", 43.3, 18.4, NA, 2010, NA, NA,
  "Parana Pesquisas", "2021-07-24", "2021-07-28", 2010, 2, "Bolsonaro", 38.2, 18.4, NA, 2010, NA, NA,
  
  "Futura", "2021-07-23", "2021-07-26", 2006, 2.2, "Lula", 51.3, 15.8, NA, 2006, NA, NA,
  "Futura", "2021-07-23", "2021-07-26", 2006, 2.2, "Bolsonaro", 32.9, 15.8, NA, 2006, NA, NA,
  
  "Datafolha", "2021-07-07", "2021-07-08", 2074, 2, "Lula", 58, 11, NA, 2074, NA, NA,
  "Datafolha", "2021-07-07", "2021-07-08", 2074, 2, "Bolsonaro", 31, 11, NA, 2074, NA, NA,
  
  "Ideia", "2021-07-05", "2021-07-08", 1200, 3, "Lula", 46, 20, NA, 1200, NA, NA,
  "Ideia", "2021-07-05", "2021-07-08", 1200, 3, "Bolsonaro", 34, 20, NA, 1200, NA, NA,
  
  "Ipespe", "2021-07-05", "2021-07-07", 1000, 3.2, "Lula", 49, 17, NA, 1000, NA, NA,
  "Ipespe", "2021-07-05", "2021-07-07", 1000, 3.2, "Bolsonaro", 35, 17, NA, 1000, NA, NA,
  
  "PoderData", "2021-07-05", "2021-07-07", 2500, 2, "Lula", 55, 13, NA, 2500, NA, NA,
  "PoderData", "2021-07-05", "2021-07-07", 2500, 2, "Bolsonaro", 32, 13, NA, 2500, NA, NA,
  
  "Quaest", "2021-07-01", "2021-07-04", 1500, 3, "Lula", 54, 13, NA, 1500, NA, NA,
  "Quaest", "2021-07-01", "2021-07-04", 1500, 3, "Bolsonaro", 33, 13, NA, 1500, NA, NA,
  
  "MDA", "2021-07-01", "2021-07-03", 2002, 2.2, "Lula", 52.6, 14.1, NA, 2002, NA, NA,
  "MDA", "2021-07-01", "2021-07-03", 2002, 2.2, "Bolsonaro", 33.3, 14.1, NA, 2002, NA, NA,
  
  "Ideia", "2021-06-22", "2021-06-24", 1200, 3, "Lula", 44, 17, NA, 1200, NA, NA,
  "Ideia", "2021-06-22", "2021-06-24", 1200, 3, "Bolsonaro", 39, 17, NA, 1200, NA, NA,
  
  "Parana Pesquisas", "2021-06-11", "2021-06-15", 2040, 2, "Lula", 40, 19.7, NA, 2040, NA, NA,
  "Parana Pesquisas", "2021-06-11", "2021-06-15", 2040, 2, "Bolsonaro", 40.2, 19.7, NA, 2040, NA, NA,
  
  "Ipespe", "2021-06-07", "2021-06-10", 1000, 3.2, "Lula", 45, 19, NA, 1000, NA, NA,
  "Ipespe", "2021-06-07", "2021-06-10", 1000, 3.2, "Bolsonaro", 36, 19, NA, 1000, NA, NA,
  
  "PoderData", "2021-06-07", "2021-06-09", 2500, 2, "Lula", 48, 15, NA, 2500, NA, NA,
  "PoderData", "2021-06-07", "2021-06-09", 2500, 2, "Bolsonaro", 37, 15, NA, 2500, NA, NA,
  
  "Ideia", "2021-05-19", "2021-05-20", 1200, 3.1, "Lula", 45, 18, NA, 1200, NA, NA,
  "Ideia", "2021-05-19", "2021-05-20", 1200, 3.1, "Bolsonaro", 37, 18, NA, 1200, NA, NA,
  
  "Vox Populi", "2021-05-12", "2021-05-16", 2000, 2.2, "Lula", 55, 17, NA, 2000, NA, NA,
  "Vox Populi", "2021-05-12", "2021-05-16", 2000, 2.2, "Bolsonaro", 28, 17, NA, 2000, NA, NA,
  
  "Datafolha", "2021-05-11", "2021-05-12", 2071, 2, "Lula", 55, 13, NA, 2071, NA, NA,
  "Datafolha", "2021-05-11", "2021-05-12", 2071, 2, "Bolsonaro", 32, 13, NA, 2071, NA, NA,
  
  "PoderData", "2021-05-10", "2021-05-12", 2500, 2, "Lula", 50, 15, NA, 2500, NA, NA,
  "PoderData", "2021-05-10", "2021-05-12", 2500, 2, "Bolsonaro", 35, 15, NA, 2500, NA, NA,
  
  "AtlasIntel", "2021-05-06", "2021-05-09", 3828, 2, "Lula", 41, 13.3, NA, 3828, NA, NA,
  "AtlasIntel", "2021-05-06", "2021-05-09", 3828, 2, "Bolsonaro", 45.7, 13.3, NA, 3828, NA, NA,
  
  "Ipespe", "2021-05-04", "2021-05-07", 1000, 3.2, "Lula", 40, 18, NA, 1000, NA, NA,
  "Ipespe", "2021-05-04", "2021-05-07", 1000, 3.2, "Bolsonaro", 42, 18, NA, 1000, NA, NA,
  
  #Margem de erro imputada pelo histórico do instituto
  "Ideia", "2021-04-19", "2021-04-22", 1200, 3, "Lula", 38, 23, NA, 1200, NA, NA,
  "Ideia", "2021-04-19", "2021-04-22", 1200, 3, "Bolsonaro", 40, 23, NA, 1200, NA, NA,
  
  "PoderData", "2021-04-12", "2021-04-14", 3500, 1.8, "Lula", 52, 14, NA, 3500, NA, NA,
  "PoderData", "2021-04-12", "2021-04-14", 3500, 1.8, "Bolsonaro", 34, 14, NA, 3500, NA, NA,
  
  "Ipespe", "2021-03-29", "2021-03-31", 1000, 3.2, "Lula", 42, 20, NA, 1000, NA, NA,
  "Ipespe", "2021-03-29", "2021-03-31", 1000, 3.2, "Bolsonaro", 38, 20, NA, 1000, NA, NA,
  
  "PoderData", "2021-03-15", "2021-03-17", 3500, 2, "Lula", 41, 23, NA, 3500, NA, NA,
  "PoderData", "2021-03-15", "2021-03-17", 3500, 2, "Bolsonaro", 36, 23, NA, 3500, NA, NA,
  
  #Margem de erro imputada, dado histórico do instituto
  "Offerwise", "2021-03-12", "2021-03-16", 1000, 3.2, "Lula", 33.8, 28.3, NA, 1000, NA, NA,
  "Offerwise", "2021-03-12", "2021-03-16", 1000, 3.2, "Bolsonaro", 38, 28.3, NA, 1000, NA, NA,
  
  "Ideia", "2021-03-10", "2021-03-11", 1000, 3.1, "Lula", 37, 19, NA, 1000, NA, NA,
  "Ideia", "2021-03-10", "2021-03-11", 1000, 3.1, "Bolsonaro", 44, 19, NA, 1000, NA, NA,
  
  "Ipespe", "2021-03-09", "2021-03-11", 800, 3.5, "Lula", 40, 19, NA, 800, NA, NA,
  "Ipespe", "2021-03-09", "2021-03-11", 800, 3.5, "Bolsonaro", 41, 19, NA, 800, NA, NA,
  
  #Margem de erro imputada, dado histórico do instituto
  "AtlasIntel", "2021-03-08", "2021-03-10", 3721, 2, "Lula", 38.8, 16.3, NA, 3721, NA, NA,
  "AtlasIntel", "2021-03-08", "2021-03-10", 3721, 2, "Bolsonaro", 44.9, 16.3, NA, 3721, NA, NA,
  
  "RealTime Big Data", "2021-03-08", "2021-03-09", 1200, 3, "Lula", 39, 18, NA, 1200, NA, NA,
  "RealTime Big Data", "2021-03-08", "2021-03-09", 1200, 3, "Bolsonaro", 43, 18, NA, 1200, NA, NA,
  
  "AtlasIntel", "2021-01-26", "2021-01-28", 2184, 2, "Lula", 37.8, 21.3, NA, 2184, NA, NA,
  "AtlasIntel", "2021-01-26", "2021-01-28", 2184, 2, "Bolsonaro", 40.9, 21.3, NA, 2184, NA, NA,
  
  #Margem de erro imputada, dado histórico do instituto
  "Ideia", "2021-01-25", "2021-01-28", 1200, 3, "Lula", 45, 26, NA, 1200, NA, NA,
  "Ideia", "2021-01-25", "2021-01-28", 1200, 3, "Bolsonaro", 28, 26, NA, 1200, NA, NA,
  
  "Parana Pesquisas", "2021-01-22", "2021-01-26", 2002, 2, "Lula", 42.4, 21.9, NA, 2002, NA, NA,
  "Parana Pesquisas", "2021-01-22", "2021-01-26", 2002, 2, "Bolsonaro", 35.7, 21.9, NA, 2002, NA, NA,
  
  #Margem de erro imputada, dado histórico do instituto
  "Ideia", "2020-11-30", "2020-12-03", 1200, 3, "Lula", 37, 31, NA, 1200, NA, NA,
  "Ideia", "2020-11-30", "2020-12-03", 1200, 3, "Bolsonaro", 32, 31, NA, 1200, NA, NA,
  
  #Margem de erro imputada, dado histórico do instituto
  "Parana Pesquisas", "2020-11-28", "2020-12-01", 2036, 2, "Lula", 47, 19.7, NA, 2036, NA, NA,
  "Parana Pesquisas", "2020-11-28", "2020-12-01", 2036, 2, "Bolsonaro", 33.4, 19.7, NA, 2036, NA, NA,
  
  #Margem de erro imputada histórico
  "Offerwise", "2020-11-04", "2020-11-09", 1000, 3.2, "Lula", 38.9, 31.6, NA, 1000, NA, NA,
  "Offerwise", "2020-11-04", "2020-11-09", 1000, 3.2, "Bolsonaro", 29.5, 31.6, NA, 1000, NA, NA,
  
  "Ideia", "2020-10-05", "2020-10-08", 1200, 3, "Lula", 43, 25, NA, 1200, NA, NA,
  "Ideia", "2020-10-05", "2020-10-08", 1200, 3, "Bolsonaro", 33, 25, NA, 1200, NA, NA,
  
  #Margem de erro imputada histórico
  "Offerwise", "2020-09-30", "2020-10-05", 1000, 3.2, "Lula", 43, 31.8, NA, 1000, NA, NA,
  "Offerwise", "2020-09-30", "2020-10-05", 1000, 3.2, "Bolsonaro", 25.2, 31.8, NA, 1000, NA, NA,
  
  "PoderData", "2020-09-14", "2020-09-16", 2500, 2, "Lula", 41, 18, NA, 2500, NA, NA,
  "PoderData", "2020-09-14", "2020-09-16", 2500, 2, "Bolsonaro", 41, 18, NA, 2500, NA, NA,
  
  #Margem de erro imputada, dado histórico do instituto
  "Ideia", "2020-08-24", "2020-08-31", 1235, 3, "Lula", 42, 27, NA, 1235, NA, NA,
  "Ideia", "2020-08-24", "2020-08-31", 1235, 3, "Bolsonaro", 31, 27, NA, 1235, NA, NA,
  
  "Parana Pesquisas", "2020-07-18", "2020-07-21", 2030, 2, "Lula", 36.4, 18, NA, 2030, NA, NA,
  "Parana Pesquisas", "2020-07-18", "2020-07-21", 2030, 2, "Bolsonaro", 45.6, 18, NA, 2030, NA, NA,
  
  "Ipespe", "2020-04-28", "2020-04-30", 1000, 3.2, "Lula", 40, 21, NA, 1000, NA, NA,
  "Ipespe", "2020-04-28", "2020-04-30", 1000, 3.2, "Bolsonaro", 39, 21, NA, 1000, NA, NA,
  
  #Linha com margem de erro imputada, dado histórico do instituto
  "Ipespe", "2020-03-16", "2020-03-18", 1000, 3.2, "Lula", 42, 20, NA, 1000, NA, NA,
  "Ipespe", "2020-03-16", "2020-03-18", 1000, 3.2, "Bolsonaro", 39, 20, NA, 1000, NA, NA,
  
  "Ipespe", "2020-02-17", "2020-02-19", 1000, 3.2, "Lula", 43, 17, NA, 1000, NA, NA,
  "Ipespe", "2020-02-17", "2020-02-19", 1000, 3.2, "Bolsonaro", 40, 17, NA, 1000, NA, NA,
  
  "FSB", "2020-02-07", "2020-02-10", 2000, 2, "Lula", 48, 11, NA, 2000, NA, NA,
  "FSB", "2020-02-07", "2020-02-10", 2000, 2, "Bolsonaro", 40, 11, NA, 2000, NA, NA,
  
  "Ipespe", "2020-01-13", "2020-01-15", 1000, 3.2, "Lula", 43, 17, NA, 1000, NA, NA,
  "Ipespe", "2020-01-13", "2020-01-15", 1000, 3.2, "Bolsonaro", 40, 17, NA, 1000, NA, NA,
  
  #Margem calculada
  "Quaest", "2019-12-26", "2019-12-27", 1000, 3.1, "Lula", 46, 22, NA, 1000, NA, NA,
  "Quaest", "2019-12-26", "2019-12-27", 1000, 3.1, "Bolsonaro", 32, 22, NA, 1000, NA, NA,
  
  "FSB", "2019-11-29", "2019-12-02", 2000, 2, "Lula", 40, 16, NA, 2000, NA, NA,
  "FSB", "2019-11-29", "2019-12-02", 2000, 2, "Bolsonaro", 45, 16, NA, 2000, NA, NA,
  
  "FSB", "2019-10-11", "2019-10-14", 2000, 2, "Lula", 38, 17, NA, 2000, NA, NA,
  "FSB", "2019-10-11", "2019-10-14", 2000, 2, "Bolsonaro", 46, 17, NA, 2000, NA, NA
  
  
)

# ============================================================
# 3. TRANSFORMAÇÃO DO 1º TURNO
# ============================================================

base_1T <- base_1T_raw %>%
  mutate(
    data_inicio = as.Date(data_inicio),
    data_fim = as.Date(data_fim),
    data_referencia = data_fim,
    turno = 1L,
    ano = year(data_referencia),
    
    # Mantém os valores brutos no raw; aqui passam para proporção.
    abstencao_nao_decidiu =
      (outros_branco_nulo + indecisos_nao_sabe) / 100
  ) %>%
  pivot_longer(
    cols = c(
      lula, bolsonaro, ciro, tebet, soraya,
      felipe_davila, kelmon, pericles, sofia_manzano,
      vera_lucia, eymael
    ),
    names_to = "nome_clean",
    values_to = "percentual"
  ) %>%
  filter(!is.na(percentual)) %>%
  mutate(
    percentual = percentual / 100,
    categoria_voto_corrigida = "candidato",
    nome_candidato = case_when(
      nome_clean == "lula" ~ "Lula",
      nome_clean == "bolsonaro" ~ "Bolsonaro",
      nome_clean == "ciro" ~ "Ciro Gomes",
      nome_clean == "tebet" ~ "Simone Tebet",
      nome_clean == "soraya" ~ "Soraya Thronicke",
      nome_clean == "felipe_davila" ~ "Felipe D'Avila",
      nome_clean == "kelmon" ~ "Padre Kelmon",
      nome_clean == "pericles" ~ "Leo Péricles",
      nome_clean == "sofia_manzano" ~ "Sofia Manzano",
      nome_clean == "vera_lucia" ~ "Vera Lúcia",
      nome_clean == "eymael" ~ "Eymael",
      TRUE ~ nome_clean
    )
  )

# ============================================================
# 4. TRANSFORMAÇÃO DO 2º TURNO
# ============================================================

base_2T <- base_2T_raw %>%
  mutate(
    data_inicio = as.Date(data_inicio),
    data_fim = as.Date(data_fim),
    data_referencia = data_fim,
    turno = 2L,
    ano = year(data_referencia),
    percentual = percentual / 100,
    abstencao_nao_decidiu = abstencao_nao_decidiu / 100,
    categoria_voto_corrigida = "candidato",
    nome_clean = case_when(
      nome_candidato == "Bolsonaro" ~ "bolsonaro",
      nome_candidato == "Lula" ~ "lula",
      TRUE ~ nome_candidato
    )
  )

# ============================================================
# 5. BASE FINAL
# ============================================================

base_2022 <- bind_rows(
  base_1T %>%
    select(
      instituto, data_inicio, data_fim, data_referencia,
      amostra, margem_erro, turno, ano,
      nome_clean, nome_candidato, percentual,
      categoria_voto_corrigida,
      abstencao_nao_decidiu,
      registro_tse, amostra_tse, contratante, id_painel
    ),
  
  base_2T %>%
    select(
      instituto, data_inicio, data_fim, data_referencia,
      amostra, margem_erro, turno, ano,
      nome_clean, nome_candidato, percentual,
      categoria_voto_corrigida,
      abstencao_nao_decidiu,
      registro_tse, amostra_tse, contratante, id_painel
    )
) %>%
  arrange(data_referencia, turno, instituto, nome_candidato)


# ============================================================
# 6. DADOS METODOLÓGICOS DO TSE
# ============================================================
#
# O TSE não entrega estas características já prontas como
# "presencial", "telefone", "PPT", "cotas" etc.
#
# Ele entrega, por pesquisa registrada:
#   - metodologia;
#   - plano amostral e ponderação;
#   - sistema de controle;
#   - dados de municípios/bairros;
#   - empresa, contratante, período de campo;
#   - número de entrevistados;
#   - divulgação, custo, estatístico responsável etc.
#
# A documentação oficial do TSE confirma que DS_METODOLOGIA_PESQUISA,
# DS_PLANO_AMOSTRAL e DS_SISTEMA_CONTROLE são campos específicos do
# registro da pesquisa.
#
# Nesta etapa:
#   1. preservamos os textos originais do TSE;
#   2. criamos indicadores derivados por pesquisa;
#   3. não inventamos classificação quando o texto não permite afirmar.
# ============================================================

tse_2022 <- read_delim(
  arquivo_tse_2022,
  delim = ";",
  locale = locale(encoding = "Latin1"),
  col_types = cols(.default = col_character()),
  na = c("#NULO#", "#NE", ""),
  trim_ws = TRUE,
  show_col_types = FALSE
) %>%
  filter(
    SG_UF == "BR",
    SG_UE == "BR"
  ) %>%
  mutate(
    registro_tse_chave =
      str_remove_all(NR_PROTOCOLO_REGISTRO, "[^0-9]"),
    
    registro_tse = paste0(
      "BR-",
      substr(registro_tse_chave, 1, 5),
      "/",
      substr(registro_tse_chave, 6, 9)
    ),
    
    qt_entrevistado_tse =
      parse_number(
        QT_ENTREVISTADO,
        locale = locale(
          decimal_mark = ",",
          grouping_mark = "."
        )
      ),
    
    valor_pesquisa =
      parse_number(
        VR_PESQUISA,
        locale = locale(
          decimal_mark = ",",
          grouping_mark = "."
        )
      ),
    
    dt_registro = as.Date(substr(DT_REGISTRO, 1, 10)),
    dt_inicio_tse = as.Date(substr(DT_INICIO_PESQUISA, 1, 10)),
    dt_fim_tse = as.Date(substr(DT_FIM_PESQUISA, 1, 10)),
    dt_divulgacao = as.Date(substr(DT_DIVULGACAO, 1, 10))
  ) %>%
  distinct(registro_tse_chave, .keep_all = TRUE) %>%
  select(
    registro_tse,
    registro_tse_chave,
    dt_registro,
    st_pesquisa_propria = ST_PESQUISA_PROPRIA,
    cnpj_empresa = NR_CNPJ_EMPRESA,
    empresa_pesquisa = NM_EMPRESA,
    empresa_fantasia = NM_EMPRESA_FANTASIA,
    cargo_pesquisa = DS_CARGO,
    dt_inicio_tse,
    dt_fim_tse,
    dt_divulgacao,
    qt_entrevistado_tse,
    estatistico_responsavel = NM_ESTATISTICO_RESP,
    conre = CD_CONRE,
    valor_pesquisa,
    metodologia_pesquisa = DS_METODOLOGIA_PESQUISA,
    plano_amostral = DS_PLANO_AMOSTRAL,
    sistema_controle = DS_SISTEMA_CONTROLE,
    dado_municipio = DS_DADO_MUNICIPIO
  )


# ============================================================
# 7. LIGAÇÃO DA BASE DE PESQUISAS COM O TSE
# ============================================================

base_2022 <- base_2022 %>%
  left_join(
    tse_2022,
    by = "registro_tse"
  )



# ============================================================
# 8. BASE NO FORMATO DE 2018: IDENTIFICAÇÃO E CAMPOS DO REGISTRO
# ============================================================


base_v7 <- base_2022 %>%
  transmute(
    instituto,
    instituto_metodologia = instituto,
    turno = as.integer(turno),
    nome_clean,
    data_inicio = as.Date(data_inicio),
    data_fim = as.Date(data_fim),
    amostra = as.numeric(amostra),
    margem_erro = as.numeric(margem_erro),
    percentual,
    outros = NA_real_,
    abstencao_nao_decidiu,
    registro_tse,
    contratante,
    empresa_pesquisa,
    st_pesquisa_propria,
    valor_pesquisa,
    estatistico_resp_tse = estatistico_responsavel,
    dt_registro = as.Date(dt_registro),
    metodologia_pesquisa,
    plano_amostral,
    sistema_controle
  ) %>%
  mutate(
    # identificador: protocolo do TSE; sem registro (até 2021):
    # SEM-REGISTRO_<instituto>_<data de término>
    id_pesquisa = coalesce(
      registro_tse,
      paste0("SEM-REGISTRO_", str_remove_all(instituto_metodologia, "[^A-Za-z0-9]"),
             "_", format(data_fim, "%Y%m%d"))
    ),
    corrigido_tse = 0,
    dias_campo = as.integer(data_fim - data_inicio) + 1L,
    dias_ate_eleicao = as.integer(
      if_else(turno == 1L, data_eleicao_1t, data_eleicao_2t) - data_fim
    )
  )

duplicadas <- base_v7 %>% count(id_pesquisa, turno, nome_clean) %>% filter(n > 1)
if (nrow(duplicadas) > 0) {
  print(duplicadas)
  stop("Há pesquisas repetidas (mesmo id, turno e candidato) na base de 2022.")
}

# contratante digitado só em um dos turnos: vale para a pesquisa toda
base_v7 <- base_v7 %>%
  group_by(id_pesquisa) %>%
  mutate(contratante = coalesce(contratante, na.omit(contratante)[1])) %>%
  ungroup()
# ============================================================
# 9. METODOLOGIA REGISTRADA NO TSE (CODIFICADA) - MESMAS REGRAS DE 2018
# ============================================================
# tse_modo_coleta: online / telefonica_IVR / telefonica_entrevistador /
#                  presencial / misto
# tse_modo_fonte:  "explicito" (declarado na metodologia) ou "implicito"

extenso_pct <- c(
  "vinte e cinco" = 25, "cinco" = 5, "dez" = 10, "quinze" = 15,
  "vinte" = 20, "trinta" = 30, "quarenta" = 40, "cinquenta" = 50
)

norm_txt <- function(x) {
  x %>%
    coalesce("") %>%
    str_to_lower() %>%
    stringi::stri_trans_general("Latin-ASCII") %>%
    str_squish()
}

base_v7 <- base_v7 %>%
  mutate(
    .met = norm_txt(metodologia_pesquisa),
    .pla = norm_txt(plano_amostral),
    .ctl = norm_txt(sistema_controle),
    .tudo = paste(.met, .pla),
    .tudo_ctl = paste(.met, .pla, .ctl),
    
    # 2022: questionário web (AtlasIntel)
    .onl  = str_detect(.met, "online|internet|\\bweb\\b"),
    .ivr  = str_detect(.met, "automatizad|\\bura\\b|\\bivr\\b|unidade de resposta"),
    # "domicílio" em cotas de renda ("renda do chefe do domicílio",
    # "renda domiciliar") não indica coleta domiciliar: sai antes da busca
    .met_modo = str_remove_all(.met, "renda[^.;]{0,30}domicil[a-z]*|chefe d[oe] domicilio"),
    .pres = str_detect(.met_modo, "pessoa(l|is)\\b|face.a.face|pontos? de fluxo|domicil|abordagem pessoal"),
    .tel  = str_detect(.met, "telef"),
    # evidência de presencial que não seja só "entrevistas pessoais": em
    # 2022 há textos como "entrevistas pessoais, por telefone" (MDA) e
    # "entrevistas pessoais telefônicas" (Parana), que são telefone
    .pres_forte = str_detect(.met_modo, "face.a.face|pontos? de fluxo|domicil|abordagem pessoal|presencia"),
    
    tse_modo_coleta = case_when(
      is.na(empresa_pesquisa) ~ NA_character_,
      .onl ~ "online",
      .ivr ~ "telefonica_IVR",
      .pres_forte & .tel ~ "misto",
      .pres_forte ~ "presencial",
      .tel ~ "telefonica_entrevistador",
      .pres ~ "presencial",
      str_detect(.tudo, "setor(es)? censitario") ~ "presencial",
      str_detect(.pla, "telef") ~ "telefonica_entrevistador",
      TRUE ~ NA_character_
    ),
    tse_modo_fonte = case_when(
      is.na(tse_modo_coleta) ~ NA_character_,
      .onl | .ivr | .pres | .tel ~ "explicito",
      TRUE ~ "implicito"
    ),
    tse_local_entrevista = case_when(
      is.na(empresa_pesquisa) ~ NA_character_,
      tse_modo_coleta == "online" ~ "online",
      tse_modo_coleta %in% c("telefonica_IVR", "telefonica_entrevistador") ~ "telefone",
      str_detect(.tudo_ctl, "domicil") & str_detect(.tudo_ctl, "fluxo") ~ "domiciliar_ou_fluxo",
      str_detect(.tudo_ctl, "domicil") ~ "domiciliar",
      str_detect(.tudo_ctl, "fluxo|pontos de abordagem") ~ "ponto_fluxo",
      TRUE ~ NA_character_
    ),
    tse_cotas          = if_else(is.na(empresa_pesquisa), NA_real_, as.numeric(str_detect(.tudo, "cota|quota"))),
    tse_ppt            = if_else(is.na(empresa_pesquisa), NA_real_, as.numeric(str_detect(.tudo, "\\bppt\\b|probabilidade proporcional"))),
    tse_multiestagio   = if_else(is.na(empresa_pesquisa), NA_real_, as.numeric(str_detect(.tudo, "estagio|etapa"))),
    tse_estratificacao = if_else(is.na(empresa_pesquisa), NA_real_, as.numeric(str_detect(.tudo, "estratific"))),
    tse_tablet         = if_else(is.na(empresa_pesquisa), NA_real_, as.numeric(str_detect(paste(.met, .ctl), "tablet|questionario eletronico"))),
    tse_checagem_pct   = suppressWarnings(as.numeric(str_extract(.ctl, "\\d{1,3}(?=\\s*%)"))),
    .chk_extenso = str_match(.ctl, paste0("(", paste(names(extenso_pct), collapse = "|"), ") por cento"))[, 2],
    tse_checagem_pct   = coalesce(tse_checagem_pct, unname(extenso_pct[.chk_extenso])),
    tse_checagem_pct   = if_else(tse_checagem_pct > 0 & tse_checagem_pct <= 100, tse_checagem_pct, NA_real_)
  ) %>%
  select(-starts_with("."))

# ============================================================
# 10. METODOLOGIA CONSOLIDADA (SÓ TSE EM 2022)
# ============================================================

base_v7 <- base_v7 %>%
  mutate(
    modelo_coleta_final = tse_modo_coleta,
    fonte_modelo_coleta = case_when(
      tse_modo_fonte == "explicito" ~ "tse_explicito",
      tse_modo_fonte == "implicito" ~ "tse_implicito",
      TRUE ~ NA_character_
    ),
    coleta_presencial_final = case_when(
      is.na(modelo_coleta_final) ~ NA_real_,
      modelo_coleta_final %in% c("presencial", "misto") ~ 1,
      TRUE ~ 0
    ),
    coleta_telefone_final = case_when(
      is.na(modelo_coleta_final) ~ NA_real_,
      modelo_coleta_final %in% c("telefonica_IVR", "telefonica_entrevistador", "misto") ~ 1,
      TRUE ~ 0
    ),
    coleta_ivr_final = case_when(
      is.na(modelo_coleta_final) ~ NA_real_,
      modelo_coleta_final == "telefonica_IVR" ~ 1,
      TRUE ~ 0
    ),
    local_entrevista_final = tse_local_entrevista,
    usa_quotas_final = tse_cotas,
    ppt_final = tse_ppt,
    amostragem_multietapas_final = tse_multiestagio,
    tem_estratificacao_final = tse_estratificacao,
    tse_metodologia_fonte = if_else(!is.na(empresa_pesquisa), "registro_tse", "sem_registro")
  )

# ============================================================
# 11. FINANCIAMENTO E TIPO DE CONTRATANTE
# ============================================================
# Mesmas categorias de 2018. O arquivo do TSE de 2022 não traz o nome do
# contratante; usa-se a coluna contratante da base de 2022 e, quando a
# pesquisa é própria, a empresa.

base_v7 <- base_v7 %>%
  mutate(
    pesquisa_autofinanciada = case_when(
      st_pesquisa_propria == "S" ~ 1,
      st_pesquisa_propria == "N" ~ 0,
      TRUE ~ NA_real_
    ),
    contratante_tse = coalesce(
      contratante,
      if_else(pesquisa_autofinanciada %in% 1, empresa_pesquisa, NA_character_)
    ),
    .contr = norm_txt(contratante_tse),
    tipo_contratante = case_when(
      is.na(empresa_pesquisa) ~ NA_character_,
      pesquisa_autofinanciada == 1 ~ "proprio_instituto",
      is.na(contratante_tse) ~ NA_character_,
      str_detect(.contr, "partido|fundo partidario") ~ "partido",
      str_detect(.contr, "banco|corretora|investimentos|empiricus|btg|liquidez|\\bxp\\b|modal|genial|arko") ~ "mercado_financeiro",
      str_detect(.contr, "folha|globo|estado de s|abril|record|editora|comunicac|jornal|exame|cnn|\\btv\\b|istoe|veja") ~ "midia",
      str_detect(.contr, "confederacao|federacao|\\bcnt\\b|asserj|abrapel") ~ "entidade_empresarial",
      str_detect(.contr, "central unica|sindicato|movimento") ~ "sindical_ou_movimento",
      TRUE ~ "outro"
    )
  ) %>%
  select(-.contr)

# ============================================================
# 12. IMPUTAÇÃO MANUAL DAS CARACTERÍSTICAS FALTANTES
# ============================================================
# Origem: planilha imputacao_manual_2022.xlsx (aba "preencher"), revisada
# à mão: 152 pesquisas, sendo 78 sem registro no TSE (2019-2021), 9 com
# registro mas sem modo de coleta no texto e 65 com lacunas pontuais.
#
# Regras
#   - Só preenche o que está NA na base. Nada que veio do registro do
#     TSE é sobrescrito.
#   - Modo de coleta imputado: fonte_modelo_coleta = "imputado_manual"
#     (mesma categoria usada em 2018) e as dummies de coleta são
#     recalculadas a partir dele.
#   - tse_metodologia_fonte continua "sem_registro" nas pesquisas sem
#     registro: a imputação não cria um registro que não existe.
#   - Checagem (tse_checagem_pct) que continuar vazia: usa o percentual
#     mais comum entre as outras pesquisas do MESMO instituto (regra
#     interna do instituto; ex.: Datafolha e Ideia 30%, RealTime 15%).
#     Se o instituto não tem nenhuma pesquisa com checagem informada,
#     usa 20%, o padrão mais comum entre os institutos. Afeta 25
#     pesquisas.
#   - Contratante, tipo de contratante e autofinanciamento ficam NA
#     quando não foram encontrados (13 pesquisas de 2019-2021: Ideia,
#     Vox Populi e Quaest de dez/2019).
#
# Correções feitas ao transcrever a planilha, para seguir as categorias
# de 2018 (onde CNT/MDA é entidade_empresarial):
#   - CNT (MDA: 2 de 2021 e BR-09751/2022) e ASSERJ (Brasmarket
#     BR-05691/2022): sindical_ou_movimento -> entidade_empresarial
#   - BR-05757/2022 (MDA): o nome do contratante estava na coluna do
#     tipo -> entidade_empresarial
#   - BR-07451/2022 (RealTime, Novus Mídia): tipo vazio -> midia

imputacao_manual <- tribble(
  ~id_pesquisa, ~modelo_coleta_final, ~local_entrevista_final, ~usa_quotas_final, ~ppt_final,
  ~amostragem_multietapas_final, ~tem_estratificacao_final, ~tse_tablet, ~tse_checagem_pct,
  ~empresa_pesquisa, ~contratante_tse, ~tipo_contratante, ~pesquisa_autofinanciada,
  "BR-02346/2022", "presencial", "domiciliar", 1, 0, 0, 0, 0, 20, "GERP EMPRESA BRASILEIRA DE PESQUISA LTDA.", "Gerp", "proprio_instituto", 1,
  "BR-00123/2022", "presencial", "domiciliar", 1, 0, 0, 0, 0, 20, "GERP EMPRESA BRASILEIRA DE PESQUISA LTDA.", "GERP EMPRESA BRASILEIRA DE PESQUISA LTDA.", "proprio_instituto", 1,
  "BR-09327/2022", "presencial", "domiciliar", 1, 0, 0, 0, 0, 20, "GERP EMPRESA BRASILEIRA DE PESQUISA LTDA.", "GERP EMPRESA BRASILEIRA DE PESQUISA LTDA.", "proprio_instituto", 1,
  "BR-09102/2022", "presencial", "domiciliar", 1, 0, 0, 0, 0, 20, "GERP EMPRESA BRASILEIRA DE PESQUISA LTDA.", "Gerp", "proprio_instituto", 1,
  "BR-02322/2022", "presencial", "domiciliar", 1, 0, 0, 0, 0, 20, "GERP EMPRESA BRASILEIRA DE PESQUISA LTDA.", "Gerp", "proprio_instituto", 1,
  "BR-05418/2022", "presencial", "domiciliar", 1, 0, 0, 0, 0, 20, "GERP EMPRESA BRASILEIRA DE PESQUISA LTDA.", "Gerp", "proprio_instituto", 1,
  "BR-07451/2022", "presencial", "domiciliar_ou_fluxo", 1, 0, 0, 0, 0, 15, "REAL TIME MIDIA LTDA", "NOVUS MIDIA", "midia", 0,
  "BR-03033/2022", "presencial", "domiciliar_ou_fluxo", 1, 1, 1, 0, 0, 20, "INSTITUTO VERITA LTDA", "Verita", "proprio_instituto", 1,
  "BR-01060/2022", "presencial", "domiciliar_ou_fluxo", 1, 1, 1, 0, 0, 20, "INSTITUTO VERITA LTDA", "Verita", "proprio_instituto", 1,
  "SEM-REGISTRO_AtlasIntel_20210128", "online", "online", 1, 0, 0, 1, 1, 15, "ATLASINTEL TECNOLOGIA DE DADOS LTDA", "ATLASINTEL TECNOLOGIA DE DADOS LTDA", "proprio_instituto", 1,
  "SEM-REGISTRO_AtlasIntel_20210310", "online", "online", 1, 0, 0, 1, 1, 15, "ATLASINTEL TECNOLOGIA DE DADOS LTDA", "ATLASINTEL TECNOLOGIA DE DADOS LTDA", "proprio_instituto", 1,
  "SEM-REGISTRO_AtlasIntel_20210509", "online", "online", 1, 0, 0, 1, 1, 15, "ATLASINTEL TECNOLOGIA DE DADOS LTDA", "ATLASINTEL TECNOLOGIA DE DADOS LTDA", "proprio_instituto", 1,
  "SEM-REGISTRO_AtlasIntel_20210729", "online", "online", 1, 0, 0, 1, 1, 15, "ATLASINTEL TECNOLOGIA DE DADOS LTDA", "ATLASINTEL TECNOLOGIA DE DADOS LTDA", "proprio_instituto", 1,
  "SEM-REGISTRO_AtlasIntel_20210904", "online", "online", 1, 0, 0, 1, 1, 15, "ATLASINTEL TECNOLOGIA DE DADOS LTDA", "ATLASINTEL TECNOLOGIA DE DADOS LTDA", "proprio_instituto", 1,
  "SEM-REGISTRO_AtlasIntel_20211129", "online", "online", 1, 0, 0, 1, 1, 15, "ATLASINTEL TECNOLOGIA DE DADOS LTDA", "ATLASINTEL TECNOLOGIA DE DADOS LTDA", "proprio_instituto", 1,
  "SEM-REGISTRO_DataTempo_20210915", "presencial", "domiciliar", 1, 1, 0, 0, 0, NA, "DataTempo", "Folha de S.Paulo", "midia", 0,
  "SEM-REGISTRO_Datafolha_20210512", "presencial", "domiciliar_ou_fluxo", 1, 1, 0, 0, 0, NA, "DATAFOLHA INSTITUTO DE PESQUISAS LTDA.", "Folha de S.Paulo", "midia", 0,
  "SEM-REGISTRO_Datafolha_20210708", "presencial", "ponto_fluxo", 1, 1, 1, 1, 1, 30, "DATAFOLHA INSTITUTO DE PESQUISAS LTDA.", "Folha de S.Paulo", "midia", 0,
  "SEM-REGISTRO_Datafolha_20210915", "presencial", "ponto_fluxo", 1, 1, 1, 1, 1, 30, "DATAFOLHA INSTITUTO DE PESQUISAS LTDA.", "Folha de S.Paulo", "midia", 0,
  "SEM-REGISTRO_Datafolha_20211216", "presencial", "ponto_fluxo", 1, 1, 1, 1, 1, 30, "DATAFOLHA INSTITUTO DE PESQUISAS LTDA.", "Folha de S.Paulo", "midia", 0,
  "SEM-REGISTRO_FSB_20191014", "telefonica_entrevistador", "telefone", 0, 0, 0, 1, 0, 20, "IPRI INSTITUTO DE PESQUISA DE REPUTACAO E IMAGEM LTDA", "REVISTA VEJA", "midia", 0,
  "SEM-REGISTRO_FSB_20191202", "telefonica_entrevistador", "telefone", 0, 0, 0, 1, 0, 20, "IPRI INSTITUTO DE PESQUISA DE REPUTACAO E IMAGEM LTDA", "REVISTA VEJA", "midia", 0,
  "SEM-REGISTRO_FSB_20200210", "telefonica_entrevistador", "telefone", 0, 0, 0, 1, 0, 20, "IPRI INSTITUTO DE PESQUISA DE REPUTACAO E IMAGEM LTDA", "REVISTA VEJA", "midia", 0,
  "SEM-REGISTRO_Futura_20210726", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "FUTURA CONSULTORIA E ASSESSORIA LTDA", "Modalmais", "mercado_financeiro", 0,
  "SEM-REGISTRO_Futura_20210820", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "FUTURA CONSULTORIA E ASSESSORIA LTDA", "Modalmais", "mercado_financeiro", 0,
  "SEM-REGISTRO_Futura_20210924", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "FUTURA CONSULTORIA E ASSESSORIA LTDA", "Modalmais", "mercado_financeiro", 0,
  "SEM-REGISTRO_Futura_20211022", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "FUTURA CONSULTORIA E ASSESSORIA LTDA", "Modalmais", "mercado_financeiro", 0,
  "SEM-REGISTRO_Futura_20211120", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "FUTURA CONSULTORIA E ASSESSORIA LTDA", "Modalmais", "mercado_financeiro", 0,
  "SEM-REGISTRO_Ideia_20200831", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, NA, "MM IDEIA INSTITUTO DE PESQUISA LTDA.", NA, NA, NA,
  "SEM-REGISTRO_Ideia_20201008", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, NA, "MM IDEIA INSTITUTO DE PESQUISA LTDA.", NA, NA, NA,
  "SEM-REGISTRO_Ideia_20201203", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, NA, "MM IDEIA INSTITUTO DE PESQUISA LTDA.", NA, NA, NA,
  "SEM-REGISTRO_Ideia_20210128", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, NA, "MM IDEIA INSTITUTO DE PESQUISA LTDA.", NA, NA, NA,
  "SEM-REGISTRO_Ideia_20210311", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, NA, "MM IDEIA INSTITUTO DE PESQUISA LTDA.", NA, NA, NA,
  "SEM-REGISTRO_Ideia_20210422", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, NA, "MM IDEIA INSTITUTO DE PESQUISA LTDA.", NA, NA, NA,
  "SEM-REGISTRO_Ideia_20210520", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, NA, "MM IDEIA INSTITUTO DE PESQUISA LTDA.", NA, NA, NA,
  "SEM-REGISTRO_Ideia_20210624", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, NA, "MM IDEIA INSTITUTO DE PESQUISA LTDA.", NA, NA, NA,
  "SEM-REGISTRO_Ideia_20210708", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, NA, "MM IDEIA INSTITUTO DE PESQUISA LTDA.", NA, NA, NA,
  "SEM-REGISTRO_Ideia_20211111", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, NA, "MM IDEIA INSTITUTO DE PESQUISA LTDA.", NA, NA, NA,
  "SEM-REGISTRO_Ipespe_20200115", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "IPESPE INST DE PESQUISAS SOCIAIS POLITICAS E ECONOMICAS", "XP INVESTIMENTOS", "mercado_financeiro", 0,
  "SEM-REGISTRO_Ipespe_20200219", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "IPESPE INST DE PESQUISAS SOCIAIS POLITICAS E ECONOMICAS", "XP INVESTIMENTOS", "mercado_financeiro", 0,
  "SEM-REGISTRO_Ipespe_20200318", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "IPESPE INST DE PESQUISAS SOCIAIS POLITICAS E ECONOMICAS", "XP INVESTIMENTOS", "mercado_financeiro", 0,
  "SEM-REGISTRO_Ipespe_20200430", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "IPESPE INST DE PESQUISAS SOCIAIS POLITICAS E ECONOMICAS", "XP INVESTIMENTOS", "mercado_financeiro", 0,
  "SEM-REGISTRO_Ipespe_20210311", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "IPESPE INST DE PESQUISAS SOCIAIS POLITICAS E ECONOMICAS", "XP INVESTIMENTOS", "mercado_financeiro", 0,
  "SEM-REGISTRO_Ipespe_20210331", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "IPESPE INST DE PESQUISAS SOCIAIS POLITICAS E ECONOMICAS", "XP INVESTIMENTOS", "mercado_financeiro", 0,
  "SEM-REGISTRO_Ipespe_20210507", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "IPESPE INST DE PESQUISAS SOCIAIS POLITICAS E ECONOMICAS", "XP INVESTIMENTOS", "mercado_financeiro", 0,
  "SEM-REGISTRO_Ipespe_20210610", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "IPESPE INST DE PESQUISAS SOCIAIS POLITICAS E ECONOMICAS", "XP INVESTIMENTOS", "mercado_financeiro", 0,
  "SEM-REGISTRO_Ipespe_20210707", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "IPESPE INST DE PESQUISAS SOCIAIS POLITICAS E ECONOMICAS", "XP INVESTIMENTOS", "mercado_financeiro", 0,
  "SEM-REGISTRO_Ipespe_20210814", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "IPESPE INST DE PESQUISAS SOCIAIS POLITICAS E ECONOMICAS", "XP INVESTIMENTOS", "mercado_financeiro", 0,
  "SEM-REGISTRO_Ipespe_20210924", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "IPESPE INST DE PESQUISAS SOCIAIS POLITICAS E ECONOMICAS", "XP INVESTIMENTOS", "mercado_financeiro", 0,
  "SEM-REGISTRO_Ipespe_20211028", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "IPESPE INST DE PESQUISAS SOCIAIS POLITICAS E ECONOMICAS", "XP INVESTIMENTOS", "mercado_financeiro", 0,
  "SEM-REGISTRO_Ipespe_20211124", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "IPESPE INST DE PESQUISAS SOCIAIS POLITICAS E ECONOMICAS", "XP INVESTIMENTOS", "mercado_financeiro", 0,
  "SEM-REGISTRO_Ipespe_20211216", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "IPESPE INST DE PESQUISAS SOCIAIS POLITICAS E ECONOMICAS", "XP INVESTIMENTOS", "mercado_financeiro", 0,
  "SEM-REGISTRO_MDA_20210703", "presencial", "domiciliar_ou_fluxo", 1, 0, 1, 1, 1, 20, "MDA-PESQUISA DE OPINIAO PUBLICA E CONSULT. ESTATIST. LTDA - EPP", "CONFEDERAÇÃO NACIONAL DE TRANSPORTE", "entidade_empresarial", 0,
  "SEM-REGISTRO_MDA_20211211", "presencial", "domiciliar_ou_fluxo", 1, 0, 1, 1, 1, 20, "MDA-PESQUISA DE OPINIAO PUBLICA E CONSULT. ESTATIST. LTDA - EPP", "CONFEDERAÇÃO NACIONAL DE TRANSPORTE", "entidade_empresarial", 0,
  "SEM-REGISTRO_Offerwise_20201005", "online", "online", 1, 0, 1, 1, 1, NA, "OFFERWISE DO BRASIL SERVICOS DE PESQUISA LTDA", "REVISTA FORUM", "midia", 0,
  "SEM-REGISTRO_Offerwise_20201109", "online", "online", 1, 0, 1, 1, 1, NA, "OFFERWISE DO BRASIL SERVICOS DE PESQUISA LTDA", "REVISTA FORUM", "midia", 0,
  "SEM-REGISTRO_Offerwise_20210316", "online", "online", 1, 0, 1, 1, 1, NA, "OFFERWISE DO BRASIL SERVICOS DE PESQUISA LTDA", "REVISTA FORUM", "midia", 0,
  "SEM-REGISTRO_ParanPesquisas_20200721", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 1, NA, "INSTITUTO PARANA DE PESQUISAS E ANALISE DE CONSUMIDOR LTDA", "REVISTA VEJA", "midia", 0,
  "SEM-REGISTRO_ParanPesquisas_20201201", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 1, NA, "INSTITUTO PARANA DE PESQUISAS E ANALISE DE CONSUMIDOR LTDA", "REVISTA VEJA", "midia", 0,
  "SEM-REGISTRO_ParanPesquisas_20210126", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 1, NA, "INSTITUTO PARANA DE PESQUISAS E ANALISE DE CONSUMIDOR LTDA", "REVISTA VEJA", "midia", 0,
  "SEM-REGISTRO_ParanPesquisas_20210615", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 1, NA, "INSTITUTO PARANA DE PESQUISAS E ANALISE DE CONSUMIDOR LTDA", "INSTITUTO PARANA PESQUISAS", "proprio_instituto", 1,
  "SEM-REGISTRO_ParanPesquisas_20210728", "presencial", "domiciliar", 1, 1, 1, 0, 0, 20, "INSTITUTO PARANA DE PESQUISAS E ANALISE DE CONSUMIDOR LTDA", "INSTITUTO PARANA PESQUISAS", "proprio_instituto", 1,
  "SEM-REGISTRO_ParanPesquisas_20211119", "presencial", "domiciliar", 1, 1, 1, 0, 0, 20, "INSTITUTO PARANA DE PESQUISAS E ANALISE DE CONSUMIDOR LTDA", "INSTITUTO PARANA PESQUISAS", "proprio_instituto", 1,
  "SEM-REGISTRO_PoderData_20200916", "telefonica_IVR", "telefone", 0, 0, 0, 1, 0, 20, "PODERDATA PESQUISA, JORNALISMO E COMUNICACAO LTDA", "PODERDATA PESQUISA, JORNALISMO E COMUNICACAO LTDA", "proprio_instituto", 1,
  "SEM-REGISTRO_PoderData_20210317", "telefonica_IVR", "telefone", 0, 0, 0, 1, 0, 20, "PODERDATA PESQUISA, JORNALISMO E COMUNICACAO LTDA", "PODERDATA PESQUISA, JORNALISMO E COMUNICACAO LTDA", "proprio_instituto", 1,
  "SEM-REGISTRO_PoderData_20210414", "telefonica_IVR", "telefone", 0, 0, 0, 1, 0, 20, "PODERDATA PESQUISA, JORNALISMO E COMUNICACAO LTDA", "PODERDATA PESQUISA, JORNALISMO E COMUNICACAO LTDA", "proprio_instituto", 1,
  "SEM-REGISTRO_PoderData_20210512", "telefonica_IVR", "telefone", 0, 0, 0, 1, 0, 20, "PODERDATA PESQUISA, JORNALISMO E COMUNICACAO LTDA", "PODERDATA PESQUISA, JORNALISMO E COMUNICACAO LTDA", "proprio_instituto", 1,
  "SEM-REGISTRO_PoderData_20210609", "telefonica_IVR", "telefone", 0, 0, 0, 1, 0, 20, "PODERDATA PESQUISA, JORNALISMO E COMUNICACAO LTDA", "PODERDATA PESQUISA, JORNALISMO E COMUNICACAO LTDA", "proprio_instituto", 1,
  "SEM-REGISTRO_PoderData_20210707", "telefonica_IVR", "telefone", 0, 0, 0, 1, 0, 20, "PODERDATA PESQUISA, JORNALISMO E COMUNICACAO LTDA", "PODERDATA PESQUISA, JORNALISMO E COMUNICACAO LTDA", "proprio_instituto", 1,
  "SEM-REGISTRO_PoderData_20210804", "telefonica_IVR", "telefone", 0, 0, 0, 1, 0, 20, "PODERDATA PESQUISA, JORNALISMO E COMUNICACAO LTDA", "PODERDATA PESQUISA, JORNALISMO E COMUNICACAO LTDA", "proprio_instituto", 1,
  "SEM-REGISTRO_PoderData_20210901", "telefonica_IVR", "telefone", 0, 0, 0, 1, 0, 20, "PODERDATA PESQUISA, JORNALISMO E COMUNICACAO LTDA", "PODERDATA PESQUISA, JORNALISMO E COMUNICACAO LTDA", "proprio_instituto", 1,
  "SEM-REGISTRO_PoderData_20210929", "telefonica_IVR", "telefone", 0, 0, 0, 1, 0, 20, "PODERDATA PESQUISA, JORNALISMO E COMUNICACAO LTDA", "PODERDATA PESQUISA, JORNALISMO E COMUNICACAO LTDA", "proprio_instituto", 1,
  "SEM-REGISTRO_PoderData_20211027", "telefonica_IVR", "telefone", 0, 0, 0, 1, 0, 20, "PODERDATA PESQUISA, JORNALISMO E COMUNICACAO LTDA", "PODERDATA PESQUISA, JORNALISMO E COMUNICACAO LTDA", "proprio_instituto", 1,
  "SEM-REGISTRO_PoderData_20211124", "telefonica_IVR", "telefone", 0, 0, 0, 1, 0, 20, "PODERDATA PESQUISA, JORNALISMO E COMUNICACAO LTDA", "PODERDATA PESQUISA, JORNALISMO E COMUNICACAO LTDA", "proprio_instituto", 1,
  "SEM-REGISTRO_PoderData_20211221", "telefonica_IVR", "telefone", 0, 0, 0, 1, 0, 20, "PODERDATA PESQUISA, JORNALISMO E COMUNICACAO LTDA", "PODERDATA PESQUISA, JORNALISMO E COMUNICACAO LTDA", "proprio_instituto", 1,
  "SEM-REGISTRO_PonteioPoltica_20211118", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 1, NA, "Ponteio Consultoria Política e Pesquisa", "Ponteio Consultoria Política e Pesquisa", "proprio_instituto", 1,
  "SEM-REGISTRO_Quaest_20191227", "presencial", "domiciliar", 1, 1, 1, 0, 1, 20, "QUAEST PESQUISAS, CONSULTORIA E PROJETOS LTDA.", NA, NA, NA,
  "SEM-REGISTRO_Quaest_20210704", "presencial", "domiciliar", 1, 1, 1, 0, 1, 20, "QUAEST PESQUISAS, CONSULTORIA E PROJETOS LTDA.", "Genial", "mercado_financeiro", 0,
  "SEM-REGISTRO_Quaest_20210801", "presencial", "domiciliar", 1, 1, 1, 0, 1, 20, "QUAEST PESQUISAS, CONSULTORIA E PROJETOS LTDA.", "Genial", "mercado_financeiro", 0,
  "SEM-REGISTRO_Quaest_20210829", "presencial", "domiciliar", 1, 1, 1, 0, 1, 20, "QUAEST PESQUISAS, CONSULTORIA E PROJETOS LTDA.", "Genial", "mercado_financeiro", 0,
  "SEM-REGISTRO_Quaest_20211003", "presencial", "domiciliar", 1, 1, 1, 0, 1, 20, "QUAEST PESQUISAS, CONSULTORIA E PROJETOS LTDA.", "Genial", "mercado_financeiro", 0,
  "SEM-REGISTRO_Quaest_20211106", "presencial", "domiciliar", 1, 1, 1, 0, 1, 20, "QUAEST PESQUISAS, CONSULTORIA E PROJETOS LTDA.", "Genial", "mercado_financeiro", 0,
  "SEM-REGISTRO_Quaest_20211205", "presencial", "domiciliar", 1, 1, 1, 0, 1, 20, "QUAEST PESQUISAS, CONSULTORIA E PROJETOS LTDA.", "Genial", "mercado_financeiro", 0,
  "SEM-REGISTRO_RealTimeBigData_20210309", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 1, NA, "REAL TIME MIDIA LTDA", "CNN", "midia", 0,
  "SEM-REGISTRO_Sensus_20211128", "presencial", "domiciliar_ou_fluxo", 1, 1, 0, 1, 1, 15, "DATA WORLD PESQUISA E CONSULTORIA S/C. LTDA", "IstoÉ", "midia", 0,
  "SEM-REGISTRO_VoxPopuli_20210516", "presencial", "domiciliar", 1, 1, 1, 1, 1, NA, "Vox Populi", NA, NA, NA,
  "SEM-REGISTRO_VoxPopuli_20211104", "presencial", "domiciliar", 1, 1, 1, 1, 1, NA, "Vox Populi", NA, NA, NA,
  "BR-05691/2022", "telefonica_entrevistador", "telefone", 1, 1, 1, 0, 0, 20, "BRASMARKET ANALISE E INVESTIGACAO DE MERCADO LTDA", "ASSOCIACAO DE SUPERMERCADOS DO ESTADO DO RIO DE JANEIRO", "entidade_empresarial", 0,
  "BR-08967/2022", "presencial", "ponto_fluxo", 1, 1, 1, 1, 1, 30, "DATAFOLHA INSTITUTO DE PESQUISAS LTDA.", "DATAFOLHA INSTITUTO DE PESQUISAS LTDA.", "proprio_instituto", 1,
  "BR-05166/2022", "presencial", "ponto_fluxo", 1, 1, 1, 1, 1, 30, "DATAFOLHA INSTITUTO DE PESQUISAS LTDA.", "DATAFOLHA INSTITUTO DE PESQUISAS LTDA.", "proprio_instituto", 1,
  "BR-09088/2022", "presencial", "ponto_fluxo", 1, 1, 1, 1, 1, 30, "DATAFOLHA INSTITUTO DE PESQUISAS LTDA.", "DATAFOLHA INSTITUTO DE PESQUISAS LTDA.", "proprio_instituto", 1,
  "BR-01192/2022", "presencial", "ponto_fluxo", 1, 1, 1, 1, 1, 30, "DATAFOLHA INSTITUTO DE PESQUISAS LTDA.", "DATAFOLHA INSTITUTO DE PESQUISAS LTDA.", "proprio_instituto", 1,
  "BR-09630/2022", "telefonica_entrevistador", "telefone", 0, 0, 0, 1, 0, 20, "IPRI INSTITUTO DE PESQUISA DE REPUTACAO E IMAGEM LTDA", "BTG", "mercado_financeiro", 0,
  "BR-03196/2022", "telefonica_entrevistador", "telefone", 0, 0, 0, 1, 0, 20, "IPRI INSTITUTO DE PESQUISA DE REPUTACAO E IMAGEM LTDA", "BTG", "mercado_financeiro", 0,
  "BR-03958/2022", "telefonica_entrevistador", "telefone", 0, 0, 0, 1, 0, 20, "IPRI INSTITUTO DE PESQUISA DE REPUTACAO E IMAGEM LTDA", "BTG", "mercado_financeiro", 0,
  "BR-05022/2022", "telefonica_entrevistador", "telefone", 0, 0, 0, 1, 0, 20, "IPRI INSTITUTO DE PESQUISA DE REPUTACAO E IMAGEM LTDA", "BTG", "mercado_financeiro", 0,
  "BR-09292/2022", "telefonica_entrevistador", "telefone", 0, 0, 0, 1, 0, 20, "IPRI INSTITUTO DE PESQUISA DE REPUTACAO E IMAGEM LTDA", "BTG", "mercado_financeiro", 0,
  "BR-05938/2022", "telefonica_entrevistador", "telefone", 0, 0, 0, 1, 0, 20, "IPRI INSTITUTO DE PESQUISA DE REPUTACAO E IMAGEM LTDA", "BTG", "mercado_financeiro", 0,
  "BR-08869/2022", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "FUTURA CONSULTORIA E ASSESSORIA LTDA", "MODAL", "mercado_financeiro", 0,
  "BR-03014/2022", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "FUTURA CONSULTORIA E ASSESSORIA LTDA", "MODAL", "mercado_financeiro", 0,
  "BR-00758/2022", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "FUTURA CONSULTORIA E ASSESSORIA LTDA", "MODAL", "mercado_financeiro", 0,
  "BR-08858/2022", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "FUTURA CONSULTORIA E ASSESSORIA LTDA", "MODAL", "mercado_financeiro", 0,
  "BR-05658/2022", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "FUTURA CONSULTORIA E ASSESSORIA LTDA", "MODAL", "mercado_financeiro", 0,
  "BR-09994/2022", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "FUTURA CONSULTORIA E ASSESSORIA LTDA", "MODAL", "mercado_financeiro", 0,
  "BR-07639/2022", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "FUTURA CONSULTORIA E ASSESSORIA LTDA", "MODAL", "mercado_financeiro", 0,
  "BR-01775/2022", "telefonica_entrevistador", "telefone", 1, 1, 0, 1, 0, NA, "INSTITUTO FRANCA DE PESQUISAS LTDA", "INSTITUTO FRANCA DE PESQUISAS LTDA", "proprio_instituto", 1,
  "BR-08005/2022", "telefonica_entrevistador", "telefone", 1, 1, 0, 1, 0, NA, "INSTITUTO FRANCA DE PESQUISAS LTDA", "INSTITUTO FRANCA DE PESQUISAS LTDA", "proprio_instituto", 1,
  "BR-03460/2022", "telefonica_entrevistador", "telefone", 0, 1, 0, 0, 0, 30, "MM IDEIA INSTITUTO DE PESQUISA LTDA.", "EXAME", "midia", 0,
  "BR-05955/2022", "telefonica_entrevistador", "telefone", 0, 1, 0, 0, 0, 30, "MM IDEIA INSTITUTO DE PESQUISA LTDA.", "EXAME", "midia", 0,
  "BR-02495/2022", "telefonica_entrevistador", "telefone", 0, 1, 0, 0, 0, 30, "MM IDEIA INSTITUTO DE PESQUISA LTDA.", "EXAME", "midia", 0,
  "BR-01734/2022", "telefonica_entrevistador", "telefone", 0, 1, 0, 0, 0, 30, "MM IDEIA INSTITUTO DE PESQUISA LTDA.", "EXAME", "midia", 0,
  "BR-02845/2022", "telefonica_entrevistador", "telefone", 0, 1, 0, 0, 0, 30, "MM IDEIA INSTITUTO DE PESQUISA LTDA.", "EXAME", "midia", 0,
  "BR-09608/2022", "telefonica_entrevistador", "telefone", 0, 1, 0, 0, 0, 30, "MM IDEIA INSTITUTO DE PESQUISA LTDA.", "EXAME", "midia", 0,
  "BR-03980/2022", "presencial", "domiciliar_ou_fluxo", 1, 1, 1, 0, 0, 20, "INTELIGENCIA EM PESQUISA E CONSULTORIA LTDA", "Grupo Globo", "midia", 0,
  "BR-01979/2022", "presencial", "domiciliar_ou_fluxo", 1, 1, 1, 0, 0, 20, "INTELIGENCIA EM PESQUISA E CONSULTORIA LTDA", "Grupo Globo", "midia", 0,
  "BR-00922/2022", "presencial", "domiciliar_ou_fluxo", 1, 1, 1, 0, 0, 20, "INTELIGENCIA EM PESQUISA E CONSULTORIA LTDA", "TV Globo", "midia", 0,
  "BR-01390/2022", "presencial", "domiciliar_ou_fluxo", 1, 1, 1, 0, 0, 20, "INTELIGENCIA EM PESQUISA E CONSULTORIA LTDA", "Grupo Globo", "midia", 0,
  "BR-00073/2022", "presencial", "domiciliar_ou_fluxo", 1, 1, 1, 0, 0, 20, "INTELIGENCIA EM PESQUISA E CONSULTORIA LTDA", "Grupo Globo", "midia", 0,
  "BR-01640/2022", "presencial", "domiciliar_ou_fluxo", 1, 1, 1, 0, 0, 20, "INTELIGENCIA EM PESQUISA E CONSULTORIA LTDA", "Grupo Globo", "midia", 0,
  "BR-00999/2022", "presencial", "domiciliar_ou_fluxo", 1, 1, 1, 0, 0, 20, "INTELIGENCIA EM PESQUISA E CONSULTORIA LTDA", "Rede Globo", "midia", 0,
  "BR-02736/2022", "presencial", "domiciliar_ou_fluxo", 1, 1, 1, 0, 0, 20, "INTELIGENCIA EM PESQUISA E CONSULTORIA LTDA", "Grupo Globo", "midia", 0,
  "BR-02853/2022", "presencial", "domiciliar_ou_fluxo", 1, 1, 1, 0, 0, 20, "INTELIGENCIA EM PESQUISA E CONSULTORIA LTDA", "Grupo Globo", "midia", 0,
  "BR-02707/2022", "presencial", "domiciliar_ou_fluxo", 1, 1, 1, 0, 0, 20, "INTELIGENCIA EM PESQUISA E CONSULTORIA LTDA", "Grupo Globo", "midia", 0,
  "BR-06043/2022", "presencial", "domiciliar_ou_fluxo", 1, 1, 1, 0, 0, 20, "INTELIGENCIA EM PESQUISA E CONSULTORIA LTDA", "Grupo Globo", "midia", 0,
  "BR-05256/2022", "presencial", "domiciliar_ou_fluxo", 1, 1, 1, 0, 0, 20, "INTELIGENCIA EM PESQUISA E CONSULTORIA LTDA", "Grupo Globo", "midia", 0,
  "BR-09080/2022", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "IPESPE INST DE PESQUISAS SOCIAIS POLITICAS E ECONOMICAS", "XP INVESTIMENTOS", "mercado_financeiro", 0,
  "BR-06408/2022", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "IPESPE INST DE PESQUISAS SOCIAIS POLITICAS E ECONOMICAS", "XP INVESTIMENTOS", "mercado_financeiro", 0,
  "BR-03828/2022", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "IPESPE INST DE PESQUISAS SOCIAIS POLITICAS E ECONOMICAS", "XP INVESTIMENTOS", "mercado_financeiro", 0,
  "BR-05015/2022", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "IPESPE INST DE PESQUISAS SOCIAIS POLITICAS E ECONOMICAS", "XP INVESTIMENTOS", "mercado_financeiro", 0,
  "BR-03573/2022", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "IPESPE INST DE PESQUISAS SOCIAIS POLITICAS E ECONOMICAS", "XP INVESTIMENTOS", "mercado_financeiro", 0,
  "BR-04222/2022", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "IPESPE INST DE PESQUISAS SOCIAIS POLITICAS E ECONOMICAS", "XP INVESTIMENTOS", "mercado_financeiro", 0,
  "BR-05747/2022", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "IPESPE INST DE PESQUISAS SOCIAIS POLITICAS E ECONOMICAS", "XP INVESTIMENTOS", "mercado_financeiro", 0,
  "BR-03473/2022", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "IPESPE INST DE PESQUISAS SOCIAIS POLITICAS E ECONOMICAS", "XP INVESTIMENTOS", "mercado_financeiro", 0,
  "BR-02603/2022", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "IPESPE INST DE PESQUISAS SOCIAIS POLITICAS E ECONOMICAS", "XP INVESTIMENTOS", "mercado_financeiro", 0,
  "BR-08011/2022", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "IPESPE INST DE PESQUISAS SOCIAIS POLITICAS E ECONOMICAS", "XP INVESTIMENTOS", "mercado_financeiro", 0,
  "BR-07856/2022", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "IPESPE INST DE PESQUISAS SOCIAIS POLITICAS E ECONOMICAS", "XP INVESTIMENTOS", "mercado_financeiro", 0,
  "BR-02893/2022", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "IPESPE INST DE PESQUISAS SOCIAIS POLITICAS E ECONOMICAS", "XP INVESTIMENTOS", "mercado_financeiro", 0,
  "BR-08220/2022", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 0, 20, "IPESPE INST DE PESQUISAS SOCIAIS POLITICAS E ECONOMICAS", "XP INVESTIMENTOS", "mercado_financeiro", 0,
  "BR-09751/2022", "presencial", "domiciliar_ou_fluxo", 1, 0, 1, 1, 1, 20, "MDA-PESQUISA DE OPINIAO PUBLICA E CONSULT. ESTATIST. LTDA - EPP", "CONFEDERACAO NACIONAL DO TRANSPORTE", "entidade_empresarial", 0,
  "BR-05757/2022", "telefonica_entrevistador", "telefone", 1, 0, 1, 1, 1, 20, "MDA-PESQUISA DE OPINIAO PUBLICA E CONSULT. ESTATIST. LTDA - EPP", "CONFEDERACAO NACIONAL DO TRANSPORTE", "entidade_empresarial", 0,
  "BR-09055/2022", "presencial", "domiciliar", 1, 1, 1, 0, 0, 20, "INSTITUTO PARANA DE PESQUISAS E ANALISE DE CONSUMIDOR LTDA", "BGC", "mercado_financeiro", 0,
  "BR-06682/2022", "presencial", "domiciliar", 1, 1, 1, 0, 0, 20, "INSTITUTO PARANA DE PESQUISAS E ANALISE DE CONSUMIDOR LTDA", "BGC", "mercado_financeiro", 0,
  "BR-09280/2022", "presencial", "domiciliar", 1, 1, 1, 0, 0, 20, "INSTITUTO PARANA DE PESQUISAS E ANALISE DE CONSUMIDOR LTDA", "BGC", "mercado_financeiro", 0,
  "BR-04618/2022", "presencial", "domiciliar", 1, 1, 1, 0, 0, 20, "INSTITUTO PARANA DE PESQUISAS E ANALISE DE CONSUMIDOR LTDA", "BGC", "mercado_financeiro", 0,
  "BR-05251/2022", "presencial", "domiciliar", 1, 1, 1, 0, 0, 20, "INSTITUTO PARANA DE PESQUISAS E ANALISE DE CONSUMIDOR LTDA", "BGC", "mercado_financeiro", 0,
  "BR-00075/2022", "presencial", "domiciliar", 1, 1, 1, 0, 1, 20, "QUAEST PESQUISAS, CONSULTORIA E PROJETOS LTDA.", "GENIAL", "mercado_financeiro", 0,
  "BR-08857/2022", "presencial", "domiciliar", 1, 1, 1, 0, 1, 20, "QUAEST PESQUISAS, CONSULTORIA E PROJETOS LTDA.", "GENIAL", "mercado_financeiro", 0,
  "BR-06693/2022", "presencial", "domiciliar", 1, 1, 1, 0, 1, 20, "QUAEST PESQUISAS, CONSULTORIA E PROJETOS LTDA.", "GENIAL", "mercado_financeiro", 0,
  "BR-01603/2022", "presencial", "domiciliar", 1, 1, 1, 0, 1, 20, "QUAEST PESQUISAS, CONSULTORIA E PROJETOS LTDA.", "GENIAL", "mercado_financeiro", 0,
  "BR-03552/2022", "presencial", "domiciliar", 1, 1, 1, 0, 1, 20, "QUAEST PESQUISAS, CONSULTORIA E PROJETOS LTDA.", "GENIAL", "mercado_financeiro", 0,
  "BR-02546/2022", "presencial", "domiciliar", 1, 1, 1, 0, 1, 20, "QUAEST PESQUISAS, CONSULTORIA E PROJETOS LTDA.", "GENIAL", "mercado_financeiro", 0,
  "BR-01631/2022", "presencial", "domiciliar_ou_fluxo", 1, 1, 0, 1, 1, 15, "DATA WORLD PESQUISA E CONSULTORIA S/C. LTDA", "EDITORA TRES", "midia", 0
)

# ---- preenche só as células vazias da base -------------------
modo_era_na <- is.na(base_v7$modelo_coleta_final)
linha_manual <- match(base_v7$id_pesquisa, imputacao_manual$id_pesquisa)

for (coluna in setdiff(names(imputacao_manual), "id_pesquisa")) {
  base_v7[[coluna]] <- coalesce(base_v7[[coluna]], imputacao_manual[[coluna]][linha_manual])
}

base_v7 <- base_v7 %>%
  mutate(
    fonte_modelo_coleta = if_else(modo_era_na & !is.na(modelo_coleta_final),
                                  "imputado_manual", fonte_modelo_coleta),
    # dummies recalculadas a partir do modo (mesma regra da seção 10)
    coleta_presencial_final = case_when(
      is.na(modelo_coleta_final) ~ NA_real_,
      modelo_coleta_final %in% c("presencial", "misto") ~ 1,
      TRUE ~ 0
    ),
    coleta_telefone_final = case_when(
      is.na(modelo_coleta_final) ~ NA_real_,
      modelo_coleta_final %in% c("telefonica_IVR", "telefonica_entrevistador", "misto") ~ 1,
      TRUE ~ 0
    ),
    coleta_ivr_final = case_when(
      is.na(modelo_coleta_final) ~ NA_real_,
      modelo_coleta_final == "telefonica_IVR" ~ 1,
      TRUE ~ 0
    )
  )

# ---- checagem: regra interna do instituto; sem referência, 20% ----
checagem_padrao <- 20

checagem_por_instituto <- base_v7 %>%
  filter(!is.na(tse_checagem_pct)) %>%
  distinct(id_pesquisa, instituto, tse_checagem_pct) %>%
  count(instituto, tse_checagem_pct) %>%
  group_by(instituto) %>%
  slice_max(n, n = 1, with_ties = FALSE) %>%   # percentual mais comum do instituto
  ungroup() %>%
  select(instituto, checagem_instituto = tse_checagem_pct)

base_v7 <- base_v7 %>%
  left_join(checagem_por_instituto, by = "instituto") %>%
  mutate(tse_checagem_pct = coalesce(tse_checagem_pct, checagem_instituto, checagem_padrao)) %>%
  select(-checagem_instituto)

# ============================================================
# 13. VARIÁVEIS DERIVADAS - MESMAS REGRAS DE 2018
# ============================================================

# feriados nacionais de 2019 a 2022 (mesmo critério de 2018: fixos,
# Carnaval e Sexta-feira Santa)
feriados_nacionais <- as.Date(c(
  paste0(2019:2022, "-01-01"), paste0(2019:2022, "-04-21"), paste0(2019:2022, "-05-01"),
  paste0(2019:2022, "-09-07"), paste0(2019:2022, "-10-12"), paste0(2019:2022, "-11-02"),
  paste0(2019:2022, "-11-15"), paste0(2019:2022, "-12-25"),
  # Carnaval
  "2019-03-05", "2020-02-25", "2021-02-16", "2022-03-01",
  # Sexta-feira Santa
  "2019-04-19", "2020-04-10", "2021-04-02", "2022-04-15"
))

dias_do_campo <- function(inicio, fim) map2(inicio, fim, ~ seq(.x, .y, by = "day"))

# ---- 5.1 Escopo, votos válidos e cenário ---------------------

base_v7 <- base_v7 %>%
  group_by(id_pesquisa, turno) %>%
  mutate(
    percentual_validos = percentual / (sum(percentual, na.rm = TRUE) + coalesce(first(outros), 0)),
    n_candidatos_cenario = n_distinct(nome_clean)
  ) %>%
  ungroup() %>%
  mutate(
    boca_de_urna = if_else(
      data_inicio == data_fim & data_fim %in% c(data_eleicao_1t, data_eleicao_2t), 1, 0),
    pre_ano_eleitoral = if_else(year(data_fim) < ano_eleicao, 1, 0)
  )

# ---- 5.2 Tamanho, precisão e calendário ----------------------

base_v7 <- base_v7 %>%
  mutate(
    log_amostra = if_else(!is.na(amostra) & amostra > 0, log(amostra), NA_real_),
    se_p = if_else(!is.na(amostra) & amostra > 0,
                   sqrt(percentual * (1 - percentual) / amostra), NA_real_),
    margem_teorica_95 = 1.96 * se_p * 100,
    diferenca_margem_teorica = margem_erro - margem_teorica_95,
    amostra_grande = if_else(amostra >= 5000, 1, 0),
    .dias = dias_do_campo(data_inicio, data_fim),
    dias_uteis_campo = map_dbl(.dias, ~ sum(wday(.x) %in% 2:6)),
    coleta_sabado = map_dbl(.dias, ~ as.numeric(any(wday(.x) == 7))),
    coleta_domingo = map_dbl(.dias, ~ as.numeric(any(wday(.x) == 1))),
    coleta_feriado_nacional = map_dbl(.dias, ~ as.numeric(any(.x %in% feriados_nacionais))),
    inicio_campo_dia_semana = as.character(wday(data_inicio, label = TRUE, abbr = FALSE)),
    fim_campo_dia_semana = as.character(wday(data_fim, label = TRUE, abbr = FALSE))
  ) %>%
  select(-.dias)

# ---- 5.3 Frequência e recência do instituto ------------------
# Nível da PESQUISA. Em 2022, quatro registros têm datas de campo
# ligeiramente diferentes entre 1º e 2º turno; usa-se o fim de campo
# mais tardio do registro para a recência.

recencia_instituto <- base_v7 %>%
  group_by(instituto_metodologia, id_pesquisa) %>%
  summarise(.fim = max(data_fim), .ini = max(data_inicio), .groups = "drop") %>%
  arrange(instituto_metodologia, .fim, .ini, id_pesquisa) %>%
  group_by(instituto_metodologia) %>%
  mutate(dias_desde_ultima_pesquisa_instituto = as.numeric(.fim - lag(.fim))) %>%
  ungroup() %>%
  select(instituto_metodologia, id_pesquisa, dias_desde_ultima_pesquisa_instituto)

ordem_instituto_turno <- base_v7 %>%
  distinct(instituto_metodologia, turno, id_pesquisa, data_inicio, data_fim) %>%
  arrange(instituto_metodologia, turno, data_fim, data_inicio, id_pesquisa) %>%
  group_by(instituto_metodologia, turno) %>%
  mutate(n_pesquisas_instituto_turno = row_number()) %>%
  ungroup() %>%
  select(instituto_metodologia, turno, id_pesquisa, n_pesquisas_instituto_turno)

base_v7 <- base_v7 %>%
  left_join(recencia_instituto, by = c("instituto_metodologia", "id_pesquisa")) %>%
  left_join(ordem_instituto_turno, by = c("instituto_metodologia", "turno", "id_pesquisa"))

# ---- 5.4 Consenso anterior -----------------------------------

base_v7 <- base_v7 %>%
  mutate(
    consenso_previo = map_dbl(seq_len(n()), function(i) {
      ok <- turno == turno[i] & nome_clean == nome_clean[i] & data_fim < data_fim[i]
      if (!any(ok)) NA_real_ else mean(percentual[ok], na.rm = TRUE)
    }),
    desvio_padrao_consenso = map_dbl(seq_len(n()), function(i) {
      ok <- turno == turno[i] & nome_clean == nome_clean[i] & data_fim < data_fim[i]
      if (sum(ok) < 2) NA_real_ else sd(percentual[ok], na.rm = TRUE)
    }),
    distancia_consenso = percentual - consenso_previo,
    z_consenso = distancia_consenso / desvio_padrao_consenso,
    outlier = case_when(is.na(z_consenso) ~ NA_real_, abs(z_consenso) >= 2 ~ 1, TRUE ~ 0),
    direcao_vs_consenso = sign(distancia_consenso)
  )

# ---- 5.5 Movimento em relação à pesquisa anterior do mesmo instituto

base_v7 <- base_v7 %>%
  arrange(instituto_metodologia, turno, nome_clean, data_fim, data_inicio, id_pesquisa) %>%
  group_by(instituto_metodologia, turno, nome_clean) %>%
  mutate(
    percentual_pesquisa_anterior = lag(percentual),
    movimento_candidato = percentual - percentual_pesquisa_anterior,
    dias_desde_pesquisa_anterior_candidato = as.numeric(data_fim - lag(data_fim))
  ) %>%
  ungroup()

# ============================================================
# 14. MERCADO DE PREVISÃO (OPCIONAL) E PROBABILIDADE DA PESQUISA
# ============================================================
# Mesmas definições de 2018. Sem o arquivo da Betfair de 2022, as
# variáveis de mercado ficam NA.

fator_erro_total <- 2
datas_eleicao <- c(data_eleicao_1t, data_eleicao_2t)

janela_com_eleicao <- function(a, b) {
  (datas_eleicao[1] > a & datas_eleicao[1] <= b) |
    (datas_eleicao[2] > a & datas_eleicao[2] <= b)
}

if (file.exists(arquivo_betfair_diario_2022)) {
  betfair_diario <- read_csv(arquivo_betfair_diario_2022, show_col_types = FALSE) %>%
    mutate(data_brt = as.Date(data_brt)) %>%
    arrange(nome_clean, data_brt) %>%
    group_by(nome_clean) %>%
    mutate(volume_cum = cumsum(volume_dia)) %>%
    ungroup() %>%
    select(nome_clean, data_brt, prob_norm, spread_prob, volume_cum)
  chave_mercado <- paste(betfair_diario$nome_clean, betfair_diario$data_brt)
  busca_mercado <- function(nome, data, coluna) {
    betfair_diario[[coluna]][match(paste(nome, data), chave_mercado)]
  }
} else {
  message("Arquivo da Betfair de 2022 não encontrado: colunas de mercado ficam NA.")
  busca_mercado <- function(nome, data, coluna) rep(NA_real_, length(nome))
}

base_v7 <- base_v7 %>%
  mutate(
    .vespera = data_inicio - 1,
    probabilidade_mercado = busca_mercado(nome_clean, .vespera, "prob_norm"),
    liquidez_mercado = busca_mercado(nome_clean, .vespera, "spread_prob"),
    .vol_cum_vespera = busca_mercado(nome_clean, .vespera, "volume_cum"),
    .vol_cum_8d = busca_mercado(nome_clean, .vespera - 7, "volume_cum"),
    volume_mercado = if_else(is.na(.vol_cum_vespera), NA_real_,
                             .vol_cum_vespera - coalesce(.vol_cum_8d, 0)),
    antecipacao_mercado = probabilidade_mercado -
      busca_mercado(nome_clean, data_inicio - 4, "prob_norm"),
    variacao_mercado = busca_mercado(nome_clean, data_fim, "prob_norm") -
      probabilidade_mercado,
    reacao_mercado_pos = busca_mercado(nome_clean, data_fim + 2, "prob_norm") -
      busca_mercado(nome_clean, data_fim, "prob_norm"),
    antecipacao_inclui_votacao = if_else(
      is.na(antecipacao_mercado), NA_real_,
      as.numeric(janela_com_eleicao(data_inicio - 4, .vespera))),
    variacao_inclui_votacao = if_else(
      is.na(variacao_mercado), NA_real_,
      as.numeric(janela_com_eleicao(.vespera, data_fim))),
    reacao_inclui_votacao = if_else(
      is.na(reacao_mercado_pos), NA_real_,
      as.numeric(janela_com_eleicao(data_fim, data_fim + 2)))
  ) %>%
  # 2º turno: probabilidade de vitória implícita na pesquisa (Lula x Bolsonaro)
  group_by(id_pesquisa, turno, data_fim) %>%
  mutate(
    .p_bolsonaro = if (any(nome_clean == "bolsonaro")) percentual[nome_clean == "bolsonaro"][1] else NA_real_,
    .p_lula = if (any(nome_clean == "lula")) percentual[nome_clean == "lula"][1] else NA_real_
  ) %>%
  ungroup() %>%
  mutate(
    .validos = .p_bolsonaro + .p_lula,
    .v_bolsonaro = .p_bolsonaro / .validos,
    .n_efetivo = amostra * .validos,
    .ep_total = sqrt(.v_bolsonaro * (1 - .v_bolsonaro) / .n_efetivo) * fator_erro_total,
    .pv_bolsonaro = pnorm((.v_bolsonaro - 0.5) / .ep_total),
    prob_vitoria_pesquisa = case_when(
      turno != 2L ~ NA_real_,
      nome_clean == "bolsonaro" ~ .pv_bolsonaro,
      nome_clean == "lula" ~ 1 - .pv_bolsonaro,
      TRUE ~ NA_real_
    ),
    gap_pesquisa_mercado = if_else(turno == 2L,
                                   prob_vitoria_pesquisa - probabilidade_mercado, NA_real_),
    gap_pre_1turno = if_else(is.na(gap_pesquisa_mercado), NA_real_,
                             as.numeric(data_inicio < inicio_campanha_2t))
  ) %>%
  select(-starts_with("."))

# ============================================================
# 15. BASE FINAL E EXPORTAÇÃO (MESMAS COLUNAS DE 2018)
# ============================================================

dicionario_base_2022 <- tribble(
  ~coluna, ~grupo, ~descricao,
  # identificação e escopo
  "id_pesquisa", "identificacao", "Protocolo TSE; sem registro: SEM-REGISTRO_<instituto>_<data>",
  "instituto", "identificacao", "Instituto (nome padronizado no código de 2022)",
  "instituto_metodologia", "identificacao", "Instituto padronizado",
  "turno", "identificacao", "1 ou 2",
  "nome_clean", "identificacao", "Candidato (código)",
  "data_inicio", "identificacao", "Início do campo",
  "data_fim", "identificacao", "Fim do campo",
  "dias_campo", "identificacao", "Duração do campo em dias",
  "dias_ate_eleicao", "identificacao", "Dias entre o fim do campo e a eleição do turno",
  "boca_de_urna", "identificacao", "1 = boca de urna",
  "pre_ano_eleitoral", "identificacao", "1 = pesquisa anterior a 2022",
  "corrigido_tse", "identificacao", "1 = datas/amostra corrigidas pelo registro do TSE (0 em 2022)",
  # resultado da pesquisa
  "amostra", "resultado", "Número de entrevistas",
  "margem_erro", "resultado", "Margem de erro declarada (p.p.)",
  "percentual", "resultado", "Intenção de voto sobre votos totais (0-1)",
  "percentual_validos", "resultado", "Intenção de voto sobre votos válidos (0-1)",
  "outros", "resultado", "Outros candidatos (0-1); NA em 2022 (somados a branco/nulo na fonte)",
  "abstencao_nao_decidiu", "resultado", "Branco, nulo, indecisos e candidatos que não concorreram (0-1)",
  # tamanho, precisão e calendário
  "log_amostra", "precisao_calendario", "Logaritmo da amostra",
  "se_p", "precisao_calendario", "Erro-padrão teórico (AAS) do percentual",
  "margem_teorica_95", "precisao_calendario", "Margem teórica a 95% (p.p.)",
  "diferenca_margem_teorica", "precisao_calendario", "Margem declarada - margem teórica",
  "amostra_grande", "precisao_calendario", "1 = amostra >= 5.000",
  "dias_uteis_campo", "precisao_calendario", "Dias úteis no período de campo",
  "coleta_sabado", "precisao_calendario", "1 = campo inclui sábado",
  "coleta_domingo", "precisao_calendario", "1 = campo inclui domingo",
  "coleta_feriado_nacional", "precisao_calendario", "1 = campo inclui feriado nacional",
  "inicio_campo_dia_semana", "precisao_calendario", "Dia da semana do início do campo",
  "fim_campo_dia_semana", "precisao_calendario", "Dia da semana do fim do campo",
  # cenário, recência e consenso
  "n_candidatos_cenario", "cenario_recencia", "Candidatos principais no cenário",
  "n_pesquisas_instituto_turno", "cenario_recencia", "Ordem da pesquisa no instituto e turno",
  "dias_desde_ultima_pesquisa_instituto", "cenario_recencia", "Dias desde a pesquisa anterior do instituto",
  "percentual_pesquisa_anterior", "cenario_recencia", "Percentual na pesquisa anterior do mesmo instituto",
  "movimento_candidato", "cenario_recencia", "Variação contra a pesquisa anterior do mesmo instituto",
  "dias_desde_pesquisa_anterior_candidato", "cenario_recencia", "Dias desde essa pesquisa anterior",
  "consenso_previo", "cenario_recencia", "Média das pesquisas anteriores",
  "distancia_consenso", "cenario_recencia", "Percentual - consenso",
  "desvio_padrao_consenso", "cenario_recencia", "Desvio-padrão das pesquisas anteriores",
  "z_consenso", "cenario_recencia", "Distância padronizada ao consenso",
  "outlier", "cenario_recencia", "1 = |z| >= 2",
  "direcao_vs_consenso", "cenario_recencia", "1 acima, -1 abaixo, 0 igual ao consenso",
  # metodologia consolidada
  "modelo_coleta_final", "metodologia", "Modo de coleta (registro do TSE)",
  "fonte_modelo_coleta", "metodologia", "Origem do modo de coleta",
  "coleta_presencial_final", "metodologia", "1 = presencial",
  "coleta_telefone_final", "metodologia", "1 = telefone (com entrevistador ou IVR)",
  "coleta_ivr_final", "metodologia", "1 = telefone automatizado (IVR)",
  "local_entrevista_final", "metodologia", "Domiciliar / ponto de fluxo / telefone / online",
  "usa_quotas_final", "metodologia", "1 = cotas",
  "ppt_final", "metodologia", "1 = probabilidade proporcional ao tamanho",
  "amostragem_multietapas_final", "metodologia", "1 = amostragem em múltiplos estágios",
  "tem_estratificacao_final", "metodologia", "1 = estratificação",
  "tse_tablet", "metodologia", "1 = coleta em tablet/questionário eletrônico",
  "tse_checagem_pct", "metodologia", "Percentual de questionários checados",
  "tse_metodologia_fonte", "metodologia", "registro_tse / sem_registro",
  # registro no TSE
  "empresa_pesquisa", "registro_tse", "Empresa registrada no TSE",
  "contratante_tse", "registro_tse", "Contratante (base de 2022; a empresa quando a pesquisa é própria)",
  "tipo_contratante", "registro_tse", "Mercado financeiro / mídia / próprio instituto / etc.",
  "pesquisa_autofinanciada", "registro_tse", "1 = pesquisa própria (ST_PESQUISA_PROPRIA = S)",
  "valor_pesquisa", "registro_tse", "Valor declarado (R$)",
  "estatistico_resp_tse", "registro_tse", "Estatístico responsável",
  "dt_registro", "registro_tse", "Data do registro no TSE",
  # mercado de previsão
  "probabilidade_mercado", "mercado", "Prob. de vitória na véspera do campo",
  "volume_mercado", "mercado", "Volume negociado em 7 dias até a véspera (GBP)",
  "liquidez_mercado", "mercado", "Spread na véspera (menor = mais líquido); NA = livro de um lado",
  "antecipacao_mercado", "mercado", "Variação da prob. nos 3 dias antes do campo",
  "variacao_mercado", "mercado", "Variação da prob. durante o campo",
  "reacao_mercado_pos", "mercado", "Variação da prob. do fim do campo até 2 dias depois",
  "antecipacao_inclui_votacao", "mercado", "1 = janela inclui dia de votação",
  "variacao_inclui_votacao", "mercado", "1 = janela inclui dia de votação",
  "reacao_inclui_votacao", "mercado", "1 = janela inclui dia de votação",
  "prob_vitoria_pesquisa", "mercado", "2º turno: prob. de estar à frente segundo a pesquisa",
  "gap_pesquisa_mercado", "mercado", "2º turno: prob_vitoria_pesquisa - probabilidade_mercado",
  "gap_pre_1turno", "mercado", "1 = pesquisa de 2º turno feita antes do 1º turno"
)

faltando <- setdiff(dicionario_base_2022$coluna, names(base_v7))
if (length(faltando) > 0) stop("Colunas não criadas: ", paste(faltando, collapse = ", "))

base_2022_v7 <- base_v7 %>%
  select(all_of(dicionario_base_2022$coluna)) %>%
  arrange(data_fim, turno, instituto, nome_clean)

dicionario_base_2022 <- dicionario_base_2022 %>%
  mutate(pct_na = map_dbl(coluna, ~ round(100 * mean(is.na(base_2022_v7[[.x]])), 1)))

if (salvar_arquivos) {
  saveRDS(base_2022_v7, paste0(prefixo_saida, ".rds"))
  
  # CSV para Excel em português: ";" como separador, "," decimal e
  # UTF-8 com BOM (acentos corretos no Excel)
  salvar_csv_excel <- function(df, arquivo) {
    tmp <- tempfile(fileext = ".csv")
    write.table(df, tmp, sep = ";", dec = ",", row.names = FALSE,
                na = "", qmethod = "double", fileEncoding = "UTF-8")
    conteudo <- readBin(tmp, "raw", file.info(tmp)$size)
    writeBin(c(as.raw(c(0xEF, 0xBB, 0xBF)), conteudo), arquivo)
    unlink(tmp)
  }
  salvar_csv_excel(base_2022_v7, paste0(prefixo_saida, ".csv"))
  salvar_csv_excel(dicionario_base_2022, paste0(prefixo_saida, "_dicionario.csv"))
  
  if (requireNamespace("writexl", quietly = TRUE)) {
    writexl::write_xlsx(list(base = base_2022_v7, dicionario = dicionario_base_2022),
                        paste0(prefixo_saida, ".xlsx"))
  } else {
    message("Pacote writexl não instalado: .xlsx não gerado.")
  }
}

# ---- Conferências ---------------------------------------------

cat("\nBase 2022 (formato V7):", nrow(base_2022_v7), "linhas x", ncol(base_2022_v7), "colunas\n")
count(base_2022_v7, turno)
base_2022_v7 %>% distinct(id_pesquisa, turno, .keep_all = TRUE) %>% count(tse_metodologia_fonte, modelo_coleta_final)
dicionario_base_2022 %>% filter(pct_na > 0) %>% arrange(desc(pct_na)) %>% print(n = Inf)

# ============================================================
# FIM
# ============================================================