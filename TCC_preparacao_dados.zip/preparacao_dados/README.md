# Preparação dos dados eleitorais

Esta pasta guarda os scripts que geram os arquivos de `data/raw/eleitoral/` usados pelo `run_all.R`: as probabilidades diárias da Betfair (2018 e 2022) e da Polymarket (2026) e a probabilidade diária das pesquisas eleitorais (o agregador).

**Para reproduzir as tabelas do texto, você não precisa rodar nada daqui**, porque os arquivos resultantes já estão em `data/raw/eleitoral/`. Esta pasta serve para mostrar de onde eles vêm e para quem quiser refazê-los do zero.

O agregador de pesquisas segue o método do orientador, Prof. Dr. Fernando Augusto Boeira Sabino da Silva (material metodológico não publicado). As bases de pesquisas e o estimador partem dos códigos cedidos por ele.

---

## Como rodar

Abra o RStudio com **esta pasta** como diretório de trabalho (*Session > Set Working Directory > To Source File Location*). Todos os scripts leem e gravam em uma subpasta `pasta_dados/`, que você cria aqui dentro.

### Arquivos de entrada (colocar em `pasta_dados/`)

| Arquivo | De onde vem |
|---|---|
| `1.143383495` (Betfair 2018, mercado "Next President") | Betfair Historical Data, nível PRO. **Não está no repositório** (ver abaixo). |
| `1.180434883` (Betfair 2022, mercado "President after 2022 Election") | Betfair Historical Data, nível PRO. **Não está no repositório.** |
| `pesquisa_eleitoral_2018_BR.csv`, `pesquisa_eleitoral_2022_BR.csv`, `pesquisa_eleitoral_2026_BRASIL.csv` | Portal de Dados Abertos do TSE, conjunto "Pesquisas eleitorais" de cada ano. |

As pesquisas em si (instituto, datas, amostra e percentuais) estão digitadas dentro dos scripts `01`, `02` e `03`.

### Ordem

| Passo | Script | O que gera em `pasta_dados/` |
|---|---|---|
| 1 | `betfair_2018_extracao.R` | `betfair_2018_diario.csv`, `betfair_2018_runners.csv`, `betfair_2018_eventos.rds` |
| 2 | `betfair_2022_extracao.R` | `betfair_2022_diario.csv`, `betfair_2022_runners.csv`, `betfair_2022_eventos.rds` |
| 3 | `betfair_fechamento_b3.R` | `betfair_2018_diario_fechamento_b3.csv`, `betfair_2022_diario_fechamento_b3.csv` (probabilidade no horário de fechamento da B3) |
| 4 | `polymarket_2026_coleta.ipynb` | `polymarket_mercados.csv`, `polymarket_serie_horaria.csv` (APIs públicas da Polymarket; foi rodado no Google Colab, então salve os CSVs em `pasta_dados/`) |
| 5 | `polymarket_2026_extracao.R` | `mercado_2026_diario.csv` |
| 6 | `08_mercados_vs_pesquisas.R` | `saida_mercados/painel_diario.csv`, a probabilidade diária das pesquisas (equações 1 a 3 do texto). Ele roda sozinho o `04_estimador_linear_2018_2022_2026_geral.R`, que por sua vez lê as bases `01_base_2018.R`, `02_base_2022.R` e `03_base_2026.R`. |

Depois, copie para `data/raw/eleitoral/` do projeto principal:

`betfair_2018_diario.csv`, `betfair_2018_diario_fechamento_b3.csv`, `betfair_2022_diario.csv`, `betfair_2022_diario_fechamento_b3.csv`, `mercado_2026_diario.csv`, `polymarket_serie_horaria.csv`, `polymarket_mercados.csv` e `saida_mercados/painel_diario.csv`.

### Scripts de apoio (não geram dados usados no texto)

| Script | Para que serve |
|---|---|
| `05_analises_exploratorias_2018.R`, `05_analises_exploratorias_2022.R`, `05_analises_exploratorias_2026.R` | Sensibilidade da escolha da largura de banda à data de início da validação e à janela de treino. Foram usados para fixar as datas de início da validação no `04`. Rode depois do `04`, no mesmo ambiente, com o `ANO_ANALISE` correspondente. |
| `07_auditoria_dados.R` | Auditoria das bases de pesquisas: pesquisas por ano e turno, pesquisas distintas, pareamento com o TSE e imputações (subseção 3.1 e Apêndice B). Salva em `saida_auditoria/`. |

---

## Por que os arquivos brutos da Betfair não estão aqui

Os arquivos `1.143383495` e `1.180434883` são dados históricos de nível PRO da Betfair, cedidos ao autor. Eles não foram redistribuídos. Quem quiser refazer a extração a partir do bruto pode obtê-los no serviço Betfair Historical Data (https://historicdata.betfair.com), pelos números de mercado acima.
