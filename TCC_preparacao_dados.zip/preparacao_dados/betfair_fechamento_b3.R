# ============================================================
# BETFAIR 2018 e 2022 - PROBABILIDADE NO HORÁRIO DE FECHAMENTO DA B3
# ============================================================
#
# Os scripts betfair_2018_extracao.R e betfair_2022_extracao.R montam o
# painel diário com o ÚLTIMO estado do livro no dia (23h59). Este
# script refaz o painel com o estado do livro no horário de fechamento
# da B3, para a probabilidade ficar no mesmo horário dos preços
# financeiros.
#
# Não relê o arquivo bruto da Betfair: usa a tabela de eventos que os
# scripts de extração já salvam (betfair_20XX_eventos.rds, uma linha
# por atualização de candidato, com horário) e a tabela de candidatos
# (betfair_20XX_runners.csv). Os dois arquivos de 23h59 não mudam.
#
# Regra (a mesma da extração, só muda o horário):
#   - estado do candidato no dia d = última atualização com horário
#     <= fechamento da B3 em d (se não houve atualização no dia, vale a
#     última anterior: o livro não mudou);
#   - probabilidade de referência = meio do spread; se só há um lado,
#     o limite disponível; se o livro está vazio, o último negócio;
#   - normalização: divide pela soma das probabilidades do dia.
#
# Horário de fechamento da B3 (pregão regular de ações, Brasília):
# 17h quando os EUA estão no horário de verão, 18h fora dele.
#
# Conferência: com o corte em 23h59, o script refaz o painel e compara
# com o betfair_20XX_diario.csv original. A diferença máxima deve ser
# zero (ou da ordem de 1e-15).
#
# Saída (na mesma pasta dos arquivos de entrada):
#   betfair_2018_diario_fechamento_b3.csv
#   betfair_2022_diario_fechamento_b3.csv
# Copie os dois para data/raw/eleitoral/ do projeto do mercado
# financeiro. O pipeline passa a usá-los sozinho.
# ============================================================

library(tidyverse)
library(lubridate)

fuso_br <- "America/Sao_Paulo"

# Os arquivos de entrada são os que os scripts de extração salvam em
# pasta_dados (2018 e 2022).
anos <- list(
  `2018` = list(eventos = file.path("pasta_dados", "betfair_2018_eventos.rds"),
                runners = file.path("pasta_dados", "betfair_2018_runners.csv"),
                diario  = file.path("pasta_dados", "betfair_2018_diario.csv")),
  `2022` = list(eventos = file.path("pasta_dados", "betfair_2022_eventos.rds"),
                runners = file.path("pasta_dados", "betfair_2022_runners.csv"),
                diario  = file.path("pasta_dados", "betfair_2022_diario.csv"))
)

# Hora de fechamento da B3 em cada data (17h ou 18h)
hora_fechamento_b3 <- function(datas) {
  meio_dia_ny <- as.POSIXct(paste(as.Date(datas), "12:00:00"), tz = "America/New_York")
  ifelse(dst(meio_dia_ny), 17, 18)
}

# ------------------------------------------------------------
# Painel diário com o estado do livro num horário de corte
# ------------------------------------------------------------
# corte_hora: função que recebe as datas e devolve a hora do corte
# (17/18 para a B3; 24 = fim do dia, para a conferência).

painel_no_corte <- function(eventos, runners, corte_hora) {
  data_fim_mercado <- as_date(with_tz(max(eventos$data_hora_utc), fuso_br))

  grade <- runners %>%
    transmute(runner_id, inicio = as_date(with_tz(entrada_brt, fuso_br))) %>%
    mutate(data_brt = map(inicio, ~ seq(.x, data_fim_mercado, by = "day"))) %>%
    unnest(data_brt) %>%
    select(-inicio) %>%
    mutate(hora_corte = corte_hora(data_brt),
           corte = make_datetime(year(data_brt), month(data_brt), day(data_brt), 0, tz = fuso_br) +
             dhours(corte_hora(data_brt)) - dmilliseconds(1))

  ev <- eventos %>%
    transmute(runner_id, hora_evento = with_tz(data_hora_utc, fuso_br),
              ltp, back, lay, volume_acum) %>%
    arrange(runner_id, hora_evento) %>%
    # várias atualizações no mesmo milissegundo: fica a última (como em last())
    group_by(runner_id, hora_evento) %>% slice_tail(n = 1) %>% ungroup()

  grade %>%
    left_join(ev, by = join_by(runner_id, closest(corte >= hora_evento))) %>%
    mutate(
      prob_ltp  = 1 / ltp,
      prob_back = 1 / back,
      prob_lay  = 1 / lay,
      prob_mid  = (prob_back + prob_lay) / 2,
      spread_prob = prob_back - prob_lay,
      prob_ref = coalesce(prob_mid, prob_back, prob_lay, prob_ltp),
      prob_ref_fonte = case_when(
        !is.na(prob_mid) ~ "mid",
        !is.na(prob_back) ~ "limite_back",
        !is.na(prob_lay) ~ "limite_lay",
        !is.na(prob_ltp) ~ "ultimo_negocio",
        TRUE ~ NA_character_
      )
    ) %>%
    group_by(data_brt) %>%
    mutate(soma_prob_ref = sum(prob_ref, na.rm = TRUE),
           prob_norm = prob_ref / soma_prob_ref) %>%
    ungroup() %>%
    left_join(runners %>% select(runner_id, nome_betfair, nome_clean), by = "runner_id") %>%
    transmute(data_brt, runner_id, nome_betfair, nome_clean,
              hora_corte = sprintf("%02d:00", as.integer(hora_corte)),
              ultima_atualizacao_brt = format(hora_evento, "%Y-%m-%d %H:%M:%S"),
              ltp_corte = ltp, back_corte = back, lay_corte = lay,
              prob_ref, prob_ref_fonte, prob_norm, spread_prob,
              volume_acum_corte = volume_acum, soma_prob_ref) %>%
    arrange(data_brt, desc(prob_norm))
}

# ------------------------------------------------------------
# Roda para cada ano
# ------------------------------------------------------------

for (ano in names(anos)) {
  a <- anos[[ano]]
  if (!file.exists(a$eventos) || !file.exists(a$runners)) {
    message(ano, ": não encontrei ", a$eventos, " ou ", a$runners,
            ". Rode antes o betfair_", ano, "_extracao.R (ele salva esses arquivos).")
    next
  }
  message("Betfair ", ano, "...")
  eventos <- readRDS(a$eventos)
  runners <- read_csv(a$runners, show_col_types = FALSE) %>%
    mutate(entrada_brt = with_tz(as_datetime(entrada_utc, tz = "UTC"), fuso_br))

  # Conferência: com o corte no fim do dia, tem de reproduzir o original
  if (file.exists(a$diario)) {
    fim_dia <- painel_no_corte(eventos, runners, function(d) rep(24, length(d)))
    original <- read_csv(a$diario, show_col_types = FALSE) %>%
      select(data_brt, runner_id, prob_norm_original = prob_norm)
    conf <- inner_join(fim_dia, original, by = c("data_brt", "runner_id"))
    message("  Conferência com o arquivo de 23h59: ", nrow(conf), " linhas, diferença máxima = ",
            signif(max(abs(conf$prob_norm - conf$prob_norm_original), na.rm = TRUE), 3))
  }

  b3 <- painel_no_corte(eventos, runners, hora_fechamento_b3)
  saida <- file.path(dirname(a$eventos), paste0("betfair_", ano, "_diario_fechamento_b3.csv"))
  write_csv(b3, saida)
  message("  Salvo: ", normalizePath(saida))

  # Comparação rápida: PT no horário da B3 x 23h59
  pt <- if (ano == "2018") c("lula", "haddad") else "lula"
  if (exists("fim_dia")) {
    comp <- inner_join(
      b3 %>% filter(nome_clean %in% pt) %>% group_by(data_brt) %>% summarise(p_b3 = sum(prob_norm, na.rm = TRUE)),
      fim_dia %>% filter(nome_clean %in% pt) %>% group_by(data_brt) %>% summarise(p_fim = sum(prob_norm, na.rm = TRUE)),
      by = "data_brt")
    message("  P(PT): diferença média absoluta entre o horário da B3 e 23h59 = ",
            round(100 * mean(abs(comp$p_b3 - comp$p_fim)), 2), " p.p.")
    rm(fim_dia)
  }
}
